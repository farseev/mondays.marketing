# Marketing Mondays: the agentic marketing plugin

A free Claude plugin from Marketing Mondays, the invite-only marketing room in Singapore. It packs the workflow shown live on Monday 12 October 2026 ("The 2027 marketing team: smaller, faster, or obsolete?"). Technology partner: SOMIN.

Claude becomes a marketing analyst and producer that works from your own SOMIN data, so every number traces back to real posts and studies.

Page: https://mondays.marketing/plugin/

## What it does

One loop:

1. **Listen**: track your brand and competitors week by week.
2. **Decode**: find out who the content is for, what works and why.
3. **Decide**: spot the whitespace and turn it into a strategy.
4. **Make**: produce briefs, decks and on-brand creatives.
5. **Ship**: put it on a calendar and schedule it.

## The eight main skills

| Skill | What it does | Try asking |
|---|---|---|
| `somin-pulse` | A weekly social performance report with editions, a timeline and SOMIN insight chains. | "Make a Pulse for [brand] in my [workspace] workspace." |
| `competitor-audience-content-analysis` | Keywords, share of voice, audiences, pain points and the content that performs best. | "Using SOMIN, look at [workspace]: highlight keywords and show what competitor content works." |
| `somin-landscape-report` | One clickable landscape page: findings, brands, a recommendation and what to make. | "Build a landscape breakdown for [brand] and its competitors for last month." |
| `competitor-product-market-insights` | A multi-market dashboard of competitors' offers, discounts and product launches. | "Track what competitors launched in each of our markets this year." |
| `somin-insight-engine-dashboard` | Persona, tension, angle and story chains with real evidence. | "Build an Insight Engine dashboard for [brand]'s latest study." |
| `content-diversity-scorer` | Scores how varied a brand's creative is (0 to 100) against its competitors. | "How varied is [brand]'s creative compared with its competitors?" |
| `somin-brand-deck` | A strategy briefing deck: whitespace, trends, insights, calendar and creatives. | "Build a SOMIN briefing deck for [brand] in [market]." |
| `somin-strategy-to-postly` | Strategy to scored creatives in your Figma file, a calendar, Postly scheduling and PDFs. | "Turn our SOMIN strategy into two weeks of posts and schedule them in Postly." |

## Helper skills

The main skills call these for you; you can also use them directly: persona-tension-discovery, whitespace-analysis, trend-analysis, insight-creation, insight-creation-brand, proposition-creation, moment-generation, content-calendar-build, content-brief-from-moment, content-brief-brand, brand-extraction-from-web, scope-elicitation, creative-scoring, figma-creative-production, deck-qa, deck-qa-brand, somin-keyword-explorer-widget and somin-brand-guideline.

## What you need

- **Claude with plugins**: the Claude desktop app (or claude.ai), or Claude Code.
- **A SOMIN account**: sign in or create one at https://cloud.somin.ai/auth/signin. The plugin includes the SOMIN connector (`https://cloud.somin.ai/_mcp`); you connect it once from the plugin's Connectors tab (step 3 below).
- **Optional**: the Figma and Postly connectors, for the Make and Ship steps.

## Install

### In the Claude app (desktop or claude.ai)

Guide: https://mondays.marketing/plugin/#install

1. **Sign in to SOMIN first** at https://cloud.somin.ai, then to claude.ai. Claude links to whichever SOMIN account is signed in when you click Connect.
2. **Upload the plugin.** Go to **Customize > Plugins** (https://claude.ai/customize/plugins), choose **Add > Upload plugin** and pick `marketing-mondays.plugin`. No separate skill library is needed: the plugin brings all 26 skills.
3. **Connect SOMIN from the plugin's page.** Open the plugin and select its **Connectors** tab. If SOMIN shows **Not added**, click **Add**, then **Connect**; if **Not connected**, click **Connect**. On Team and Enterprise plans, an Owner may need to add the connector first.
4. **Test it.** Ask Claude "Which SOMIN workspaces do you have access to?" A list of workspaces means you are connected. Then ask for one of the examples above, or type `/` to pick a skill.

Fallback, only if step 3 doesn't work: add SOMIN as a custom connector instead (Customize > Connectors > Add custom connector; Name `SOMIN`, Server URL `https://cloud.somin.ai/_mcp`), then click Connect. Use one route, not both.

### In Claude Code

- **Through your Claude account**: install it in the Claude app as above, then start Claude Code signed in to the same account and run `/reload-plugins`.
- **For one session, from the download**: run `claude --plugin-dir ./marketing-mondays.zip` (a `.zip` or an unzipped folder both work).

Then run `/mcp`, select the SOMIN server and sign in. Skills appear as `/marketing-mondays:<skill>`.

## Good to know

- Every example, brand and ID inside the skills is fictional; your reports use only your SOMIN data.
- Some steps mention optional SOMIN add-ons (such as the creative expressions engine). They are not included, and the skills carry on without them.
- Questions or a seat at the next room: ask@mondays.marketing

© 2026 Marketing Mondays · mondays.marketing · Technology partner SOMIN
