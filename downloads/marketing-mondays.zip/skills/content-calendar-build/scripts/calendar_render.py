#!/usr/bin/env python3
"""calendar_render.py — Render calendar.json as Markdown or plain text for human review."""
import sys
import json
import argparse


def render_md(calendar):
    out = []
    out.append(f"# Content Calendar — {calendar['summary']['total_posts']} posts")
    out.append("")
    out.append(f"**Cadence:** {calendar['metadata']['cadence']} posts/week × {calendar['metadata']['weeks']} weeks")
    out.append(f"**Lead day:** {calendar['metadata']['lead_day'].capitalize()}")
    out.append(f"**Pillar split:** {', '.join(f'{k}: {v}' for k,v in calendar['summary']['by_pillar'].items())}")
    out.append("")
    for w in calendar["weeks"]:
        out.append(f"## {w['label']} — {w['pillar']}")
        for post in w["posts"]:
            tag = "⭐ LEAD" if post["slot"] == "lead" else "    "
            anchor = f" 🎯 {post['cultural_anchor']}" if post.get("cultural_anchor") else ""
            trigger = post.get("trigger_label", "(no trigger)")
            mid = post.get("moment_id", "?")
            tid = post.get("trigger_id", "?")
            out.append(f"- {tag} {post['date']} {post['day']}{anchor} — {trigger} (m{mid}/t{tid})")
        out.append("")
    return "\n".join(out)


def render_txt(calendar):
    out = []
    for w in calendar["weeks"]:
        out.append(f"=== {w['label']} ({w['pillar']}) ===")
        for post in w["posts"]:
            marker = "LEAD" if post["slot"] == "lead" else "    "
            out.append(f"  {marker}  {post['date']} {post['day']}  {post.get('trigger_label','-')}  m{post.get('moment_id','?')}/t{post.get('trigger_id','?')}")
    return "\n".join(out)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("calendar_json")
    p.add_argument("--format", choices=["md", "txt"], default="md")
    args = p.parse_args()
    with open(args.calendar_json) as f:
        cal = json.load(f)
    if args.format == "md":
        print(render_md(cal))
    else:
        print(render_txt(cal))


if __name__ == "__main__":
    main()
