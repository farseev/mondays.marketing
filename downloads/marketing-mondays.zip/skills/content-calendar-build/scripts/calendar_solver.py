#!/usr/bin/env python3
"""
calendar_solver.py — Allocate SOMIN moment triggers to a dated publishing matrix.

Inputs:
- --moments moments.json: list of {moment_id, story_id, pillar, items: [{trigger_id, label, type}]}
- --cadence N: posts per week (default 3)
- --weeks N: number of weeks
- --start-date YYYY-MM-DD: first publish date
- --pillar-weights weights.json: {"PILLAR_NAME": float, ...} summing to 1.0
- --cultural-anchors anchors.json (optional): [{"date": "YYYY-MM-DD", "label": "..."}]
- --lead-day [monday..sunday] (default tuesday)

Output: calendar.json to stdout.
"""
import sys
import json
import argparse
import datetime
from collections import defaultdict


DAY_NAMES = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
DAY_ABBR = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]


CADENCE_PATTERNS = {
    1: [1],            # Tue only
    2: [1, 3],         # Tue Thu
    3: [1, 3, 5],      # Tue Thu Sat
    4: [0, 2, 3, 5],   # Mon Wed Thu Sat
    5: [0, 1, 2, 3, 4],  # Mon-Fri
    6: [0, 1, 2, 3, 4, 5],
    7: [0, 1, 2, 3, 4, 5, 6],
}


def generate_slots(start_date, cadence, weeks):
    """Return list of (date, day_abbr) tuples for all publishing slots."""
    pattern = CADENCE_PATTERNS.get(cadence)
    if not pattern:
        raise ValueError(f"Unsupported cadence: {cadence}")
    start = datetime.date.fromisoformat(start_date)
    # Find the first day-of-week ≥ start_date that matches an offset
    slots = []
    monday = start - datetime.timedelta(days=start.weekday())
    for w in range(weeks):
        for dow in pattern:
            d = monday + datetime.timedelta(days=dow, weeks=w)
            if d >= start:
                slots.append((d, DAY_ABBR[dow], dow))
    return slots


def allocate_pillars(slots, pillar_weights):
    """Assign each slot to a pillar in contiguous blocks proportional to weights."""
    total = len(slots)
    # Compute target count per pillar
    counts = {}
    accumulated = 0
    pillar_list = list(pillar_weights.keys())
    for i, p in enumerate(pillar_list):
        if i == len(pillar_list) - 1:
            counts[p] = total - accumulated
        else:
            c = round(total * pillar_weights[p])
            counts[p] = c
            accumulated += c
    # Assign contiguously in pillar_list order
    assignments = []
    idx = 0
    for p in pillar_list:
        for _ in range(counts[p]):
            if idx < total:
                assignments.append(p)
                idx += 1
    return assignments, counts


def collect_triggers(moments_data):
    """Flatten moments into a queue of {trigger_id, label, type, moment_id, story_id, pillar}."""
    triggers = defaultdict(list)  # pillar -> list of triggers
    for m in moments_data:
        pillar = m.get("pillar")
        if not pillar:
            continue
        for item in m.get("items", []):
            triggers[pillar].append({
                "moment_id": m["moment_id"],
                "story_id": m.get("story_id"),
                "trigger_id": item["trigger_id"],
                "trigger_label": item["label"],
                "trigger_type": item.get("type", "unknown"),
            })
    return triggers


def assign_triggers(slots, pillar_assignments, triggers_by_pillar):
    """Pair each slot with a trigger from its pillar. Round-robin if not enough."""
    result = []
    pillar_pointers = {p: 0 for p in triggers_by_pillar}
    for (date, day, dow), pillar in zip(slots, pillar_assignments):
        bucket = triggers_by_pillar.get(pillar, [])
        if not bucket:
            trigger = None
        else:
            trigger = bucket[pillar_pointers[pillar] % len(bucket)]
            pillar_pointers[pillar] += 1
        result.append({
            "date": date.isoformat(),
            "day": day,
            "day_of_week": dow,
            "pillar": pillar,
            "trigger": trigger,
        })
    return result


def apply_lead_day(allocations, lead_day_name):
    """Mark slots that fall on the lead day as 'lead'."""
    lead_dow = DAY_NAMES.index(lead_day_name.lower())
    for a in allocations:
        a["slot"] = "lead" if a["day_of_week"] == lead_dow else "support"
    return allocations


def apply_cultural_anchors(allocations, anchors):
    """If a cultural date falls within a slot, mark the slot and promote to lead."""
    anchor_by_date = {a["date"]: a["label"] for a in anchors}
    for a in allocations:
        if a["date"] in anchor_by_date:
            a["cultural_anchor"] = anchor_by_date[a["date"]]
            a["slot"] = "lead"
        else:
            a["cultural_anchor"] = None
    return allocations


def group_into_weeks(allocations, start_date):
    weeks = []
    current = None
    for a in allocations:
        d = datetime.date.fromisoformat(a["date"])
        iso_year, iso_week, _ = d.isocalendar()
        if not current or current["week_number"] != iso_week:
            monday = d - datetime.timedelta(days=d.weekday())
            sunday = monday + datetime.timedelta(days=6)
            current = {
                "week_number": iso_week,
                "label": f"WK {iso_week} · {monday.strftime('%b %-d')}-{sunday.strftime('%-d')}",
                "pillar": a["pillar"],
                "posts": [],
            }
            weeks.append(current)
        post = {
            "date": a["date"],
            "day": a["day"],
            "slot": a["slot"],
            "pillar": a["pillar"],
            "cultural_anchor": a["cultural_anchor"],
        }
        if a["trigger"]:
            post.update({
                "story_id": a["trigger"]["story_id"],
                "moment_id": a["trigger"]["moment_id"],
                "trigger_id": a["trigger"]["trigger_id"],
                "trigger_label": a["trigger"]["trigger_label"],
                "trigger_type": a["trigger"]["trigger_type"],
            })
        current["posts"].append(post)
    return weeks


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--moments", required=True)
    p.add_argument("--cadence", type=int, default=3)
    p.add_argument("--weeks", type=int, required=True)
    p.add_argument("--start-date", required=True)
    p.add_argument("--pillar-weights", required=True)
    p.add_argument("--cultural-anchors")
    p.add_argument("--lead-day", default="tuesday")
    args = p.parse_args()

    with open(args.moments) as f:
        moments_data = json.load(f)
    with open(args.pillar_weights) as f:
        pillar_weights = json.load(f)
    anchors = []
    if args.cultural_anchors:
        with open(args.cultural_anchors) as f:
            anchors = json.load(f)

    slots = generate_slots(args.start_date, args.cadence, args.weeks)
    pillar_assignments, pillar_counts = allocate_pillars(slots, pillar_weights)
    triggers = collect_triggers(moments_data)
    allocations = assign_triggers(slots, pillar_assignments, triggers)
    allocations = apply_lead_day(allocations, args.lead_day)
    allocations = apply_cultural_anchors(allocations, anchors)
    weeks = group_into_weeks(allocations, args.start_date)

    output = {
        "weeks": weeks,
        "summary": {
            "total_posts": len(allocations),
            "by_pillar": pillar_counts,
            "cultural_anchors_used": sum(1 for a in allocations if a["cultural_anchor"]),
            "lead_posts": sum(1 for a in allocations if a["slot"] == "lead"),
        },
        "metadata": {
            "cadence": args.cadence,
            "weeks": args.weeks,
            "start_date": args.start_date,
            "lead_day": args.lead_day,
            "pillar_weights": pillar_weights,
        },
    }
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
