---
name: content-calendar-build
description: Build a structured content calendar (matrix of dates × posting slots, each slot linked to a specific SOMIN moment trigger) from a set of generated SOMIN Moments. Use whenever the user asks to "build the calendar", "fill the publishing schedule", "map our moments to a posting rhythm", "plan posts for the quarter", "X posts per week for Y weeks", or any request that turns SOMIN timing triggers into a concrete dated publishing plan. Also use when the request is downstream of moment-generation and the next step is "now plan when each goes out". Handles pillar weighting (e.g. 60/25/15 split across three insight stories), publish-day cadence (Mon/Wed/Fri vs Tue/Thu/Sat vs daily), lead-post designation per month, and cultural-moment anchoring (e.g. Singapore National Day, Lunar New Year, Children's Day, school terms). Returns a JSON calendar matrix consumable by somin-brand-deck (and somin-agency-deck, if installed) and content-brief-from-moment.
---

# Content Calendar Build

Turn N SOMIN Moments into a dated publishing matrix. The math is mechanical: given a cadence and weeks, allocate trigger items to date slots with pillar weighting respected.

## When to call

- After moment-generation has produced enough triggers for the target weeks
- The user wants a "calendar", "schedule", "publishing plan", or "posts per week"
- Need to map persona-tension stories to specific dates with pillar weighting

**Don't call** if there are no moments yet — call moment-generation first.

## Workflow

1. **Confirm inputs:**
   - `momentIds` or `momentsListWorkspaceId` — where the SOMIN Moments live
   - `cadenceDaysPerWeek` — typically 3 (Tue/Thu/Sat) or 5 (M-F)
   - `weekCount` — quarter = 13, month = 4
   - `startDate` — first publish date (ISO)
   - `pillarWeights` — e.g. `{"MUSIC": 0.6, "QUIET_WORK": 0.25, "MOTHERS": 0.15}` with stories assigned to each pillar
   - Optional `culturalAnchors` — list of dated cultural moments that should win slot priority (e.g. `[{"date": "2026-08-09", "label": "Singapore National Day"}]`)
   - Optional `leadDay` — which day of week gets the strongest lead posts (default Tuesday)

2. **Fetch the moments** if working from SOMIN IDs:
   ```bash
   # Call SOMIN:moments-list via the MCP tool, save IDs to moments.json
   ```

3. **Run the solver:**
   ```bash
   python scripts/calendar_solver.py \
     --moments moments.json \
     --cadence 3 \
     --weeks 13 \
     --start-date 2026-08-03 \
     --pillar-weights pillar_weights.json \
     --cultural-anchors cultural.json \
     --lead-day tuesday \
     > calendar.json
   ```

4. **Validate the matrix.** Every slot must reference a moment_id. Pillar split should be within ±1 post of target. Lead posts (Tuesdays) get the strongest insight statements.

5. **Generate the human-readable view** if requested:
   ```bash
   python scripts/calendar_render.py calendar.json --format md > calendar.md
   ```

## Output schema

See `references/calendar-schema.md` for the full schema. Short form:
```json
{
  "weeks": [
    {
      "week_number": 31,
      "label": "WK 31 · Aug 3-9",
      "pillar": "MUSIC",
      "posts": [
        {
          "date": "2026-08-04",
          "day": "TUE",
          "slot": "lead",
          "pillar": "MUSIC",
          "story_id": 601,
          "moment_id": 701,
          "trigger_id": 801,
          "trigger_label": "Starting a family · Life",
          "format_hint": "REEL · 45s",
          "cultural_anchor": null
        }
      ]
    }
  ],
  "summary": {
    "total_posts": 39,
    "by_pillar": {"MUSIC": 12, "QUIET_WORK": 12, "MOTHERS": 15},
    "cultural_anchors_used": 2,
    "lead_posts": 13
  }
}
```

## Cadence patterns

See `references/cadence-patterns.md` for the standard cadence patterns:
- **3 posts/week (Tue/Thu/Sat)** — the SOMIN default; good engagement spacing for organic social
- **5 posts/week (Mon-Fri)** — heavy publishing rhythm; needs more moment triggers
- **Daily** — only for high-velocity campaigns

## Pillar weighting

The solver distributes slots proportionally to pillar weights, then rebalances so each pillar gets contiguous weeks rather than alternating posts. Example for 13 weeks × 3/week = 39 posts with 60/25/15:
- MUSIC: 12 posts → weeks 31–34
- QUIET WORK: 12 posts → weeks 35–38
- MOTHERS: 15 posts → weeks 39–43

Contiguous blocks let each pillar's narrative build over a month before handing off. Alternating posts (M, QW, M, QW...) is generally worse for narrative coherence.

## Creative association (creator / influencer engagements)

When the engagement is a **creator / influencer-content analysis** — i.e. the analysed profiles are themselves creators (a personal handle, a person-or-pet persona, a UGC creator), the case where the deck orchestrator defaults to rendered creatives — the creative plan is **three TOFU concepts per pillar** (`perpillar:3`; see `creative-expressions` and the deck orchestrator). Reflect that in the calendar: each pillar's contiguous block has **three rendered concepts to rotate across its slots**, so when mapping triggers to date slots, spread a pillar's three creatives across that block (e.g. one per lead/support/community role, or rotated week to week) rather than leaning on a single concept. For a corporate-brand engagement this does not apply — the creative count is whatever the brand deck's creative step resolved (often text-only), and the calendar is built purely from the moment triggers.

## Common failure modes

- **More slots than moment triggers.** If 3/week × 13 weeks = 39 but only 25 triggers exist, either reduce cadence or call moment-generation for more types.
- **Pillar imbalance.** Solver rebalances within ±1 post but if cultural anchors steal slots from a pillar's block it can drift. Inspect `summary.by_pillar`.
- **Lead-day collision.** If a cultural anchor falls on a non-lead day, decide: promote it to lead, or keep it as supporting post. Default = promote.
- **Stale dates.** If `startDate` is in the past, refuse and ask. Calendars must be forward-looking.

## Token discipline

- `calendar.json` is the artefact. Don't paste it inline into the conversation unless small.
- Pass paths, not contents, to downstream skills.
- The renderer's `--format md` is for human review; downstream skills consume the JSON.
