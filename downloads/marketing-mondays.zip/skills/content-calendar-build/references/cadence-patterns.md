# Cadence Patterns

Standard publishing rhythms for SOMIN content calendars. Pick based on the client's posting velocity (check their workspace's monthly study volume — if their top post is 1/week, don't propose 5/week).

## 1 post per week (Tuesday only)

- For brands with very low velocity or limited content production budget
- Each post must carry significant weight — no "support" posts
- Pillar block = 1 month per pillar
- Cultural anchors get promoted aggressively (every external moment matters more)

## 2 posts per week (Tuesday + Thursday)

- Mid-velocity brands
- Pattern: Tuesday = lead (insight statement), Thursday = supporting (testimonial, behind-scenes, micro)
- Pillar block = 1 month per pillar (8 posts ≈ 4 lead + 4 support)

## 3 posts per week (Tuesday + Thursday + Saturday) ⭐ SOMIN DEFAULT

- Standard for engaged brands with regular production
- Pattern: Tue = lead, Thu = supporting, Sat = community/celebratory
- Pillar block = 1 month per pillar (12 posts)
- Saturday slot pairs well with weekend audience behaviour
- This is what content-calendar-build defaults to

## 5 posts per week (Mon–Fri)

- High-velocity brands (typically with dedicated social team)
- Each pillar gets ~3 weeks of content
- Requires moment-generation to produce 5+ triggers per persona×tension across multiple moment types
- Pattern: Mon = setup, Tue = lead, Wed = depth, Thu = supporting, Fri = community
- Risk: pillar narrative starts to feel rushed; consider 2 lead days per week instead

## 7 posts per week (daily)

- Campaign mode only — not sustainable as steady state
- Best for short bursts (2–3 weeks during launches or seasonal peaks)
- Requires 50+ moment triggers per pillar
- Often combined with paid amplification

## Picking a cadence

```
moment triggers available
÷
(cadence × weeks)
=
> 1.2 → cadence is realistic
0.8–1.2 → tight; consider adding moment types
< 0.8 → reduce cadence OR call moment-generation for more types
```

For Example Academy: 9 moments × 5 triggers = 45 triggers ÷ (3 × 13) = 1.15 — works, but tight.

## Lead-day selection by audience

- **B2C consumer:** Tuesday (Mon-blues recovered, week's energy returning)
- **B2B:** Wednesday (mid-week decision-making peak)
- **Parents / family:** Sunday or Tuesday (Sunday for week-planning content, Tuesday for inside-the-week resonance)
- **Hospitality / leisure:** Thursday (weekend anticipation)
- **Default if unsure:** Tuesday
