# calendar.json — Output Schema

## Top-level

```json
{
  "weeks": [...],
  "summary": {...},
  "metadata": {...}
}
```

## weeks[i]

```json
{
  "week_number": 31,            // ISO week number
  "label": "WK 31 · Aug 3-9",   // Human label, used in deck headers
  "pillar": "MUSIC",            // Dominant pillar of this week
  "posts": [...]                // Array of 1+ posts
}
```

## weeks[i].posts[j]

```json
{
  "date": "2026-08-04",         // ISO date
  "day": "TUE",                 // 3-letter day name
  "slot": "lead",               // "lead" or "support"
  "pillar": "MUSIC",            // Per-post pillar (usually matches week's)
  "story_id": 601,             // SOMIN story this post sits under
  "moment_id": 701,             // SOMIN Moment ID
  "trigger_id": 801,           // SOMIN trigger item ID
  "trigger_label": "Starting a family · Life",
  "trigger_type": "life",       // life / seasonal / micro / emotional / purchase / vulnerable / search
  "cultural_anchor": null       // null OR string like "Singapore National Day"
}
```

## summary

```json
{
  "total_posts": 39,
  "by_pillar": {"MUSIC": 12, "QUIET_WORK": 12, "MOTHERS": 15},
  "cultural_anchors_used": 2,
  "lead_posts": 13
}
```

## metadata

```json
{
  "cadence": 3,
  "weeks": 13,
  "start_date": "2026-08-03",
  "lead_day": "tuesday",
  "pillar_weights": {"MUSIC": 0.31, "QUIET_WORK": 0.31, "MOTHERS": 0.38}
}
```

## Validation rules

- Every post must have either a trigger_id OR an explicit `cultural_anchor` (cultural anchors can be unmatched to triggers — they're standalone events)
- `summary.by_pillar` should equal pillar counts when summed
- Pillar transitions should be week-aligned (no mid-week pillar swaps)
- ISO dates only, no timezones (publishing tools localise on their end)
