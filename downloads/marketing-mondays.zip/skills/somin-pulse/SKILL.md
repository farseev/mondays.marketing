---
name: somin-pulse
description: Build a SOMIN-branded weekly social performance 'Pulse' report (editions, timeline, SOMIN insight chains) for any brand in a SOMIN workspace, using only SOMIN data. Use for 'make a Pulse for X' or /somin-pulse.
---

# SOMIN Pulse

Produces an interactive, self-contained HTML "Pulse" report: weekly editions (overview → findings → analysis pages → next review → scope), a dated timeline, and SOMIN insight chains, styled in the SOMIN brand by default. Every number and interpretation comes **strictly from SOMIN MCP data** — no web search, no outside knowledge, no invented figures.

Renderer template: `assets/pulse_template.html` (bundled with this skill). It holds the page code (CSS + renderer script) and a small fictional sample (Example Brand vs Competitor A/B, placeholder images) inside `<script type="application/json" id="pulse-data">`. Every run copies this file and replaces the sample data completely — no sample post, fact, image or wording may survive into a real report.

## Dependencies

Skills (load when the step says so):
- `somin-brand-guideline` — **required**, default styling (Step 5).
- `artifact-design` — page contract before publishing (Step 6).
- `dataviz` — only if you add or change chart forms beyond the template's bars and tables.
- `artifact-capabilities` — only if the user wants the hosted Download button to work (`downloads` capability).

Tools: SOMIN MCP (`workspaces-list`, `profiles-list`, `posts-search`, `posts-aggregate`, `studies-list`, `studies-get`, `propositions-list`; optional `concepts-search`, `products-list`), `AskUserQuestion`, `Artifact` (publish), `Bash` with Python + Pillow + Playwright, `SendUserFile`.

---

## Step 0 — Ask for parameters FIRST (before pulling posts)

Parameters are collected in two short rounds, because the channel options must come from what actually exists in the chosen workspace. Skip any question the user already answered in their request.

### Round 1 — workspace and subject brand

Call `mcp__SOMIN__workspaces-list` silently, then ask with **AskUserQuestion**:
1. **Workspace & subject brand** — which workspace, and which brand is the subject (owned) brand.

After the answer, call `profiles-list` for that workspace.

### Channel discovery (silent, before Round 2)

For the subject brand plus all other profiles, over the default window (last 8 complete Mon–Sun weeks), call `posts-aggregate` once per PAGES placement, in parallel: `FACEBOOK`, `INSTAGRAM_REELS`, `INSTAGRAM_STORIES`, `TIKTOK`, `LINKEDIN`, `TELEGRAM` (each with `breakdown: PROFILE`). A channel **has content** when count > 0. Keep the counts per channel and per brand for the question text.

### Round 2 — one AskUserQuestion call, 4 questions

2. **Competitors** (multiSelect) — which profiles to compare. Default: every other profile with ≥10 posts in the window.
3. **Time window & cadence** — Options: last 8 weeks (Recommended) / last 4 weeks / last 12 weeks; user may type custom dates. Cadence weekly by default; fortnightly or monthly if asked. Weeks are Mon–Sun in the workspace's local time zone (infer from market, e.g. Asia/Singapore).
4. **Channels to pull** (multiSelect) — build the options from discovery, listing post counts:
   - First option: **"All channels with content (Recommended)"** — description names each channel with its post count, e.g. "Instagram Reels 103 · Facebook 87 · TikTok 44 · LinkedIn 93 · Stories 296 (no counters)".
   - Next options: the three channels with the most posts, individually (users can tick several or type their own list).
   - Never offer a channel with zero posts; say in the description which channels were empty.
5. **Editions written in full** — Options: latest week + 2 retrospectives (Recommended) / latest week only / latest + 4 retrospectives.

### Defaults when not specified

If the user skips a question, or is not present to answer:
- Competitors: all other profiles with ≥10 posts in the window.
- Window: last 8 complete Mon–Sun weeks, weekly cadence.
- **Channels: all channels with content** in the window for the selected brands (count > 0). Channels with no content are skipped and named as skipped in the report scope.
- Editions: latest + 2 retrospectives.
- Styling: SOMIN brand.

State the chosen parameters in one line at the top of your work (brands, window, cadence, channels with counts, editions). If the chosen window differs from the discovery window, re-run discovery for that window and drop channels that turn out empty, telling the user.

---

## Step 1 — Collect SOMIN data (only these sources)

| Need | Tool |
|---|---|
| All posts in window | `posts-search` (source PAGES, `platforms` = the chosen channel codes, `profileIds` = subject + competitors, startDate = window start − 1 day UTC buffer, endDate = window end + 1 day, sortDir ASC, pageSize 50; page until a page returns < 50). Results overflow to files — parse them with Python, never page them through the conversation. |
| Count cross-check | `posts-aggregate` with the same filters and breakdown PROFILE (likes + comments sums); parsed counts must match |
| Interpretation | `studies-list` → pick the study whose dates and profiles best match → `studies-get` with persona, pain_points, relevance, topics |
| Insight → product → concept | `propositions-list` |

Rules:
- Map posts to workspace profiles by `post.profile.id`. Channel ids not in profiles-list (rider channels, parent-company LinkedIn) go to the profile SOMIN's aggregate breakdown assigns them to; check counts.
- Channel of a post = `rawData.placement[0]` (fallback `sourceType`).
- Convert `postDate` (UTC) to local time before bucketing weeks; out-of-window buffer posts go to `excluded`.
- **Response = likesCount + commentsCount** where both exist. Stories/Telegram without counters are "unmeasured", never zero.
- `videoViewsCount` = "reported plays" for per-100-plays comparisons.
- Images: `creatives[].images[].url` (cdn.cloud.somin.ai is reachable) → download, resize ≤1100px, JPEG q≈74, embed base64.

## Step 2 — Compute facts (Python, never by hand)

`data.facts` keyed by id. Aggregate facts hold `posts, complete_posts, partial_posts, unmeasured_posts, observed_response, complete_response, median_response, top_share, top2_share, top5_share, top_post_ids, bottom_post_ids, member_post_ids, complete_post_ids, label`.

Required ids (only for the chosen channels):
- `fact:corpus:all`, `fact:corpus:profile:<pid>`
- `fact:edition:<weekStart>:profile:<pid>` and `…:platform:<instagram_reels|tiktok|facebook|linkedin|instagram_stories|telegram>`
- `fact:post:<postId>` → `{response, values, response_complete, reported_plays, responses_per_100_plays, member_post_ids}`
- `fact:assessment:8wk:<pid>:<platform>` (whole window)
- `fact:assessment:<slug>` for every custom grouping a section cites (campaign posts, "excluding the outlier", plays comparisons).

`data.posts`: id, profile_id, profile_name, role, platform, format, published_at, publication_date, observed_at, source_updated_at (lastScrappedAt), identifiers {id, externalId, rawData.code}, caption, values, response, response_complete, links. `data.scope` records the chosen channels, their post counts, and any channels skipped as empty.

All prose numbers are generated from facts with f-strings (helpers `n(postId)`, `fv(factId,key)`, `pct()`), so text and charts never disagree.

## Step 3 — Analyse, then write the story

Find in the data: (a) the latest week's leaders per chosen channel, (b) concentration — one post supplying a large share of a channel, (c) the campaign/theme the SOMIN study explains, (d) competitor typical result vs peaks (median, top-two share) on the chosen channel the brands share most. Read captions and `feature.humanInsight / socialProblem / brandProposition / videoDescription` for every cited post. Never claim reach, paid support or sentiment unless returned. If only one channel was chosen, the channel-comparison section compares executions or weeks within that channel instead.

`story` (`pulse-story-v2`): `title, subtitle, purpose{subject, question, audience, market, basis, comparison}, current_report, reports[], timeline[], timeline_title, timeline_intro, sharing{title, description, access:'private'}, cadence`.

Report: `id, title, subject, report_type (retrospectives), created_at, captured_at, period_start, period_end, scope, verdict, summary, cover_asset, cover_layout ('split' for retrospectives), lead_example, winners[] (current only, one per chosen channel with measured posts, max 3), metrics[], chart, sections[], decisions[], review_intro, qualification, fact_ids`.

Section layouts (current edition all four; retrospectives 3–4):
1. `channel-comparison` — current performance; table of one execution across the chosen channels.
2. `concentration` — lead example + a `percent` metric first; chart = lead + others; table of plays and per-100-plays.
3. `meaning-chain` — `chain[]`, 2–3 examples, full table, `somin_path` (SOMIN chain: study → branches [persona/relevance, pain point] → insight → product → application/concept → `connection`), optional `related_somin_path`.
4. `peer-comparison` — competitor median / top-two share table + chart, one example per competitor.

Every section: `id, nav_title, layout, kicker, title, body, analysis_title, analysis_intro, chart, examples, assessment, qualification, fact_ids/post_ids/research_ids`. Metric refs: `{fact_id, key, label, format: number|percent|decimal}`.

`semantics.research_nodes`: one per study theme, insight, product and concept used — `id 'research:<kind>:<id>'`, `kind`, `chain_id`, `passages[{field,text}]` copied verbatim from SOMIN, `parents`, `url` (`https://cloud.somin.ai/app/a/<ws>/studies/<id>` or `https://cloud.somin.ai/app/inspire/propositions/<id>`). `semantics.posts` carries each post's SOMIN features.

Timeline: 8–14 dated events (`kind` moment | comparison | research) with post_ids, metrics, `why_included`, and `section_id` or `report_id`.

Writing: plain, specific, a number in every claim. Qualifications state refresh-age differences, missing counters, skipped channels, no reach/paid/comments.

## Step 4 — Assemble the HTML

1. Copy `assets/pulse_template.html` (in this skill's folder) to the run directory. Open it with Python, not by reading it into the conversation.
2. Replace the contents of `<script type="application/json" id="pulse-data">` with `{data, story, brand, semantics}` (escape `</` as `<\/`).
3. Remove any `<script id="pulse-portable">` block.
4. `brand`: `name, report_name:'Pulse', palette{ink:'#16201F', paper:'#FFFFFF', accent:'#2DBF9C', muted:'#6B7A78'}, typography{display/body:'Montserrat', headline_weight:800}, hero_asset, assets{post-<id>-0:{src, alt, credit:'<Brand> · source post imagery via SOMIN', post_id, source_url}}, post_media{postId:assetId}`.
5. Update `<title>` and og/twitter titles and descriptions; drop canonical/og:url/og:image.

## Step 5 — Apply SOMIN brand (default) — load `somin-brand-guideline`

- Remap neutral grey hexes in `<style>` to teal-tinted greys by luminance: <0x1a→#16201F, <0x24→#1F2A29, <0x40→#2A3635, <0x90→#6B7A78, <0xb8→#9BA8A6, <0xe0→#C9D1D0, else #F2FAF8; white stays.
- Replace every red (`--red`, `#df7272`, `#ba5959`, `#dc5353`, any r≫g,b) with `#2DBF9C`.
- Montserrat via Google Fonts; body and headings Montserrat, headings 800, letter-spacing −0.02em; eyebrow labels teal uppercase 0.18em; bars teal.
- Wordmark `<span class="somin-mark"><span class="s-o">SO</span><span class="min">MIN</span></span>` top-left in the header lockup (SO #2DBF9C, MIN #FFFFFF on dark), no space, normal tracking; same two-tone SVG in the rail signature.
- The template already labels everything SOMIN; keep it that way (no legacy platform names in labels, classes or copy).
- Brands voice (sentence case). Client post imagery keeps the client's look.

## Step 6 — Verify, then publish

- Script check: every `fact_id`, `key`, `post_id`, `research_id` in the story resolves; fail the build otherwise.
- Check that every channel named in the story is one of the chosen channels.
- Playwright (Chromium at `/opt/pw-browsers`): click every scene dot, the timeline and each edition; zero page errors; screenshot 1440×900 and 390×844 and look at them.
- Spot-check 3 prose numbers against raw posts.
- Load `artifact-design`, publish with `Artifact` (icon `chart`), and send the HTML file. Tell the user the page is private until shared, and that the hosted Download button needs the `downloads` capability (via `artifact-capabilities`) if they want it.

Finish with the latest edition's verdict, 2–3 key findings with numbers, the channels covered (and any skipped), and the data limitations.
