---
name: figma-creative-production
description: "Rebuild rendered creative concepts as real frames inside a client's own Figma file — real component instances, real type styles, licensed photography — instead of shipping model-generated images. Gated: only runs when the user says yes and supplies the Figma link."
---

# Figma Creative Production

Turn creative concepts into **real frames in the client's own Figma file**. Rendered expressions are model-generated images: fast, brand-locked, fine to review — but the people, instruments and rooms in them are synthetic and none of it comes from the client's components. This skill produces the other thing: artwork assembled from the design system the client actually ships with.

**It never runs on its own.** It costs a write into someone else's Figma file and needs a link only they can give. It runs when a user says yes to the question, or calls it by name.

---

## Inputs

- **`figmaUrl`** — a `figma.com/design/<fileKey>/...` link to the file holding the client's social/ad component set. **Ask for it; never guess it, never reuse one from another engagement.** If the user pastes a frame-level link, keep the whole URL — the node id is a useful entry point.
- **`concepts`** — the concept set: per key, `{key, pillar, stage, hook, tagline, cta, proposition_id}`. Keys are the render keys (e.g. `P2-B-05`), so a frame can be traced back to its concept and its study.
- **`aspect`** — target ratio (`9:16` story/reel, `4:5` feed, `1:1` square). Default to the ratio the campaign's ad sets actually use.
- **`brandTokens`** — resolved palette/type, used only to *verify* what the file gives you, never to override it.

A Figma MCP server must be connected (`mcp__Figma__use_figma` and friends — load with `tool_search` before concluding it is absent). Without it, stop and say so; do not draw look-alike frames by hand.

---

## Step 1 — Read the real design system before drawing anything

Open the file and inventory it. **Record the real node IDs as you go** — they are how every later call addresses a component.

What to find and write into `design_system.json`:

- **Component sets and their variants** — the text blocks (headline, description, call-to-action), tags/labels, location/date blocks, and the **logo component set with its variants** (e.g. a blue variant and a white variant). Note each one's real id and its declared size, e.g. `headline 2:1305 · 78px`.
- **Frame/background components** — the image containers and their native dimensions (e.g. `BackgroundImage 1080×1350`).
- **Text styles and colour styles** — the actual named styles. Every text layer you set must take one of these; never hand-set a size or hex that is not in the system.
- **Photography assets** — every licensed image already in the file, with its **real pixel dimensions** and a one-line description of its subject (a surgeon at a monitor, an instrument tray, a gloved hand on a telescope…). This inventory is what makes subject matching possible in Step 2. **Note any asset that carries a UI overlay, watermark or on-image menu** and where it sits — you will need to crop past it.

Read the file's own conventions too: does a template **allow text over imagery**, or does it stack copy in a solid panel below? Check before you decide — assuming "no overlap" when the template supports overlap produces flat, timid artwork, and the client will notice.

## Step 2 — Plan every frame before you create one

Write `build_plan.json` — one row per concept, with everything resolved: `{key, pillar, stage, template, imageAsset, imageTransform, headline, description, cta, logoVariant, tag, location}`.

**Match imagery by subject, not by slot order.**

- A concept whose expression shows **a person** gets one of the file's **licensed human photographs**. A concept about **instruments or equipment** gets an instrument photograph. Abstract or protocol concepts get the closest real asset, not a person.
- **Repetition is fine, and so is re-cropping.** A dozen frames can share one photograph if each is cropped differently — a wide establishing crop, a tight crop on the hands, an off-centre crop that leaves room for the headline. Variety comes from the crop and the copy, not from inventing new imagery.
- **Never substitute a synthetic person for a real one.** The entire point of this pass is that the humans and the equipment are the client's own licensed assets. If no suitable asset exists for a concept, say so and leave that concept on its rendered expression rather than faking it.

**Copy binding.** `headline` ← the concept's hook. `description` ← its tagline. `cta` ← its CTA, and only for BOFU-stage concepts that have one. Respect the client's real CTA vocabulary — the phrases their own paid and organic content uses — not invented ones.

## Step 3 — Compute aspect-correct crop transforms

A Figma image fill in `CROP` mode takes a matrix `[[a, 0, tx], [0, d, ty]]`, in normalised source coordinates. Getting this wrong is the most common way this pass produces stretched or badly-cut artwork.

For a source of aspect `sAR = sw/sh` into a frame of aspect `fAR = fw/fh`:

- **Source wider than the frame** (`sAR > fAR`) — take a full-height slice: `a = fAR / sAR`, `d = 1`, `ty = 0`, and `tx` chooses *which* vertical slice, in `[0, 1 − a]`.
- **Source taller than the frame** (`sAR < fAR`) — take a full-width slice: `a = 1`, `d = sAR / fAR`, `tx = 0`, and `ty` chooses the horizontal band, in `[0, 1 − d]`.

Then use `tx`/`ty` deliberately: vary them across frames that share an asset so the set does not read as one photo repeated, and **move them past any UI overlay, watermark or on-image menu** you catalogued in Step 1. A crop that leaves a stray interface element in the corner is a defect, not a texture.

## Step 4 — Build the frames

Create a dedicated page (name it for the engagement, e.g. `Example Brand 2026 — Creative Library`) and build every frame on it with `use_figma`. **Load the `/figma-use` skill before your first `use_figma` call** — it is mandatory and it carries the current API surface.

Per frame:

1. Instantiate the **real components** — background/image container, headline, description, CTA, tag, location, logo. Instances, not rectangles you drew. The logo is **always** a component instance; never re-typed text and never a re-drawn mark.
2. Pick the **logo variant that survives its background** — the white variant over dark or busy photography, the colour variant over light ground. Check the actual crop behind it, not the asset's average.
3. Set the image fill with the `imageTransform` from Step 3.
4. Set text on the real text layers, taking the file's own text styles. Keep the copy inside the client's real density conventions — a headline that overflows its block is a defect even when the words are right.
5. **Keep the node id returned at creation.** You will need it to export.

**Work in batches and checkpoint.** A hundred-plus frames is many calls; build in groups, keep `build_plan.json` updated with what exists, and make the pass resumable.

## Step 5 — Export by explicit node id

**`get_metadata` cannot see a page created in the same session.** Do not try to discover your own frames by walking the file — the call comes back blind, and it looks like the frames were never made. Export each frame with `get_screenshot`/`download_assets` against **the node id you kept at creation time**.

Save as `<key>.png` in the render key's dash form (`P2-B-05.png`) so the frames line up with the concepts, the expressions, and the scoring map.

## Step 6 — Verify before handing on

Look at a real sample of the exported frames — not the plan, the pixels. Check:

- the **wordmark is intact and un-cropped**, in the right variant for its background;
- **no text overflows** its block and nothing is clipped at a frame edge;
- **no stray UI overlay, watermark or interface element** survived a crop;
- imagery **matches its concept's subject** (people where the concept is about people, instruments where it is about instruments);
- frames sharing one photograph are **cropped differently enough** to read as distinct;
- every colour and type size traces to a **style in the file**, not to something you typed.

Any failure is fixed in the plan and the frame is rebuilt — never patched by hand-editing an exported PNG.

## Step 7 — Hand off

1. **Scoring.** Pass the exported frames to `creative-scoring`. When this skill ran, **the Figma frames are what gets scored** — they are what would actually ship. A creative qualifies only when **both** halves hold: predicted class `ABOVE_AVERAGE` **and** confidence `≥ 0.80`. Never rank on the probability alone or the class alone.
2. **Activation.** Creatives that cleared the gate are eligible for `meta-campaign-refresh` (separate SOMIN skill, if installed), which pushes them into the live Meta campaign — mirroring the winning ad's body, headline and CTA, each into the ad set whose aspect ratio matches, so a 9:16 frame needs no re-cropping. That handoff is itself offered, never automatic; nothing that spends money moves without an explicit go. If nothing cleared the gate, push nothing and say so.
3. **Record** `figma_file_key`, `figma_page`, `figma_frames`, and the key → node-id map, so a later session can update the same frames instead of building a second set.

---

## What this skill does not do

- It does not invent components, type styles or colours. If the file lacks a piece, report the gap — do not approximate it.
- It does not generate imagery. Every pixel of photography comes from the client's file.
- It does not replace the rendered expressions. Both sets survive; the client chooses.
- It does not push anything live. That is `meta-campaign-refresh` (separate SOMIN skill, if installed), and it asks first.