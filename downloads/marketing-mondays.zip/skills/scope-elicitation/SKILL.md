---
name: scope-elicitation
description: The Step-0 gate for SOMIN deck orchestrators (somin-brand-deck; also somin-agency-deck if installed). Extracts scope from the user's prompt and asks ONLY the questions the prompt cannot answer, producing a scope.json that drives every downstream step. Default posture is full analysis on, expensive per-post outputs off, no IDs asked (names only). Use whenever about to invoke somin-brand-deck (or somin-agency-deck, if installed) — before any SOMIN call, before brand extraction, before anything. Returns a structured scope.json that the orchestrator and the deck-QA skills both read.
---

# Scope Elicitation — The Step-0 Gate

A deck orchestrator without an explicit scope decision is an orchestrator that makes scope decisions silently. This skill replaces silent inference with an explicit, declared scope captured up front and carried as data through to the QA gate.

It is small by design — most of its work is **not** asking. The agent reads the original prompt, applies the defaults table, and asks only the dimensions the prompt cannot answer. The unanswered defaults run rich (analysis on), the expensive outputs default off, and every choice is recorded in `scope.json` so QA can verify the deck against what was agreed — not against a guess.

## When to use

- At Step 0 of `somin-brand-deck` (or `somin-agency-deck`, if installed) — always, before any SOMIN call
- When the user asks for "a SOMIN deck", "the briefing", "the pitch", "the strategy", and the agent is about to chain the analysis layers
- When adapting a prior engagement to a new market or quarter — re-run elicitation; do not inherit the prior scope silently

## When NOT to use

- A user asks for a single analysis layer ("just the whitespace") — call that skill directly, no orchestration scope needed
- The agent already has a `scope.json` from this engagement on disk — read it, don't re-elicit. Re-elicit only when the user explicitly asks to change scope.

## Core principle

**Default to full analysis. Default to no per-post outputs. Ask only what the prompt cannot answer. Never ask for IDs — always names.**

The agent's job is to maximise the information it extracts from the prompt before asking anything. If the prompt names markets, the agent does not ask for markets. If the prompt names a creator panel, the agent does not ask for a creator panel. If the prompt is silent on wireframes, the agent does not generate wireframes (and does not ask — the silence is the answer).

## The defaults table

This is the source of truth. Every downstream step reads `scope.json`; every field below has a default that is applied when the prompt is silent.

| Dimension | Default | Ask only if |
|---|---|---|
| `markets` | Infer from the prompt (workspace names, brand profiles, country mentions in the request) | The prompt names a brand or workspace but markets are ambiguous (e.g. "build a deck for Example Auto" with no country) — propose all detected brand workspaces by NAME and let the user multi-select |
| `time_window_days` | 365 (12 months) | The prompt names a time anchor that is ambiguous — "this year" (Jan→now, or trailing year?), "Q3" (which year?) — ask with concrete date options |
| `run_trends` | `true` | Never asked — analysis runs by default |
| `prior_year_verification` | `true` | Never asked — directional claims must be verified |
| `run_whitespace` | `true` | Never asked |
| `run_insight_chains` | `true`, with `pillar_count: 3` | Never asked unless prompt says "one pillar", "two pillars", or similar |
| `run_propositions` | `true` | Never asked — core analysis output |
| `influencer_panel` | `null` (no influencer panel) | Ask only if (a) the prompt does not name a panel AND (b) the agent detects candidate creator/influencer workspaces in the user's account (workspace names containing "Influencers", "Creators", "Panel", "Talent" — see Detection rules below). Propose by NAME, allow `none`, allow multi-select for multi-market |
| `topicality` | `true` if `influencer_panel != null` else `false` | Never asked separately — tied to the influencer-panel answer |
| `run_moments` | `true` | Never asked |
| `moment_types` | `"derive_from_analysis"` (chosen post-analysis from tension shape) | Never asked at Step 0 — type-selection is computed after Step 7 (whitespace) using the rules in *Moment-type derivation* below |
| `run_calendar` | `true` if `run_moments` else `false` | Calendar dates: infer publish window from prompt; ask only if a calendar is wanted but the publish window is not derivable |
| `cadence_per_week` | 3 | Ask only if prompt says "the calendar" but no cadence is mentioned AND the publish window is short enough that 3/week feels wrong |
| `run_wireframes` | `false` | Ask only if the prompt explicitly mentions "wireframes", "ready-to-publish briefs", "per-post briefs", "the briefs", etc. — flip default to `true` and confirm |
| `deck_variant` | Inferred from which meta-skill called this one (`brand` or `agency`) | Never asked here — the meta-skill identifies itself |

## Workflow

### Step 1 — Extract from the prompt

Read the original prompt and pull every dimension you can:

- **Markets** — look for country names, country codes (UK/JP/US/IN/MX/ZA), region words, workspace names ("Example Auto UK", "Example Auto Japan"), brand-profile mentions
- **Time anchor** — "Q3 2026", "last 6 months", "trailing year", explicit ISO dates
- **Influencer / creator panel** — phrases like "Auto Creators", "Foodie Creators", "the panel", "matched creator workspaces"
- **Publish window** — "next quarter", "Aug→Oct 2026", "the next 12 weeks"
- **Specific layer omissions** — "no calendar", "skip the trends", "snapshot only", "just the whitespace and insights"
- **Specific layer additions** — "include wireframes", "give me the briefs", "ready-to-publish posts"
- **Pillar count** — "two pillars per market", "five pillars", default to 3

Apply each extracted value to `scope.json` and mark the source as `from_prompt`.

### Step 2 — Detect candidate influencer panels (only if not extracted in Step 1)

If the prompt did not name a creator panel, scan workspaces available to the agent (via `SOMIN:workspaces-list` when MCP is available, or via the engagement registry passed by the orchestrator). A workspace is a *candidate creator panel* if its name contains any of: `Influencers`, `Creators`, `Panel`, `Talent`, `Creator Cohort`, `Audience Proxy`. List the matches by **name**, never by ID.

If candidates exist and the user did not preempt the question, ask exactly one question (see Step 4 prompt format).

If no candidates exist, the default (`influencer_panel: null`) applies silently — do not ask.

### Step 3 — Apply defaults to every unfilled field

Walk the defaults table. For each field still empty, fill it with its default and mark the source as `default`.

### Step 4 — Ask only the ambiguities

If anything remains unresolved, batch the questions into one `ask_user_input_v0` call. Phrase by NAME, never by ID. Keep to three questions maximum — three is a ceiling, not a target. Typical batches:

**Ambiguity batch — example shapes:**

- Markets ambiguous → "Which markets is this engagement for?" — multi-select from detected workspace names
- Influencer panel candidates exist + not named → "I see candidate creator panels in your workspaces — include one for topicality and emerging-trend signal?" — single-select: `none` (default) / each detected panel by name / `all matching panels` for a multi-market engagement
- Wireframes mentioned but ambiguous → "Generate per-post wireframes for the full calendar? (expensive — adds 30–60 minutes)" — single-select: `no` (default) / `yes`
- Time anchor ambiguous → "Analysis window?" — single-select: concrete date ranges

If nothing is ambiguous, **do not ask**. Skip to Step 5.

### Step 5 — Write `scope.json`

Write the resolved scope to `<engagement_dir>/scope.json`. Schema:

```json
{
  "deck_variant": "brand" | "agency",
  "markets": [
    {"name": "UK", "workspace_id": 1239, "brand_profile_id": 1112, "competitor_profile_ids": [...]}
  ],
  "time_window": {
    "start_date": "2025-05-29",
    "end_date": "2026-05-29",
    "days": 365,
    "source": "default" | "from_prompt" | "user_chose"
  },
  "analysis": {
    "run_trends": true,
    "prior_year_verification": true,
    "run_whitespace": true,
    "run_insight_chains": true,
    "pillar_count": 3,
    "run_propositions": true
  },
  "influencer_panel": null | {
    "name": "Auto Creators UK",
    "workspace_id": 1240,
    "profile_ids": [...],
    "source": "from_prompt" | "user_chose"
  },
  "topicality": true | false,
  "moments": {
    "run": true,
    "types": "derive_from_analysis" | ["life", "seasonal", "emotional"]
  },
  "calendar": {
    "run": true,
    "publish_start_date": "2026-08-03",
    "publish_end_date": "2026-10-26",
    "publish_weeks": 13,
    "_publish_weeks_note": "derived: ceil((publish_end_date - publish_start_date) / 7); always computed, never asked",
    "cadence_per_week": 3
  },
  "wireframes": {
    "run": false
  },
  "ask_decisions": [
    {"dimension": "influencer_panel", "asked": true, "user_chose": "Auto Creators UK"},
    ...
  ]
}
```

The `ask_decisions` array records which dimensions were asked vs defaulted vs extracted — this is what the deck's audit-trail slide displays so reviewers can see what was agreed.

### Step 6 — Return control to the orchestrator

The orchestrator reads `scope.json` and gates every subsequent step on it. The elicitation is done — no further questions from this skill in this engagement.

## Moment-type derivation

Run AFTER Step 7 (whitespace) of the orchestrator, before Step 10 (moments). For each (persona, tension) pair selected as a pillar, the derivation picks 2–3 moment types from the seven available (`life`, `seasonal`, `purchase`, `micro`, `search`, `emotional`, `vulnerable`) by matching tension shape to type. The rules:

| Tension shape (signals in the tension title + theme corpus) | Derived moment types |
|---|---|
| **Lifecycle / identity** — words like "becoming", "transition", "stage", "milestone", persona age/role markers | `life`, `emotional` |
| **Calendar-cyclic** — trend windows show monthly/quarterly cyclicality; tension title mentions seasons, festivals, weather | `seasonal`, `emotional` (drop `seasonal` if the cyclicality is weekly, not annual) |
| **Decision / purchase** — words like "choosing", "comparing", "deciding", "researching", "considering"; tension corpus contains product/model comparisons | `purchase`, `search` |
| **Search-intent / discovery** — tension corpus reads as questions, how-tos, "I want to know / go / do / buy" | `micro`, `search` |
| **Emotional / identity** — words like "feeling", "anxiety", "confidence", "pride", "belonging" | `emotional`, `life` |
| **Vulnerability / care** — words like "doubt", "isolation", "transition", "loss", "exclusion" | `vulnerable`, `emotional` — flag for brand-voice review before including `vulnerable` |
| **Default fallback** when no shape matches strongly | `life`, `emotional`, `seasonal` |

A pillar gets 2–3 types — never just 1 (would underfeed the calendar — see `moment-generation` supply math), never more than 4 (diminishing returns and dilutes the calendar pillar weighting).

If `run_moments` is `false`, this step is skipped entirely.

## Detection rules — candidate creator panels

A workspace is a creator panel candidate if its name (case-insensitive) contains any of:

```
"influencer", "influencers"
"creator", "creators"
"panel"
"talent"
"creator cohort", "creator panel"
"audience proxy"
```

For a multi-market engagement, match by market in the name (e.g. "Auto Creators UK" pairs with the Example Auto UK workspace). If only one panel candidate exists and there are multiple markets, ask whether to use it across all markets or only one.

## The audit-trail surface

The deck's audit-trail slide (the final slide on a briefing, the last appendix slide on a pitch) must include a `SCOPE` section that reads from `ask_decisions`. Format:

```
SCOPE
─────
Time window      · 12 months  · default
Markets          · UK, JP, US · from prompt
Influencer panel · Auto Creators UK/JP/US · from prompt
Topicality       · included
Trends           · prior-year verified
Insight chains   · 3 pillars per market
Propositions     · generated
Moments          · life + seasonal + emotional (derived from analysis)
Calendar         · 13 weeks, 3/week, starts 2026-08-03 (from prompt)
Wireframes       · NOT generated (default off)
```

This makes "what was actually delivered" inspectable by anyone reviewing the deck — closing the loop on the "agent made silent scope decisions" problem.

## Output

| File | Purpose | Read by |
|---|---|---|
| `scope.json` | The full resolved scope, including `ask_decisions` audit | `somin-brand-deck`, `deck-qa-brand` (plus `somin-agency-deck` / `deck-qa-agency` if installed), the deck builder |

## Common failure modes

- **Asking when the prompt already answered** — re-read the prompt before asking. "build an Example Auto deck across UK/JP/US with Auto Creators panels" answers markets AND influencer panel; ask nothing.
- **Asking for IDs** — never. Workspace names, brand names, panel names. The skill itself resolves IDs from names via `workspaces-list` / the engagement registry.
- **Filling defaults silently without recording them** — every defaulted field has `source: "default"` in `ask_decisions`. The audit trail must show what was defaulted, not just what was asked.
- **Reduced scope without an audit entry** — if `run_wireframes: false`, the audit-trail slide must say so. A reduced-scope deck whose audit-trail slide doesn't acknowledge the reduction fails `deck-qa-brand` C13 (or `deck-qa-agency` C13, if installed).
- **Asking more than three questions in one batch** — three is the ceiling. If more than three dimensions are ambiguous, prioritise: markets → influencer panel → wireframes. Re-run elicitation later if needed.
- **Re-eliciting on every adaptation** — if the user adapts a prior engagement to a new quarter, only the time + publish window change. Read the prior `scope.json`, update the windows, do not re-ask everything.

## Token discipline

- `scope.json` is small (under 2 KB) — fine to keep in context throughout the engagement
- The defaults table is the contract — do not duplicate the logic in the orchestrator skills; they read `scope.json` and act on it
