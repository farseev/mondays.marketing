---
name: content-brief-brand
description: BRIEFING variant of content-brief-from-moment. Converts a single SOMIN moment trigger into a decision-grade content brief — CHANNEL, MESSAGE, CALL TO ACTION, and a full WHY THIS POST that cites the story + moment + trigger IDs and a SOMIN data point — because the brand briefing is evidence-led and every post traces to the data. Consumes brand.json + a moment-trigger record. Use when filling briefing wireframes (somin-brand-deck). For the agency pitch (creative/activation emphasis, audit moved to a small field) use content-brief-agency (separate SOMIN skill, if installed). One call per post.
---

# Content Brief from Moment — Briefing variant (evidence-led)

Single-trigger → single decision-grade brief. Turns one row of a content calendar into a publishable post spec whose every claim traces to the data.

## Briefing stance — decision-grade and evidence-led

This variant feeds the **brand briefing** (`somin-brand-deck`). The brief is something a client signs off, so evidence leads:
- **WHY THIS POST is the load-bearing field.** Every brief cites the story ID, moment ID and trigger ID AND at least one SOMIN data point (e.g. "Home-cooking = WHITESPACE, creators 62.9% / cola 0%"). The four fields stay; the WHY earns the decision.
- **MESSAGE stays on-strategy and on-claim** — never beyond what `brand.offerings` / the source story support.
- IDs are kept and shown — the briefing carries the audit trail.

For the agency pitch (lead with the creative idea, audit demoted) use `content-brief-agency` (separate SOMIN skill, if installed).

## When to call

- Drafting wireframes for slides 22+ in a SOMIN strategy deck
- The user asks "write the post for [date]" or "draft the brief for the [trigger]"
- The orchestrator (somin-brand-deck, or somin-agency-deck if installed) is iterating over calendar slots

**Don't call** if there's no brand.json — call brand-extraction-from-web first. Don't call if there's no underlying SOMIN moment — call moment-generation first.

## Required inputs

A single trigger record (from `calendar.json` posts[] or from `SOMIN:moments-list`):
```json
{
  "date": "2026-08-18",
  "day": "TUE",
  "slot": "lead",
  "pillar": "MUSIC",
  "story_id": 601,
  "moment_id": 703,
  "trigger_id": 815,
  "trigger_label": "Connection Through Creative Expression · Emotional",
  "format_hint": "REEL · 60s",
  "cultural_anchor": null
}
```

A brand JSON (from brand-extraction-from-web) — provides handles, URLs, phone, taglines, real product names.

Optional: the underlying story summary (call `SOMIN:studies-get` with the story's parent study to retrieve, or pass in from prior context).

## Output shape

```json
{
  "date": "2026-08-18",
  "format": "REEL · 60s",
  "channel": "Instagram Reel · @exampleacademy + Facebook (organic + boosted to Singapore parents 30–50)",
  "message": "Example Academy is the only academy in the city where ballet and piano live in the same loyalty card.",
  "cta": "→ Read the Kiasu-Friendly Music Q&A at example-academy.com/qa/music · Book trial via DM",
  "why": "Lead post · Aug. Story 601 (Aina × Multiple Intelligences) + SOMIN Moment 703 / trigger 815 (Connection Through Creative Expression · Emotional). Parent voice = highest-trust format. Cites Example Academy Loyalty Programme as proof.",
  "thumbnail_spec": {
    "background_color": "#58C8F0",
    "hero_text": "We came for ballet.\nWe stayed because\nof piano.",
    "hero_style": "italic display, charcoal text",
    "sub_label": "PARENT TESTIMONIAL · LING'S STORY"
  },
  "audit": {
    "story_id": 601,
    "moment_id": 703,
    "trigger_id": 815,
    "brand_sources": ["facts.socials.instagram", "offerings.kiasu_friendly_music_qa"]
  }
}
```

## Field rules

**CHANNEL** must include:
- Platform (Instagram / Facebook / YouTube / TikTok)
- Format from `format_hint` (REEL · 60s, CAROUSEL · 6, STORY · 24h, POST · 1080×1350)
- The real handle from `brand.facts.socials`
- Cross-post note if relevant ("+ Facebook cross-post", "+ YouTube Short edit")

**MESSAGE** must:
- Be ≤ 25 words
- Be in the brand's voice (pull tone from `brand.voice.taglines` and `tone_words`)
- Reference a specific Example Academy product/service when relevant — use `brand.offerings`
- NEVER invent product features or claims not in `brand.offerings`, `brand.facts`, or the source story

**CTA** must:
- Begin with "→ "
- Contain at least one verifiable element: real URL from `brand.offerings`, real phone from `brand.facts.phones`, real handle from `brand.facts.socials`, or a clear social action (Tag X, Save, Share to story, Comment Y)
- For lead-slot posts: include a way to book/learn more (URL or DM CTA)
- For support-slot posts: a lighter community action is fine (Tag, Save, Share)

**WHY** must:
- Cite the story ID
- Cite the moment ID and trigger ID
- Reference at least one SOMIN data point (e.g. "M12 shows 38% category shift", "Quiet Work wave cresting M09–M11", "Music = WHITESPACE — 2 posts in 200")
- Stay under 50 words

## Thumbnail color logic

Pull palette from `brand.json`. Standard rotation for visual variety across consecutive posts:

| Slot | Background | Hero text color |
|---|---|---|
| Lead post 1 of pillar | `brand.palette.dark_utility` (charcoal) | `brand.palette.neutral_light` (white) |
| Lead post 2 of pillar | `brand.palette.pale_tint` (pale primary) | `brand.palette.primary` |
| Support 1 | `brand.palette.primary` (saturated brand color) | `brand.palette.neutral_light` (white) |
| Support 2 | `brand.palette.secondary` (lime/accent) | `brand.palette.neutral_dark` (charcoal) |
| Cultural anchor | `brand.palette.primary` + larger hero text | `brand.palette.neutral_light` |

See `references/voice-patterns.md` for tone calibration when the brand voice is "heritage" vs "playful" vs "kiasu-friendly" vs "minimalist".

## Common failure modes

- **Inventing CTAs.** If `brand.facts.phones` is empty, the brief CTA cannot say "call +65 ...". Either pick a different CTA verb (DM, Tag, Save) or flag missing brand data.
- **Generic message.** "Inspiring children since 2014" sounds like every brand. Pull the actual tagline from `brand.voice.taglines` and adapt.
- **Missing audit chain.** Every WHY field MUST cite story + moment + trigger IDs.
- **Wrong format vs trigger type.** Micro triggers (I-want-to-know) suit STORY or CAROUSEL formats, not Reels. Emotional triggers suit REELs. Match format to trigger type.

## Token discipline

- This skill is called in a loop by the orchestrator. Keep individual calls fast — read brand.json once, reuse it across all briefs in a session.
- The brief output is small (~300 tokens each). Safe to inline into deck slides.
