# Voice Patterns — Tone Calibration

When writing MESSAGE and CTA fields, calibrate to the brand's tone. The brand.json `voice.tone_words` field guides this. Common patterns:

## Heritage / Premium (e.g. heritage RAD ballet academies, long-established craft brands)
- Lowercase or sentence-case, never SHOUTY
- Short declarative sentences
- Editorial restraint — say less, mean more
- Avoid: exclamation marks, emoji clusters, "Discover", "Unlock", "Transform"
- Use: "We", "Since [year]", "Built for", concrete proof points
- CTA verbs: Read, Visit, Book, Reserve, Explore

Example MESSAGE: *"Twelve weeks. Same plié. The work that compounds."*

## Kiasu-friendly (Singapore parent audience — Example Academy specifically)
- Acknowledges the cultural anxiety (kiasu = fear of losing out)
- Practical, specific, no fluff
- Often uses Q&A framing
- Cites specific outcomes (Grade 2 → Grade 3, exam pass rates, real student names)
- CTA verbs: Read the Q&A, Tag a friend, DM "TRIAL"

Example MESSAGE: *"Two RAD exams in 18 months. Anya didn't have natural turnout. The loyalty programme isn't a discount — it's a structure."*

## Playful (consumer brands, younger audiences)
- Sentence fragments OK
- Direct address ("you", "your")
- One emoji max, used as punctuation not decoration
- Cultural references welcome
- CTA verbs: Tag, Share, Save, Try, Get

Example MESSAGE: *"Same plié, three months later. You see nothing. We see everything."*

## Minimalist (luxury, design-forward brands)
- 3–7 word headlines
- Generous white space implied
- Heavy use of period as full stop after each thought
- Avoid superlatives, adjectives
- CTA verbs: Discover. Book. View.

Example MESSAGE: *"Backstage. Thirty minutes before."*

## Empathetic (mental health, parenting, mom audiences — Mothers pillar)
- Names the unspoken truth
- "You" / "we" — never "they"
- Acknowledges effort before recognising outcome
- CTA verbs: Tag, Share, Send to, Read

Example MESSAGE: *"To the mother who's been driving here since 2019. Rewarding dedication. Celebrating progress."*

## Voice mapping by SOMIN persona archetype

| Persona archetype (from SOMIN) | Likely voice |
|---|---|
| Passionate Performer | Playful or Heritage depending on category |
| Artistic Trailblazer | Heritage |
| Creative Soul / Creative Blossom | Empathetic |
| Artistic Achiever | Heritage + practical |
| Graceful Empowerer / Heartfelt Creator | Empathetic |
| Cultivator / Nurturer | Empathetic |
| Melodic Pathfinder | Heritage + curious |

## Universal rules (regardless of voice)

1. **Never invent.** If a fact isn't in brand.json or the source story, don't write it.
2. **One claim per message.** Don't stack "RAD-certified, Vaganova-trained, 12 years running, $88 referral". Pick one.
3. **No corporate filler.** Cut "We are pleased to", "We are excited to", "Don't miss out". Start with the noun.
4. **Local specifics beat global generic.** "#04-17, 1 Example Road" beats "our two locations".
