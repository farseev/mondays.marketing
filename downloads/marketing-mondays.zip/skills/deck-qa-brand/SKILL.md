---
name: "deck-qa-brand"
description: "QA gate for a SOMIN brand briefing deck: full correctness checklist, rendered-PDF zero-overlap gate, v3 ordering, competitor diversity slide, creatives on every calendar post, organic-timeline palette and word band."
---

# Deck QA — Pre-Delivery Quality Assurance

A deck builder produces a polished-looking file even when it is wrong — wrong numbers, dead links, a mis-coloured logo, a chart label that contradicts its own line. Nothing crashes. This skill is the verification gate that catches those errors before a deck reaches a client.

It is a **separate, reusable skill**: any deck-building workflow invokes it as its final step. It owns exactly one responsibility — *verifying a finished deck against its own source data and brand spec* — and does not build, style, or restyle anything.

## When to use

- A deck (PPTX/PDF) has just been built or edited and is about to be delivered.
- The user asks to "QA the deck", "check the deck", "audit the slides", "is this consistent".
- A deck was produced by adapting another deck (new market, client, quarter) — the highest-risk case.
- One deck in a multi-deck set changed and the set must stay mutually consistent.

## When NOT to use

- The deck has not been built yet — build first, QA after.
- The request is to *create* or *restyle* slides — that is the builder / brand skill. QA only inspects and reports.
- The user wants a content critique ("is the strategy any good") — QA checks correctness, consistency, references, brand and layout, not strategic merit.

## Core principle

A slide is correct only when **everything printed on it traces to a verifiable source**: a number to the deck's own data, a name to the source record, a URL to a real resource, a colour to the brand spec, a data-object field to the actual object returned by the platform. Anything that cannot be traced is a defect. QA is a **gate, not advice** — a deck that fails is rebuilt and re-QA'd; it is never delivered with known defects.

## Required inputs

| Input | Purpose |
|---|---|
| The built deck | PPTX and PDF to inspect |
| The deck's source data | The JSON/registry/data files the deck was built from — ground truth for figures, names, counts, IDs |
| The brand spec | The brand-guideline skill or brand.json — ground truth for logo/wordmark, palette, category colour-coding |
| The reference list | Which SOMIN/source URLs each slide is required to cite, so QA can confirm presence AND clickability |
| Deck configuration | single vs multi-deck; influencer/audience cohort?; extra workspaces?; adapted-from another deck? — selects conditional checks |
| The builder source (if available) | Lets QA separate data-driven slides (safe) from hardcoded literals (must verify) |

If any input is unavailable, QA still runs the checks it can and **states in the verdict which checks were skipped** — a deck cannot be certified clean with checks skipped.

## The workflow

### Step 1 — Establish configuration
Determine: number of decks; influencer/audience cohort present; extra workspaces present; whether this deck was adapted from another. This selects which conditional sections of `references/qa-checklist.md` apply.

### Step 2 — Render the deck to images
QA is visual. Convert every PDF page to an image and inspect what actually rendered — overflow, clipping, axis scaling, logo colour and link styling are only visible in the render, never in the builder source.

**Render with the deck's real fonts installed first.** Run `fc-list | grep -i "<head font>\|<body font>"` for every `fontFace` the builder uses. If one is missing, install it before converting (Google-font families are on npm as `@fontsource/<family>`; convert the `.woff` files to `.ttf` with fontTools and run `fc-cache -f`). A PDF rendered with a substituted fallback font (DejaVu, Liberation) re-wraps every line: headlines spill onto a second line and labels collide. The PDF you QA, and deliver, must be the one with the real fonts.

```bash
pdftoppm -jpeg -r 130 <deck>.pdf <prefix>
```

### Step 3 — Classify every slide: data-driven vs hardcoded
If the builder source is available, scan it. A slide that reads its content from a data file adapts automatically (low risk). A slide with literal numbers/names/captions typed into the builder is the risk surface — every literal must be traced in Step 4. Hardcoded summary/headline slides are top priority.

### Step 4 — Run the checklist
Run the **core checklist** (always) plus every **conditional section** the configuration activates. Full itemised checklist in `references/qa-checklist.md`. The core checklist covers twelve defect families — C1–C11 and C13 below; a further family, C12, activates only on multi-market runs:

- **C1 Summary-vs-detail** — every headline/summary figure matches the detail slide that derives it.
- **C2 Data tracing** — every figure, count, name, title, ID traces to the source data for THIS deck.
- **C3 No foreign leftovers** — nothing inherited from a prior market/client/template.
- **C4 Chart integrity** — every data label matches the line/bar it sits on (a "Rising" label never on a falling line); axis maxima fit the data; legend matches series; and every chart is readable on its own — a reader can quantify each point because the axis is labelled or the points carry value labels. **A trend status word (SUSTAINED / SEASONAL / FALLING / RISING / EMERGING / SINGLE-SHOT / DECAYED) is a computed claim, not a caption** — when the chart shows per-point values, re-derive the status from those values against the trend rubric (SUSTAINED = mean ≥20% AND coefficient of variation <30%; FALLING = net decline ending at the minimum; SEASONAL = cyclic peaks/troughs / CV ≥30% with no monotonic trend) and confirm the printed label matches. A volatile series (deep troughs, CV well above 30%) labelled SUSTAINED is a defect even though its average is high. **And the SAME tension must carry the SAME status on every slide it appears** — the trend-chart slide, the movement-table slide and any divergence/narrative slide must agree; one tension shown SUSTAINED on one slide and SEASONAL/FALLING on another is a cross-slide contradiction. **A delta or "X → Y" arrow notation must show the series' actual start and end values.** If the second value is a mid-series peak rather than the endpoint, that is a misrepresentation — relabel it (e.g. "X → end · peak Y"). The arrow must never imply a flattering peak is where the series finished.
- **C5 References & links** — every required source URL is present AND actually clickable (a real hyperlink, not plain text); post/insight references resolve to the right resource; on the audit-trail slide the classes that have a public URL — workspace, study, story — are each hyperlinked to their SOMIN record, while **product, proposition, moment, persona, tension, angle and character** IDs (which have no per-object public URL) are shown as plain, workspace-traceable IDs. PASS when the linkable classes are linked and the rest are plain; FAIL only if a workspace/study/story ID is plain text, or a blanket "every ID is a live link" caption sits above plain-text IDs. The footer URL is a live link on every slide. **Every hyperlinked run must be underlined.** The deck deliberately varies link *color* by background for contrast (a light card uses one accent, a dark card a lighter one) — color alone is not a reliable "this is clickable" signal, so `link_somin.py` underlines every run it attaches a hyperlink to. Sample text runs that carry a real `hlinkClick` across a few slides (footer credit, audit-trail IDs, "Open story" affordances, any bare URL) — any hyperlinked run without underline is a **FAIL** (it means `link_somin.py` was bypassed, edited, or run from a stale copy).
- **C6 Brand identity** — logo/wordmark rendered in the correct colours AND the correct spacing per the brand spec; palette correct; every recurring category (e.g. a whitespace verdict) uses ONE consistent colour and label everywhere it appears.
- **C7 Layout — STRICTLY no overlapping text, anywhere, zero tolerance.** No glyph may touch another text line, a bar, a chip, a swatch, a chart line or axis, a Venn/diagram outline, a connector arrow, an image, or the slide edge. No slide headline may wrap onto a second line unless the box was deliberately sized for two lines. No `%`/value label may sit on its own bar or on the next column's bars. Nothing collides with the reserved footer band (the footer text and page-number strip at the slide bottom) — captions, footnotes, chart labels and the last card row must clear it. No empty filler slide. **C7 is verified mechanically, never by eye alone** — run the overlap gate (§ "C7 overlap gate" below) on the rendered PDF; a single hit is a FAIL. Eyeballing thumbnails is how wrapped headlines, stacked chart labels and `%` marks sitting on bars reached the client before.
- **C8 Data-object fidelity** — when the deck presents a platform object (SOMIN proposition, study, moment), it shows that object's REAL fields from the actual record, not invented content and not an arbitrary subset that drops the object's defining fields. A proposition in particular must appear with its actual **name (focus line) and insight tagline** — a card printing only "Proposition {id}" shows an ID reference, not the proposition, and fails.
- **C9 Tone** — professional MNC-marketing register; no buzzwords or hype filler; headlines and on-slide labels state the actual finding in plain words, not borrowed strategy-framework jargon ("where to play / how to play", "north star", "the X imperative").
- **C10 Claim integrity** — language never claims more than SOMIN measured. SOMIN detects concepts from CONTENT; it does not observe the audience. No slide may say "audience demand", "what [audience] wants/talks about", "demand-side" or similar. Content cohorts are "content made for [audience]"; whitespace is a content-supply gap. "Audience reacted" is allowed only when citing a views/engagement figure, as volume.
- **C11 Comparison-slide integrity** — any slide comparing entities side by side must make the compared dimension actually vary. A hero stat identical across every column (three "1 of 6" tiles), or columns mixing different metrics/units under one headline, is a defect. If a statistic is genuinely uniform, state it once as the finding — do not repeat N identical tiles.
- **C12 Cross-deck independence (multi-market runs only)** — in a multi-market engagement each market's deck must be derived from its own market's data. No two market decks may share pillar names, insight-story text, character names, product IDs or proposition text. Identical pillars or propositions across markets is a FAIL — it means the analysis was reused, not run per market. A theme may legitimately recur across markets, but only if each deck's pillars, stories, characters, product and propositions trace to that market's own SOMIN records; verify the IDs differ deck to deck.
- **C13 Deliverable completeness** — the deck contains every layer and every object its agreed scope requires, **counted across the main section AND the appendix together** (under the v3 ordering most evidence lives in the appendix; that is not a shortfall). Two failure shapes: (1) **dropped objects** — the analysis generated 9 propositions, 3 insight chains, N moments, but the deck shows only a subset (e.g. 3 of 9 propositions, or a pillar with no chain). Every generated object appears somewhere in the deck. (2) **scope shortfall** — a deck presented as the full strategy deck is missing whole layers (competitor diversity, trend evidence, content calendar, proposition set, audit trail). Slide count is not the test; missing layers are. A reduced-scope deck is acceptable *only* when the configuration says reduced scope was explicitly agreed; a full-scope deck missing layers, or a reduced-scope deck presented as complete, is a FAIL. Check the deck's section coverage and object counts against the scope recorded in the configuration.

- **C14 Briefing-specific (this variant)** — beyond the core families, a briefing must also pass:
  - **C14.1 Ordering matches the deck's declared default — v3 unless the configuration records `scope.ordering: "v2"`.** **v3 (default):** a main section a client reads end to end, then an appendix. Main section, in order: hero → competitor creative diversity (slide 2) → whitespace cohort cross-check → trending-and-whitespace gate → where to invest → the engine as layers → insight chains with a creative per chain → creatives per pillar across the funnel → brand permission → integration with existing effort → calendar overview → one slide per calendar month showing each post's creative → lead briefs with their creatives → recommendations. Appendix: an "Appendix" divider, then every supporting chart and table (method notes, audience definition, competitive landscape, product reality, paid-vs-organic lift, trend lines, additional territories, persona characters, full proposition list, excluded moment types, brand rules, diversity worked calculation, predicted performance, creative library, audit trail), each carrying an appendix eyebrow. FAIL if a main-section slide repeats a point another main-section slide already makes (it belongs in the appendix), if a justification slide the engagement moved forward sits in the appendix, or if the appendix carries a slide the main section needs to make its argument. **v2 (opt-in only):** Under the v2 order (see `somin-brand-deck/references/slide-blueprint.md` § "Ordering principle, v2"): Method Notes + Additional Content Territories appear right after the hero (not in the appendix); Whitespace & Trends (the diagnosis) and the prioritisation/selection-logic slide come BEFORE personas; personas lead only The Audience + The Engine sections, not the whole deck. Within whichever section personas lead, ordering is still persona → tension → evidence, never a flat wall of tensions. **Check which default the configuration recorded** — a deck built against the OLDER personas-first default (personas before Section 2's whitespace/trend) is only a PASS if that older order was the explicitly recorded choice for this engagement; otherwise it's a stale-template FAIL. A deck that mixes the two orderings (e.g. Method Notes moved forward but personas still lead) is always a FAIL regardless of which default was chosen — apply the ordering consistently.
  - **C14.2 Engine shown as layers.** The persona→tension→angle→proposition chain appears as layers (one persona → many tensions), with character names and theme IDs kept and shown — not a flat insight list.
  - **C14.3 Share-of-voice, not raw counts.** The whitespace / "money" slides show share-of-voice (and engagement where claimed), never raw post counts.
  - **C14.4 Honest whitespace.** No strand is labelled WHITESPACE unless creators are high AND the whole category (brand + competitors) is low. Brand-inactive-but-competitors-present is CONTESTED / BLOCKED / AUDIENCE-LEFT, never whitespace (mirrors `whitespace-analysis`).
  - **C14.5 Prior-year-verified trends.** Any RISING / FALLING shown carries its prior-year-verified status; an unverified single-cycle decline is never presented as a confident fact.
  - **C14.6 Briefing beats present, and Brand permission OPENS the engine section.** Brand-permission, integration-with-existing-effort, market prioritisation, and an evidence-posts-before-recommendations slide are all present. Beyond position: under **v3**, Brand permission sits immediately before Integration, after the creatives-per-pillar slide and before the calendar. Under **v2**, Brand permission must be the FIRST slide after the Section 4 close (market prioritisation / strategic frame) — i.e. immediately before integration, insight chains and propositions, per `references/slide-blueprint.md` Section 5. A deck where Brand permission has drifted later (e.g. re-grouped next to the persona/proposition slides) is a **FAIL** even though the slide exists — this has happened before from an ad hoc section-order edit and is exactly the kind of defect presence-only checking misses.
  - **C14.7 FMCG website discipline.** No brand-site / traffic-analysis slide for a low-involvement (FMCG) client; present only for high-involvement categories.
  - **C14.8 Full audit trail.** Every study / character / story / product / proposition / moment ID is present, IDs are kept (not suppressed), and they are linked per C5 (workspace/study/story hyperlinked; product/proposition/moment shown as plain, workspace-traceable IDs).
  - **C14.9 No duplicate pillar-ranking slide.** In a single-market deck, exactly ONE slide ranks pillars by opportunity ("Where to invest first"). A deck showing the same pillar/verdict set twice on consecutive slides — a "market prioritisation" slide immediately followed by a "strategic frame" card-grid slide with the same pillars — is a FAIL: it is the pre-merge redundant pair `somin-brand-deck`'s `build_deck.js` no longer emits, so its reappearance signals a stale builder copy or a hand-edited deck. (Exception: a multi-market *cross-market summary* deck's per-market strategic-frame slide, N columns/one lead pillar each, is a distinct required slide — see C12 and `slide-blueprint.md` → Multi-market runs — and is not this defect.)
  - **C14.10 Named creator/influencer panel disclosed when used as evidence.** If the deck's whitespace/trend analysis drew on an influencer/creator content-proxy panel (an `influencer_panel`/`influencerWorkspaceId` was part of the configuration), the Method Notes appendix slide must name every creator in the panel in full (not just a count, not an unnamed "content-proxy" reference) and the Audit Trail slide should point to that disclosure. A deck that used a named panel as evidence but never discloses which creators were analyzed is a FAIL — this is exactly the gap a client asking "which creators did you actually analyze?" would otherwise expose.
  - **C14.11 Competitor creative diversity is a standard main-section slide.** Slide 2 of a v3 deck (right after the hero) scores the brand and every competitor on Meta Diversity from their organic creatives (per `content-diversity-scorer` § Cohort mode). The slide must: state the direction ("0–100, higher is more diverse"); show every competitor in scope, not a subset; show the image-only control beside the headline score for any entity that publishes both images and video; show n per entity and flag any entity below n=8 instead of scoring it; state the structural-coverage gate result and label any entity under 0.60 as "message-only". The appendix must carry the worked calculation (formula, weights, one worked pair, unification collapse rate). Missing slide, missing direction, a dropped competitor, or ranking on the headline when video shares differ and the control is absent: **FAIL**. Re-derive each printed score from `content_diversity.json`.
  - **C14.12 A creative on every calendar post.** Every post on every calendar-month slide carries its assigned creative thumbnail, and the assignment traces to `calendar_creatives.json` (every slot mapped, pinned slots honoured). A calendar of text-only rows, or a month slide where some posts have no creative, is a **FAIL**. The same creative must not be assigned to two slots unless the mapping file records it deliberately.
  - **C14.13 Palette and on-image copy length are measured from the brand's own organic timeline.** `inferred_guideline.json` (or `brand.json`) must record a palette pixel-sampled from the brand's organic creatives and an on-image word band (median + band) from OCR of those creatives, with the post count each was measured on. Check: every generated creative uses only that palette (plus neutrals); every creative's headline word count falls inside the measured band (re-count from `banner_compliance.json` or by OCR); the brand-lock suffix quotes the band. A palette taken from the website/logo only, or copy lengths not measured from the organic timeline, is a **FAIL** — say which of the two rules was not applied.
  - **C14.14 Service constraints respected.** Every entry in `brand.json` → `service_constraints[]` (for example "no home visits") is honoured by every creative, brief, hook and calendar post. A creative that shows a service the brand does not offer (a doctor at the patient's home for a brand that does not do home visits) is a **FAIL** even if it is on-pillar and on-brand. Inspect the renders, not only the prompts.
  - **C14.15 No process narration in the deck.** No slide — least of all a headline — states that a step failed, was skipped, is pending, was rate-limited or "could not be computed". Unfinished work is reported in the chat reply, not printed in the deck. A metric that genuinely cannot exist (a set below n=8) is stated as a property of the data ("7 creatives — below the 8 needed for a score"), never as a pipeline status. Any slide narrating the build process is a **FAIL**.
  - **C14.16 Main section is argument, not evidence dump.** Each main-section slide makes a distinct point in the argument; two main-section slides making the same point with different charts is a **FAIL** — move one to the appendix. Every appendix slide carries the appendix eyebrow so a reader can tell where the argument ends.

### Step 5 — Produce the verdict
Output **PASS** or **FAIL** with a defect list (`references/qa-report-format.md`). For each defect: slide, family, what is wrong, the correct value/spec, the fix.

### Step 6 — The rebuild loop (mandatory on any FAIL)
A FAIL is not a report the user acts on at their discretion — it triggers a fixed loop that QA owns and drives to completion:

1. **The deck is blocked from delivery.** Do not present, send, link, or describe a FAILed deck as finished. One unresolved defect blocks the whole deck.
2. **Fix at the source — never patch the output.** For every defect, change the **source data or the builder code**, not the rendered PPTX/PDF. Hand-editing the output file, or patching a single literal in place, is forbidden — it leaves the root cause live and the next rebuild reintroduces the defect. If a defect is a hardcoded literal, the fix is to make that value read from / be computed from data.
3. **Rebuild the whole deck** from the corrected source — re-run the builder end to end. Do not splice a corrected slide into the old file.
4. **Re-run the FULL checklist from the top** — every core family and every conditional section, not only the slides that failed. A fix routinely introduces a new defect elsewhere (a corrected stat with a now-stale caption; a widened axis that overflows its frame; a relinked URL that shifts layout). Partial re-QA misses these.
5. **Repeat 1–4 until the verdict is PASS.** There is no iteration cap and no "good enough" — the loop ends only on a clean PASS.

**Only a PASS makes a deck deliverable.** QA is a gate, not advice: every issue it finds sends the deck back through this loop. In a multi-deck run, each deck runs its own loop and must individually reach PASS before the set is delivered.

## What a defect looks like (one per family)

- **C1** Slide 2 shows 50%; the deck's data has no 50% theme — its largest is 55%. FAIL — stale hardcoded summary stat.
- **C2** Slide 3 says "21 studies"; the registry lists 17. FAIL — hardcoded count.
- **C3** Slide 4 names an ambassador/competitor/city from another market. FAIL — stale template text.
- **C4** Slide 9 line trends downward but is labelled "Rising". FAIL — label contradicts the data.
- **C4** A trend chart shows 79, 4, 36, 0, 69, 77% labelled SUSTAINED. Recomputed: mean 44% but coefficient of variation ≈75% — far above the 30% SUSTAINED ceiling. FAIL — the series is volatile/seasonal; SUSTAINED is wrong even though the average is high. Re-derive the label from the values.
- **C4** A tension is shown SUSTAINED on the trend-chart slide but FALLING on the movement-table slide and "swings seasonally" on the divergence slide. FAIL — the same tension must carry one status everywhere; reconcile all three to the value-derived status.
- **C4** A small-multiple panel of four line charts has no axis and no value labels — the reader sees four shapes but cannot read any level off them. FAIL — chart not readable on its own; add an axis or point labels.
- **C4** A trend table shows volume as "23 → 89" where 89 is a mid-year peak and the actual final value is 55. FAIL — the arrow implies an endpoint; show the true start→end and note the peak separately ("23 → 55 · peak 89").
- **C5** A slide cites a SOMIN insight but the URL is plain text, not a clickable link. FAIL — reference not clickable.
- **C5** The audit-trail slide promises "every claim traces to a SOMIN ID" but the workspace/study/story IDs are plain text, not hyperlinks. FAIL — the traceability slide must have every ID linked to its SOMIN record.
- **C5** The audit-trail slide links workspaces, studies and stories, and shows product and proposition IDs as plain text — which is correct, they have no per-object URL — but the caption still says "every ID below is a live link". FAIL — the false blanket caption is the defect; scope it to the linkable classes (plain product/proposition IDs are fine).
- **C6** The "SOMIN" wordmark is rendered in one flat colour, or with the letters spaced out / wide-tracked / written "S O MIN". FAIL — wordmark must be "SO" teal + "MIN" dark/white as two tight tonal groups, joined, with NO space and NO wide tracking, per the brand spec. (The slide header wordmark is the client's own brand mark per its guideline; this rule governs the "SOMIN" preparer mark in the footer.)
- **C7** Slide 11 body text runs past the slide edge. FAIL — overflow.
- **C7** A 25pt headline ("Brand A is third by volume and second by engagement.") wraps to a second line and its second line prints through the subtitle below it. FAIL — the headline must fit one line (shrink to the floor, else reword at source), and the subtitle must start below the headline's rendered bottom.
- **C7** A two-column bar slide prints each organic `%` label at a fixed x that lands on the first paid bar, so "26%" and the purple bar overprint. FAIL — a value label rides on its own bar's end (`x = bar_x + bar_w + gap`) and every column's max bar + label clears the next column's start.
- **C7** A native line chart with `showValue:true` stacks the 0% labels of three series on top of each other and on the lines. FAIL — drop per-point data labels when series converge (carry the values in a side panel or table), or label only line ends.
- **C7** A Venn slide places "TRENDING" and the pillar name inside the ellipses where the outlines cut through the letters. FAIL — circle titles sit above the circles, and each region's text box is sized to lie wholly inside its region (check the ellipse equation at the box corners).
- **C8** Propositions are listed by name only; the proposition object's own fields are dropped or replaced with invented copy. FAIL — show the real object fields.
- **C8** A proposition slide shows nine cards each reading only "Proposition 1201", "Proposition 1202"… FAIL — an ID is not the proposition; each card must show the real name (focus line) and insight tagline from the record.
- **C9** A slide leans on hype filler ("unleash next-level synergy"). FAIL — rewrite in plain professional register.
- **C9** A headline reads "Where to play, how to play — everywhere" — borrowed strategy-framework jargon that states no actual finding and could sit on any deck. FAIL — rewrite to the concrete point of the slide ("One strategic frame, used in all four markets").
- **C10** A slide says "what Foodies want" or "audience demand" for a metric derived from creator content. FAIL — SOMIN measured content, not the audience; reframe as "content made for Foodies".
- **C11** A four-market comparison slide shows "1 of 6" as the hero stat in three columns and "15" in the fourth. FAIL — the columns don't differ and mix two metrics; give each market a distinct hero number on the same metric, or state the uniform finding once.
- **C12** The UK, JP and US market decks each show the same three propositions, word-for-word. FAIL — propositions were copied across markets instead of generated per market from each market's own insight stories; each deck must carry its own product and proposition IDs.
- **C13** The analysis generated 9 propositions; the deck's proposition slide shows 3. FAIL — every generated proposition must appear (on dedicated plate slides); a 3-of-9 subset drops two-thirds of the work.
- **C13** A deck presented as the full SOMIN strategy deck has 14 slides, no trend evidence, no competitor diversity and no content calendar, and the configuration records no reduced-scope agreement. FAIL — build the missing layers (main section + appendix), or have reduced scope explicitly agreed and recorded.
- **C14.1** A v3 deck shows three main-section slides in a row that each plot paid vs organic lift for the same tags. FAIL — one point, three charts; keep one in the main section and move the others to the appendix.
- **C14.11** The competitor-diversity slide shows the brand at 71 and two of four competitors, with no direction stated and no image-only control, while one competitor posts 60% video. FAIL — every competitor, "higher is more diverse", and the image-only control beside each headline.
- **C14.12** The December calendar slide lists nine posts with dates and hooks but only four thumbnails. FAIL — every post carries its creative from `calendar_creatives.json`.
- **C14.13** The creatives carry 18-word headlines while the brand's organic timeline measured a median of 10 words (band 6–14). FAIL — copy length must sit in the measured band; regenerate with the band in the brand-lock.
- **C14.14** A "home recovery" creative shows a doctor examining a mother in her living room; `service_constraints` records "no home visits". FAIL — regenerate with the clinician at the brand's own centre or no clinician in the home scene.
- **C14.15** A slide headline reads "Paid diversity could not be computed — rate limit". FAIL — process status belongs in the chat reply, not the deck.
- **C14.1** The configuration records the v2 default, but the deck still shows persona commons before the whitespace cohort cross-check, and Method Notes is the second-to-last slide instead of the second slide. FAIL — half-applied reorder; a stale builder copy or a hand-edited deck.
- **C14.9** A single-market deck shows "Market prioritisation by whitespace size" on slide 17 and "Whitespace strategic frame" on slide 18 with the same three pillars and verdicts on both. FAIL — pre-merge redundant pair; the current builder emits one ranked "Where to invest first" slide.
- **C14.10** The deck's whitespace read cites an influencer/creator content-proxy panel throughout, but Method Notes only says "a panel of creators" with no names, and no slide answers which creators were analyzed. FAIL — a named panel used as evidence must be disclosed by name.

## Common failure modes (of QA itself)

- **QA'ing from the builder source instead of the rendered deck** — overflow, clipping, link styling and logo colour only show in the render.
- **Judging C7 by eye at thumbnail size** — overlaps of a few points (a `%` sign on a bar end, a descender through the next line, a chart label on a line) are invisible in a 9-up contact sheet. Run the overlap gate; eyes are the second check, not the first.
- **QA'ing a PDF rendered with fallback fonts** — the wraps you see (or miss) are not the deck's real wraps. Install the fonts first (Step 2).
- **Spot-checking instead of full coverage** — the defect hides on whichever slide was not checked. Every slide, every literal, every link, every chart.
- **Trusting a slide because it "looks reasonable"** — 50/2/45 looked reasonable on three decks. Reasonable is not correct; only tracing to source is.
- **Reading a trend status as a caption instead of recomputing it** — SUSTAINED / SEASONAL / FALLING are computed verdicts. If the chart shows the values, recompute (mean + coefficient of variation) and check against the rubric; a high-average but wildly swinging series is not SUSTAINED.
- **Checking that a URL is present but not that it is clickable** — a printed URL that is not a live hyperlink still fails C5.
- **Passing a v3 deck on a v2 checklist** — under v3 the main section is short and evidence sits in the appendix. Count completeness across both, and check ordering against the v3 list, not the old ~32-slide blueprint.
- **Checking the calendar for dates and hooks but not for creatives** — every post needs its thumbnail.
- **Skipping the conditional sections** — a multi-market run with the multi-market section skipped is how decks inherit each other's content.
- **Treating QA as advisory** — a FAIL means rebuild-and-recheck, not "deliver with a note".

## Token discipline

- Render to images and inspect; do not paste builder source or full JSONs into context.
- The itemised checklist, report format and defect library live in `references/`; load them when running a pass.
- The verdict is small — the PASS/FAIL line plus the defect table is the deliverable.

## References

- `references/qa-checklist.md` — the full itemised checklist: eight-family core section + every conditional section.
- `references/qa-report-format.md` — the PASS/FAIL verdict and defect-table format.
- `references/failure-pattern-library.md` — catalogued real defects from past engagements, each with cause and how it is caught.


## Creative expressions check (only if the run included `creative-expressions`)

Apply these **only** when the scope passed to QA says expressions were generated:

- **Count matches scope.** The number of rendered expressions in the Creative-Library appendix equals what was agreed (All / Top N per pillar / specific total). A short appendix when "All" was chosen is a FAIL.
- **Full funnel is the default (required).** Unless the scope records an **explicit user cap**, the appendix must be the full funnel — **≥30 concepts per pillar** across TOFU/MOFU/BOFU (per `creative-expressions/references/funnel-taxonomy.md`). An appendix carrying only a handful per pillar (e.g. 1–3 per stage) with no recorded cap is a FAIL — the default is the maximum funnel, not a sample.
- **Predicted-performance scoring ran (required).** If the deck contains a rendered Creative Library, the scope must show `scoring_ran: true` and the deck must carry the predicted-performance treatment (a "Predicted performance" explanation slide + "Top performer potential" leaderboard/badges) — **unless** `top_performers: 0`, in which case badges/summary are correctly omitted but `scoring_ran` must still be true and `scoring_method` recorded. A rendered Creative Library with no scoring pass (`scoring_ran` absent/false) is a **FAIL** — scoring is mandatory after generation and cannot be skipped.
- **No stray placeholders.** In a final (non-partial) deck, no "Pending render" cards or blank cells remain. Every appendix cell shows a real render with its concept-key + subtype caption.
- **Grouped correctly.** One grid per (pillar × TOFU/MOFU/BOFU); each grid's pillar/persona header matches its concepts; no thumbnail or caption overflows the footer.
- **On-brand.** The appendix uses the client's real brand tokens (surface, ink, accent, fonts) — not the engine's neutral defaults.
- **Real logo composited, on-palette — no model-drawn mark (required).** Every rendered cell must carry the brand's real wordmark/logo *composited* into its reserved corner (the correct mark per the brand-guideline, not one the model drew) and use only the brand's palette. FAIL any cell where the image model invented its own logo (an invented or misspelled mark, a wrong letterform such as a dotted/ring "O") or used a colour outside the brand palette — even when the caption styling is on-brand. The fix is `somin-brand-deck` Step 12B's brand-lock + wordmark composite; neutral-default styling (the "On-brand" check above) is necessary but not sufficient.
- **Proposition visuals (only if "embed" was chosen).** Each embedded example sits on a proposition slide and matches that slide's insight/pillar. If "text-only" was chosen, there are **no** creative images anywhere in the proposition section.
- **Provenance honesty.** Any audit/method note describes the expressions accurately (SOMIN-generated, the count, and that the full set lives in the appendix).
- **Provenance gate — engine-generated, not hand-written (required).** Run `python3 <creative-expressions>/scripts/check_prompts.py --concepts <concepts.json> --prompts <emit-prompts out.json> --images-dir <renders> --manifest <manifest.json>` and require PASS (exit 0). It FAILs if any concept carried `imageConcept` (the engine's master prompt was bypassed) or if any emitted prompt is a verbatim echo of one — i.e. the "creatives" were typed by the operator, not generated. Every embedded thumbnail must trace to an engine prompt in the manifest. (This is the SKILL-side companion to checklist item **C5b**.)
- **No stray proposition-visual thumbnails outside the proposition section (required when "embed" was chosen).** `creative-expressions`' proposition-visual placement has a known defect where it can drop a `creative-example` picture + `"Creative example"` caption at a fixed bottom-right position on a slide that isn't actually a proposition slide — observed on an Audit Trail slide, directly over the Scope panel's values. For every slide, check any shape named `creative-example` (or any textbox reading exactly `"Creative example"`) against every OTHER shape's bounding box on that same slide; any overlap is a **FAIL**, and any occurrence on a slide that is not one of the pillar/proposition slides is a FAIL regardless of overlap. `somin-brand-deck`'s Step 12B documents the required cleanup pass — confirm it ran rather than re-deriving the fix here.
- **Scoring method disclosure matches reality (required).** Read the "Predicted performance" explanation slide's body text. If it describes live per-asset SOMIN scoring ("uploaded to the SOMIN content library and scored by SOMIN's clickability model"), confirm the scope actually recorded `scoring_method: per_asset` with real `posts-search` results for these exact creatives — if the scope says `corpus_lift` (the near-universal case for generated/unpublished creatives, per `somin-brand-deck/references/somin-schema-gotchas.md`) but the slide reads like per-asset scoring, that is a **FAIL**: the deck is overclaiming precision it doesn't have. Also check the sentence names the brand correctly — `score_annotate.py`'s brand-name lookup has a fallback bug history (rendered as "graded against 's own High-vs-Low..." with the name silently dropped when `brand.json` only carries a `brand` key, not `name`); any missing-name gap in that sentence is a **FAIL**.

## C7 overlap gate (mandatory on every deck)

The deck is not deliverable until this gate prints `PASS — 0 overlap(s)`. It reads the **rendered PDF** — what a reader actually sees — so it catches wraps and collisions a font fallback or a chart engine introduces, which geometry in the builder source cannot show.

1. Render the PDF with the real fonts installed (Step 2).
2. Write the script below to `overlap_gate.py` (needs `pip install pymupdf`) and run `python3 overlap_gate.py <deck>.pdf`.
3. Any hit is a C7 FAIL. Each hit names the slide, the kind (`T-T` text-on-text, `T-G fill` text on a bar/chip, `T-G line` text crossed by a chart line/outline/rule, `T-I` text on an image, `OFF` off-page, `WRAP` headline on two lines) and the glyph position in points, so the fix goes straight to the right builder line.
4. Fix at the source (the builder), rebuild, re-render, re-run the gate and the full checklist — the Step 6 loop. Never nudge a box in the output file.
5. After PASS, still look at every slide at ≥80 dpi; the gate is the first check, the eye is the second.

**Builder-side rules that keep the gate green** (enforce them in the builder, not in QA):
- Measure text with the real font's advance widths and line height before placing it (a small `font_metrics.json` exported with fontTools covers it). A slide headline must fit ONE line: shrink toward a floor (e.g. 25pt → 20pt), and if it still wraps, reword it — never let it spill into the subtitle.
- Multi-line boxes must fit their frame; shrink no further than 85% of the design size, else the build refuses to write the deck and names the box.
- Place value labels relative to the mark they describe (`bar_x + bar_w + gap`), never at a fixed column x; size every column so its longest bar plus label ends before the next column starts.
- Line charts: no per-point data labels where series converge — carry values in a side panel or label line ends only.
- Diagrams (Venn, flows): titles outside the shapes; every inner text box lies wholly inside its region, checked at the box corners.

```python
"""Deck layout gate: STRICTLY no overlapping text anywhere.

Reads the RENDERED PDF (what a reader actually sees), not the PPTX geometry, so it catches
wrapped headlines, chart labels, data labels, Venn labels and anything a font fallback moves.

A page FAILS on any of:
  T-T  text over text     two glyphs from different lines/blocks whose ink boxes intersect
  T-G  text over graphic  a glyph partly covered by a filled shape it is not fully inside
                          (bars, chips, swatches), or crossed by a stroked line or curve
                          (chart lines, axes, Venn outlines, rules, connector arrows)
  T-I  text over image    a glyph partly overlapping an image it is not fully inside
  OFF  off page           a glyph outside the page or inside the 0.12in edge margin
  WRAP title wrap         a slide headline (>=20pt, top band) rendered on more than one line

Usage: python3 overlap_gate.py deck.pdf [--json out.json]   exit 0 = PASS, 1 = FAIL
"""
import sys, json, fitz

MIN_FRAC = 0.12          # intersection must cover >=12% of the smaller glyph box
EDGE_PT = 0.12 * 72

def ink_box(ch, size, origin):
    """Tight glyph ink box from the baseline, not the line box (line boxes of adjacent,
    tightly-leaded lines legitimately touch and would otherwise read as overlaps)."""
    x0, _, x1, _ = ch["bbox"]
    by = origin[1]
    return fitz.Rect(x0 + 0.08 * (x1 - x0), by - 0.70 * size, x1 - 0.08 * (x1 - x0), by + 0.16 * size)

def glyphs(page):
    out = []
    raw = page.get_text("rawdict")
    for bi, b in enumerate(raw["blocks"]):
        if b.get("type") != 0:
            continue
        for li, l in enumerate(b["lines"]):
            for s in l["spans"]:
                for c in s["chars"]:
                    if not c["c"].strip():
                        continue
                    out.append({"c": c["c"], "r": ink_box(c, s["size"], c["origin"]),
                                 "line": (bi, li), "size": s["size"], "y": c["origin"][1]})
    return out

def frac(a, b):
    i = a & b
    if i.is_empty:
        return 0.0
    return i.get_area() / max(1e-6, min(a.get_area(), b.get_area()))

def seg_hits_rect(p, q, r):
    """does segment p-q pass through rect r (sampled, robust for curves split into segments)"""
    n = max(2, int(abs(q.x - p.x) + abs(q.y - p.y)) // 2)
    for k in range(n + 1):
        t = k / n
        x = p.x + (q.x - p.x) * t; y = p.y + (q.y - p.y) * t
        if r.x0 < x < r.x1 and r.y0 < y < r.y1:
            return True
    return False

def check_page(page):
    issues = []
    G = glyphs(page)
    W, H = page.rect.width, page.rect.height
    # OFF
    for g in G:
        r = g["r"]
        if r.x0 < EDGE_PT or r.y0 < 0 or r.x1 > W - EDGE_PT or r.y1 > H:
            issues.append(("OFF", g["c"], None)); break
    # T-T
    G.sort(key=lambda g: g["r"].x0)
    for i, a in enumerate(G):
        for b in G[i + 1:]:
            if b["r"].x0 > a["r"].x1:
                break
            if a["line"] == b["line"]:
                continue
            if frac(a["r"], b["r"]) >= MIN_FRAC:
                issues.append(("T-T", a["c"] + "|" + b["c"], [round(a["r"].x0), round(a["r"].y0)]))
    # T-G
    for d in page.get_drawings():
        rr = d["rect"]
        if rr.width > W * 0.97 and rr.height > H * 0.9:
            continue                                   # page background
        filled = d.get("fill") is not None
        stroked = d.get("color") is not None and (d.get("width") or 0) > 0
        for g in G:
            r = g["r"]
            if not (r & rr).is_empty or r.intersects(rr):
                if filled:
                    inside = rr.contains(r)
                    if not inside and frac(r, rr) >= MIN_FRAC and not (rr.width < 2 or rr.height < 2):
                        issues.append(("T-G fill", g["c"], [round(r.x0), round(r.y0)]))
                        continue
                if stroked:
                    for it in d["items"]:
                        pts = []
                        if it[0] == "l": pts = [(it[1], it[2])]
                        elif it[0] == "c": pts = [(it[1], it[2]), (it[2], it[3]), (it[3], it[4])]
                        elif it[0] == "re":
                            q = it[1]; pts = [(q.tl, q.tr), (q.tr, q.br), (q.br, q.bl), (q.bl, q.tl)]
                        elif it[0] == "qu":
                            q = it[1]; pts = [(q.ul, q.ur), (q.ur, q.lr), (q.lr, q.ll), (q.ll, q.ul)]
                        # a stroked box that fully contains the glyph is a card outline, not a crossing
                        if it[0] in ("re", "qu") and rr.contains(r):
                            continue
                        if any(seg_hits_rect(fitz.Point(p), fitz.Point(q), r) for p, q in pts):
                            issues.append(("T-G line", g["c"], [round(r.x0), round(r.y0)]))
                            break
    # T-I
    for im in page.get_image_info():
        ir = fitz.Rect(im["bbox"])
        for g in G:
            if g["r"].intersects(ir) and not ir.contains(g["r"]) and frac(g["r"], ir) >= MIN_FRAC:
                issues.append(("T-I", g["c"], [round(g["r"].x0), round(g["r"].y0)]))
    # WRAP: headline = largest text in the top 26% of the page, >=20pt
    top = [g for g in G if g["r"].y1 < H * 0.26 and g["size"] >= 20]
    if top:
        mx = max(g["size"] for g in top)
        ys = sorted({round(g["y"]) for g in top if g["size"] >= mx - 0.5})
        rows = [y for k, y in enumerate(ys) if k == 0 or y - ys[k - 1] > mx * 0.5]
        if len(rows) > 1:
            issues.append(("WRAP", f"headline on {len(rows)} lines", None))
    # de-duplicate by kind+position
    seen, out = set(), []
    for k, c, pos in issues:
        key = (k, tuple(pos) if pos else c)
        if key in seen:
            continue
        seen.add(key); out.append({"kind": k, "glyph": c, "at_pt": pos})
    return out

def main():
    pdf = sys.argv[1]
    doc = fitz.open(pdf)
    report = {}
    for n, page in enumerate(doc, 1):
        iss = check_page(page)
        if iss:
            report[n] = iss
    total = sum(len(v) for v in report.values())
    for n, iss in report.items():
        kinds = {}
        for i in iss:
            kinds[i["kind"]] = kinds.get(i["kind"], 0) + 1
        ex = "; ".join(f'{i["kind"]} "{i["glyph"]}" @{i["at_pt"]}' for i in iss[:4])
        print(f"slide {n:>2}: {kinds}  e.g. {ex}")
    print(("FAIL" if total else "PASS") + f" — {total} overlap(s) on {len(report)} of {len(doc)} slides")
    if "--json" in sys.argv:
        json.dump(report, open(sys.argv[sys.argv.index("--json") + 1], "w"), indent=1)
    sys.exit(1 if total else 0)

if __name__ == "__main__":
    main()
```