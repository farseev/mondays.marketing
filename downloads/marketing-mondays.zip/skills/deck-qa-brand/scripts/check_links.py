#!/usr/bin/env python3
"""
check_links.py — automated clickability gate for a generated deck.

Turns deck-qa checklist item C5 ("references are actually-clickable hyperlinks,
not styled plain text") into a script that cannot be eyeballed away.

Scans every visible URL and email in the PPTX and FAILS if any of them is not
backed by a real external hyperlink relationship. Optionally cross-checks the
sibling PDF's link annotations.

Usage:
    python3 check_links.py deck.pptx [--pdf deck.pdf]

Exit 0 = PASS, 1 = FAIL (prints a defect list).
"""
import sys, re, argparse, zipfile

URL_RE = re.compile(
    r'(?:https?://[^\s<>"]+'
    r'|(?<![@\w])(?:[a-z0-9-]+\.)+(?:com|net|org|io|ai|gov|edu|co|app)(?:\.[a-z]{2})?(?:/[^\s<>"]*)?)',
    re.I)
EMAIL_RE = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')

def _slides(z):
    return sorted((n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)),
                  key=lambda n: int(re.findall(r'\d+', n)[-1]))

def _text(xml):
    return " ".join(re.findall(r'<a:t>([^<]*)</a:t>', xml))

def _targets(z, slide_name):
    rels = "ppt/slides/_rels/" + slide_name.split("/")[-1] + ".rels"
    if rels not in z.namelist():
        return []
    r = z.read(rels).decode("utf-8", "ignore")
    return re.findall(r'Target="([^"]+)"\s+TargetMode="External"', r) + \
           re.findall(r'TargetMode="External"\s+[^>]*?Target="([^"]+)"', r)

def _norm(t):
    return t.lower().replace("mailto:", "").replace("https://", "").replace("http://", "").rstrip("/")

def check_pptx(path):
    z = zipfile.ZipFile(path)
    defects = []
    tokens = 0
    links = 0
    for sn in _slides(z):
        xml = z.read(sn).decode("utf-8", "ignore")
        text = _text(xml)
        targets = [_norm(t) for t in _targets(z, sn)]
        links += len(targets)
        found = set()
        for m in EMAIL_RE.findall(text):
            found.add(("email", m.strip()))
        # remove emails from text so their domains aren't re-counted as bare URLs
        clean = EMAIL_RE.sub(" ", text)
        for m in URL_RE.findall(clean):
            found.add(("url", m.strip().rstrip('.,);:')))
        for kind, tok in found:
            tokens += 1
            nt = _norm(tok)
            if not any(nt in tg or tg in nt for tg in targets):
                defects.append((sn.split('/')[-1], kind, tok))
    return defects, tokens, links

def check_pdf(path):
    try:
        from pypdf import PdfReader
    except Exception:
        return None
    uris = []
    for i, pg in enumerate(PdfReader(path).pages, 1):
        for a in (pg.get("/Annots") or []):
            o = a.get_object()
            if o.get("/Subtype") == "/Link":
                u = (o.get("/A") or {}).get("/URI")
                if u:
                    uris.append((i, str(u)))
    return uris

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx")
    ap.add_argument("--pdf")
    a = ap.parse_args()
    defects, tokens, links = check_pptx(a.pptx)
    print(f"[links] visible URL/email tokens: {tokens} | external hyperlink rels: {links}")
    if a.pdf:
        uris = check_pdf(a.pdf)
        print("[links] PDF clickable annotations: " + ("(pypdf unavailable)" if uris is None else str(len(uris))))
    if defects:
        print(f"FAIL — {len(defects)} visible link(s) are plain text with no hyperlink:")
        for slide, kind, tok in defects:
            print(f"   - {slide}: {kind} '{tok}' is not clickable")
        sys.exit(1)
    print("PASS — every visible URL/email is a real clickable hyperlink.")
    sys.exit(0)

if __name__ == "__main__":
    main()
