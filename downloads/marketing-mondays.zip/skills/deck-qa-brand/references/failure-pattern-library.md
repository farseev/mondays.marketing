# Failure-Pattern Library

Real defects caught in deck engagements, kept so the next QA pass knows exactly what to look for. Grouped by the core family that catches each. Add new patterns as they are found.

---

## Family C1/C2/C3 — stale hardcoded content (the largest class)

Shared root cause: a value was hardcoded into the builder instead of read from source data, and the deck was then reused for another market — so the literal survived unchanged and went stale. A builder has **data-driven** slides (read from a data file, adapt automatically — low risk) and **hardcoded literals** (typed into the builder — high risk, invisible until QA). String-patching a deck for a new market does not touch literals a patch script misses.

- **Pattern 1 — hardcoded summary statistics.** A one-page-read slide showed the same three stats on three decks for three different markets. The stats were literals; the patch updated competitor names but not the numbers. Caught by C1: every headline stat must match the detail slide that derives it.
- **Pattern 2 — hardcoded brand/context copy.** A brand-position slide carried another market's ambassadors, brand-voice line, competitor list and citation IDs. Caught by C3: read every proper noun, ask "does this belong here?".
- **Pattern 3 — hardcoded persona name.** The persona slide showed the same persona name on every deck. Caught by C2: the persona name must equal this deck's persona theme title.
- **Pattern 4 — hardcoded count.** "21 studies" printed on decks whose runs had 17. Caught by C2: every count checked against the registry.
- **Pattern 5 — stale closing phrasing.** Closing slides named the first market's strategic territory. Caught by C3: read closing-slide theme language against this deck's territory.
- **Pattern 6 — stale internal numbering.** Builder slide-comments ran 1–19 then 29–33 while the deck rendered 30 slides — a reliable signal the deck was copied without cleanup; wherever seen, expect Patterns 1–5 nearby.

## Family C4 — chart label contradicts the data

- **Pattern 7 — status label vs line direction.** A trend slide labelled a series "Rising" while its line visibly fell across the windows. The status label was assigned independently of the plotted data. A status label is a *claim about the data* — QA confirms each label is true of its line. Also covers: legend colour not matching the series; status-row colour chip not matching the line it refers to.

## Family C5 — references and links

- **Pattern 8 — URLs not clickable.** The deck cited SOMIN insights, but the URLs were rendered as plain text, not live hyperlinks. The brief required every referenced insight to be reachable by its URL. C5 checks presence AND clickability — a printed-but-dead URL fails.
- **Pattern 9 — post references not specific.** Post-level references pointed at a workspace or were missing, instead of resolving to the specific post (with its visual where layout allows). C5 checks that a post reference resolves to that post.
- **Pattern 10 — foreign-market reference IDs.** A citation line carried another market's study/cohort IDs. Caught by C5 + C3.

## Family C6 — brand identity

- **Pattern 11 — wrong logo/wordmark colour.** The "S O MIN" wordmark was rendered in a single flat colour instead of its two tonal groups ("S O" teal #2DBF9C, "MIN" #16201F on light / #FFFFFF on dark). The brand spec defines the wordmark as two tonal groups in one mark; rendering it flat breaks brand identity.
- **Pattern 11b — wrong wordmark spacing.** The "S O MIN" wordmark was rendered with the letters set tight, or with the "S O" and "MIN" groups jammed together, or as the string "SOMIN" with no spaces. The wordmark has two mandatory spacings — wide inter-letter tracking AND a gap between the two tonal groups. In PPTX this means `charSpacing` set on the runs and the mark split into two text runs ("S O " + "MIN"); a plain `addText("S O MIN")` with no `charSpacing` renders wrong. C6 checks both colour AND spacing, on a light slide and a dark slide.
- **Pattern 12 — inconsistent category colour-coding.** A recurring category (a whitespace verdict, a pillar) appeared in different colours on different slides, or two categories shared one colour, or a category's label changed between slides. The brief explicitly required one consistent colour + unambiguous label per category everywhere. C6 checks colour-coding consistency across the whole deck.

## Family C7 — layout

- **Pattern 13 — text overflow.** Body text on a slide ran past the slide edge / outside its frame. Only visible in the render. C7 checks every slide for overflow, overlap and truncation.
- **Pattern 14 — empty or filler slides.** Slides padded with too little content where the brief asked for combined, fuller slides. C7 checks for filler and combinable slides.
- **Pattern 14b — chart axis maximum hardcoded below the data.** A line/bar chart's axis maximum was a fixed literal in the builder (e.g. `valAxisMaxVal: 60`) while the deck's data ran higher (e.g. peaks of 81% and 96%). The lines shot off the top of the chart and reappeared — peaks invisible, and the C4 label-vs-line check impossible to verify. This is a hardcoded-literal defect: the axis max fit whichever deck it was first written for and clipped every later deck whose data ran higher. Caught by C4. The fix is NOT to bump the literal to a bigger number — it is to compute the axis maximum from the data (largest series value + ~15% headroom) so it adapts per deck. Bumping the literal fixes one deck and leaves the next to clip again.

## Family C8 — data-object fidelity

- **Pattern 15 — platform object shown without its real fields.** SOMIN propositions were listed by name only; the proposition object's own defining fields were dropped or replaced with invented copy. When the deck presents a platform object, it must show that object's actual fields, retrieved from the API. C8 checks each presented object against the real record. The remedy is to re-fetch the object and render its true fields — never invent or omit the defining content.

## Family C9 — tone

- **Pattern 16 — buzzword copy.** Hype filler instead of the register an MNC marketing manager expects. C9 checks tone.

---

## The QA takeaway

If a deck was adapted from another deck, assume the C1–C3 patterns are present until each is checked off. But the C4–C9 patterns are NOT adaptation-specific — a brand-new deck can still ship a mislabelled chart, a dead link, a flat logo, an overflowing text box, or a proposition with no real fields. The core checklist runs in full on every deck for that reason. The builder-level prevention (make slides read from data, derive labels from data, emit real hyperlinks, render the logo from the brand spec, pull real object fields) is the durable fix; until every builder does all of that, QA is the gate that catches what the builder still gets wrong.
