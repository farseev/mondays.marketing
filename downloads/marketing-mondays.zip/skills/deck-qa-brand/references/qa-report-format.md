# QA Report Format

The QA pass produces one verdict per deck. Keep it short — the verdict line plus the defect table is the whole deliverable.

## Verdict line

```
QA — <deck name>
Configuration: <single | multi-deck N of M> · <influencer cohort: yes/no> · <extra workspaces: yes/no> · <adapted-from: <source> | built fresh>
Sections run: CORE (C1–C9) + <A/B/C/D/E as applicable>
Checks skipped: <none | list, with reason — e.g. "C5 links: reference list not provided">
VERDICT: PASS  (or)  FAIL — <N> defect(s)
```

- **PASS** — every applicable checklist item passed. The deck is deliverable.
- **FAIL** — one or more defects. The deck is NOT deliverable; it returns to the builder, is rebuilt, and is re-QA'd from the top.

There is no "pass with notes". A defect is a defect.

## Defect table

One row per defect:

| # | Slide | Family | What is wrong | Correct value / spec | Fix |
|---|-------|--------|---------------|----------------------|-----|
| 1 | 2 | C1 | Headline stat 50%; deck has no 50% theme | 55% — largest theme in whitespace data | Re-derive slide-2 stat from whitespace data |
| 2 | 9 | C4 | "Rising" label on a line trending down | Line falls W1→W6 → label "Falling" | Derive status label from the series' actual trend |
| 3 | 6 | C5 | Insight URL is plain text | Must be a clickable hyperlink to the study | Make the reference a live hyperlink |
| 4 | 1 | C6 | "S O MIN" wordmark in one flat colour | "S O" #2DBF9C, "MIN" #16201F/#FFFFFF | Render the wordmark in its two tonal groups |
| 5 | 11 | C7 | Body text runs past slide edge | Text within margins | Reduce text or resize the box |
| 6 | 20 | C8 | Propositions shown by name only, real fields dropped | Show the proposition object's actual fields | Re-fetch proposition objects; render their real fields |

Columns:
- **Slide** — slide number as rendered.
- **Family** — which core family (C1–C9) or conditional section (A–E) caught it.
- **What is wrong** — the defect as it appears.
- **Correct value / spec** — what the source data or brand spec says it should be. If the source was unavailable, say so.
- **Fix** — the specific change. Prefer "read from <data file>" / "derive from <data>" over "change the literal" — a literal wrong once goes stale again.

## After a FAIL — the rebuild loop

A FAIL verdict is not the end of the QA pass. It starts the Step 6 rebuild loop (see SKILL.md):

1. The deck is blocked from delivery until it passes.
2. Every defect is fixed at the **source data or builder code** — never by hand-editing the rendered file or patching a lone literal.
3. The deck is **rebuilt end to end** from corrected source.
4. The **FULL checklist re-runs from the top** — every core family and conditional section, not only the failed items. A fix routinely introduces a new defect (correcting a stat but leaving its caption stale; widening an axis so it overflows its frame; relinking a URL so layout shifts).
5. A fresh verdict is issued. The loop repeats until the verdict is PASS.

Do not report a deck as done while any verdict in this conversation is still FAIL.

## Multi-deck runs

One verdict block per deck, then a cross-deck line:

```
CROSS-DECK: <PASS — no shared content except where data coincides | FAIL — decks X and Y share <item> without a data basis>
```

Each deck runs its own rebuild loop and must individually reach PASS before the set is delivered.
