# Brand Deck Blueprint — Cross-Market Briefing Slide Architecture

The BRIEFING variant: posture is **rigour + audience**. Slide count ~38 including section dividers (31 content slides), flexing with influencer presence and interval per the adaptive-sizing rules at the foot of this file. Structural choices that distinguish the briefing from a generic deck are tagged **[BRIEFING]**.

Read this when assembling via `scripts/build_deck.js`. **The builder is brand-agnostic and data-driven** — it reads `brand.json` (identity + palette: `brand.colors.*`, pillar/verdict colours `brand.category_colors.*`), `scope.json`, and the analysis JSONs from the working directory and hardcodes no client; bespoke copy is data-derived with an optional `brand.narrative` override. The exact inputs and override keys are in `references/data-contract.md`. (The palette shorthand in the constants list below maps to those `brand.colors.*` keys.) For the agency PITCH structure (~16–20 slides, big-idea-first, IDs suppressed) see `somin-agency-deck` (separate SOMIN skill, if installed).

## Ordering principle, v2 — setup, then diagnosis, then audience, then engine

**This supersedes an earlier "personas lead the whole deck" design.** The original principle (still recorded in this file's history) was: set the wider lens first, then lead with personas, then move to tensions/whitespace/engine. A client explicitly asked for a different sequence and, on review, confirmed it should become this template's default — not a one-off override. The new sequence is:

**Setup & Method → Whitespace & Trends (the diagnosis) → selection logic (prioritisation) → The Audience (personas) → The Engine (permission/integration/chains/propositions) → Calendar & Execution → Proof & Recommendations.**

Two concrete changes from the old default:
1. **Method Notes and Additional Content Territories moved from the LAST two appendix slides to the FIRST two slides after the hero.** A reader sees how the briefing was produced — what SOMIN measures, the trend/whitespace method, the audience panel disclosure, and adjacent content ideas — before any analysis, not buried at the back where only a determined reader finds it.
2. **Personas moved from leading the whole deck to leading only the Engine section.** Whitespace and trend analysis now run first and surface the pillars; personas are introduced right before those pillars turn into an insight chain, so a persona is attached to a tension the reader has already seen matters — not asserted up front, before there's a tension to hang it on.

**Why this is a considered default and not a silent override:** the old principle's argument — "a market leader who has never seen this work must be able to follow it" — still holds; what changed is which lens does that job. Under v2, Setup & Method (audience defined, competitive landscape, product reality, the five-layer method) is what orients a first-time reader, not personas. Personas still organize the Engine section internally: **persona → tension → post evidence**, never a wall of disconnected tensions — that part of the old principle is unchanged, it now just applies to one section instead of the whole deck.

**If a future engagement asks for the OLD personas-first order instead:** that is a legitimate, different default — don't silently pick one. Ask the client which they want (as was done here) and record the answer; do not assume v2 fits every engagement just because it is now the template default.

**Section dividers (now 6, was 5).** `build_deck.js` groups the deck into 6 named parts and inserts a full-bleed dark title card before each (default ON — see SKILL.md → "Deck structure"): "Setup & Method" (before the audience-defined slide), "Whitespace & Trends" (before the whitespace cross-check — covers whitespace, trend and the prioritisation/selection-logic slide), "The Audience" (before persona commons — new in v2, replacing the old "Audience & Evidence" divider now that personas no longer lead), "The Engine" (immediately before Brand Permission, reinforcing the Brand-permission-leads-the-engine guardrail below), "Calendar & Execution", "Proof & Recommendations". These boundaries are load-bearing — if you restructure a section in this file, update `sectionDivider()`'s call sites in `build_deck.js` to match (including each call's `total` argument, now 6), so the divider titles never describe a section that no longer starts where the divider sits. `build_deck.js` also carries a short ordering-note comment block right before its first slide — keep that comment in sync with this section if the order changes again.

## Section 0 — Orientation + provenance (slides 1–3) [BRIEFING: how this was made, before any analysis]

| # | Title | Content |
|---|---|---|
| 1 | Hero / Title (dark surface) | Cover + workspace ID(s) + date + the **one-line cross-market synthesis** that ties the markets together (e.g. "owns the table — now the kitchen"). The unifying thread is stated up front, not left implicit. |
| 2 | Method notes [BRIEFING — moved here in v2] | "How to read this briefing" — what SOMIN measures, trend windows, whitespace method, noise handling, sources. **When `scope.influencer_panel.profile_names` is populated, an "Audience panel" row discloses the full named creator/influencer list** (count + names + workspace ID) — answers "which creators did you actually analyze?" and must never be silently omitted when a named panel exists; omitted entirely (not a placeholder) when no panel was used. Formerly the last appendix slide — now the second slide in the deck, per the *Ordering principle, v2* above. |
| 3 | Additional content territories [BRIEFING — moved here in v2] | More content suited to the brand + audience, drawn from `brand.offerings`. Formerly the second-to-last appendix slide; moved forward alongside Method Notes. |

## Section 1 — Setup & Method (slides 4–11) [BRIEFING: orients the reader before any diagnosis]

| # | Title | Content |
|---|---|---|
| 4 | The audience, defined [BRIEFING] | Plain-language definition of the target audience — what "Foodies"/"Adventurers" means here — with the SOMIN measurement caveat (this is content made *for* that audience, not the audience itself). |
| 5 | The competitive landscape, market by market | Who the brand is up against in each market. |
| 6 | Three-stat one-page read | 3 bold stats summarising the diagnosis. **Each stat read at build time from `whitespace.json`/`trends.json` — never hardcoded.** Must equal the figures on the detail slides for the SAME market. |
| 7 | Method / Five layers | PRODUCT / CONTENT / TREND / WHITESPACE / INSIGHTS. The systematic method is part of the credibility argument for a skeptical buyer. |
| 8 | Client's product reality | From `brand.offerings` + RTBs. |
| 9 | Content proof wall | Top organic post per window (N rows = N windows, max 12) — real posts inline. |
| 10 | Breakout case study | Top-engagement post with stats + clickable post URL. |
| 11 | Why we look at creators / how we read the market [BRIEFING] | Explicit rationale: competitors are tracked for **parity**, creators (if an influencer workspace exists) are watched for **differentiation** because they pick up and drive trends first. If no influencer workspace, this becomes a short "how we read the market" note. |

**Website/owned-journey thread is category-conditional [BRIEFING].** For low-involvement (FMCG) clients, do NOT add a brand-site/traffic-analysis slide — nobody visits the site and performance marketing routes straight to sale. Include an owned-journey slide ONLY for high-involvement categories (autos, considered purchases).

## Section 2 — Whitespace & Trends: the diagnosis (slides 12–16) [BRIEFING, v2: whitespace and trend now run BEFORE personas]

| # | Title | Content |
|---|---|---|
| 12 | Whitespace cohort cross-check | Dual/triple **proportional** charts; **share-of-voice**, never raw counts. |
| 13 | Whitespace 6-verdict map | BLOCKED / CONTESTED / WHITESPACE / AUDIENCE LEFT / PARTIAL / EMERGING. Brand-LOW alone is NOT whitespace — see `whitespace-analysis`. |
| **13B** (INFLUENCER ONLY) | Topicality alert | Live-30D creator signals. |
| 14 | Trend 6-status matrix | (interval ≥90d) Statuses computed from the data. A FALLING row carries its **prior-year verification status** — never an unverified single-cycle decline shown as fact. |
| 15 | Trending tensions over time (primary) | Line chart; status labels derived from the series; prior-year-verified. |
| **15B** (INFLUENCER ONLY) | Audience-directed content trend | Parallel chart for the creator cohort. |
| 16 | Where to invest first — selection logic [BRIEFING] | **Single ranked list**, one row per pillar (verdict chip + tension note), sized dynamically to `pillars.length`. This merges what used to be two separate slides — "market prioritisation by whitespace size" and "whitespace strategic frame" — which showed the SAME pillars/verdicts twice in a row; the old strategic-frame card grid also hardcoded exactly 3 fixed-width columns, a real bug for any pillar count other than 3. One ranked list replaces both. **This merge applies to the single-market builder only.** A multi-market *cross-market summary* deck still needs its own strategic-frame slide — but per-market, never one shared pillar (N columns, one real lead pillar each — see SKILL.md → Multi-market runs). |

## Section 3 — The Audience: personas (slides 17–19) [BRIEFING, v2: personas now lead only THIS section, not the whole deck]

Personas are introduced here, immediately after the diagnosis has surfaced the pillars — not at the front of the deck. Personas remain the organizing layer *within* this section and the Engine section that follows: **persona → tension → post evidence**, never a wall of disconnected tensions.

| # | Title | Content |
|---|---|---|
| 17 | Persona commons | Dominant persona per window; personas are the organizing layer. |
| 18 | Persona → tension map [BRIEFING] | One persona maps to MANY tensions (one-to-many), ordered **persona → tension → post count**. This is the entry to the permutation engine — not a flat tension list. |
| **18B** (INFLUENCER ONLY) | Content made for the audience | Top tensions in the creator cohort vs brand+comp, at shared scale. |
| 19 | Tension commons | Tensions across windows, hung off their personas. |

## Section 4 — The Engine: permission, integration, chains, propositions (slides 20–25) [BRIEFING]

**Ordering guardrail — Brand permission OPENS this section, before integration/chains/propositions.** It has drifted in at least one engagement build (ended up re-grouped with the persona/proposition slides much later in the deck, after an ad hoc edit merged the prioritisation and strategic-frame sections and shuffled Brand Permission along with it). Brand permission answers "why does the brand get to say this at all" — it has to land before the reader sees the engine's output (chains, propositions), not alongside it. If you ever hand-edit `build_deck.js`'s section order for one engagement, verify Brand Permission is still the FIRST slide of this section — don't just check that it exists somewhere in the deck.

| # | Title | Content |
|---|---|---|
| 20 | Brand permission [BRIEFING] | Why the brand credibly belongs in the chosen space — and any reason the category has avoided it (e.g. cultural-sensitivity risk). Competitor absence is NOT automatic permission. |
| 21 | Integration with existing effort [BRIEFING] | How the recommendation EXTENDS what the brand already publishes — a continuation, not a from-scratch plan. |
| 22–24 | Three insight chains, shown as LAYERS | PERSONA → TENSION → ANGLE → INSIGHT story. Persona names + theme IDs are KEPT and shown (traceability is part of briefing credibility). The one-persona-maps-to-many-tensions permutation is made explicit. |
| 25 | Editorial pillars + proposition plates | Pillar split + every proposition. Card body = the proposition's `name` field (the full SOMIN-generated statement). Never the `focus` seed alone; never a bare "Proposition {id}". All N propositions shown. |

## Section 5 — Calendar + wireframes (slides 26–31ish, varies with publishWeeks)

| # | Title | Content |
|---|---|---|
| 26 | Publishing calendar matrix | `publishWeeks` × `cadence`; each cell shows its moment ID. |
| 27+ | Per-pillar wireframes | 4-up post mockups; each card = thumbnail + brief fields + moment/trigger ID badge. Card count across slides = posts in the matrix. |

## Section 6 — Closing (slides ~28–31) [BRIEFING: evidence before recommendations]

| # | Title | Content |
|---|---|---|
| n | Organic vs paid | Where paid pushes vs. where organic carries alone — sets up the depth read. |
| n+1 | Engagement + share-of-voice depth | **Share-of-voice + engagement**, not raw post counts — who is under- vs over-indexing. |
| n+2 | Recommendations | Prioritised list. **No "how much effort / level of investment" proposal slide** — the client does not want it; it is removed from the briefing. |
| n+3 | Audit trail | Every SOMIN ID across both workspaces — full traceability is kept in the briefing. When an influencer/creator panel was used as evidence, the audit-trail note also points to its full named disclosure in **Method Notes (slide 2, near the front — not the appendix, per v2)** — the panel is core evidence, never an unnamed black-box "content proxy". |

## Appendix (after the closing section — Creative Library only, per v2)

| Slide | Content |
|---|---|
| Appendix divider | Full-bleed dark title card, now scoped to just the creative library ("The full creative library rendered from this briefing's insight chains") — Method Notes and Additional Content Territories no longer live here; see Section 0. |
| Creative library (if `creative-expressions` ran) | Grouped grid per pillar × TOFU/MOFU/BOFU, appended by the `creative-expressions` engine — not the legacy in-builder 3-column grid, which is permanently disabled in `build_deck.js` (single source of truth for expressions is the engine; see SKILL.md Step 12B). |

## Layout constants (consumed by build_deck.js)

- Slide size: 13.333 × 7.5 (WIDE)
- Headline font size: 22pt for normal, 28–40 for hero/promise
- Body: 9.5–10pt
- ALL CAPS section labels: 11pt with charSpacing 3
- Dark surfaces (slides 1, 7, 14, 31): use `brand.palette.dark_utility`
- Light surfaces (everywhere else): `brand.palette.neutral_light` (typically white)
- Accent rules and stat numbers: `brand.palette.primary`
- Reserved footer band: the footer + page number occupy a strip at the bottom of every slide (`FOOT = 6.9`, i.e. y ≈ 6.9–7.5). All body content, captions, footnotes and the last row of any card grid MUST clear it — size grids and place footnotes against the band's top edge, not the slide edge. `deck-qa-brand` C7 fails footer collisions.

## Numeric consistency rule

Any slide that displays a literal number — summary stats, footprint stats, headline figures — must derive that number from an analysis JSON at build time. The detail slides (whitespace bars, verdict map, cohort cross-check) and the summary slides draw on the same data and MUST agree. After every build, cross-check summary figures against detail figures for the same market. A hardcoded literal will survive market-to-market template reuse and silently go stale — this is a known, repeated failure. See `../SKILL.md` → Common failure modes.
- Charts: `brand.palette.primary` + `brand.palette.secondary` as bar fills

## Visual rules — non-negotiable

1. The whitespace cohort cross-check slide (12 in the current single-market numbering) MUST use proportional layouts when sample-size disparity >5x — see whitespace-analysis skill's sample-size-honesty.md
2. The audit trail slide (last slide before the Appendix divider) MUST cite every SOMIN ID used (across BOTH workspaces if influencer present). Hyperlink only the classes that have a public SOMIN URL — workspace, study, story; show product, proposition, moment, persona, tension, angle and character IDs as plain, workspace-traceable IDs (no per-object public URL exists). Do not caption plain IDs as live links.
3. Wireframe thumbnails MUST cite their moment + trigger ID badge
4. Calendar matrix MUST show `cadence` posts/week × `publishWeeks` consistently
5. The number of wireframe cards across the per-pillar wireframe slides MUST equal posts in the calendar matrix
6. The influencer-only "audience-directed content trend" companion slide (15B) MUST be visually parallel to the primary trend line chart (15) — same axes, same time labels, only data differs — so the lag pattern is visible
7. Every chart's series status label (Rising / Falling / Sustained / etc.) MUST be computed from that series' actual values — never assigned independently. The label, the colour chip and the line must all agree.
8. Every slide that cites a SOMIN insight/study/story/post MUST carry the reference as a real clickable hyperlink (not plain text); post references resolve to the specific post, with its visual where layout allows.
9. The **"SOMIN" wordmark** (it appears two-tone in the footer "Prepared with SOMIN"; the slide *header* carries the **client** brand wordmark) MUST render as a single word in two tight tonal groups ("SO" teal #2DBF9C + "MIN" #16201F on light / #FFFFFF on dark) — never one flat colour — joined, with NO space and NO wide tracking — in PPTX, two text runs "SO"+"MIN" with no space and small `charSpacing` (~0.3). Never write "S O MIN" or space the letters out. See the `somin-brand-guideline` skill and `assets/wordmark-spec.md`.
10. Every recurring category (whitespace verdict, pillar, trend status) MUST use ONE consistent colour and label across the whole deck. Define the colour map once; never let a category change colour between slides.
11. When a slide presents a SOMIN object (proposition, study, moment), it MUST show that object's real fields retrieved from the API — never invented content, never the defining fields dropped.
12. No text may overflow its box, overlap another element, or run past the slide edge — verified on the rendered PDF, not the builder source.

All twelve rules are verified by the `deck-qa-brand` skill at Step 13 before the deck is deliverable.

## Adaptive sizing summary

```
base_content_slides = 31   (v2 ordering — includes Method Notes + Territories, which used to be
                             unnumbered appendix extras and are now numbered slides 2-3)
+ 6 section dividers (Setup & Method / Whitespace & Trends / The Audience / The Engine /
  Calendar & Execution / Proof & Recommendations) -- default ON, scope.section_dividers:false to drop
+ 1 appendix divider (always emitted by build_deck.js; the creative-expressions engine appends
  the actual Creative Library slides after it, if that skill ran)
+ 3 if influencerWorkspaceId is provided (companion slides 13B + 15B + 18B)
- 1 if analysisIntervalDays < 90 (trend matrix slide replaced)
- 1 if analysisIntervalDays < 60 (trend chart slide replaced too)
+ 1 wireframe slide per additional 4 calendar posts above 39
```

`build_deck.js` alone (no influencer, no creative library) produces 38 slides for a standard single-market run: 31 content + 6 dividers + 1 appendix divider. Most engagements land between 36 and 42 slides from the builder, before any creative-expressions appendix is appended.
