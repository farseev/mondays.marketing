# SOMIN Schema Gotchas

Known discrepancies between SOMIN MCP tool descriptions and actual API behaviour. Update this file when new gotchas surface.

## propositions-create — `promotion` vs `promotions`

The `focus` parameter's keys are documented as:
```
product_features, promotions, rtb, usp
```

But the actual accepted keys are:
```
product_features, promotion, rtb, usp   ← singular "promotion"
```

If you pass `promotions` (plural), you get `Invalid focus type: promotions`.

**Workaround:** always normalise to singular before the call.

## moments-create — items returned per call

Each call yields ~5 trigger items for each (persona × tension) combination. If you pass 1 persona + 1 tension, expect 5 items. If you pass 2 personas + 3 tensions, expect 30 items.

**Implication:** for a calendar of 39 posts, plan moment-generation around the supply equation:
```
required_triggers = posts_per_week × weeks
supply = personas × tensions × moment_types × 5
moment_types_needed = ceil(required_triggers / (personas × tensions × 5))
```

Default mix of 3 moment types (life, seasonal, emotional) gives 15 triggers per (persona, tension). For 3 (persona, tension) chains that's 45 triggers — enough for 39 calendar slots.

## studies-create — async behaviour

A study takes 60–90 seconds to process. The MCP returns immediately with a study ID; you must poll via `SOMIN:studies-get` to read results.

**Workflow:** fire all monthly studies in parallel (don't wait between calls), then poll the full batch with a single `studies-get` call passing all 12 IDs.

## studies-get — partial results

If a study isn't done, `studies-get` returns it with `status: "pending"` or similar. Re-poll only the pending ones.

## product-create — profile linkage is one-way

Products attach to a profile, but the profile doesn't list its products. To enumerate products for a profile, use `products-list` filtered by the workspace, not by the profile.

## propositions-list — lists by workspace, and routing is not always obvious

`propositions-list` takes a `workspaceId` and returns the propositions whose product's profile lives in that workspace. A product created on a brand profile may surface under whichever workspace that profile is attached to — which can be a *different* workspace than the one you created the study or product call from. In a multi-workspace engagement (e.g. a brand workspace plus an influencer workspace), a proposition set can appear under the influencer workspace rather than the brand workspace.

**Workaround:** if `propositions-list` on the expected workspace returns `[]`, query the other workspaces in the engagement before assuming the propositions were not created. Record the proposition ID range at creation time (the `propositions-create` response) so you can verify by ID regardless of which workspace lists them.

## persona-create_characters — temperature variation

The character generation has high variance — same persona ID can produce subtly different characters across calls. If reproducibility matters, cache the character ID and reuse it across the engagement rather than regenerating.

## studies generationOptions — minClusters meaning

`minClusters: 3` is a floor not a ceiling. SOMIN may return more clusters; it won't return fewer (unless the corpus is too small to support 3 clusters, in which case it fails or returns a degraded study).

## concepts-search / posts-search — `clickability` requires ADS_LIBRARY + a date range

The `clickability` filter (High / Normal / Low predicted performance) is **paid-only**. It is rejected on organic content and rejected without a date window:
```
source: PAGES + clickability  -> "Clickability filter is not supported for PAGES source."
source: ADS_LIBRARY, no dates -> "Either datePreset, startDate, or both startDate and endDate must be provided."
```
**Workaround:** any clickability query MUST use `source: ADS_LIBRARY` **and** a `datePreset` (e.g. `LAST_90_DAYS`) or explicit `startDate`/`endDate`. There is no way to get a clickability signal for organic / PAGES content.

## concepts-search — results are absolute counts, not shares (rank by lift, not count)

`concepts-search` returns a raw **count** of ads per concept value within the filtered set, e.g. `[{"Informative":46}, ...]`. The High-clickability set is typically **far smaller** than the Low/baseline set (observed ~160 vs ~1,600 tag-instances), so the most *frequent* value in the High set is usually just the category default — not what drives clickability. Comparing raw counts is the clickability equivalent of the Breakdown-Effect trap.

**Workaround:** pull the same concept twice (`clickability:High` and `clickability:Low`), normalise each to **share-of-set**, and rank by **High-minus-Low lift (pp)**. Report differentiators (positive lift), never raw frequency. This is the same share-of-voice discipline the whitespace step already uses for cohorts.

## No creative ingest, no per-asset scoring, no owned-content upload via MCP

There is **no MCP endpoint** that (a) uploads/ingests an arbitrary image into a workspace as owned content, (b) creates an owned post, or (c) returns a predicted score for a specific generated creative. `SOMIN:image-generate` only returns a CDN URL — the image is **not** attached to any workspace or profile. `profiles-list` is read-only; there is no create-profile / add-media / add-content tool. "Owned content" is populated only by a connected profile's **published** posts.

**Implication:** you cannot "upload the deck's creatives into SOMIN for scoring." The legitimate uses of clickability are (1) **pattern extraction** — read the High-vs-Low patterns of the *existing* ADS_LIBRARY corpus and grade concepts against them (a proxy, not a per-asset score); (2) **publish-then-measure** — once creatives are published on a connected profile, the platform ingests them and clickability computes on the real assets. Never state or imply in a deliverable that generated creatives were scored in-platform unless they were actually published and ingested.

**Workspace naming:** there is often no single workspace literally named after the brand — e.g. SOMIN's own org exposes several (`SOMIN | Audience Research`, `SOMIN | Ads Optimization`, `SOMIN | Social Listening`). Resolve the intended workspace by **ID** via `workspaces-list`; never assume one canonical name.

## Why this file exists

The MCP tool descriptions are auto-generated from the API spec. When the spec drifts from reality, this file is the bridge. Update it when you hit something unexpected; don't assume the next person will hit the same bug.
