# Interval Splitting — Automatic Trend-Window Sizing

The orchestrator takes `analysisStartDate` and `analysisEndDate` and decides how to split that interval into trend windows for `SOMIN:studies-create`. This file documents the algorithm.

## Goal

Produce N windows where:
- N is between 3 and 12 (3 is the minimum for `trend-analysis` to detect a pattern; 12 is the cap to keep study count manageable)
- Each window is at least 21 days long (below that, themes don't stabilise — sample sizes drop too far)
- Windows are contiguous and non-overlapping
- The total spans the analysis interval

## Algorithm

```
interval_days = (analysisEndDate − analysisStartDate) in days

# Step 1: try monthly windows
target_count = round(interval_days / 30)
target_count = clamp(target_count, 3, 12)

# Step 2: check viability
window_size = interval_days / target_count
if window_size < 21:
    # interval too short for that many windows
    target_count = floor(interval_days / 21)
    target_count = max(3, target_count)
    if target_count < 3:
        # interval is genuinely too short for trend analysis
        SKIP_TREND = True
        do a single 90-day snapshot study only

# Step 3: compute window boundaries
window_size_days = interval_days / target_count
windows = []
for i in range(target_count):
    start = analysisStartDate + i * window_size_days
    end = start + window_size_days
    windows.append({start, end, label: "W{i+1}"})
```

## Cases this handles

| Interval | Days | Result |
|---|---|---|
| 30 days | 30 | SKIP_TREND — single 30-day snapshot study, no trend section in deck |
| 60 days | 60 | 3 windows × 20 days (borderline) — orchestrator may downgrade to a single 60-day snapshot |
| 90 days | 90 | 3 windows × 30 days |
| 120 days | 120 | 4 windows × 30 days |
| 180 days | 180 | 6 windows × 30 days |
| 270 days | 270 | 9 windows × 30 days |
| 365 days | 365 | 12 windows × ~30 days (~monthly cuts — the canonical case) |
| 540 days | 540 | 12 windows × 45 days (caps at 12) |
| 730 days | 730 | 12 windows × ~60 days (~bimonthly cuts) |

## Why 21 days minimum

SOMIN Perspective Studies need a minimum corpus to stabilise tension clusters. Below ~21 days, even a high-velocity influencer panel rarely produces enough posts (with applied filters) to hit 30+ items per study. Below 30 items, the cluster count collapses to 1–2 themes, which is too coarse to track over time.

## Why 12 maximum

Beyond 12 windows the trend chart in slide 11 becomes visually crowded (x-axis labels overlap), and the SOMIN compute cost per engagement grows linearly. 12 is the practical ceiling for client-readable line charts.

If the user has a 2+ year analysis interval and genuinely needs higher granularity, run the orchestrator twice (year 1, year 2) and merge the results manually, OR override to weekly cuts for a specific sub-period.

## When SKIP_TREND fires

If the interval is genuinely too short (≤ ~30 days), the orchestrator:
- Runs a single 30-day snapshot study instead of trend windows
- Skips Step 5 (trend analysis)
- The deck's trend section (slide 10–11) is replaced with a single "current state" slide
- Slide 13 (whitespace) still works — whitespace is snapshot-based, not time-series

This typically happens for campaign launches or event-window analyses where the user doesn't have a long history.

## Supply-math implications

Calendar supply (from moment-generation):
```
required_triggers = publishWeeks × cadence
supply = pillarCount × momentTypesPerPillar × 5
moment_types_per_pillar_needed = ceil(required_triggers / (pillarCount × 5))
```

For different publishing intervals:

| publishWeeks | cadence | required | pillars × types × 5 = supply | types needed |
|---|---|---|---|---|
| 4 | 3 | 12 | 3 × 1 × 5 = 15 | 1 type per pillar |
| 8 | 3 | 24 | 3 × 2 × 5 = 30 | 2 types per pillar |
| 13 | 3 | 39 | 3 × 3 × 5 = 45 | 3 types per pillar (canonical quarter) |
| 26 | 3 | 78 | 3 × 6 × 5 = 90 | 6 types per pillar — exhausts the 7-type catalogue |
| 26 | 5 | 130 | not feasible from 3 pillars | bump pillarCount to 4–5 or reduce cadence |

The orchestrator should check supply at Step 10 and either add moment types per pair or warn the user about cadence reduction.

## When publishing interval > analysis interval

Allowed. Common case: 90-day analysis interval feeding a 26-week (~6 month) publishing plan. The orchestrator does not require these intervals to match — they're independent.

What matters: analysis windows give the historical signal; publishing windows are forward-looking calendar slots.

## When publishing interval < analysis interval

Also allowed. Common case: 12-month trend analysis feeding a 4-week publishing burst. The full trend context informs which 4 weeks to bet on.
