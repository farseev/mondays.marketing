# Workflow Map — Skill Dependency Chain

> **Variant: BRAND / cross-market briefing.** The dependency chain below is the full SOMIN analysis, run in full. This variant *presents* all of it — persona-led, engine-as-layers, share-of-voice depth, brand-permission + integration beats, full audit trail (~32 slides). The analysis internals it calls are `insight-creation-brand`, `content-brief-brand` and `deck-qa-brand`; all other analysis skills (`trend-analysis`, `whitespace-analysis`, `moment-generation`, etc.) are shared and unforked. Trend directions are prior-year-verified before they reach a slide.

```
START: client name + URL + workspace IDs + profile IDs + publish interval
│
├─[1]─ brand-extraction-from-web ────→ brand.json
│
├─[2]─ Interval splitting (see interval-splitting.md)
│      analysisStartDate → analysisEndDate
│      → N trend windows (3 ≤ N ≤ 12; each ≥ 21 days)
│      → trend_windows.json
│
├─[3]─ SOMIN:studies-create × N ─────→ studies_primary.json
│      (one per window on primary workspace; async — fire all then poll)
│
├─[3B]─ IF influencerWorkspaceId provided:                          
│       SOMIN:studies-create × (N+1) → studies_influencer.json      
│       (N matched-window cuts + 1 live 30-day study for topicality)
│
├─[4]─ SOMIN:studies-get (batch all study IDs)
│
├─[5]─ trend-analysis (×1 or ×2)
│      → trends_primary.json
│      → trends_influencer.json (if influencer ws)
│      (See dual-cohort-trends.md for the 4-cell verdict matrix)
│
├─[6]─ SOMIN:studies-create × 2 or 3 → whitespace_studies.json
│      Cohort A: [brandProfileId] · 90D
│      Cohort B: [...competitorProfileIds] · 90D
│      Cohort C: influencerProfileIds · 90D + influencerFilters   ← IF influencer ws
│
├─[7]─ whitespace-analysis ───────────→ whitespace.json
│      (FULL coverage mode with 3 cohorts; PARTIAL with 2)
│
├─[8]─ insight-creation-brand × pillarCount → insights.json
│      (pick top tensions from whitespace + trends)
│      (each chain: char + persona + tension + angle + story)
│
├─[9]─ SOMIN:products-list/create +
│      propositions-create ──────────→ propositions.json
│      (story_ids × focus dimensions, using SINGULAR `promotion` key)
│
├─[10]─ SOMIN:moments-create × M ─────→ moments.json
│       (M = pillarCount × momentTypesPerPillar; supply math in interval-splitting.md)
│
├─[11]─ content-calendar-build ──────→ calendar.json
│       --weeks publishWeeks (derived from publishEndDate − publishStartDate)
│       --cadence cadence
│       --start-date publishStartDate
│       --pillar-weights (derived from whitespace verdicts)
│
├─[12a]─ content-brief-brand × N → briefs.json
│        (one call per calendar slot, consumes brand.json)
│
├─[12b]─ scripts/build_deck.js ──────→ strategy_deck.pptx ──→ .pdf
│        (consumes ALL JSONs above + brand.json)
│
├─[12c]─ IF Step 12B rendered a Creative-Library appendix:
│        SOMIN:posts-upload (image URL + hook) → poll SOMIN:posts-search
│        (source=OWNED; async, 10–30+ min) → flag clickability High ≥ 0.80
│        → scripts/score_annotate.py ──→ "Predicted performance" +
│        "Top performer potential" slides + tile badges
│        (SKIP the summary slide if 0 creatives reach ≥ 0.80; see the creative-scoring skill)
│
└─[13]── deck-qa-brand ───────────────────→ PASS / FAIL verdict
         (verifies the rendered deck against its source JSONs;
          FAIL → fix + rebuild from 12b → re-run deck-qa-brand)
              │
              ▼ (only on PASS)
         USER DELIVERABLE
         (deck + brand.json + all intermediate JSONs for audit)
```

## Branching: with vs without influencer workspace

```
Without influencer workspace:                With influencer workspace:
  - N trend studies on primary               - N primary trend studies
  - 2 whitespace cohort studies              - N + 1 influencer studies (matched + live 30D)
  - PARTIAL whitespace mode                  - 2 + 1 = 3 whitespace cohort studies
  - Single trend output                      - FULL whitespace mode
                                             - Dual trend output (primary + influencer)
                                             - 4-cell dual-cohort verdict logic
                                             - +3 deck slides (creator-content trend, 3-cohort whitespace, topicality)
```

## Data flow rules

- Every artefact is a JSON file on disk. Pass paths between steps, not contents.
- `brand.json` consumed by Step 1 (produces), 12a (briefs), 12b (deck builder)
- Studies are large — never inline. `studies_*.json` holds IDs + metadata; downstream calls `studies-get` on actual IDs
- `briefs.json` is the largest artefact. Each brief ~300 tokens × N posts

## Parallelisation opportunities

- **Step 3 + Step 3B:** fire ALL trend studies (primary + influencer if applicable) in one parallel batch
- **Step 6:** all whitespace cohort studies fire in parallel
- **Step 8:** the pillarCount insight chains can each run as a separate sub-orchestration
- **Step 10:** moment-generation calls are independent — fire all in parallel
- **Step 12a:** brief generation is the longest serial loop; consider batching by pillar

A 12-window primary + 12-window influencer engagement involves ~25 SOMIN studies. With parallel firing the wall-clock cost is ~90 seconds (one polling cycle) plus orchestrator overhead.

## When to skip steps

- Skip Step 1 if `brand.json` already exists in conversation context
- Skip Step 3 / 3B if studies already exist for the desired windows (call `SOMIN:studies-list` to check)
- Skip Step 9 if propositions already exist (call `SOMIN:propositions-list` filtered by product)
- Skip Step 10 if moments already exist (call `SOMIN:moments-list`)

The orchestrator should run a "what already exists" sweep at the start and produce a "resume from step N" summary before deciding what to build. This is critical when iterating on a deck — re-running upstream studies wastes SOMIN compute and time.

## Audit trail (final slide)

Must list:
- All study IDs (primary + influencer if applicable), with workspace labels
- All character IDs (one per pillar)
- All theme IDs (personas + tensions)
- All angle IDs and story IDs
- All product IDs and proposition ID range
- All moment IDs and trigger ID range

Format example for a dual-workspace engagement:

```
WORKSPACES
  Primary (brand + competitors):    1234 — N studies (IDs xxxx-yyyy)
  Influencer (audience proxy):      1235 — N+1 studies (IDs xxxx-yyyy)

INSIGHT CHAINS (3)
  Chain 01 · Music:   char 401 ← persona theme 10051 / tension theme 10052 / angle 501 / story 601
  Chain 02 · ... :    ...
  Chain 03 · ... :    ...

PRODUCT + PROPOSITIONS
  Products 91-92 (Music + Dance Programmes, profile 1111)
  Propositions 1301-1357 (30 total · 15/product × 3 stories × 5 focuses)

MOMENTS
  9 SOMIN Moments (IDs 701-709) · 45 timing triggers · across life / seasonal / emotional / micro / purchase types
  → Feed N-post calendar (cadence × publishWeeks)
```
