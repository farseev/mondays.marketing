# `build_deck.js` data contract

`scripts/build_deck.js` is **brand-agnostic and data-driven**. It hardcodes nothing about any
client: identity comes from `brand.json` + `scope.json`, every figure comes from the analysis
JSONs, and bespoke prose is **data-derived** with an optional `brand.narrative` override. The
same file is used for every engagement — only the JSON inputs change.

It reads these files from the **current working directory** (run it from the engagement dir):

```
brand.json  scope.json  studies_primary.json  trends_primary.json  whitespace.json
pillars.json  personas.json  paid.json  insights.json  propositions.json  calendar.json
```

Optional: `expr/` (9 PNGs `P{1,2,3}_{TOFU,MOFU,BOFU}.png` + `expr/expressions.json`) — if present,
3 Creative-Library appendix slides are added; if absent they are silently skipped.

No client example ships with this plugin. Every input file, key and type the builder reads is listed
below: create those JSON files for your engagement in one directory, then run `node build_deck.js`
from that directory to see the generic builder render.

---

## `brand.json` — identity (no narrative ⇒ a clean, generic deck still renders)

| key | type | used for |
|---|---|---|
| `brand` | string | the brand name shown everywhere (wordmark fallback, footer, S3 tile, audit) |
| `market` | string | market label (also resolvable from `scope`) |
| `colors` | object | `primary, deep_navy, midnight, action_blue, page_grey, ink, body, secondary, chrome, hairline` (hex strings, `#` optional) |
| `category_colors` | object | `P1, P2, P3` (pillar colours) and the verdict colours `WHITESPACE, PARTIAL, CONTESTED, EMERGING` |
| `wordmark` | object | `primary` (big word; defaults to `brand`), `sub` (small endorsement line), `dot_on_o` (bool — draws a lens-dot over the first “O”), `on_light`, `on_dark` |
| `offerings` | array | `[{name, note}]` — S6 product-reality tiles **and** the generic fallback for the appendix territories |
| `rtb` | array | strings — S6 reason-to-believe strip |
| `narrative` | object | **optional** copy overrides — see below |

## `scope.json` — engagement parameters (nested orchestrator shape OR flat keys)

The builder reads flat keys first, then falls back to the orchestrator's nested shape:

| flat key | nested fallback | used for |
|---|---|---|
| `workspace_id` | `markets[0].workspace_id` | study/story/workspace hyperlinks, hero, audit |
| `market` | `markets[0].name` | market label |
| `audience` | `audience_filter.values[0]` | the audience named throughout |
| `brand_profile_id` | `markets[0].brand_profile_id` | S3 brand tile |
| `whitespace_studies` | — | audit-trail row (omitted if absent) |
| `paid_study` | — | audit-trail row (omitted if absent) |
| `moments_range` | — | audit-trail row (omitted if absent) |
| `window_label` | — | hero window chip + scope box |
| `sources_label` | — | scope box (defaults to “Organic + paid”) |
| `output` | — | output `.pptx` path (defaults to `<Brand>_<Market>_Briefing.pptx`) |

## Analysis JSONs (figures — never invented by the builder)

- **studies_primary.json** — `trend_studies: [{id, label, n}]` (peak window = the one with max `n`), `competitors: [{name}]` (count drives “N competitors”).
- **trends_primary.json** — `labels: ["W1"…]`, `quarters: {W1:"2024 Q3"…}`, `axis_max`, and `series: { KEY: { name, values:{W1..}, trend:{status,start,end,peak,peak_window}, prior_year:{verdict}, color? } }`. `color` is optional per series; otherwise a cool palette is assigned in series order.
- **whitespace.json** — `themes: [{key,label,brand_share,comp_share,verdict,verdict_note}]` (+ optional `brand_n`,`comp_n`).
- **pillars.json** — `pillars: [{id:"P1", name, verdict, territory, tension, why_now, brand_permission, ws_basis}]`. Verdict’s first word drives colour + ranking (`WHITESPACE < CONTESTED < PARTIAL < EMERGING < BLOCKED`).
- **personas.json** — `primary:{name,definition,needs[]}`, optional `secondary`,`tertiary` `{name,definition}`.
- **paid.json** — `content_types:{ organic:{Type:count…}, paid:{Type:count…} }`.
- **insights.json** — `shared_character:{id,name,persona_theme,persona_title,shortDesc}`, `chains:[{pillar,pillar_name,verdict,tension_theme,tension_title,angle_id,angle_reason,angle_theory,angle_type,story_id,story_narrative_title,story_line,story_summary,engagement,media_refs,media_total}]`.
- **propositions.json** — `product:{id,name}`, `by_pillar:{ P1:{story_line, propositions:[{id,focusType,focus}]} … }`.
- **calendar.json** — `weeks:[{label, posts:[{day,pillar,slot,trigger_label,trigger_id,moment_id,date}]}]`, `summary:{total_posts,lead_posts}`, `metadata:{pillar_weights:{P1..}, start_date, cadence}`.

---

## `brand.narrative` — optional copy overrides

Every value below is **optional**. When absent, the builder uses a data-derived fallback (shown), so
a bare `brand.json` still produces a coherent, honest deck. Provide overrides to author the polished
voice. Values are plain strings unless a shape is given.

| key | controls | fallback when omitted |
|---|---|---|
| `synthesis` | hero headline | `"<Brand>: the strategic read."` |
| `synthesis_sub` | hero sub-line | derived from audience/market/competitor count |
| `hero_eyebrow` | hero eyebrow | `"Cross-market briefing · <Market> workspace #<id>"` |
| `window` | hero window chip | `scope.window_label` |
| `s2_headline` / `s2_measure` / `s2_caveat` | audience-definition slide | audience-interpolated defaults |
| `s3_headline` / `landscape_note` | landscape slide | `"<Brand> versus N <market> competitors…"` |
| `layer_product` / `layer_content` | S5 layer cards 1–2 | brand/market/count defaults |
| `s6_headline` | product-reality headline | `"<Brand> has the right to make every claim it makes."` |
| `s7_headline` / `s7_note` | content-by-quarter | audience defaults |
| `peak_headline` / `peak_rows` / `peak_note` | peak-quarter slide. `peak_rows` = `[[title, "N items"]…]` | headline + top-3 themes in the peak window (derived) |
| `s9_headline` / `s9_competitors` / `s9_supply` | how-we-read-the-market | brand/market defaults |
| `s10_headline` / `persona_recurs` | persona-commons | window-count default |
| `s11_headline` | persona→tension | static default |
| `s12_eyebrow` / `s12_headline` / `s12_note` | tension-commons | theme-count default |
| `s13_headline` / `s13_note` | trend matrix | static default |
| `s14_headline` | trend line | `"How the themes move over time."` |
| `ws_reads` | S15 read card. `[[label, "Brand x% vs y% — note"]…]` | derived from `whitespace.themes` |
| `s16_headline` / `s16_note` | whitespace verdict | brand defaults |
| `s17_headline` / `prioritisation` | prioritisation. `prioritisation` = `[{p, c, rankn, note}]` | pillars ranked by verdict (derived) |
| `s18_headline` | strategic-frame | pillar-count default |
| `s19_headline` / `s19_note` | brand-permission | brand defaults |
| `s20_headline` / `today_bullets` / `shift_bullets` | integration. bullets = `string[]` | `today` from top organic content types; `shift` from pillar names |
| `s24_headline` | propositions plates | `"<N> propositions — every pillar expressed several ways."` |
| `calendar_note` | calendar footnote | static default |
| `briefs` | S26 lead-post cards. `[{k:"P1",fmt,msg,cta,why}]` | derived from each pillar’s story line + its first calendar slot |
| `recommendations_headline` / `recommendations` | S29. `recommendations` = `[[title, body, colorHex]]` | pillars ranked by verdict (derived) |
| `depth_ws_keys` | S28 pillar→whitespace-theme mapping. `["CLIN","EDU","TRUST"]` | first 3 `whitespace.themes` keys |
| `territories_headline` / `extra_territories` | appendix territories. `[[title, note]]` | from `brand.offerings` |
| `method_notes` | appendix method notes. `[[title, body]]` | SOMIN-methodology defaults with real counts |
| `scope_box` | audit scope box. `[[label, value]]` | derived from scope + counts |

### Minimal example
```jsonc
// brand.json
{ "brand":"ACME", "market":"Robotics",
  "colors":{...}, "category_colors":{"P1":"#...","P2":"#...","P3":"#...",
    "WHITESPACE":"#...","PARTIAL":"#...","CONTESTED":"#...","EMERGING":"#..."},
  "wordmark":{"primary":"ACME","sub":"ACME ROBOTICS","dot_on_o":false},
  "offerings":[{"name":"...","note":"..."}], "rtb":["..."],
  "narrative":{ "synthesis":"Own the floor.", "recommendations_headline":"Do these three things." }
}
```

> **Multi-market note.** This builder renders one market. For a multi-market briefing, run it once per
> market (point `scope`/`brand` at each market’s JSONs and set a distinct `output`), or loop the
> per-market sections — the layout components are per-market and compose cleanly.
