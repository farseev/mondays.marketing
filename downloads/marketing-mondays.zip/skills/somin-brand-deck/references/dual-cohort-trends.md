# Dual-Cohort Trends — Brand-Published vs Creator-Published Content

When `influencerWorkspaceId` is provided, the orchestrator runs `trend-analysis` on BOTH the primary workspace (brand + competitors) AND the influencer workspace (a panel of creators publishing content for the target audience). The two trend outputs together reveal the lag pattern between what brands publish and what creators publish toward that audience.

## What each cohort actually is

SOMIN detects concepts **from content**. Both cohorts are content. Neither is the audience.

- **Brand+competitor trend** — what advertisers/marketers are publishing month-on-month.
- **Influencer/creator trend** — what creators are publishing *toward* the target audience month-on-month (content tagged to that audience). This is **content made for the audience**, NOT a record of what the audience consumed, said, or wanted.

Do not describe the creator cohort as "demand", "audience demand", or "what the audience is asking for". It is content supply from a different set of publishers. The honest framing throughout the deck is "content made for [audience]" / "[audience]-directed content".

## Why the dual signal still matters

Even though both cohorts are content, the contrast is genuinely useful. Brands and creators publish on different rhythms: brand/competitor content typically lags creator content by 2–4 months (0–2 for fast-moving brands). A theme RISING in the creator cohort but FALLING or LOW in the brand+comp cohort is **emerging whitespace** — a content territory creators are building toward that the category's brands have not yet entered.

This is a supply-vs-supply gap (two groups of publishers diverging), not a supply-vs-demand gap. The strategic conclusion — open editorial territory the brand can claim — is unchanged; the claim is just scoped honestly to content.

## The verdict cells

For each aligned tension, classify against BOTH content cohorts:

| Creator cohort | Brand+Comp cohort | Verdict | Action |
|---|---|---|---|
| RISING | LOW / FALLING | **EMERGING WHITESPACE** | Open content territory — brand can lead the category |
| RISING | RISING | CONTESTED-GROWING | Category catching up; differentiate hard |
| SUSTAINED | SUSTAINED | BLOCKED-COMMONS | Established commodity content territory |
| FALLING | RISING | LAGGED-COMPETITORS | Competitors over-investing in a fading content theme — exit cleanly |
| FALLING | FALLING | DECAYED | Both publisher sets walking away; no opportunity |
| SUSTAINED | LOW | UNDERSERVED COMMONS | Creators sustain it, brands don't — partial whitespace |

Most actionable: **EMERGING WHITESPACE** and **LAGGED-COMPETITORS**.

## What the "live" 30-day creator study adds

Beyond the matched-window cuts, the orchestrator runs ONE additional study on the creator panel: the last 30 days, narrowest possible. This catches:

- Cultural moments competitors haven't yet incorporated into their content
- Single-shot content signals that disappear within a month
- Content-theme shifts driven by current events

This becomes a "topicality" callout slide — what creators are publishing toward this audience RIGHT NOW. It does NOT claim to show what the audience currently wants; it shows what is currently being made for them.

## Engagement is the only audience-side signal

If a study surfaces views or engagement volume, that — and only that — is a genuine audience reaction. Even then it tells you only that a reaction of some size occurred, never who reacted, and never that the reaction came from the intended audience. A deck may say an audience "reacted" only when citing an engagement/view figure, and only as volume. Everywhere else, describe content.

## How the deck visualises this

Slide additions when the creator workspace is present:

- **Slide 8B**: "Content made for [audience]" — bar chart of top 5 tensions in the creator cohort vs the brand+comp cohort at the same scale (both cohorts are typically 100+ posts, so the disparity rule does not apply)
- **Slide 11B**: "[Audience]-directed content trend" — line chart for the creator cohort
- **Slide 12** (whitespace cross-check): a 3-cohort chart instead of 2-cohort
- **Slide 13B**: "Topicality" — the live-30D study; 2–3 RIGHT-NOW content signals not in the matched-window data

Chart titles and captions name **content**, never demand.

## Token note

The dual-cohort case roughly doubles the SOMIN study count (N primary + N+1 creator). The audit trail slide must list both workspaces clearly so the client knows which IDs belong to which cohort.
