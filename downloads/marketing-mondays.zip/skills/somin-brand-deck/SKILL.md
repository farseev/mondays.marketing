---
name: "somin-brand-deck"
description: "End-to-end orchestrator for a SOMIN brand BRIEFING deck: competitor creative diversity, whitespace-and-trend gate, insight chains, creatives on every calendar post, styled from the brand's organic timeline."
---

# SOMIN Brand Deck — Cross-Market Briefing Orchestrator

Chains every SOMIN analysis layer + brand extraction + calendar build + deck rendering into a single **cross-market briefing** for the brand/client. A successful run takes 20–60 minutes elapsed (most of it SOMIN study generation, which is async).

## Deck stance — this is the briefing, not the pitch

This variant produces the **brand-facing cross-market briefing**: the audience is the client and its market leaders, and the job is to help them decide *where to play across markets*. Its posture is **rigour + audience**, and that posture drives every structural choice below.

**Ordering, v3 (current default) — a main section that makes the case, and an appendix that proves it.** The reader gets the decision, the reason for it, and the executable plan in the main section; every supporting chart that repeats a point already made lives in the appendix. See **§ "Deck structure — v3"** below for the slide-by-slide order. This supersedes v2 (Setup & Method → Whitespace & Trends → prioritisation → Audience → Engine → Calendar → Proof, with six section dividers), which is described in `references/slide-blueprint.md` § "Ordering principle, v2" and **remains a legitimate opt-in** when a client explicitly asks for it — ask and record the choice (`scope.ordering: "v3"|"v2"`), don't silently pick one.

**Why v3.** A client reviewing a v2 briefing (a healthcare client, 2026) found it carried "tons of plots that repeat the same point" — five slides restated that one territory qualified, and the calendar, the creatives and the insight chain were separated from each other. v3 keeps the justification (competitor diversity, the three-cohort whitespace read, the trending-AND-whitespace gate, prioritisation) and the execution (chain → stories → creative → permission → integration → calendar with a creative on every post → briefs) together, and moves method, market sizing, trend lines, excluded territories, persona detail, proposition plates, brand rules, predicted performance, the full creative library and the audit trail behind an appendix divider.

- **Open with the competitor read, then the gate.** The first content slide after the hero is the competitor creative-diversity comparison (brand vs every competitor — see Step 12A), followed by the three-cohort whitespace read and the trending-AND-whitespace gate. Those three slides are the justification for the territory; the prioritisation slide then states the choice. Setup & Method material (audience definition, share of voice, product reality, method notes) moves to the appendix.
- **Show the engine as proof of coverage.** The persona→tension→angle→proposition chain is presented as layers — one persona maps to many tensions, each yielding different propositions — because the systematic permutation IS the credibility argument for a skeptical buyer. Personas remain the organizing layer *within* this section: persona → tension → post evidence, never a wall of disconnected tensions.
- **Carry the depth.** Share-of-voice + engagement (not raw post counts), prior-year verification on every directional trend, a brand-permission beat (why the brand credibly belongs in a space), an integration beat (how this extends what the brand already does), and a full audit trail. Everything traces to data.
- **Prioritise.** Rank markets by whitespace size rather than treating all markets as equal priority.
- **Keep provenance one click away, not in the way.** Method Notes open the appendix (first slide after the appendix divider), and the audit trail closes it. Under v3 they no longer sit in front of the analysis; under v2 they still do.
- **Execution is shown, not described.** Every calendar post appears with the rendered creative that runs on it; every story in the insight chain is shown with its creative; every pillar gets a slide of its strongest creatives per funnel stage.

For the agency **pitch** (single throughline, big idea first, activation-led, ~16–20 slides, IDs suppressed) use `somin-agency-deck` (separate SOMIN skill, if installed).

## When to call

- The brand/client wants a cross-market briefing or internal strategy deck
- The user names a client + workspace + asks for "the briefing", "the strategy", or "where to play"
- All preconditions exist: workspace ID, profile IDs for brand + competitors, a known time interval

**Don't call** for partial requests — if the user only wants the whitespace analysis, call `whitespace-analysis` directly. For an external agency pitch, use `somin-agency-deck` (separate SOMIN skill, if installed). This skill is the full briefing orchestration.

## What SOMIN measures — read this before writing any slide copy

SOMIN detects **concepts from content** — it classifies what posts are *about* and what audience they were *created for*. It does **not** observe the audience directly.

This has hard consequences for every word in the deck:

- An "audience" tag (e.g. "Foodies") is a property of the **content** — it means *content created for that audience by a creator or brand*. It is **not** a measured group of people, and it is **not** a record of what those people did, said, or wanted.
- Therefore the deck must **never** say "audience demand", "what Foodies want", "what the audience is asking for", "what Foodies talk about", "demand-side", or "consumers want". None of that was measured.
- The correct framing is **content supply**: "content made for Foodies", "Foodie-directed content", "what creators publish toward this audience", "the content focus". A trend chart shows how the *content mix* moved, not how *demand* moved.
- A whitespace "gap" is a **content-supply gap** — creators publish heavily toward a theme, cola brands do not — **not** an unmet audience demand. The strategic conclusion (open editorial territory) still holds; the claim is just honestly scoped to content.
- The **only** audience-side signal SOMIN has is **views and engagement volume**. Even that tells you only *that a reaction of some size occurred* — never *who* reacted, and never that the reaction came from the audience the content was built for. Only when citing a view/engagement figure may the deck say an audience "reacted", and only as volume.

When in doubt: describe what was *published*, not what anyone *wants*. The influencer/creator panel is a **content proxy** — a sample of content made for the target audience — never an "audience proxy" in the sense of the audience itself.

## Required inputs

1. `workspaceId` — primary SOMIN workspace (brand + competitors)
2. `brandProfileId` — the client's own profile
3. `competitorProfileIds` — list of competitor profile IDs (no upper limit; SOMIN handles 3–20+)
4. `clientWebsiteUrl` — for brand-extraction-from-web
5. `publishStartDate` — first calendar publish date (ISO, e.g. 2026-08-03)
6. `publishEndDate` — last calendar publish date (ISO); calendar week count derived automatically

## Optional inputs

- `clientScreenshot` — for pixel-accurate palette
- `analysisStartDate` — defaults to 12 months before `analysisEndDate`
- `analysisEndDate` — defaults to today
- `cadence` — posts per week, default 3
- **`influencerWorkspaceId`** — separate workspace of content-proxy profiles (e.g. an influencer/creator panel — a sample of content created for the target audience). When provided, the orchestrator runs parallel trend + whitespace cohort studies on this workspace for topicality and emerging content-trend signal.
- `influencerProfileIds` — required if `influencerWorkspaceId` set
- `influencerFilters` — optional concept filters on the influencer panel (e.g. `[{"key": "AUDIENCES", "values": ["Car Lovers"]}]`) to scope to content created for that audience segment
- `pillarCount` — number of editorial pillars (default 3)

## Two measured rules from the brand's own organic timeline — required on EVERY run

These two values are **always measured from `brandProfileId`'s own organic timeline** (`source: PAGES`), on every run, whether or not a dedicated `<brand>-brand-guideline` skill or a website palette exists. They describe what the brand actually publishes today, which is what new creative has to sit beside in the feed.

1. **Palette = pixel-sampled from the brand's organic creatives.** Pull the brand's recent organic posts (`posts-search`, `sortBy:"date"`, `sortDir:"DESC"`, `LAST_90_DAYS`, widening in fixed steps only if the sample is thin), download the thumbnails at `creatives[].images[].url` (recurse into `children[]` for carousels), and run `extract_palette.py` over them. **Flatten RGBA onto white before sampling** — a transparent PNG read as-is samples its empty pixels as black. Cross-check against the supplied logo. The resulting palette drives **both** the rendered creatives (brand-lock palette clause) and the deck chrome. Record `palette_provenance: "pixel_sampled_organic"`, the post count and the window.
2. **On-image word count = measured from the brand's organic designed creatives.** SOMIN's `ocrText` is frequently empty for organic images (observed: empty on all 77 organic images in one healthcare client run), so **download the creatives and OCR them directly**: `tesseract <img> - --psm 11 tsv`, keep only words with confidence ≥ 70, exclude the brand-lockup words (brand name, tagline words), and count only *designed* creatives (≥ 4 confident words — plain photos are not banners). Report the median and a band (the brand's own interquartile-ish spread; e.g. one healthcare client measured median 10, band 7–14). Measure paid the same way when the brand advertises and report both medians. **Every rendered creative's headline must sit inside this band** (count the authored hook before rendering; rewrite any that fall outside), and the brand-lock prompt carries the band verbatim ("TOTAL on-image word count must be 7–14 words, targeting about 10 — the brand's own measured house rule"). A CTA button counts toward the total — prefer the brand's shortest real CTA on cells where the headline is already near the top of the band.

Persist both in `inferred_guideline.json` as `palette{…}` + `banner_rule:{band_lo, band_hi, target, median_organic, median_paid, method, n_designed}` and merge into `brand.json`. **If a dedicated brand-guideline skill also exists** and disagrees, the organic-timeline measurement still governs the creatives (it is what the feed looks like now); use the guideline for anything it specifies that the timeline can't show (type, wordmark construction, spacing), and state the disagreement on the Method Notes slide. Disclose both measurements on the deck (Method Notes and the "Brand rules" appendix slide): "palette pixel-sampled from N organic creatives; on-image copy band measured by OCR of M designed creatives".

## Brand-guideline resolution — when no client guideline skill exists

Visual identity AND creative conventions (copy length, CTA phrasing, hashtag/emoji habits, dominant format) for this deck come from, in priority order:

1. **A dedicated `<brand>-brand-guideline` skill**, if one exists for this client (e.g. a `<client>-brand-guideline` skill the user has installed; this plugin ships only `somin-brand-guideline`) — check the available-skills listing for the client/brand name before assuming none exists. When found, it is the primary source of palette, type, wordmark and layout patterns.
2. **`brand-extraction-from-web`** (Step 1) — pixel/CSS palette + voice/taglines/verified facts from the client's public site. Always run this regardless of (1) or (3); it's the only source for verified facts (phone/email/addresses/offerings) and real taglines.
3. **Content-inferred guideline — run whenever Step 1 found no dedicated guideline skill for this brand.** A website gives colour and voice but not the brand's *actual creative conventions* — how much copy it runs per post/ad, its real CTA phrasing, its hashtag/emoji habits, its dominant format. Infer these from `brandProfileId`'s own SOMIN data (its paid and/or organic content), never from training-data assumptions about the category. **Validated on a real run (a food & agriculture brand workspace); the field paths here are the actual ones that worked, not assumed ones:**
   - **Organic signature:** `concepts-search` with `key: "TONES"`, `source: PAGES`, `profileIds:[brandProfileId]`, a `datePreset` such as `LAST_YEAR` for a stable ranked tone list (e.g. Informal > Supportive > Warm > Playful…). This is a real, reliable signal — use it as the tone-word source.
   - **Real captions and thumbnails — pull from `posts-search`, not a separate scrape, and bias the sample toward NOW, not the brand's history.** Each returned item carries the actual creative under `item.creatives[].texts[].content` (the real caption/on-post text — read it directly, don't assume a top-level `caption` field) and `item.creatives[].images[].url` (a real hosted thumbnail URL — usable directly, no separate screenshot step needed). **Explicitly set `sortBy: "date", sortDir: "DESC"` (this is the tool's default, but state it — don't rely on an unstated default) and prefer a short, recent window (`datePreset: "LAST_90_DAYS"`, or `LAST_30_DAYS` for a fast-moving account) for the sample that drives palette/copy-density/CTA inference** — the wider `LAST_YEAR` window above is for the TONES aggregate only, which benefits from more data; the copy/palette sample should reflect what the brand looks like *today*, not a year-blended average that can under-weight a recent rebrand or over-weight a stale campaign. If `LAST_90_DAYS` returns too few posts to be a usable sample, widen the window in fixed steps (`LAST_90_DAYS` → last 6 months via explicit `startDate` → `LAST_YEAR`) rather than jumping straight to a year, and record which window was actually used. **Pull whatever `posts-search` actually returns for that window (often a small sample, e.g. a dozen posts, not 20–40) and record the real count — never pad the number or imply a bigger sample than was pulled.**
   - **Paid signature (if the brand advertises):** `concepts-search`/`posts-search` with `source: ADS_LIBRARY`, `profileIds:[brandProfileId]` — **`datePreset` (or explicit start/end dates) is required whenever paid/`clickability` fields are queried** (see `references/somin-schema-gotchas.md`). Same field paths as above for text and thumbnails.
   - **Measure, don't guess, from the pulled sample:** average caption length (characters + words, computed from `creatives[].texts[].content`) → label **minimal / moderate / dense**; the brand's actual recurring CTA phrases, verbatim, extracted by scanning caption text for imperative call-outs — and note **organic CTAs are usually engagement actions** ("comment X", "tag a friend", a hashtag-challenge prompt), while **paid CTAs skew transactional** ("Shop Now" / a checkout phrase) — keep the two lists separate, don't merge them into one generic CTA set; hashtag count/style; emoji usage; dominant format (single image / carousel / short-form video/Reel).
   - **Palette cross-check — do this, don't skip it for lack of a source image.** `posts-search` results already carry real thumbnail URLs at `creatives[].images[].url`; run a representative handful through the same `extract_palette.py` used by `brand-extraction-from-web`. **On the validated run this step was skipped and the palette fell back to a category-typical guess even though real thumbnail URLs were sitting in the already-pulled `posts-search` data** — that is the single biggest concrete gap to not repeat. Only fall back to an ESTIMATED/category-typical palette (clearly labelled as such) if `posts-search` genuinely returns no usable thumbnails.
   - Persist as `inferred_guideline.json`: `{palette, palette_provenance: "pixel_sampled"|"estimated", copy_style: {avg_caption_length, text_density, common_ctas_organic[], common_ctas_paid[], hashtag_style, emoji_usage}, creative_conventions: {dominant_format, dominant_composition}, sample: {organic_n, paid_n, window, sort: "date_desc"}, provenance: "somin_content_inferred"}` — carry the actual `window` used (e.g. `LAST_90_DAYS`) so a reviewer can tell the guideline reflects current content, not a year-blended one. Merge into `brand.json` as `brand.inferredGuideline` — never silently overwrite the web-extracted palette; where they disagree, prefer the content-inferred (pixel-sampled) palette for in-feed creative rendering and the website palette for the deck's own chrome (the same split the `somin-brand-guideline` skill uses for client mockups vs deck chrome).
   - **This is a fallback, not a substitute for a real guideline.** If a dedicated brand-guideline skill turns up later in the engagement, switch to it and note the change in the audit trail rather than continuing on the inferred one.
   - **Disclose it on the deck, not just in the JSON.** Whenever `brand.inferredGuideline` is the styling source (and especially when `palette_provenance` is `"estimated"` rather than `"pixel_sampled"`), the Method Notes / audit-trail slide must say so explicitly — "brand guideline inferred from N organic + M paid posts, palette pixel-sampled from real thumbnails / palette estimated pending client confirmation" — the same disclosure discipline the deck already applies to reduced-scope trend windows and reconstructed whitespace verdicts. A client asking "where did these colours come from" must be answerable from the deck itself.

**Service constraints — record what the brand does NOT offer.** Before any creative is authored, record in `brand.json` → `service_constraints[]` the services the brand does not provide that a scene could otherwise imply (e.g. a healthcare client: "no home visits — no clinician may ever be shown inside a home"). Every concept hook and every brand-lock prompt must respect them: a scene set at home shows only family members; a service is only ever shown as somewhere the family goes. This is brand data, not skill logic — never hardcode one brand's constraint into the builder or the prompt template. A render that implies a service the brand does not offer is a defect even when it is otherwise on-brand.

Whichever source wins, its `copy_style.text_density` and `common_ctas_organic`/`common_ctas_paid` govern two downstream things: brief copy generated in Step 12 (`content-brief-brand`) should match the brand's real brevity/density instead of a generic house style, and the brand-lock suffix appended to every `creative-expressions` prompt in Step 12B must instruct the image model to match that same text amount (see Step 12B, "Brand-lock + wordmark composite").

## Derived values (orchestrator computes automatically)

- `publishWeeks` = ceil((publishEndDate − publishStartDate) / 7)
- `analysisIntervalDays` = (analysisEndDate − analysisStartDate)
- Trend window count and size: see `references/interval-splitting.md`

## Multi-market runs

When an engagement spans more than one market (e.g. UK + JP + US, or a four-market global brief), the unit of work is **one full run of Steps 1–13 per market** — not one run with shared outputs. Each market has its own workspace, brand profile, competitor set, website and locale, and the markets are genuinely different competitive landscapes. Treat them that way.

**Each market derives its own pillars.** Steps 2–11 — trend studies, trend analysis, whitespace, insight creation, product + propositions, moments, calendar — run independently against that market's own data. A market's editorial pillars come **only** from that market's own whitespace verdicts + trend status. Never copy pillars, insight chains, characters, products, propositions or calendar from one market to another, and never seed one market's analysis with another market's themes.

**Convergence is an output, never an input.** Two markets may independently land on the same strategic territory — that is a finding, and a strong one. But it must emerge from each market's own data. A territory that is WHITESPACE in one market can be CONTESTED, BLOCKED or absent in another; assuming a shared pillar hides exactly the divergence the client is paying to see. Do not pre-decide that "pillars 1–2 are shared, pillar 3 is local" — derive every pillar per market and let any overlap fall out on its own.

**Per market, produce its own:** pillar set (from that market's whitespace + trend output) · insight chains — characters, angles, stories — from that market's personas and tensions · product, created on that market's own brand profile, with propositions generated from that market's own stories · moments and content calendar · deck, rendered and individually QA'd.

**A market with no brand-side data still gets its own run.** If an owned channel is dormant, that market's pillars are derived from its competitor and creator cohorts and the absence is reported as a finding — it is never a reason to borrow another market's pillars or propositions.

**The cross-market summary deck must show divergence, not manufacture a single idea.** A multi-market engagement often also produces one *cross-market* (portfolio) deck that summarises all the per-market analyses side by side. This deck is uniquely prone to one failure: because a summary invites a unifying narrative — and reference decks often supply a single shared "big idea" — the builder collapses the independent per-market analyses back into one shared pillar or "strategic frame." Do not. Specifically:
- The cross-market deck's strategy slide is **per market, not one shared card set.** A "strategic frame" / "where to play" slide must present each market's *own* lead pillar (e.g. UK community, JP frontier, US capability) — never one territory + one gap applied to all. If a slide would carry a single shared pillar for every market, it is wrong; rebuild it as N columns, one real lead pillar each.
- **Convergence is shown only where it independently emerged, and labelled as an observed output.** If two of three markets' analyses both selected the same territory, the deck may note that — explicitly as "two independent analyses converged here," and explicitly *not* extended to the market that diverged.
- **A verdict/whitespace matrix must not imply a shared pillar.** If a territory shows the same verdict in every market column, check it was genuinely selected as a pillar by every market. A market that did not surface or select a territory gets a distinct cell value (e.g. "NOT SURFACED"), never the same verdict as the markets that did — and the caption must not claim a universal opening.
- **Internal consistency.** The cross-market deck's pillar-architecture slide (distinct per-market pillars) and its strategic-frame slide must agree. A deck that shows three different pillar sets on one slide and one shared pillar on another is self-contradictory — fix the frame slide.
- Headlines and closing copy must not imply one shared pillar. "One audience, one conversation" is fine when the trend data shows a shared *conversation*; "one frame / one gap / one pillar" is not, unless every market's own analysis independently selected it.

**Cross-deck QA.** `deck-qa-brand`'s cross-deck check (C12) confirms no market deck inherited another's figures **or** another's pillars, stories, characters, products or propositions, **and** that any cross-market summary deck presents per-market divergence rather than one imposed shared pillar. Identical pillar names or proposition text appearing in two market decks, or a cross-market frame slide asserting one pillar for all markets, is a FAIL.

## Scope discipline — the full briefing is the default

This skill's deliverable is the **complete** cross-market briefing: every analysis layer in *The workflow* below, producing the v3 main section plus the full evidence appendix (roughly 35–45 slides in total for one pillar; the main section grows by one "pillar in creative" slide per additional pillar). Completeness is counted across main section **and** appendix — moving a slide to the appendix is never dropping it. Running a reduced subset is allowed, but it is a deliberate, declared decision — never a silent default.

- **Default to the full chain.** Trend windows (Step 2–5) with prior-year verification, moments (Step 10), the dated content calendar (Step 11) and per-insight proposition plates are part of the deliverable, not optional extras. A deck built from only persona/whitespace/insight/proposition steps is a **reduced-scope deck** — typically ~14 slides, roughly half the standard — and looks materially thinner than a normal briefing.
- **The briefing-specific beats are required, not optional.** Beyond the analysis chain, a briefing MUST include: **the competitor creative-diversity slide in the main section (Step 12A)**, a competitive-landscape scene-setter (share of voice — appendix under v3), a plain audience definition, the persona-led permutation engine shown as layers, share-of-voice + engagement (not raw counts), a brand-permission beat, an integration-with-existing-effort beat, market prioritisation by whitespace size, and a full audit trail. Dropping these turns the briefing into a pitch — if that is what's wanted, use `somin-agency-deck` (separate SOMIN skill, if installed).
- **Missing inputs are not a reason to silently shrink the deck.** If `publishStartDate`/`publishEndDate` or an analysis interval were not supplied, do not quietly skip the calendar and trend layers. Use the documented defaults (`analysisStartDate` = 12 months back; calendar = next quarter) and run the full chain, or — if the omission is deliberate — declare the reduced scope.
- **Declare reduced scope up front.** If any layer will be skipped, tell the user before building: which layers are omitted, why, and the slide-count consequence (e.g. "snapshot only — no 12-month trend, no calendar; ~14 slides, not the usual 35–45"). Offer the full build. Never present a reduced-scope deck as if it were the complete briefing.
- **Record the scope.** Whatever scope is run, note it in the data passed to `deck-qa-brand` (see Step 13) so QA's completeness check (C13) measures the deck against the scope that was actually agreed, not against a guess.

## The workflow

### Step 1 — Brand extraction + guideline resolution
Call `brand-extraction-from-web` with `clientWebsiteUrl` (+ screenshot if available). Output: `brand.json`. Then resolve the full styling/creative-conventions source per "Brand-guideline resolution" above — check for a dedicated `<brand>-brand-guideline` skill first; if none exists, run the content-inference fallback against `brandProfileId`'s own SOMIN paid/organic content and merge the result into `brand.json` as `brand.inferredGuideline`. Do not proceed to Step 12's build with only neutral/generic defaults when real content to infer from exists.

### Step 2 — Interval splitting
Compute trend-window count and size from `analysisIntervalDays`. See `references/interval-splitting.md`. Output: `trend_windows.json` with N window definitions.

### Step 3 — Trend studies on primary workspace
For each window, call `SOMIN:studies-create` with:
- `profileIds: [brandProfileId, ...competitorProfileIds]`
- `startDate`/`endDate`: the window
- `generationOptions: [{reportType: "persona", minClusters: 3}, {reportType: "tensions", minClusters: 4}]`

Fire all N studies in parallel (each returns immediately with a study ID). Capture IDs into `studies_primary.json`.

### Step 3B — Trend studies on influencer workspace (IF provided)
If `influencerWorkspaceId` is set:
- Run the same window cuts on the influencer workspace with `influencerProfileIds` + `influencerFilters`
- ALSO run one "live" study (last 30 days, separate from window cuts) for topicality signal
- Capture into `studies_influencer.json`

Both sets of studies fire in parallel. Total study count: N (primary) + N+1 (influencer, if provided).

### Step 4 — Poll all studies
After ~90 seconds, call `SOMIN:studies-get` with ALL study IDs in one batch.

### Step 5 — Trend analysis
Run the `trend-analysis` skill TWICE if influencer workspace exists:
- Primary trend (brand+comp cohort) → `trends_primary.json`
- Influencer trend (Foodie-directed content cohort) → `trends_influencer.json` — surfaces EMERGING + RISING content signals that the brand+comp side reacts to lagged

Otherwise once on primary. The dual-cohort case contrasts brand-published content with creator-published content — see `references/dual-cohort-trends.md`.

**Prior-year verification (required):** before any tension is presented as RISING or FALLING, run `trend-analysis`'s prior-year pass (same windows, one year earlier) to confirm the direction is a real trend and not a seasonal slope. Carry the UNVERIFIED flag into the deck where the prior year can't be obtained — never render an unverified single-cycle decline as a confident one.

### Step 6 — Whitespace cohort studies
- Cohort A (brand voice): `profileIds: [brandProfileId]`, last 90 days
- Cohort B (competitor coverage): `profileIds: [...competitorProfileIds]`, last 90 days
- **Cohort C (Foodie-directed content proxy)** — IF `influencerWorkspaceId` set: `profileIds: influencerProfileIds`, `filters: influencerFilters`, last 90 days

### Step 7 — Whitespace analysis
Call `whitespace-analysis`. With 3 cohorts → FULL coverage mode; with 2 → PARTIAL. Output: 6-verdict map.

### Step 8 — Insight creation
For top `pillarCount` tensions (typically 3) from whitespace + trend output, call `insight-creation-brand` once per pillar. Pick mix of one WHITESPACE, one PARTIAL/CLAIMABLE, one EMERGING. In a multi-market run this runs **per market** against that market's own whitespace + trend output (see *Multi-market runs*) — pillars are derived independently and are never shared or copied across markets.

**Brief stance:** render the result as the persona→tension→angle→proposition chain in layers (slide blueprint Section 3/5) — persona names and theme IDs are KEPT and shown, because traceability is part of the briefing's credibility. The one-persona-maps-to-many-tensions structure is the point, not an implementation detail.

### Step 9 — Product + propositions
- `SOMIN:products-list` to check; if missing, `product-create` once per product line from `brand.offerings`
- `SOMIN:propositions-create` with all story IDs × focus dimensions. Use singular `promotion` not plural (see `references/somin-schema-gotchas.md`).
- In a multi-market run, create the product on **that market's own brand profile** and generate propositions **only from that market's own stories** — never reuse one market's product or propositions in another market's deck.
- **Render propositions by their actual content, not by ID.** When a proposition reaches a slide it must show the real fields from the SOMIN record: the **proposition name** (its focus line — what the post executes) and the **insight tagline** (the story line it integrates). A card that reads only "Proposition 1201" is an ID reference, not the proposition — it fails `deck-qa-brand` C8. Retrieve the text with `SOMIN:propositions-list` and print the name + tagline; the ID is supporting metadata, never the whole card.
- **Show every proposition that was generated.** If Step 9 created 9 propositions (3 stories × 3 focuses), all 9 appear in the deck — on dedicated proposition-plate slides per `references/slide-blueprint.md` — not a 3-of-9 subset. A deck that silently drops generated propositions fails `deck-qa-brand` C13.

### Step 10 — Moment generation
Call `SOMIN:moments-create` for each (persona, tension) pair across moment types. Default mix: 3 types per pair → 5 triggers × N pairs × 3 types. Adjust based on supply math against `publishWeeks × cadence`.

### Step 11 — Calendar
Call `content-calendar-build`:
```
--moments moments.json
--cadence <cadence>
--weeks <publishWeeks>     # derived, not user-supplied
--start-date <publishStartDate>
--pillar-weights <derived from whitespace verdicts>
--cultural-anchors <pulled from seasonal moments and locale>
--lead-day tuesday
```

### Step 12A — Competitor creative diversity (STANDARD — always runs, always a main-section slide)

Score creative variety for the brand **and every competitor** with the `content-diversity-scorer` skill in its **cohort mode** (see that skill's § "Cohort mode — brand vs competitors"). Default cut: organic (`PAGES`), `LAST_90_DAYS`, the most recent 28 extraction-successful posts per entity, explicit `profileIds` **and** a per-item `profile.id` purity check. Report, per entity: Meta Diversity (0–100, **higher is more diverse — say so on the slide**), the image-only control, EEC out of n, structural coverage with the < 0.60 "message-only" gate, and cross-posts collapsed. Sort the table by the image-only control when video shares differ. Output `content_diversity.json` + `diversity_worked_example.json` (the brand's most-similar and most-distinct pair, broken out by axis group).

- **Main section:** slide 2 — "Brand and N competitors, scored", every entity on one table, the brand's row highlighted, one note on what drives the ranking (usually media mix — headline vs image-only).
- **Appendix:** the worked calculation (formula, the two extreme pairs by axis group, concept-unification collapse rate).
- **Optional extensions, only when asked:** the paid cohort (`ADS_LIBRARY`, 12 months; Google search text ads score "message-only"; watch sampling windows — a brand whose latest 28 ads sit in one short burst needs a year-spread control beside it) and the in-pillar cut (organic and paid, pillar membership tested on each post's stated `topic`). Never compare a paid score with an organic one.

### Step 12B-pre — Map a creative to every calendar slot

After Step 12B's renders exist (below), assign each calendar slot the creative that runs on it: best text similarity (all-mpnet-base-v2 cosine) between the slot's trigger + brief message and the creative's hook + home occasion, funnel stage matched to trigger type (emotional / life / seasonal → TOFU, search / micro → MOFU, purchase → BOFU), each creative used at most twice (optimal assignment, `scipy.optimize.linear_sum_assignment`). **Pin by hand** any slot whose cultural anchor or trigger names a specific occasion (a festival, a holiday trip, a school event) to the creative showing that occasion, and **read the result** — the matcher will happily put a lactation creative on a car-seat post. Persist as `calendar_creatives.json` with the method string and which slots were pinned. The calendar month pages, the lead-post briefs and the story slide all read from it.

### Step 12 — Brief generation + deck rendering
- For each calendar slot, call `content-brief-brand`. Output: N briefs.
- **Known limitation — check before relying on the shipped builder.** `scripts/build_deck.js` still renders the **v2** order with six section dividers and still carries theme keys from an earlier medical-device client build (`EDU`/`CLIN`/`TRUST`/`MENS` and a fixed lead-theme tile) in its trend and summary slides, so it breaks on any engagement whose trend series use other keys or a single pillar. Until it is updated to v3, build the v3 order by wrapping each slide block in its own function and calling them in the § "Deck structure — v3" order (a healthcare client build, 2026, did exactly this), and add the new v3 slides (story + creative, pillar in creative, calendar month pages, briefs with creative). Whatever builder is used, every figure and label must come from the analysis JSONs — no theme IDs, post counts or study IDs typed into slide code.
- Render the deck. **`scripts/build_deck.js` is intended to be brand-agnostic and data-driven** — it reads `brand.json`, `scope.json` and the analysis JSONs **from the current working directory** (no CLI flags). Put the engagement's JSONs in one directory and run it there:
  ```bash
  cd <engagement-dir>   # holds brand.json scope.json studies_primary.json trends_primary.json
                        # whitespace.json pillars.json personas.json paid.json insights.json
                        # propositions.json calendar.json   (+ optional expr/ for the Creative Library)
  node /path/to/somin-brand-deck/scripts/build_deck.js
  ```
  Identity (wordmark, palette, audience, market, workspace) comes from `brand.json`/`scope.json`; **every figure** comes from the analysis JSONs; **bespoke copy is data-derived** and can be overridden per slot via an optional `brand.narrative` block. With no `narrative` the deck still renders cleanly and generically. Output path = `scope.output` (else `<Brand>_<Market>_Briefing.pptx`).
  - **Full input + `brand.narrative` override schema:** `references/data-contract.md`.
  - **Worked inputs:** no client example ships with this plugin. Create the input JSONs from `references/data-contract.md` (every file, key and type the builder reads is listed there), then run `node build_deck.js` from that directory to watch the generic builder render.
  - Do **not** copy a prior engagement's *output* deck and string-patch the copy — author voice through `brand.narrative`, never by editing the builder.
- **Layout gates — STRICTLY no overlapping text anywhere, on every deck.** (1) Install the deck's real fonts before rendering any PDF (`fc-list | grep -i <font>`; Google families from npm `@fontsource/<family>`, `.woff` → `.ttf` with fontTools, `fc-cache -f`) — a fallback font re-wraps every line. (2) Wrap `slide.addText` with a fit guard that measures text with the real font's advance widths: a slide headline must fit ONE line (shrink toward ~20pt, else reword), any multi-line box must fit its frame (shrink no further than 85%), otherwise the build refuses to write the deck and names the box. (3) Place value labels relative to their own mark (`bar_x + bar_w + gap`), never at a fixed column x; no per-point data labels on line charts whose series converge; diagram titles outside the shapes. (4) Run `deck-qa-brand`'s C7 overlap gate on the rendered PDF — the deck is not deliverable until it prints `PASS — 0 overlap(s)`. Embed renders in the deck as ~640×960 JPEG thumbnails, not the 1024×1536 PNGs, so a deck with a creative on every calendar post stays under the 30 MB delivery limit.
- **Make the SOMIN IDs clickable — required, run after the deck is fully assembled (i.e. after Step 12B if a Creative Library is added, otherwise straight after the build).** The builder renders every study/story/persona/tension/workspace ID as **plain text** on purpose: pptxgenjs emits broken hyperlink relationships (`r:id="rIdundefined"`) on multi-link slides, which fail OOXML validation and make PowerPoint report the file as corrupt. So inject **valid** hyperlinks as a post-build step with `scripts/link_somin.py` (python-pptx, which writes correct relationships) — it builds the ID→URL map from the same working-directory JSONs and links each ID to its own SOMIN record (studies → `/app/a/{ws}/studies/{id}`, stories → `/app/inspire/insights/story/{id}`, persona/tensions → their source study, workspace → `/app/a/{ws}`; angles/product/propositions have no public per-object URL and stay as traceable text):
  ```bash
  python3 /path/to/somin-brand-deck/scripts/link_somin.py \
    --deck <assembled_or_built>.pptx --inputs-dir . --out <final>.pptx
  ```
  Do this on the assembled deck **before** converting to PDF. (The audit-trail caption already states which IDs are linked, so the claim stays true.)
  - **`--inputs-dir` must be the SAME directory `build_deck.js` was run from** (the one holding `studies_primary.json`, `scope.json`, `insights.json`, etc.) — not the engagement's project root one level up. `link_somin.py` now checks for `studies_primary.json`/`scope.json` in `--inputs-dir` and **exits loudly** if either is missing, and prints a warning if the resolved ID map has fewer than 3 tokens. This closes a real regression observed once: pointing `--inputs-dir` at the wrong directory produced no error, just a near-empty token map and a link count that silently dropped from 47 to 18. Don't silence or work around the check — if it fires, the fix is to pass the correct directory.
- Convert to PDF (on the linked deck):
  ```bash
  python /mnt/skills/public/pptx/scripts/office/soffice.py \
    --headless --convert-to pdf /tmp/strategy_deck.pptx
  ```

### Step 12B — Creative expressions (render concepts into the deck — only if the skill is installed)

**Discovery gate — do this first.** The `creative-expressions` skill is optional and ships separately (it carries the encrypted render/assembly engine). Check whether it is installed before doing anything in this step — e.g. `find /mnt/skills -path '*/creative-expressions/scripts/unlock.py' 2>/dev/null` (or confirm `creative-expressions` is in your available skills).

- **If it is NOT found → skip this entire step.** Deliver the deck exactly as earlier package versions did: **text-only — no rendered Creative-Library appendix and no proposition visuals.** Do not ask the two questions, do not call `SOMIN:image-generate`, and record in the scope passed to Step 13 that expressions were not generated (so QA's creative-expressions check is skipped). This fallback is expected and fully supported — it is not an error or a degraded deck.

- **If it IS found → run it, and by DEFAULT render the FULL creative funnel.** **Default production volume for every brand run = the maximum canonical funnel:** author `creative-expressions/references/funnel-taxonomy.md` **in full** for each pillar — **≥30 concepts per pillar** (12 TOFU + 12 MOFU + 12 BOFU = 36/pillar) — and render **all** of them with `--select all`. This is the deliverable, not a sample: earlier versions' 3-or-9 subset is deprecated. **If the user has NOT specified a count, ASK before rendering — use the interactive picker, state this skill's default (the full funnel — 36/pillar, ≈108 for a 3-pillar deck), and offer options:** **`Full funnel — 36/pillar` (default)** · `9 per pillar (3 per funnel stage)` · `3 per pillar (1 per funnel stage)` · `a specific total N`. Render the **full funnel** if the user picks it or declines to choose; render fewer only when the user selects a smaller option (map to `--select perpillar:N` / `total:N`, or author the reduced concept set). Do not silently render 108 without offering the choice, and do not silently default to fewer than the stated default. The other question worth asking (picker) is whether to **embed example visuals in the proposition section or keep it text-only** (default text-only). **Creator/influencer runs** (a personal handle, person-or-pet persona, or UGC creator whose feed *is* the subject, with a creator competitor cohort) are owned by `somin-influencer-deck` (separate SOMIN skill, if installed) and keep its own per-creator defaults — they are out of scope for this brand orchestrator. Then follow `creative-expressions`, and **use its master prompt — never hand-write image prompts**:
  1. **Build the FULL-FUNNEL concepts JSON from the insight chains and OMIT `imageConcept`.** Produce `insights[]`, each `{pillar_id, pillar, persona:{name,theme_id}, concepts:[{type:"TOFU"|"MOFU"|"BOFU", subtype, hook}]}` — write only the funnel `subtype` and the `hook`. **Populate EVERY subtype in `creative-expressions/references/funnel-taxonomy.md` for each pillar (≥30 concepts/pillar), each `hook` a distinct angle grounded in that pillar's own insight story/tension (never generic, never a duplicate). This complete funnel is the default — a partial set is only produced when the user explicitly capped the count.** Leaving `imageConcept` absent is exactly what makes the engine apply its **encrypted TOFU/MOFU/BOFU master prompt** (the canonical content-generation template) to build each render prompt from `{persona, subtype, hook}` + brand tokens. Hand-authoring `imageConcept` silently overrides that master prompt — do not do it here.
  2. **`emit-prompts`** on that concepts JSON (the engine builds every prompt via the master template); **immediately run `<creative-expressions>/scripts/check_prompts.py --concepts <concepts.json> --prompts <emit-prompts out.json>` and require PASS** (no `imageConcept`, no echoes) — the source-side guard that the prompts are engine-generated, not hand-written. Then **generate each image** with `SOMIN:image-generate` (1024×1536, `medium`; one render per turn), saving each as `<key>.png` (dash form, e.g. `P1-T-03.png`). **`SOMIN:image-generate` is a deferred tool — call `tool_search` to load it first; never treat its absence from the visible tool list as "unavailable", and never fall back to placeholders without loading it and attempting a real render.**
  3. **`assemble`** the grouped **Creative-Library appendix** (one grid per pillar × TOFU/MOFU/BOFU) onto the Step 12 deck — adding proposition visuals if chosen. The base builder (`build_deck.js`) deliberately does **not** render the library; the engine owns it, so `assemble` is the single place the master prompt is applied. **Derive the brand tokens from the same source resolved in "Brand-guideline resolution" above** — the dedicated brand-guideline skill if one exists, else `brand.json`'s palette merged with `brand.inferredGuideline` (`paper`/`ink`/`accent`/`grey`/`soft`/`hair` + `font_head`/`font_body` + `name`/`library_title`) — and pass them **hex without `#`**. When the source is `brand.inferredGuideline` (no dedicated skill), also carry its `copy_style` block (`text_density`, `common_ctas_organic`, `common_ctas_paid`) forward to 2a below — it is not a template input for the encrypted engine, but the brand-lock suffix must encode it so renders match the brand's real on-image text amount instead of a generic default. The engine is brand-agnostic, so it injects these tokens into every prompt's *"Render in the {brand} visual identity…"* clause and into the appendix surface/captions. **This token clause is necessary but NOT sufficient: on its own the image model still invents a logo/wordmark (an invented mark or misspelling) and strays off the brand's palette. You MUST also brand-lock the prompts and composite the real wordmark — see *Brand-lock + wordmark composite* below.** Never ship the engine's neutral defaults — `deck-qa-brand` fails a default-styled appendix, a model-drawn mark, or an off-palette cell. Record the run scope (expression count, propositions embed yes/no) for Step 13.
  4. **Mandatory cleanup pass when `--propositions embed` was used — check for stray thumbnails before moving on.** The engine's proposition-visual placement has a known defect: it can drop a small `creative-example` picture shape (plus a `"Creative example"` caption textbox) at a fixed bottom-right position on a slide regardless of whether that slide actually has room for it — observed overlapping the Scope panel values on an Audit Trail slide, and overlapping content-card text on Pillars+Propositions slides. After `assemble` runs, always check for this before proceeding: any shape named `creative-example`, or any text box whose text is exactly `"Creative example"`, whose bounding box overlaps another shape's bounding box on the same slide → remove both the picture and its caption (`shape._element.getparent().remove(shape._element)` via python-pptx; match on exact shape name / exact caption text so you never touch an unrelated same-named shape elsewhere in the deck — shape name `t` is pptxgenjs's generic default and is reused hundreds of times for unrelated text boxes). This is a stopgap at the orchestrator level for an upstream `creative-expressions` bug — file it against that skill; do not skip this cleanup while waiting for an upstream fix.

**Brand-lock + wordmark composite (required — the engine does NOT do this).** The `creative-expressions` engine emits brand-token prompts, but it does not stop the image model drawing its own logo, and it does not place the real wordmark. Both are added here, exactly as Pillars 1–3 were produced — the engine's *"Render in the {brand} visual identity…"* clause is necessary but not sufficient.
  - **2a — Brand-lock every emitted prompt.** After `emit-prompts` + `check_prompts` PASS, append a strict suffix to every prompt *string*: do NOT draw any logo, wordmark, brand name, monogram, icon, emblem or abstract mark anywhere in the image; leave the top-left corner clean and empty (reserve ~24% width × 12% height with nothing in it) so the wordmark can be placed there; use ONLY the brand's own defined palette + neutral greys — no colour outside it (what counts as off-palette is per-brand: red is off-palette for a teal/ink brand, on-palette for a red brand); use the brand body font for any on-image text; spell all on-image text correctly; keep any numbers illustrative; **state the brand's measured on-image word band verbatim** (from § "Two measured rules": "TOTAL on-image word count must be X–Y words, targeting about Z — the brand's own measured house rule") and match the resolved `copy_style.text_density` instead of the model's own default text amount; **encode every `brand.service_constraints[]` entry as a scene rule** (e.g. "show ONLY family members at home — no doctor, nurse or clinician, no scrubs or medical kit — the brand does not offer home visits"); never render the concept code or subtype label as on-image text; **when a CTA appears on-image, use only a phrase from `copy_style.common_ctas_organic` or `copy_style.common_ctas_paid`** (whichever matches this render's funnel stage/channel — the brand's own real recurring CTAs) rather than an invented one. This edits the prompt strings, not the concepts JSON, so `check_prompts` still PASSes — it is an additive brand constraint, not a hand-written `imageConcept`.
  - **2b — Composite the real wordmark after each render.** The wordmark is PLACED, never generated: stamp the brand's real wordmark/logo into the reserved zone of every rendered PNG — at the size and position measured from the brand's own timeline in the creative brand-fit step (top-left only when that is where the brand's feed puts it), per that brand's brand-guideline skill. A text logotype is rendered in its own font + colours; a graphical or script logo (custom letterform, emblem, script) is composited from the actual logo **asset**, never re-drawn as text. (Worked example — SOMIN, a text logotype: two runs, `SO` #2DBF9C + `MIN` #16201F, joined, no space, Montserrat ExtraBold.) Only the composited PNGs go into `assemble`.
  - A render whose mark was drawn by the model, whose wordmark is the wrong letterform/spacing, or that carries any off-palette colour is a defect — re-render with the brand-lock and re-composite. Relying on the engine's brand-token clause alone (no brand-lock, no composite) is the root cause of off-brand cells, and `deck-qa-brand` must fail it.

### Step 12B-fit — Creative brand-fit: renders must look like the brand's own current creatives (instruction + QA gate — mandatory whenever creatives are rendered)

**Why this exists.** On a real run (a telecom client, 2026), all 108 renders were on palette, but they still did not look like the brand's feed. They were magenta-drenched night scenes with a condensed headline face drawn by the model, a logo 22% wide in the top-left, a 2:3 format and almost no offer badge. The brand's own last-6-month timeline looked different. Half of it was flat brand-colour cards with glossy 3D objects, and half was natural-colour photos of real people. The logo was small, at the bottom centre. The format was 4:5. Offers were stated in a round badge. The client asked for the whole set to be regenerated "so our new creatives look like theirs". A palette lock and a composited logo are necessary, but they are not brand fit. Brand fit means the renders sit in the brand's feed without looking foreign.

**A — Read the brand's current creatives before any render.**
1. Pull the brand's own organic timeline for the last 6 months (`source: PAGES`, the subject's profile id). Take every image, `main` and video `thumbnail`, from `creatives[].images[]` and its children, then download them.
   - Use the brand's paid ads as a creative reference only if its paid source passes the same data-coverage gate the analysis uses. Otherwise use organic only, and say so on the first slide's data-basis panel.
2. Measure every image:
   - HSV pixel classes: brand colour, badge colours, neutral, warm/skin, off-palette.
   - Median brightness.
   - OCR word count, counting only "designed" images (4 or more words).
   - Aspect ratio.
   - Logo presence, size and position, by template match on the real logo asset **plus** a visual check.
3. Build a contact sheet of the latest ~48 images and **look at it**.
   - Name the recurring **looks**, for example: flat brand-colour card with 3D objects; natural-colour photo; info or alert card; event poster.
   - Record each look's share of the timeline.
   - For each look, record the headline case and weight, text zone, logo size and position, badge shape, colour and wording (how offers and prices are stated), background treatment, object style and photo treatment. Photo treatment means natural colour versus a brand-colour cast.
   - Record the dominant format.
4. Persist `creative_style.json` with these fields:
   - `looks[]`: `{name, share, prompt_recipe, headline_case, text_zone}`
   - `logo`: `{size_pct_of_width, position}`
   - `badge`: `{shape, colour, text_colour, used_when}`
   - `format`
   - `words_band`
   - `font`: `{brand_face, stand_in}`
   - `sample`: `{n_images, window, profile_id}`
   Carry it into `brand.json` next to `inferredGuideline`. When it disagrees with a brand-guideline skill on how the **feed** looks, the timeline measurement governs the creatives, and the guideline governs anything the timeline can't show.

**B — Render to the observed looks; never invent a new look.**
- **Write one prompt recipe per look** from the observations: exact hex colours, background shapes, object material and lighting, photo realism and colour treatment. Add a per-creative scene from the concept's hook.
- **Assign each concept to the look the brand uses for that job.** Offer, product and price concepts go to the card look; emotional and top-of-funnel concepts go to the photo look. Keep the overall look mix close to the timeline's.
- **Render the art only** with `SOMIN:image-generate` (`gpt-image-2`) at the dominant aspect (4:5 → `1024x1280`, verified; for other ratios render the nearest supported size and crop), `quality: medium`.
  - The prompt must say: **no text, no letters, no numbers, no logos, no signage, no third-party brands**.
  - Reserve the zones the compositor needs: headline band, logo zone, and the badge circle where the concept states an offer.
  - `image-generate` is a deferred tool. Load it with tool search; never fall back to placeholders.
- **Typeset copy afterwards; never let the model draw it.**
  - Use the brand face, or the nearest free stand-in (state it, and flag the brand-face swap as a production step).
  - Copy is exact and in the local language, with every diacritic.
  - Case follows the look (for example, caps on cards, sentence case on photos).
  - Balanced line breaks; keep number and currency together with a non-breaking space; respect product casing (e.g. "iPhone").
- **Composite the real logo asset** at the measured size and position.
- **Add the badge** (shape, colour and wording as measured) **only** where the hook states a verified offer number. List every badge claim for legal sign-off.
- **Order and review:**
  - Go pillar by pillar, and within each pillar TOFU → MOFU → BOFU.
  - After each stage, build a contact sheet, look at it, and fix bad crops, overlaps or orphans before moving on.
  - Send each finished pillar's sheet to the user as progress.
  - Log `{key: url}` for every render, and keep the scene text actually sent next to it (audit trail).
- **Where this sits relative to the engine:**
  - This step supersedes the engine's image styling when the user asks for creatives that look like the brand's own, or when the QA below fails.
  - The concepts, subtypes and hooks still come from the insight chains and the funnel taxonomy.
  - Record the switch in the audit trail.

**C — Brand-fit QA (gate).** Measure the rendered set with the same metrics as A. Put a before/after table in the deck (a "Brand-fit check" slide: criterion · subject's timeline · rendered set · verdict), and add a side-by-side strip of timeline images against our renders. Every check must pass:

| # | Check | Pass when |
|---|---|---|
| C1 | Look mix | Each look's share is within ±20 pp of the timeline's |
| C2 | Photography | Photo-look renders are natural colour: brand-colour pixel share ≤ timeline photo median + 5 pp; no brand-colour cast on people |
| C3 | Brightness | Median per look is within ±0.15 of the timeline's median for that look |
| C4 | Palette | Off-palette share ≤ timeline p90 (photos judged against timeline photos) |
| C5 | Logo | Real asset, never model-drawn; width within ±4 pp of the measured size; measured position |
| C6 | Headline | Typeset, not model-drawn; copy exact incl. diacritics (OCR spot-check on ≥10%); case per look; no orphan single word where a balanced break exists |
| C7 | Format | Rendered at the timeline's dominant format; missing crops (e.g. 9:16) listed as production steps |
| C8 | Copy amount | Words on image within the timeline's designed band |
| C9 | Offer badge | Present on every creative whose hook states a verified offer number, absent elsewhere; claims listed for legal |
| C10 | Clean art | No model-drawn text, digits, logos, signage or third-party brands in the art (visual check of every contact sheet) |

- Write `brandfit_qa.json` with `{check: {pass, value, reference, failing_keys[]}}` and pass it to QA together with `creative_style.json`.
- Any FAIL: re-render or re-compose only the failing keys, then re-measure. **A deck whose creatives fail C1–C10 is not deliverable.**
- The deck states the result plainly: what the timeline looks like, what ours looked like, and what the regenerated set looks like.
- Do not narrate the process ("we reran…") beyond that before/after.

### Step 12C — Predicted-performance scoring (MANDATORY whenever Step 12B rendered creatives — never skipped)

**This step is not optional and must not be skipped.** Whenever Step 12B produced rendered creatives — which, given 12B's full-funnel default, is **every** brand run — scoring **must** run before QA. Generating a Creative Library and *not* scoring it is a defect, not a shortcut. The **only** case where 12C does not run is when Step 12B itself was skipped (the `creative-expressions` engine is not installed, i.e. a genuinely text-only deck with zero rendered creatives). **A deck that contains a rendered Creative Library but no predicted-performance pass is incomplete, and `deck-qa-brand` FAILS it** — QA checks that `scoring_ran` is true whenever creatives exist.

Invoke the **`creative-scoring`** skill in **GRID** placement on the assembled deck. It uploads every rendered creative (image URL + hook) to the workspace, polls `posts-search` until the **asynchronous** scoring finalizes (10–30+ min; empty until done), flags each creative **"Top performer potential" at above-average clickability ≥ 0.80** (keep 0.80), then runs its `scripts/score_annotate.py` to badge the qualifying grid tiles and insert a "Predicted performance" explanation slide + a "Top performer potential" leaderboard after the Creative-Library cover. **It skips the summary slide and all badges when nothing reaches 0.80** — that skip governs *display only*; the scoring pass itself still ran and `scoring_ran` is still true.

**Method + mandatory fallback (so a predicted-performance layer is ALWAYS produced).** Per `references/somin-schema-gotchas.md`, SOMIN clickability is **paid-only** and there is no guaranteed MCP path to ingest a generated image as owned content and return a per-asset score. So: **attempt** the `posts-upload` → `posts-search` render-scoring path above; **if** the platform returns per-asset scores, use them (never call predictions "results"). **If it does not** (upload/scoring unsupported in this workspace — the realistic outcome for essentially every brand run, since generated/unpublished creatives have no ingest path at all per the schema-gotchas note "no creative ingest, no per-asset scoring... unless actually published and ingested"), do **not** skip — **fall back** to *clickability-lift grading against the brand's own paid (`ADS_LIBRARY`) corpus*: pull each creative attribute at `clickability:High` and `clickability:Low`, normalise to share-of-set, rank by **High-minus-Low lift**, and grade each rendered concept against the winning patterns to produce the same "Predicted performance" + leaderboard treatment (labelled as a **corpus-pattern proxy**, not a per-asset score). Either way the deck gains a predicted-performance layer; scoring is never silently dropped. **`scripts/score_annotate.py`'s `--method` flag has no default — you must pass `--method corpus_lift` (the near-universal case for a rendered-not-published Creative Library) or `--method per_asset` (only if `posts-search` genuinely returned per-asset scores for these exact creatives).** Passing the wrong one — or, previously, relying on the old silent `per_asset` default — puts the wrong explanation text on the deck's "Predicted performance" slide: it will claim live per-image AI scoring when the real method was corpus-pattern grading, which is a factual-accuracy defect, not a style nit. Record `scoring_ran`/`creatives_scored`/`top_performers`/`scoring_method` in the scope passed to Step 13. Full procedure + the helper live in the `creative-scoring` skill.

### Step 13 — QA gate (mandatory — deck is not deliverable until this passes)
**Creative brand-fit first.** When creatives were rendered, Step 12B-fit's C1–C10 must PASS before QA is invoked; pass `creative_style.json` and `brandfit_qa.json` to `deck-qa-brand` with the other inputs, and treat any C1–C10 failure as a QA FAIL.
The deck is NOT finished when the PDF renders. It is finished when it has passed QA.

Invoke the **`deck-qa-brand`** skill on the rendered deck. QA is a separate skill with its own responsibility — verifying a finished deck against its own source data — so this orchestrator does not re-implement the checklist; it calls `deck-qa-brand` and passes:
- the rendered PPTX/PDF
- the deck's source data (`whitespace.json`, `trends_*.json`, `studies_*.json` / study registry, `brand.json`, `insights.json`, `calendar.json`)
- the configuration: single vs multi-market, influencer workspace present or not, extra category workspaces or not, and whether this deck was adapted from another market's deck
- the builder source, so QA can separate data-driven slides from hardcoded literals
- the ordering recorded (`scope.ordering`: `v3` default, or `v2` if the client chose it), `content_diversity.json`, `calendar_creatives.json` and `inferred_guideline.json` (palette provenance + banner rule), so QA can check the competitor slide, the creative-per-post calendar and the two organic-timeline rules

`deck-qa-brand` runs its core checklist plus the conditional sections the configuration activates and returns a **PASS** or **FAIL** verdict with a defect list.

- **PASS** → the deck is deliverable. Proceed to delivery.
- **FAIL** → the deck is NOT deliverable. Enter `deck-qa-brand`'s rebuild loop: for every defect, fix the **source JSON or the builder code** (never hand-edit the rendered PPTX/PDF and never patch a lone literal — a hardcoded value that was wrong once must be made data-driven), rebuild the whole deck from Step 12, then re-invoke `deck-qa-brand` and re-run its FULL checklist. Repeat the fix → rebuild → re-QA loop until the verdict is PASS. There is no iteration cap.

Do not deliver, present, or describe a deck as finished before `deck-qa-brand` returns PASS. In a multi-market run, every market's deck runs its own rebuild loop and must individually reach PASS, and `deck-qa-brand`'s cross-deck check confirms no deck inherited another's figures.

## Deck structure — v3 (current default)

**Main section — makes the case and the plan (~16 pages for one pillar; no hard cap, but no slide may repeat a point another main slide already makes):**

1. **Hero** — the finding in one sentence, three numbers read from the data.
2. **Competitor creative diversity** — brand + every competitor (Step 12A). *Standard slide.*
3. **Whitespace, three cohorts** — creators / brand / competitors per territory, with verdicts.
4. **The gate** — trending AND whitespace; which territories clear both.
5. **Where to invest first** — the ranked pillar(s) and the nearest misses.
6. **The insight chain** — persona → tension → angles → stories, as layers.
7. **The stories, each with its creative** — every story card carries the creative the calendar runs most for it.
8. **The pillar in creative** — the strongest three creatives per funnel stage; **one slide per pillar**.
9. **Brand permission** — why the brand credibly belongs here.
10. **Integration** — how this extends what the brand already publishes.
11. **Calendar overview** — every slot on one grid, colour-coded by trigger type.
12. **Calendar, one page per month** — every post as its creative thumbnail with date, stage, anchor and trigger; lead posts framed.
13. **Lead-post briefs** — channel, message, CTA and audit chain, with the creative that runs that day.
14. **Recommendations** — three, ranked by what the data supports; the one number to re-check.

**Appendix — the evidence (opens with a single appendix divider; every appendix eyebrow is prefixed "Appendix ·"):** method notes · audience definition · share of voice + engagement · product reality · paid vs organic content mix + clickability lift · the creator trend line · territories examined and set aside · persona + character · all propositions (dedicated plates) · the excluded moment type · brand rules (organic-timeline palette + word band) · diversity worked calculation · predicted performance · the full creative library (every concept, 6 per page) · audit trail.

**No section dividers under v3** (only the appendix divider). The v2 six-part dividers remain available via `scope.ordering: "v2"`.

**What goes to the appendix — the test.** A slide belongs in the main section only if removing it would leave the decision unjustified or the plan un-executable. Charts that restate a point already made on a main slide (a trend line when the gate slide already carries the trend verdict; a share-of-voice chart when the diversity slide already carries the competitor comparison) go to the appendix.

### v2 reference (opt-in)

See `references/slide-blueprint.md` — the **briefing** blueprint. Per the v2 ordering, it opens with Method Notes + Additional Content Territories, then Setup & Method (competitive landscape, audience definition), then Whitespace & Trends (the diagnosis) and selection logic, THEN personas, then the permutation engine as layers. It carries share-of-voice + engagement and prior-year verification, and adds a brand-permission beat and an integration beat. When `influencerWorkspaceId` is provided the deck gains:
- A content-trend chart (emerging signals in Foodie-directed content)
- A 3-cohort whitespace dual-chart (Foodie-directed content + brand + competitor)
- A topicality callout slide from the live-30D influencer study

When the analysis interval is shorter than 90 days, the trend section collapses to a single delta-chart slide (not a 12-month line chart).

**Section dividers (v2 only — OFF under v3; 6 as of v2 ordering — was 5).** `build_deck.js` inserts 6 full-bleed dark title cards splitting the body into named parts — "Setup & Method", "Whitespace & Trends", "The Audience", "The Engine", "Calendar & Execution", "Proof & Recommendations" — each stating the part number, a one-line summary, and 2–4 bullets on exactly what's inside. They are entirely data-driven (brand/audience names interpolate; no hand-tuning per engagement) and sit at the blueprint's own section boundaries, so they hold up regardless of market or pillar count. Disable per-engagement with `scope.section_dividers: false` if the client explicitly doesn't want them — do not hand-edit the generated PPTX to remove them, and do not hand-roll a one-off divider scheme for a single engagement; if the default 6-part grouping genuinely doesn't fit a deck's structure, change `sectionDivider()`'s call sites in `build_deck.js` itself (updating every call's `total` argument together) so every future deck benefits.

**No duplicate pillar-ranking slide (fixed default).** `build_deck.js` renders exactly ONE ranked "Where to invest first" slide, sized dynamically to `pillars.length`. This replaced two separate slides — "market prioritisation" and "whitespace strategic frame" — that showed the identical pillar/verdict data twice back to back, and whose strategic-frame card grid hardcoded exactly 3 fixed-width columns (a real bug for any other pillar count). Do not reintroduce a second pillar-ranking slide in a single-market deck; the merge is a template default, not an engagement-specific edit. (The multi-market *cross-market summary* deck's own per-market strategic-frame slide is a distinct object and still required there — see *Multi-market runs* above.)

**Named creator/influencer panel disclosure (fixed default).** Whenever `scope.influencer_panel.profile_names` is populated, the Method Notes appendix slide adds an "Audience panel" row naming every creator in full (count + names + workspace ID), and the Audit Trail slide's traceability note points to it. A client asking "which creators did you actually analyze?" must be answerable from the deck itself — never leave the panel as an unnamed "content-proxy" black box when real names exist in scope. The row is entirely conditional and omitted (not shown blank) when no panel was used.

## Workflow map

See `references/workflow-map.md` for the full dependency graph.

## Common failure modes

**Briefing-specific (this variant) + shared correctness:**
- **Renders on palette but not like the brand's feed** — palette lock plus a composited logo is not brand fit. Creatives drawn in a look the brand does not use (brand-colour-drenched scenes, a model-drawn headline face, an oversized logo, the wrong format, offers without the brand's badge) fail Step 12B-fit's C1–C10. Measure the brand's own last-6-month timeline, render to its observed looks, typeset copy and composite the real logo, and show the before/after on the Brand-fit check slide.
- **Writing unaccomplished process steps into the deck** — a deck states findings; it never narrates work that could not be done. Blocked tools, refused uploads, skipped steps and reworded prompts go in the chat reply to the user, never on a slide and never in a headline (e.g. "no creative carried top-performer potential" when per-asset scoring was simply unavailable). Evidence limits that qualify a claim (an UNVERIFIED trend, a small cohort, a proxy score) DO stay on the slide as a qualifier — name the method used ("corpus-lift pattern read"), not the blockage ("per-asset upload blocked").
- **Repetitive main section** — five slides that each restate "one territory qualifies", or a trend line, a verdict table, a Venn and a ranking that all make the same point. Keep the gate and the ranking in the main section, move the rest to the appendix (§ "Deck structure — v3").
- **Calendar without creatives** — a calendar grid of trigger names alone makes the reader cross-reference a library 20 slides later. Every calendar post shows its creative (Step 12B-pre).
- **Creative scene implies a service the brand does not offer** — e.g. a clinician visiting a family home for a hospital that does no home visits. Record `brand.service_constraints[]` before authoring concepts and encode them in the brand-lock.
- **Palette or copy length taken from anywhere but the brand's organic timeline** — a website palette or a category-typical word count produces creatives that don't match the brand's feed. Both are measured, every run (§ "Two measured rules").
- **Omitting `profileIds` in `posts-aggregate` / `posts-search`** — it does NOT mean "all profiles"; it silently returns a partial workspace (observed: 1,935 posts vs 3,082 for the seven explicit profiles). Always pass explicit IDs for share-of-voice denominators. And the reverse leak: an explicit `profileIds` can still return another profile's items (observed: a query for one hospital's profile returned 17 ads from a rival hospital, and `posts-aggregate` leaked identically) — verify `profile.id` on every item.
- **Headline wraps into the subtitle, or labels overprint marks** — see Step 12 "Layout gates"; `deck-qa-brand` C7 fails any overlap.
- **Personas buried instead of leading the Engine section** — under v2 ordering, personas lead The Audience + The Engine sections (not the whole deck — see "Ordering, v2" above), and within those sections the order is still persona → tension → post evidence. A wall of disconnected tensions with no persona to hang them on reads as implausible to the client, regardless of which section it's in.
- **v2 ordering applied inconsistently (v2 opt-in only)** — a deck where Method Notes/Territories sit at the front but personas are STILL ordered before Whitespace & Trends (or vice versa) is a half-applied reorder, not a deliberate choice. Apply both changes from "Ordering, v2" together, or neither (if the engagement explicitly wants the old personas-first order).
- **Permutation engine hidden** — the persona→tension→angle→proposition chain must be shown as *layers* (one persona → many tensions → many propositions). A flat insight list throws away the coverage/credibility argument the briefing exists to make.
- **Raw post counts on the money slide** — show **share-of-voice + engagement**, not raw counts; raw counts mislead about who is under- vs over-indexing.
- **Directional trend shown as fact without the prior-year pass** — every RISING/FALLING claim needs `trend-analysis`'s prior-year verification; an unverified single-cycle "decline" may be a seasonal downslope. Render UNVERIFIED honestly rather than as a confident decline.
- **Brand inactivity sold as whitespace** — brand-LOW alone is not open ground (it may be a deliberate choice and competitors may be present). See `whitespace-analysis` → "Brand inactivity is NOT whitespace."
- **No brand-permission or integration beat** — competitor absence is not permission to enter. The briefing must say *why the brand credibly belongs* in a space and *how the recommendation extends what the brand already does* — not present a from-scratch plan.
- **Markets treated as equal priority** — rank markets by whitespace size; don't present three markets as one undifferentiated priority.
- **Website-analysis thread on a low-involvement client** — cut the brand-site/traffic thread for FMCG (nobody visits the site; performance marketing routes to sale). Keep it only for high-involvement categories (autos, considered purchases).
- **No post evidence before the recommendations** — show real example posts inline; clickable story links won't be opened.
- **Seasonal triggers invented for year-round pillars** — see `moment-generation` → "Seasonal trigger discipline"; a year-round behaviour (home cooking) carries no Oct/Nov season.

- **Audience-as-demand overclaim** — writing "audience demand", "what Foodies want", "what the audience is asking for", "what Foodies talk about", or "demand-side" anywhere in the deck. SOMIN measured content, not the audience (see "What SOMIN measures" above). Every such phrase is a factual overclaim and must read as content supply: "content made for Foodies", "Foodie-directed content", "what creators publish toward this audience". The `deck-qa-brand` skill's C10 check fails this.
- **Skipping brand extraction** — deck looks generic without real palette
- **Neutral/generic styling defaulted when no brand-guideline skill exists** — absence of a dedicated `<brand>-brand-guideline` skill is not licence to fall back to plain defaults or invented copy conventions. Run the content-inference fallback in "Brand-guideline resolution" against the brand's own SOMIN paid/organic content on `brandProfileId` before ever defaulting to neutral — the brand's real text density, CTA phrasing and format habits are almost always recoverable from its own published content.
- **Comparing cohorts of different sizes at shared % axis** — slide 12 uses dual proportional charts (whitespace-analysis handles; don't override)
- **Calendar size > moment supply** — check supply equation BEFORE calendar-build; add moment types if short
- **Inventing CTAs** — every CTA traces to `brand.facts` or `brand.offerings`
- **Forgetting audit trail slide** — final slide MUST list every study, character, story, product, proposition, moment ID across BOTH workspaces if influencer panel was used
- **Treating influencer signals as brand signals** — the influencer panel is content made FOR the audience by creators; the brand cohort is what the brand published. Different content, never merge them
- **Trend windows too small** — if `analysisIntervalDays / windowCount < 21`, themes won't stabilise; orchestrator rebalances per `references/interval-splitting.md`
- **Hardcoded numbers on summary/headline slides** — every figure shown on a slide (especially the one-page-read / "three numbers" slide and any headline stat) MUST be read from an analysis JSON (`whitespace.json`, `trends.json`), never written as a literal in the builder. A hardcoded stat silently survives market-to-market reuse and goes stale while the data-driven charts update correctly. If a literal must exist, it has to be re-derived per run.
- **Summary slide contradicts detail slides** — the headline/one-page-read slide and the detail slides (whitespace bars, verdict map, cohort cross-check) draw on the same underlying numbers; they must agree. After every build, cross-check the summary slide's figures against the detail slides. A mismatch means a stale literal somewhere.
- **Reusing the builder across engagements** — `scripts/build_deck.js` embeds no client and reads everything from the working-directory JSONs, so reuse is the intended path: point it at the new brand's `brand.json`/`scope.json`/analysis JSONs (see `references/data-contract.md`). Author the new voice through `brand.narrative`, never by editing the builder. Do **not** instead copy a prior engagement's *output* deck and patch its copy strings — patched copy leaves stale figures behind the new words.
- **Chart status labels not derived from the data** — a trend status (Rising / Falling / Sustained) is a claim about a line. Compute every status label from the series' actual values; never assign it independently. A "Rising" label on a falling line is a defect the `deck-qa-brand` skill will fail.
- **Chart axis maximum hardcoded** — never type a fixed `valAxisMaxVal` (e.g. 60, 80) into the builder. Compute every line/bar chart's axis maximum from the data: `max(all series values) × ~1.15` for headroom. A hardcoded axis fits the deck it was written for and silently clips the next market whose data runs higher — peaks shoot off the top of the chart. `deck-qa-brand` C4 fails this.
- **Reference URLs not clickable** — the brief requires every SOMIN insight/study/story/post to be referenced by its URL. Emit each reference as a real hyperlink in the PPTX, not plain text. Post references must resolve to the specific post, with its visual where layout allows. On the **audit-trail slide**, link every ID **that has a public SOMIN URL**: workspaces (`cloud.somin.ai/app/a/{wsId}`), studies (`…/a/{wsId}/studies/{studyId}`) and stories (`…/inspire/insights/story/{storyId}`). Persona, tension, angle, character, **product, proposition and moment** IDs have **no per-object public URL** — render them as plain IDs and note they are *traceable inside the workspace* (the builder does this automatically). Do **not** place a blanket "every ID is a live link" caption above plain-text IDs; scope the caption to what is actually clickable. The **page footer** "somin.ai" must be a live link on every slide. A traceability slide whose *linkable* IDs are styled-but-dead text fails `deck-qa-brand` C5.
- **Chart unreadable without context** — a line or bar chart must let a first-time reader quantify it. Either show a labelled axis or put a value label on each data point. A chart with a hidden axis AND no data labels — bare shapes the reader cannot put a number to — is a defect even if the geometry is accurate. Small-multiple panels especially: a row of mini-charts on a shared hidden axis needs point labels on every panel so levels can be read and compared. `deck-qa-brand` C4 fails this.
- **Delta notation that cherry-picks the peak** — writing a trend as "X → Y" where Y is the series' high point rather than its final value. The arrow implies an endpoint; using the peak misrepresents the trajectory. Show the true start→end and note the peak separately ("23 → 55 · peak 89"). `deck-qa-brand` C4 fails this.
- **Headline is consultant-register filler, not the finding** — every slide headline should state what the slide actually shows, in plain words. Do not reach for borrowed strategy-framework phrases ("where to play / how to play", "win the right to play", "north star", "the X imperative", "unlock / unpack / double-down") — they sound strategic but carry no specific finding and could sit on any deck. The same applies to on-slide card labels and eyebrows: "THE TERRITORY", not "WHERE TO PLAY". A punchy headline is fine when it states a real finding; it fails when cleverness substitutes for substance. `deck-qa-brand` C9 fails this.
- **Logo / wordmark rendered off-spec** — the SOMIN wordmark is the single word "SOMIN" as two tight tonal groups: "SO" teal `#2DBF9C`, "MIN" `#16201F` on light / `#FFFFFF` on dark, with NO space and NO wide tracking. Never render it in one flat colour, never space the letters out, never write "S O MIN". In PPTX, use two text runs (`"SO"` + `"MIN"`, no space) with small `charSpacing` (~0.4). Follow the `somin-brand-guideline` skill and its `assets/wordmark-spec.md` for every artefact.
- **Rendered creative carries a model-drawn logo or off-palette colour** — in the Creative-Library appendix every rendered cell must show the brand's real wordmark/logo *composited* into the reserved corner (the correct mark per the brand's brand-guideline, not one the model invented) and use only the brand's palette. A cell where the image model drew its own logo (an invented or misspelled mark) or introduced a colour outside the brand palette is a defect even when the caption styling is on-brand — fix it via Step 12B's brand-lock + wordmark composite. Relying on the engine's brand-token clause alone is the root cause. The `deck-qa-brand` creative-expressions check must fail this, not only non-default styling.
- **Comparison slide whose columns do not differ** — an N-up slide that sets out to compare markets (or pillars, segments, periods) must make the compared dimension actually vary. Two failure shapes: (1) the hero stat or label is identical across every column — three "1 of 6" tiles read as a layout error and carry no information after the first; the varying dimension should BE the hero number. (2) columns mix incompatible metrics or units under one headline — e.g. three columns showing a ratio and the fourth a raw count — so nothing is comparable. Before shipping a comparison slide, check: does the hero number differ column to column, and is it the same metric and unit everywhere? If a stat genuinely is uniform across all columns, that uniformity is the story — state it once in prose, do not repeat it as N identical tiles. `deck-qa-brand` C11 fails this.
- **Inconsistent category colour-coding** — every recurring category (each whitespace verdict, each pillar) must use ONE colour and ONE unambiguous label everywhere it appears across the deck. Define the colour-to-category map once and reuse it; never let a category change colour between slides.
- **Platform objects shown without their real fields** — when a slide presents a SOMIN object (proposition, study, moment), render that object's actual fields retrieved from the API. Never invent content for it or silently drop its defining fields.
- **Propositions shown as bare ID references** — a proposition card that prints only "Proposition 1201" (or just the focus type) shows the ID, not the proposition. Every proposition on a slide must carry its real name (focus line) and its insight tagline, retrieved via `propositions-list`. The ID is metadata, not the content. `deck-qa-brand` C8 fails an ID-only card.
- **Only a subset of generated objects reaches the deck** — if the analysis generated 9 propositions, 3 insight chains and N moments, the deck must show all of them (propositions on dedicated plate slides per the blueprint). Quietly displaying 3 of 9 propositions, or dropping a pillar's chain, is a completeness defect — `deck-qa-brand` C13 fails it.
- **Reduced-scope deck shipped as the full deliverable** — skipping the trend windows, moments or content calendar produces a ~14-slide deck, far short of the standard 35–45 (main section + appendix). That is a legitimate option only when *declared to the user up front* with the slide-count consequence (see *Scope discipline*). Building the short deck silently — especially because publish dates or an interval were not supplied — and presenting it as the complete strategy deck is a defect; `deck-qa-brand` C13 fails a deck whose section coverage is below its agreed scope.
- **Body content colliding with the footer band** — the page footer and page number occupy a reserved strip at the bottom of every slide. Captions, footnotes, chart labels and the last row of any card grid must clear it. Recurring overflow into the footer is a layout defect; size card grids and place footnotes against the footer band's top edge, not the slide edge. `deck-qa-brand` C7 fails footer collisions.

- **Predicted-performance step mishandled** — (a) showing a "Top performer potential" summary slide when **no** creative scored above-average ≥ 0.80; the summary slide and badges must be **skipped** when nothing qualifies (`score_annotate.py` enforces this). (b) Running the step when Step 12B was skipped — it runs only when a Creative-Library appendix was rendered. (c) Calling the scores "results" — they are pre-launch *predictions*, not measured performance. (d) Enumerating winners with the `clickability:"High"` filter (caps at 50, drops genuine ≥80% creatives) instead of retrieving every uploaded postId and thresholding. (e) Giving up when `posts-search` returns empty — scoring is asynchronous and takes 10–30+ min; poll until every id finalizes. (f) **Skipping 12C after Step 12B rendered creatives — it is MANDATORY whenever a Creative Library exists; a rendered library with no predicted-performance pass fails QA. If per-asset scoring is unsupported, fall back to paid-corpus clickability-lift grading — never drop the step.** See the `creative-scoring` skill.

## Token discipline

- Most token-expensive skill in the library — use deliberately
- All intermediate JSONs on disk; pass paths between scripts
- `build_deck.js` (data-driven pptxgenjs, ~700 lines) executes via bash — never read it into context