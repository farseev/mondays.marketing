/* SOMIN cross-market BRIEFING deck — DATA-DRIVEN, BRAND-AGNOSTIC builder.
   Reads brand.json + scope.json + the analysis JSONs from the working directory.
   NOTHING about any client is hardcoded here: identity (wordmark, palette, audience,
   market, workspace) comes from brand.json/scope.json; every figure comes from the
   analysis JSONs; bespoke copy is DATA-DERIVED with an optional brand.narrative override
   (see references/data-contract.md for the full input schema).
   Run from the engagement dir:  node build_deck.js   ·   verify:  node --check build_deck.js */
const fs = require("fs");
const pptxgen = require("pptxgenjs");
const D = p => JSON.parse(fs.readFileSync(p, "utf8"));

const brand   = D("brand.json");
const studies = D("studies_primary.json");
const trends  = D("trends_primary.json");
const ws      = D("whitespace.json");
const pillars = D("pillars.json").pillars;
const personas= D("personas.json");
const paid    = D("paid.json");
const insights= D("insights.json");
const props   = D("propositions.json");
const cal     = D("calendar.json");
const scope   = D("scope.json");

// ===== engagement identity & narrative (data-driven; NO embedded client) =====
const nar = brand.narrative || {};
const N   = (k, f) => (nar[k] != null ? nar[k] : f);          // narrative override else derived fallback
const _m0 = (scope.markets && scope.markets[0]) || {};
const BRAND    = brand.brand || brand.name || _m0.brand_name || "Brand";
const MARKET   = scope.market || _m0.name || brand.market || "";
const AUDIENCE = scope.audience || (scope.audience_filter && (scope.audience_filter.values||[])[0]) || "Professionals";
const WSID     = scope.workspace_id || _m0.workspace_id;
const BRANDPROF= scope.brand_profile_id || _m0.brand_profile_id;
const NCOMP    = (studies.competitors || []).length;
const WM       = brand.wordmark || {};
const PEAKWIN  = (() => { let b = studies.trend_studies[0]; (studies.trend_studies||[]).forEach(x => { if (x.n > b.n) b = x; }); return b; })();
const PROP_IDS = (() => { const a = []; Object.values(props.by_pillar||{}).forEach(pl => (pl.propositions||[]).forEach(pr => a.push(pr.id))); return a; })();
const PROP_N   = PROP_IDS.length;

// ---------- palette (from brand.json) ----------
const C = brand.colors;
const PRIMARY=C.primary.slice(1), DEEP=C.deep_navy.slice(1), MID=C.midnight.slice(1), ACTION=C.action_blue.slice(1);
const WHITE="FFFFFF", PAGE=C.page_grey.slice(1), INK=C.ink.slice(1), BODY=C.body.slice(1),
      SEC=C.secondary.slice(1), SOFT=C.chrome.slice(1), HAIR=C.hairline.slice(1),
      CARDNAVY="0C2F66", DIVNAVY="1C3F73", SECDARK="B9C4D6";
const TEAL="2DBF9C"; // SOMIN producer mark only
const FONT="Arial";
const PC = {P1: brand.category_colors.P1.slice(1), P2: brand.category_colors.P2.slice(1), P3: brand.category_colors.P3.slice(1), MENS:"8B93A1"};
const VC = {WHITESPACE:ACTION, PARTIAL:PRIMARY, CONTESTED:SEC, EMERGING:"7BA7E0"};
// theme<->pillar colour unity
const THEME_COLOR = {EDU:PC.P2, CLIN:PC.P1, TRUST:PC.P3, MENS:PC.MENS};

const pres = new pptxgen();
pres.defineLayout({ name:"W", width:13.333, height:7.5 });
pres.layout = "W";
pres.author = "SOMIN"; pres.company = "SOMIN"; pres.title = BRAND+" "+MARKET+" \u2014 "+AUDIENCE+" briefing";
const SW=13.333, SH=7.5, M=0.62, FOOT=6.9;

// ---------- helpers ----------
function bg(s,c){ s.background={color:c}; }
function wordmark(s, onDark){
  const col = onDark ? WHITE : PRIMARY;
  const big = (WM.primary || BRAND || "BRAND");
  s.addText(big,{x:M,y:0.30,w:3.6,h:0.5,fontFace:FONT,fontSize:26,bold:true,color:col,charSpacing:1.5,margin:0,valign:"middle"});
  if(WM.dot_on_o && big.toUpperCase().indexOf("O")>=0){
    s.addShape(pres.shapes.OVAL,{x:M+0.475,y:0.515,w:0.062,h:0.062,fill:{color:col},line:{type:"none"}});
  }
  if(WM.sub) s.addText(WM.sub,{x:M+0.02,y:0.74,w:3.8,h:0.22,fontFace:FONT,fontSize:8.5,bold:true,color:col,charSpacing:2.2,margin:0,valign:"middle"});
}
function footer(s, n, onDark){
  const sub = onDark ? SECDARK : SOFT;
  s.addText([{text:"Prepared with ",options:{color:sub}},
             {text:"SO",options:{color:TEAL,bold:true}},
             {text:"MIN",options:{color:onDark?WHITE:INK,bold:true}}],
    {x:M,y:FOOT,w:3.2,h:0.3,fontFace:FONT,fontSize:9,margin:0,valign:"middle",charSpacing:0.3});
  s.addText("somin.ai",{x:3.0,y:FOOT,w:1.2,h:0.3,fontFace:FONT,fontSize:9,color:sub,margin:0,valign:"middle"});
  s.addText(BRAND+" \u00b7 "+MARKET+" \u00b7 "+AUDIENCE,{x:SW-6.2,y:FOOT,w:5.0,h:0.3,align:"right",fontFace:FONT,fontSize:8.5,color:sub,margin:0,valign:"middle"});
  s.addText(String(n),{x:SW-1.0,y:FOOT,w:0.4,h:0.3,align:"right",fontFace:FONT,fontSize:9,color:sub,margin:0,valign:"middle"});
}
function eyebrow(s,t,c){ s.addText(t,{x:M,y:1.18,w:SW-2*M,h:0.3,fontFace:FONT,fontSize:12,bold:true,color:c||ACTION,margin:0}); }
function headline(s,t,onDark,size){ s.addText(t,{x:M,y:1.5,w:SW-2*M,h:1.0,fontFace:FONT,fontSize:size||23,bold:true,color:onDark?WHITE:INK,margin:0,valign:"top",lineSpacing:(size||23)*1.12}); }
function pill(s,t,x,y,w){ s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y,w:w||2.4,h:0.42,rectRadius:0.21,fill:{color:ACTION},line:{type:"none"}});
  s.addText(t,{x,y,w:w||2.4,h:0.42,align:"center",valign:"middle",fontFace:FONT,fontSize:11,bold:true,color:WHITE,margin:0}); }
function card(s,x,y,w,h,fill){ s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y,w,h,rectRadius:0.08,fill:{color:fill||WHITE},line:{color:HAIR,width:1},
  shadow:{type:"outer",color:"9AA3B0",blur:7,offset:3,angle:135,opacity:0.18}}); }
function vdots(s,x,y,h){ s.addShape(pres.shapes.LINE,{x,y,w:0,h,line:{color:HAIR,width:1.5,dashType:"sysDot"}}); }
function num(s){ return s.toLocaleString("en-US"); }
function txtOn(hex){ const h=hex.replace("#",""); const lum=parseInt(h.substr(0,2),16)*0.299+parseInt(h.substr(2,2),16)*0.587+parseInt(h.substr(4,2),16)*0.114; return lum>150?INK:WHITE; }
// dense list rows carry the lead clause of a note (before " — "/" -- "), trimmed to a max
// length — real text, just not the full supporting sentence, so many rows fit without overlap.
function shortNote(str, maxLen){ maxLen = maxLen || 100; let t = String(str||"").split(/\s+—\s+|\s+--\s+/)[0].trim();
  if(t.length > maxLen) t = t.slice(0, maxLen-1).replace(/\s+\S*$/,"") + "…";
  return t; }
const Q = trends.quarters, L = trends.labels;
const sUrl = id => `https://cloud.somin.ai/app/a/${WSID}/studies/${id}`;
const storyUrl = id => `https://cloud.somin.ai/app/inspire/insights/story/${id}`;

let page=0;
function slide(onDark){ const s=pres.addSlide(); bg(s,onDark?MID:PAGE); page++; wordmark(s,onDark); footer(s,page,onDark); return s; }

// ---------- section divider: full-bleed dark title card separating major report parts ----------
// Default ON (disable per-engagement with scope.section_dividers===false). Five broad parts
// map onto references/slide-blueprint.md's eight named sections so the labels stay generic
// across any brand/market — do not hand-tune per engagement; adjust the blueprint instead.
const SECTION_DIVIDERS = scope.section_dividers !== false;
function sectionDivider(idx, total, title, blurb, steps){
  const s = pres.addSlide(); bg(s,MID); page++; wordmark(s,true); footer(s,page,true);
  s.addShape(pres.shapes.RECTANGLE,{x:0,y:0,w:0.14,h:SH,fill:{color:ACTION},line:{type:"none"}});
  s.addText(`PART ${idx} OF ${total}`,{x:M,y:2.0,w:SW-2*M,h:0.35,fontFace:FONT,fontSize:13,bold:true,color:SECDARK,charSpacing:2,margin:0});
  s.addText(title,{x:M,y:2.45,w:SW-2*M,h:1.15,fontFace:FONT,fontSize:40,bold:true,color:WHITE,margin:0,lineSpacing:44});
  s.addText(blurb,{x:M,y:3.72,w:10.2,h:0.9,fontFace:FONT,fontSize:14.5,color:SECDARK,margin:0,valign:"top",lineSpacing:20});
  let y = 4.78;
  steps.forEach(st=>{
    s.addShape(pres.shapes.OVAL,{x:M+0.02,y:y+0.085,w:0.09,h:0.09,fill:{color:ACTION},line:{type:"none"}});
    s.addText(st,{x:M+0.3,y:y-0.06,w:10.0,h:0.36,fontFace:FONT,fontSize:12.5,color:WHITE,margin:0,valign:"top"});
    y += 0.44;
  });
  return s;
}

// ============================================================================
// DECK ORDERING, v2 (client-directed default as of this session) —
// Setup & Method -> Whitespace & Trends -> selection logic (prioritisation) ->
// The Audience (personas) -> The Engine (permission/integration/chains/propositions)
// -> Calendar & Execution -> Proof & Recommendations -> Appendix (creative library only).
// Method Notes and Additional Content Territories, formerly the LAST two appendix
// slides, are now the FIRST two slides after the hero, so a reader sees how this
// briefing was produced before any analysis. Personas moved from leading the whole
// deck to leading only the Engine section, immediately after whitespace/trend/
// prioritisation have surfaced the pillars a persona then gets attached to.
// This is a deliberate reversal of an earlier "personas-first" design (still the
// right call for other engagements that haven't asked for this ordering) -- see
// references/slide-blueprint.md § "Ordering principle, v2" for the full rationale
// and for what a future re-order should re-check before changing this again.
// ============================================================================

// ============================================================ S1 — HERO
(()=>{ const s=pres.addSlide(); bg(s,MID); page++;
  s.addShape(pres.shapes.RECTANGLE,{x:0,y:0,w:SW,h:1.6,fill:{color:DEEP},line:{type:"none"}});
  wordmark(s,true);
  s.addText(N("hero_eyebrow","Cross-market briefing  \u00b7  "+MARKET+" workspace #"+WSID),{x:M,y:2.5,w:SW-2*M,h:0.4,fontFace:FONT,fontSize:13,bold:true,color:SECDARK,charSpacing:1,margin:0});
  s.addText(N("synthesis",BRAND+": the strategic read."),{x:M,y:3.0,w:SW-2*M,h:1.5,fontFace:FONT,fontSize:46,bold:true,color:WHITE,margin:0,lineSpacing:46});
  s.addText(N("synthesis_sub","Content made for "+AUDIENCE+" in "+MARKET+", read across "+BRAND+" and "+NCOMP+" competitors \u2014 where the strengths already pay off, and the open ground still to claim."),
    {x:M,y:4.7,w:9.6,h:1.2,fontFace:FONT,fontSize:15,color:SECDARK,margin:0,valign:"top",lineSpacing:21});
  s.addText([{text:"Window  ",options:{color:SOFT}},{text:N("window",scope.window_label||""),options:{color:WHITE,bold:true}},
             {text:"     Sources  ",options:{color:SOFT}},{text:"Organic + paid",options:{color:WHITE,bold:true}},
             {text:"     Audience  ",options:{color:SOFT}},{text:AUDIENCE,options:{color:WHITE,bold:true}}],
    {x:M,y:6.35,w:SW-2*M,h:0.4,fontFace:FONT,fontSize:12,margin:0});
  s.addText([{text:"Prepared with ",options:{color:SECDARK}},{text:"SO",options:{color:TEAL,bold:true}},{text:"MIN",options:{color:WHITE,bold:true}},
             {text:"   \u00b7   somin.ai",options:{color:SECDARK}}],
    {x:SW-3.6,y:6.95,w:3.0,h:0.3,align:"right",fontFace:FONT,fontSize:10,margin:0});
})();

// ============================================================ METHOD NOTES (moved upfront, right after the hero, per client-directed ordering — a reader should see how this briefing was produced before the analysis starts. Kept OUT of the Appendix on purpose; see the ordering note near the top of this file and references/slide-blueprint.md § "Ordering principle, v2".)
(()=>{ const s=slide(false);
  eyebrow(s,"Method notes");
  headline(s,"How to read this briefing.");
  const baseNotes=[["What SOMIN measures","Content, not people. Every \u201Caudience\u201D figure is content created for that audience; engagement is the only audience-side signal, as volume."],
    ["Trend windows",studies.trend_studies.length+" quarterly windows give a readable line and built-in same-quarter prior-year verification."],
    ["Whitespace method","Share-of-cohort over the recent window. Proportional, never raw counts, because the cohorts differ in size."],
    ["Noise handling","Cross-specialty content is excluded from the core pillars but noted where it shapes paid."],
    ["Sources","Organic = SOMIN PAGES; paid = ADS_LIBRARY. Both filtered to the "+AUDIENCE+" audience across "+BRAND+" + "+NCOMP+" competitors."]];
  // Disclose the real named creator/influencer panel whenever the engagement used one as evidence \u2014
  // it is core evidence for the whitespace/trend read and must not be an unnamed "content-proxy"
  // black box. Row is added only when scope.json actually carries an influencer_panel; omitted
  // entirely (not a placeholder row) when the engagement has none.
  const ip = scope.influencer_panel || {};
  if ((ip.profile_names||[]).length) {
    baseNotes.push(["Audience panel","The "+AUDIENCE+" content-proxy is "+ip.profile_names.length+" named creators (workspace "+ip.workspace_id+"): "+ip.profile_names.join(", ")+" \u2014 tracked across the same monitoring windows as the brand cohort."]);
  }
  const notes = N("method_notes", baseNotes);
  const mnDy = Math.min(0.74, (FOOT-0.15-2.8)/Math.max(1,notes.length)), mnCh = Math.max(0.5, mnDy-0.1);
  notes.forEach((n,i)=>{ const y=2.8+i*mnDy; card(s,M,y,SW-2*M,mnCh);
    s.addText(n[0],{x:M+0.25,y:y+0.08,w:3.3,h:mnCh-0.16,valign:"middle",fontFace:FONT,fontSize:11,bold:true,color:PRIMARY,margin:0,lineSpacing:13});
    s.addText(n[1],{x:M+3.7,y:y+0.06,w:8.8,h:mnCh-0.12,valign:"middle",fontFace:FONT,fontSize:9.5,color:BODY,margin:0,lineSpacing:12}); });
  s.addText([{text:"Prepared with ",options:{color:SEC}},{text:"SO",options:{color:TEAL,bold:true}},{text:"MIN",options:{color:INK,bold:true}},{text:"  \u00b7  somin.ai  \u00b7  data pulled June 2026",options:{color:SEC}}],
    {x:M,y:6.7,w:SW-2*M,h:0.3,fontFace:FONT,fontSize:9.5,margin:0});
})();

// ============================================================ ADDITIONAL CONTENT TERRITORIES (moved upfront, right after Method Notes — see ordering note near the top of this file)
(()=>{ const s=slide(false);
  eyebrow(s,"Additional content territories");
  headline(s,N("territories_headline","More content suited to "+BRAND+" and this audience."));
  const cats=N("extra_territories",(brand.offerings||[]).slice(0,6).map(o=>[o.name,o.note||""]));
  const cols=2, cw=6.05, ch=1.18, x0=M, y0=2.75, gx=0.2, gy=0.12;
  cats.forEach((c,i)=>{ const r=Math.floor(i/cols), cc=i%cols; const x=x0+cc*(cw+gx), y=y0+r*(ch+gy);
    card(s,x,y,cw,ch); s.addShape(pres.shapes.RECTANGLE,{x,y,w:0.1,h:ch,fill:{color:i%2?ACTION:PRIMARY},line:{type:"none"}});
    s.addText(c[0],{x:x+0.25,y:y+0.12,w:cw-0.45,h:0.32,fontFace:FONT,fontSize:12,bold:true,color:PRIMARY,margin:0});
    s.addText(c[1],{x:x+0.25,y:y+0.44,w:cw-0.45,h:0.68,fontFace:FONT,fontSize:9.3,color:BODY,margin:0,valign:"top",lineSpacing:12}); });
})();

// ============================================================ DIVIDER 1 — SETUP & METHOD
if (SECTION_DIVIDERS) sectionDivider(1,6,"Setup & Method",
  `Who "${AUDIENCE}" are, what's already in market, and how every claim in this deck was produced.`,
  [`The audience, defined — who "${AUDIENCE}" are and what SOMIN actually measured`,
   "The competitive landscape and "+BRAND+"'s own product reality",
   "The method, and why the "+AUDIENCE+" panel is read separately"]);

// ============================================================ S2 — AUDIENCE DEFINED
(()=>{ const s=slide(false);
  eyebrow(s,"The audience, defined");
  headline(s,N("s2_headline","Who \u201C"+AUDIENCE+"\u201D are \u2014 and what SOMIN actually measured."));
  card(s,M,2.7,6.0,3.4);
  s.addText("The audience",{x:M+0.35,y:2.95,w:5.3,h:0.35,fontFace:FONT,fontSize:14,bold:true,color:ACTION,margin:0});
  s.addText(personas.primary.definition,{x:M+0.35,y:3.35,w:5.3,h:1.5,fontFace:FONT,fontSize:12.5,color:BODY,margin:0,valign:"top",lineSpacing:18});
  s.addText([{text:"Primary persona  ",options:{color:SEC}},{text:personas.primary.name,options:{bold:true,color:INK}}],
    {x:M+0.35,y:5.45,w:5.3,h:0.4,fontFace:FONT,fontSize:12,margin:0});
  card(s,6.95,2.7,5.78,3.4,"FFFFFF");
  s.addText("What SOMIN measures",{x:7.3,y:2.95,w:5.1,h:0.35,fontFace:FONT,fontSize:14,bold:true,color:ACTION,margin:0});
  s.addText(N("s2_measure","SOMIN classifies content \u2014 what posts are about and which audience they were made for. \u201C"+AUDIENCE+"\u201D is therefore a property of the content: posts created for that audience by "+BRAND+" and its competitors. It is a content-supply signal, not a measured group of people."),
    {x:7.3,y:3.35,w:5.1,h:1.7,fontFace:FONT,fontSize:12,color:BODY,margin:0,valign:"top",lineSpacing:17});
  s.addText(N("s2_caveat","Throughout this deck we describe what is published toward "+AUDIENCE+" \u2014 never \u201Cwhat they want.\u201D Views and engagement are the only audience-side signal, and only as volume."),
    {x:7.3,y:5.15,w:5.1,h:0.9,fontFace:FONT,fontSize:11,italic:true,color:SEC,margin:0,valign:"top",lineSpacing:15});
})();

// ============================================================ S3 — COMPETITIVE LANDSCAPE
(()=>{ const s=slide(false);
  eyebrow(s,"The competitive landscape");
  headline(s,N("s3_headline",BRAND+" versus "+NCOMP+" "+(MARKET||"").toLowerCase()+" competitors in one workspace."));
  // brand chip
  s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:M,y:2.7,w:3.0,h:1.5,rectRadius:0.08,fill:{color:PRIMARY},line:{type:"none"}});
  s.addText(BRAND,{x:M,y:3.05,w:3.0,h:0.5,align:"center",fontFace:FONT,fontSize:18,bold:true,color:WHITE,margin:0});
  s.addText("Brand profile"+(BRANDPROF?" #"+BRANDPROF:""),{x:M,y:3.6,w:3.0,h:0.3,align:"center",fontFace:FONT,fontSize:10,color:SECDARK,margin:0});
  s.addText("The "+NCOMP+" tracked competitors \u2014 tracked for parity",{x:4.0,y:2.62,w:8.7,h:0.3,fontFace:FONT,fontSize:11,bold:true,color:SEC,margin:0});
  const comps=studies.competitors; const cols=3, cw=2.78, ch=0.62, gx=0.07, gy=0.12, x0=4.0, y0=3.0;
  comps.forEach((c,i)=>{ const r=Math.floor(i/cols), cc=i%cols; const x=x0+cc*(cw+gx), y=y0+r*(ch+gy);
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y,w:cw,h:ch,rectRadius:0.06,fill:{color:WHITE},line:{color:HAIR,width:1}});
    s.addText(c.name,{x:x+0.12,y,w:cw-0.24,h:ch,valign:"middle",fontFace:FONT,fontSize:11.5,bold:true,color:INK,margin:0}); });
  s.addText(N("landscape_note","Some competitors also publish in adjacent specialties; this briefing isolates "+(MARKET||"").toLowerCase()+" content made for "+AUDIENCE+"."),
    {x:M,y:6.15,w:SW-2*M,h:0.45,fontFace:FONT,fontSize:10,italic:true,color:SEC,margin:0});
})();

// ============================================================ S4 — THREE-STAT ONE-PAGE READ
(()=>{ const s=pres.addSlide(); bg(s,MID); page++; wordmark(s,true); footer(s,page,true);
  eyebrow(s,"The one-page read"); s.addText("Three numbers that frame the opportunity.",{x:M,y:1.5,w:SW-2*M,h:0.8,fontFace:FONT,fontSize:23,bold:true,color:WHITE,margin:0});
  const edu=trends.series.EDU, clin=trends.series.CLIN, tr=trends.series.TRUST;
  const wsTrust=ws.themes.find(t=>t.key==="TRUST");
  const stats=[
    {big:`${edu.values.W1} \u2192 ${edu.values.W8}`, lab:"Lead-theme content per quarter", sub:"Rising · prior-year verified (up YoY 4/4 quarters). The most persistent theme in every window.", c:THEME_COLOR.EDU},
    {big:`${clin.values.W1} \u2192 ${clin.values.W8}`, lab:"Emerging-theme content per quarter", sub:`Rising · verified. Peak ${clin.trend.peak} in ${Q[clin.trend.peak_window]}. `+BRAND+`'s product home ground.`, c:THEME_COLOR.CLIN},
    {big:`${wsTrust.brand_share}% vs ${wsTrust.comp_share}%`, lab:"Peer-community content: "+BRAND+" vs competitors", sub:"WHITESPACE. Emerging in the category, near-absent for the brand \u2014 the open territory.", c:"7BA7E0"}
  ];
  stats.forEach((st,i)=>{ const x=M+i*4.07; card(s,x,2.7,3.85,3.4,CARDNAVY);
    s.addShape(pres.shapes.RECTANGLE,{x:x,y:2.7,w:0.12,h:3.4,fill:{color:st.c},line:{type:"none"}});
    s.addText(st.big,{x:x+0.3,y:3.05,w:3.4,h:1.0,fontFace:FONT,fontSize:34,bold:true,color:WHITE,margin:0});
    s.addText(st.lab,{x:x+0.3,y:4.15,w:3.35,h:0.7,fontFace:FONT,fontSize:13,bold:true,color:WHITE,margin:0,valign:"top",lineSpacing:17});
    s.addText(st.sub,{x:x+0.3,y:4.95,w:3.35,h:1.0,fontFace:FONT,fontSize:10.5,color:SECDARK,margin:0,valign:"top",lineSpacing:14}); });
})();

// ============================================================ S5 — METHOD / FIVE LAYERS
(()=>{ const s=slide(false);
  eyebrow(s,"How we got here");
  headline(s,"Five layers of SOMIN analysis behind every recommendation.");
  const layers=[["Product",N("layer_product",BRAND+"'s real "+(MARKET||"").toLowerCase()+" portfolio \u2014 the right to make each claim.")],
    ["Content",N("layer_content","Organic + paid posts made for "+AUDIENCE+", across "+(NCOMP+1)+" brands.")],
    ["Trend",studies.trend_studies.length+" trend windows; direction confirmed against the prior year."],
    ["Whitespace","Brand vs competitor share within each cohort \u2014 what is open, contested or owned."],
    ["Insights","Persona \u2192 tension \u2192 angle \u2192 story \u2192 proposition \u2014 the engine that fills the calendar."]];
  const cw=2.3, x0=M, y0=2.9;
  layers.forEach((ly,i)=>{ const x=x0+i*(cw+0.09);
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y:y0,w:cw,h:2.7,rectRadius:0.07,fill:{color:WHITE},line:{color:HAIR,width:1}});
    s.addShape(pres.shapes.OVAL,{x:x+0.25,y:y0+0.28,w:0.5,h:0.5,fill:{color:i<4?PRIMARY:ACTION},line:{type:"none"}});
    s.addText(String(i+1),{x:x+0.25,y:y0+0.28,w:0.5,h:0.5,align:"center",valign:"middle",fontFace:FONT,fontSize:16,bold:true,color:WHITE,margin:0});
    s.addText(ly[0],{x:x+0.22,y:y0+0.95,w:cw-0.44,h:0.4,fontFace:FONT,fontSize:14,bold:true,color:INK,margin:0});
    s.addText(ly[1],{x:x+0.22,y:y0+1.35,w:cw-0.44,h:1.2,fontFace:FONT,fontSize:10.5,color:BODY,margin:0,valign:"top",lineSpacing:14});
    if(i<4) s.addText("\u203A",{x:x+cw-0.04,y:y0+1.0,w:0.18,h:0.5,align:"center",valign:"middle",fontFace:FONT,fontSize:20,bold:true,color:SOFT,margin:0}); });
})();

// ============================================================ S6 — PRODUCT REALITY
(()=>{ const s=slide(false);
  eyebrow(s,"The product reality");
  headline(s,N("s6_headline",BRAND+" has the right to make every claim it makes."));
  const offs=brand.offerings.slice(0,6); const cols=3, cw=3.9, ch=1.18, x0=M, y0=2.75, gx=0.08, gy=0.14;
  offs.forEach((o,i)=>{ const r=Math.floor(i/cols), cc=i%cols; const x=x0+cc*(cw+gx), y=y0+r*(ch+gy);
    card(s,x,y,cw,ch);
    s.addText(o.name,{x:x+0.2,y:y+0.12,w:cw-0.4,h:0.34,fontFace:FONT,fontSize:12,bold:true,color:PRIMARY,margin:0});
    s.addText(o.note,{x:x+0.2,y:y+0.46,w:cw-0.4,h:0.64,fontFace:FONT,fontSize:9.5,color:BODY,margin:0,valign:"top",lineSpacing:12}); });
  s.addText([{text:"Reason to believe   ",options:{bold:true,color:ACTION}},{text:brand.rtb.slice(0,3).join("   \u00b7   "),options:{color:BODY}}],
    {x:M,y:y0+2*(ch+gy)+0.05,w:SW-2*M,h:0.5,fontFace:FONT,fontSize:10.5,margin:0,valign:"middle"});
})();

// ============================================================ S7 — CONTENT PROOF WALL (per-window dominant theme) DARK
(()=>{ const s=pres.addSlide(); bg(s,MID); page++; wordmark(s,true); footer(s,page,true);
  eyebrow(s,"The content, quarter by quarter");
  s.addText(N("s7_headline","What "+AUDIENCE+" content was about, every quarter."),{x:M,y:1.5,w:SW-2*M,h:0.8,fontFace:FONT,fontSize:21,bold:true,color:WHITE,margin:0});
  // per-window dominant macro-theme (compute from trends series)
  const labels=L; const seriesKeys=["EDU","CLIN","TRUST","MENS"];
  const rowY=2.6, rh=0.5;
  labels.forEach((lab,i)=>{ const y=rowY+i*rh;
    let best="EDU",bv=-1; seriesKeys.forEach(k=>{const v=trends.series[k].values[lab]; if(v>bv){bv=v;best=k;}});
    const st=studies.trend_studies[i];
    s.addText(Q[lab],{x:M,y,w:1.8,h:rh,valign:"middle",fontFace:FONT,fontSize:10.5,bold:true,color:WHITE,margin:0});
    // bar proportional to window size
    const maxN=Math.max(...studies.trend_studies.map(t=>t.n));
    const bw=Math.max(0.25, (st.n/maxN)*5.4);
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:2.5,y:y+0.07,w:bw,h:rh-0.18,rectRadius:0.04,fill:{color:THEME_COLOR[best]},line:{type:"none"}});
    s.addText(`${trends.series[best].name}`,{x:2.5+bw+0.12,y,w:6.0,h:rh,valign:"middle",fontFace:FONT,fontSize:9.5,color:SECDARK,margin:0});
    s.addText([{text:`n=${st.n}  `,options:{color:WHITE,bold:true}},{text:`study ${st.id}`,options:{color:"7FB0FF"}}],
      {x:SW-2.5,y,w:1.9,h:rh,align:"right",valign:"middle",fontFace:FONT,fontSize:9,margin:0}); });
  s.addText(N("s7_note","Bars = volume of "+AUDIENCE+" content in each quarter; colour = the dominant theme."),
    {x:M,y:rowY+labels.length*rh+0.08,w:SW-2*M,h:0.5,fontFace:FONT,fontSize:9.5,italic:true,color:SECDARK,margin:0});
})();

// ============================================================ S8 — PEAK QUARTER SPOTLIGHT
(()=>{ const s=slide(false);
  eyebrow(s,"Breakout quarter");
  const w6=PEAKWIN;
  headline(s,N("peak_headline",Q[w6.label]+": the busiest quarter for "+(MARKET||"").toLowerCase()+" content."));
  card(s,M,2.8,3.7,2.9,PRIMARY);
  s.addText(num(w6.n),{x:M,y:3.05,w:3.5,h:1.0,align:"center",fontFace:FONT,fontSize:52,bold:true,color:WHITE,margin:0});
  s.addText("content items made for "+AUDIENCE+" in "+Q[w6.label],{x:M+0.25,y:4.1,w:3.2,h:0.8,align:"center",fontFace:FONT,fontSize:12,color:SECDARK,margin:0,valign:"top",lineSpacing:16});
  s.addText("study "+w6.id,{x:M,y:5.25,w:3.7,h:0.3,align:"center",fontFace:FONT,fontSize:10,bold:true,color:"7FB0FF",margin:0});
  const pts=N("peak_rows",(()=>{ const pw=w6.label; return Object.keys(trends.series).map(k=>({name:trends.series[k].name,v:(trends.series[k].values[pw]||0)})).sort((a,b)=>b.v-a.v).slice(0,3).map(x=>[x.name,x.v+" items"]); })());
  pts.forEach((p,i)=>{ const y=2.9+i*0.95; card(s,4.6,y,8.1,0.82);
    s.addText(p[0],{x:4.85,y:y+0.1,w:7.6,h:0.34,fontFace:FONT,fontSize:13,bold:true,color:INK,margin:0});
    s.addText(p[1],{x:4.85,y:y+0.44,w:7.6,h:0.3,fontFace:FONT,fontSize:10.5,color:BODY,margin:0}); });
  s.addText(N("peak_note",""),
    {x:4.6,y:5.8,w:8.1,h:0.5,fontFace:FONT,fontSize:9.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ S9 — HOW WE READ THE MARKET
(()=>{ const s=slide(false);
  eyebrow(s,"How we read the market");
  headline(s,N("s9_headline","Competitors set parity. Content gaps point the direction."));
  card(s,M,2.8,6.0,3.0);
  s.addText("Why competitors are tracked",{x:M+0.3,y:3.05,w:5.4,h:0.35,fontFace:FONT,fontSize:14,bold:true,color:PRIMARY,margin:0});
  s.addText(N("s9_competitors",NCOMP+" competitors set the baseline for parity \u2014 the themes every serious "+(MARKET||"").toLowerCase()+" brand is expected to cover. Where "+BRAND+" matches them it stays competitive; where it is out-shouted, there is work to do."),
    {x:M+0.3,y:3.45,w:5.4,h:2.1,fontFace:FONT,fontSize:12,color:BODY,margin:0,valign:"top",lineSpacing:17});
  card(s,6.95,2.8,5.78,3.0);
  s.addText("Why we read content supply",{x:7.25,y:3.05,w:5.2,h:0.35,fontFace:FONT,fontSize:14,bold:true,color:ACTION,margin:0});
  s.addText(N("s9_supply","No creator/influencer panel exists for this workspace, so differentiation is read from the gap between what the whole category publishes and what "+BRAND+" publishes. A theme the category is moving toward but no one owns is the opening."),
    {x:7.25,y:3.45,w:5.2,h:2.1,fontFace:FONT,fontSize:12,color:BODY,margin:0,valign:"top",lineSpacing:17});
})();

// ============================================================ DIVIDER 2 — WHITESPACE & TRENDS (retitled from "Audience & Evidence" -- personas moved to their own divider, later, per the ordering note near the top of this file)
if (SECTION_DIVIDERS) sectionDivider(2,6,"Whitespace & Trends",
  "Where competitors are loud versus where the ground is open, how each theme has moved over 12 months, and which pillars that opens up first.",
  ["The whitespace map — contested, blocked, open, tension by tension",
   "12 months of trend data, prior-year-verified",
   "Pillars ranked by the opportunity they open"]);

// ============================================================ S15 — WHITESPACE COHORT CROSS-CHECK (proportional)
(()=>{ const s=slide(false);
  eyebrow(s,"Whitespace \u2014 cohort cross-check");
  headline(s,"Share of each cohort's content, not raw counts.");
  const th=ws.themes; const labels=th.map(t=>t.label.replace(" & ","\n& "));
  const data=[
    {name:BRAND+" (share of its content)", labels:th.map(t=>t.label), values:th.map(t=>t.brand_share)},
    {name:"Competitors (share of theirs)", labels:th.map(t=>t.label), values:th.map(t=>t.comp_share)}
  ];
  s.addChart(pres.ChartType.bar, data, {
    x:M, y:2.75, w:8.3, h:3.4, barDir:"col", barGrouping:"clustered",
    chartColors:[PRIMARY, SEC], showValue:true, dataLabelFontSize:9, dataLabelColor:INK, dataLabelFontFace:FONT, dataLabelFormatCode:'0"%"',
    catAxisLabelFontSize:9, catAxisLabelColor:BODY, catAxisLabelFontFace:FONT,
    valAxisMaxVal:80, valAxisMinVal:0, valAxisMajorUnit:20, valAxisLabelFontSize:8.5, valAxisLabelColor:SEC, valAxisLabelFormatCode:'0"%"',
    valGridLine:{color:HAIR,style:"solid",size:1}, showLegend:true, legendPos:"b", legendFontSize:9, legendFontFace:FONT
  });
  card(s,9.2,2.75,3.55,3.4);
  s.addText("Read",{x:9.45,y:2.95,w:3.1,h:0.3,fontFace:FONT,fontSize:12,bold:true,color:ACTION,margin:0});
  const reads=N("ws_reads", ws.themes.map(th2=>[th2.label.split(" ")[0], "Brand "+th2.brand_share+"% vs "+th2.comp_share+"% \u2014 "+(th2.verdict_note||th2.verdict)]));
  reads.forEach((r,i)=>{ const y=3.3+i*0.72;
    s.addText(r[0],{x:9.45,y,w:3.05,h:0.26,fontFace:FONT,fontSize:10.5,bold:true,color:INK,margin:0});
    s.addText(r[1],{x:9.45,y:y+0.24,w:3.05,h:0.46,fontFace:FONT,fontSize:9,color:BODY,margin:0,valign:"top",lineSpacing:11}); });
  s.addText("Proportional share within each cohort \u2014 the only honest comparison when the cohorts differ in size.",{x:M,y:6.35,w:8.3,h:0.35,fontFace:FONT,fontSize:9,italic:true,color:SEC,margin:0});
})();

// ============================================================ S16 — WHITESPACE 6-VERDICT MAP
(()=>{ const s=slide(false);
  eyebrow(s,"Whitespace \u2014 the verdict");
  headline(s,N("s16_headline","What is open, what is contested, what we already own."));
  const th=ws.themes;
  th.forEach((t,i)=>{ const y=2.8+i*0.82; const vc=VC[t.verdict.split(" ")[0]]||SEC;
    card(s,M,y,SW-2*M,0.72);
    s.addText(t.label,{x:M+0.3,y:y+0.08,w:5.0,h:0.34,fontFace:FONT,fontSize:13,bold:true,color:INK,margin:0});
    s.addText(t.verdict_note,{x:M+0.3,y:y+0.42,w:6.2,h:0.26,fontFace:FONT,fontSize:9,color:SEC,margin:0});
    s.addText([{text:`${t.brand_share}% `,options:{bold:true,color:PRIMARY}},{text:"brand   ",options:{color:SOFT}},
               {text:`${t.comp_share}% `,options:{bold:true,color:SEC}},{text:"comp",options:{color:SOFT}}],
      {x:7.4,y,w:2.4,h:0.72,valign:"middle",fontFace:FONT,fontSize:11,margin:0});
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:SW-M-2.6,y:y+0.18,w:2.4,h:0.36,rectRadius:0.18,fill:{color:vc},line:{type:"none"}});
    s.addText(t.verdict.split(" \u2014 ")[0],{x:SW-M-2.6,y:y+0.18,w:2.4,h:0.36,align:"center",valign:"middle",fontFace:FONT,fontSize:9,bold:true,color:txtOn(vc),margin:0}); });
  s.addText(N("s16_note","Brand-low alone is not whitespace \u2014 a strand qualifies only when the category is moving toward it AND "+BRAND+" is absent in content yet has the real-world permission to lead."),
    {x:M,y:2.8+th.length*0.82+0.05,w:SW-2*M,h:0.5,fontFace:FONT,fontSize:9.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ S13 — TREND 6-STATUS MATRIX
(()=>{ const s=slide(false);
  eyebrow(s,"Trend status \u2014 with prior-year verification");
  headline(s,N("s13_headline","Which themes are really rising \u2014 confirmed against the prior year."));
  const cols=["Theme","Start \u2192 latest","Peak","Status","Prior-year check"];
  const cx=[M,4.3,6.5,7.7,9.4], cwn=[3.6,2.1,1.1,1.6,3.1];
  s.addShape(pres.shapes.RECTANGLE,{x:M,y:2.8,w:SW-2*M,h:0.42,fill:{color:PRIMARY},line:{type:"none"}});
  cols.forEach((c,i)=>s.addText(c,{x:cx[i],y:2.8,w:cwn[i],h:0.42,valign:"middle",fontFace:FONT,fontSize:10.5,bold:true,color:WHITE,margin:0,align:i>=2&&i<=3?"center":"left"}));
  const order=["EDU","CLIN","TRUST","MENS"];
  order.forEach((k,i)=>{ const t=trends.series[k]; const y=3.22+i*0.78; if(i%2===1) s.addShape(pres.shapes.RECTANGLE,{x:M,y,w:SW-2*M,h:0.78,fill:{color:"FFFFFF"},line:{type:"none"}});
    s.addShape(pres.shapes.OVAL,{x:M+0.05,y:y+0.28,w:0.16,h:0.16,fill:{color:THEME_COLOR[k]},line:{type:"none"}});
    s.addText(t.name,{x:M+0.3,y,w:3.3,h:0.78,valign:"middle",fontFace:FONT,fontSize:11,bold:true,color:INK,margin:0,lineSpacing:13});
    s.addText(`${t.trend.start} \u2192 ${t.trend.end}`,{x:cx[1],y,w:cwn[1],h:0.78,valign:"middle",fontFace:FONT,fontSize:11,color:BODY,margin:0});
    s.addText(`${t.trend.peak}`,{x:cx[2],y,w:cwn[2],h:0.78,align:"center",valign:"middle",fontFace:FONT,fontSize:11,color:BODY,margin:0});
    s.addText(t.trend.status.split(" ")[0],{x:cx[3],y,w:cwn[3],h:0.78,align:"center",valign:"middle",fontFace:FONT,fontSize:10,bold:true,color:THEME_COLOR[k],margin:0});
    s.addText(t.prior_year.verdict.replace(/^[A-Z\-]+ \u2014 /,""),{x:cx[4],y,w:cwn[4],h:0.78,valign:"middle",fontFace:FONT,fontSize:9,color:SEC,margin:0,lineSpacing:11}); });
  s.addText(N("s13_note","A single late spike is shown as EMERGING/UNVERIFIED \u2014 never as a confident trend."),{x:M,y:6.5,w:SW-2*M,h:0.35,fontFace:FONT,fontSize:9.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ S14 — TREND LINE CHART
(()=>{ const s=slide(false);
  eyebrow(s,"Trending content over time");
  headline(s,N("s14_headline","How the themes move over time."));
  const labels=L.map(l=>Q[l]);
  const data=[
    {name:trends.series.EDU.name, labels, values:L.map(l=>trends.series.EDU.values[l])},
    {name:trends.series.CLIN.name, labels, values:L.map(l=>trends.series.CLIN.values[l])},
    {name:trends.series.TRUST.name, labels, values:L.map(l=>trends.series.TRUST.values[l])}
  ];
  s.addChart(pres.ChartType.line, data, {
    x:M, y:2.7, w:8.4, h:3.5, chartColors:[THEME_COLOR.EDU,THEME_COLOR.CLIN,THEME_COLOR.TRUST],
    lineSize:3, lineSmooth:true, showLegend:true, legendPos:"b", legendFontSize:9, legendFontFace:FONT,
    catAxisLabelFontSize:8.5, catAxisLabelColor:SEC, catAxisLabelFontFace:FONT,
    valAxisMinVal:0, valAxisMaxVal:trends.axis_max, valAxisMajorUnit:80, valAxisLabelFontSize:9, valAxisLabelColor:SEC,
    valGridLine:{color:HAIR,style:"solid",size:1}, catGridLine:{style:"none"}, showTitle:false
  });
  // side annotations
  const ann=["EDU","CLIN","TRUST"].filter(k=>trends.series[k]).map(k=>{const tt=trends.series[k];const st=tt.trend.status.split(" ")[0];const pv=String(tt.prior_year&&tt.prior_year.verdict||"").toUpperCase();const tag=pv.includes("UNVERIFIED")?" · unverified":pv.includes("VERIFIED")?" · verified":"";return [k, st.charAt(0)+st.slice(1).toLowerCase()+tag, THEME_COLOR[k]];});
  ann.forEach((a,i)=>{ const y=2.95+i*1.05; card(s,9.3,y,3.4,0.9);
    s.addShape(pres.shapes.RECTANGLE,{x:9.3,y,w:0.1,h:0.9,fill:{color:a[2]},line:{type:"none"}});
    s.addText(trends.series[a[0]].name,{x:9.5,y:y+0.1,w:3.0,h:0.5,fontFace:FONT,fontSize:10,bold:true,color:INK,margin:0,valign:"top",lineSpacing:12});
    s.addText(a[1],{x:9.5,y:y+0.58,w:3.0,h:0.28,fontFace:FONT,fontSize:9.5,bold:true,color:a[2],margin:0}); });
  s.addText("Values = SOMIN content items per quarter (axis to "+trends.axis_max+"). Same-quarter year-on-year confirms the rise; Trust has one strong window only.",
    {x:M,y:6.45,w:8.4,h:0.4,fontFace:FONT,fontSize:9,italic:true,color:SEC,margin:0});
})();

// ============================================================ S17 — PRIORITISATION (merged with the former S18 "strategic frame" -- both showed the SAME pillars/verdicts, just laid out twice; S18's fixed 3-column card grid also hard-broke for any pillar count other than 3. One ranked list, dynamically sized to N pillars.)
(()=>{ const s=slide(false);
  eyebrow(s,"Where to invest first");
  headline(s,N("s17_headline",pillars.length+" pillars, ranked by the opportunity they open."));
  const _rw={WHITESPACE:0,CONTESTED:1,PARTIAL:2,EMERGING:3,BLOCKED:4};
  const rank=N("prioritisation", pillars.map((p,pi)=>({p,c:PC["P"+(pi+1)]})).sort((a,b)=>((_rw[a.p.verdict.split(" ")[0]]??9)-(_rw[b.p.verdict.split(" ")[0]]??9))).map((o,oi)=>({p:o.p,c:o.c,rankn:String(oi+1).padStart(2,"0"),note:(o.p.why_now||o.p.territory||"")})));
  const rh17=Math.min(1.15, 3.85/Math.max(1,rank.length)), ch17=Math.max(0.5,rh17-0.08);
  rank.forEach((r,i)=>{ const y=2.8+i*rh17; card(s,M,y,SW-2*M,ch17);
    s.addShape(pres.shapes.RECTANGLE,{x:M,y,w:0.14,h:ch17,fill:{color:r.c},line:{type:"none"}});
    s.addText(r.rankn,{x:M+0.3,y,w:1.0,h:ch17,valign:"middle",fontFace:FONT,fontSize:Math.min(30,ch17*32),bold:true,color:r.c,margin:0});
    s.addText(r.p.name,{x:M+1.5,y:y+ch17*0.06,w:6.5,h:ch17*0.28,fontFace:FONT,fontSize:Math.max(9,Math.min(15,ch17*15)),bold:true,color:INK,margin:0,valign:"top"});
    s.addText(shortNote(r.note,110),{x:M+1.5,y:y+ch17*0.36,w:7.3,h:ch17*0.30,fontFace:FONT,fontSize:Math.max(7.5,Math.min(10.5,ch17*11)),color:BODY,margin:0,valign:"top",lineSpacing:13});
    s.addText(shortNote(r.p.tension||"",95),{x:M+1.5,y:y+ch17*0.68,w:7.3,h:ch17*0.28,fontFace:FONT,fontSize:Math.max(7.5,Math.min(9,ch17*10)),italic:true,color:SEC,margin:0,valign:"top"});
    const v17=VC[r.p.verdict.split(" \u2014 ")[0]]||SEC;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:SW-M-2.6,y:y+ch17/2-0.18,w:2.4,h:0.36,rectRadius:0.18,fill:{color:v17},line:{type:"none"}});
    s.addText(r.p.verdict.split(" \u2014 ")[0],{x:SW-M-2.6,y:y+ch17/2-0.18,w:2.4,h:0.36,align:"center",valign:"middle",fontFace:FONT,fontSize:9,bold:true,color:txtOn(v17),margin:0}); });
})();

// ============================================================ DIVIDER — THE AUDIENCE (personas; positioned AFTER whitespace/trend/prioritisation per client-directed reorder. This is a deliberate departure from this file's older default — see the ordering note near the top of this file and references/slide-blueprint.md § "Ordering principle, v2" before moving it again.)
if (SECTION_DIVIDERS) sectionDivider(3,6,"The Audience",
  "The personas who anchor every tension the whitespace and trend read just surfaced — the same pillars, now given a face.",
  ["Persona commons — who recurs across every window",
   "One persona, many tensions — the permutation engine's entry point",
   "Tensions across the window, hung off their personas"]);

// ============================================================ S10 — PERSONA COMMONS
(()=>{ const s=slide(false);
  eyebrow(s,"The audience, in their own shape");
  headline(s,N("s10_headline","One persona recurs in every quarter."));
  card(s,M,2.75,5.0,3.35,PRIMARY);
  s.addText(personas.primary.name,{x:M+0.3,y:3.0,w:4.5,h:0.5,fontFace:FONT,fontSize:20,bold:true,color:WHITE,margin:0});
  s.addText(N("persona_recurs","Recurs across all "+studies.trend_studies.length+" windows."),{x:M+0.3,y:3.55,w:4.4,h:0.7,fontFace:FONT,fontSize:10.5,italic:true,color:SECDARK,margin:0,valign:"top",lineSpacing:14});
  personas.primary.needs.forEach((n,i)=>{ const y=4.35+i*0.42;
    s.addShape(pres.shapes.OVAL,{x:M+0.3,y:y+0.04,w:0.12,h:0.12,fill:{color:WHITE},line:{type:"none"}});
    s.addText(n,{x:M+0.52,y,w:4.2,h:0.34,valign:"middle",fontFace:FONT,fontSize:11.5,color:WHITE,margin:0}); });
  // secondary + tertiary
  [["Secondary",personas.secondary],["Tertiary",personas.tertiary]].forEach((p,i)=>{ const y=2.75+i*1.72;
    card(s,6.4,y,6.33,1.55);
    s.addText([{text:p[0]+"  ",options:{color:SEC,bold:true}},{text:p[1].name,options:{color:INK,bold:true}}],
      {x:6.65,y:y+0.14,w:5.9,h:0.34,fontFace:FONT,fontSize:13,margin:0});
    s.addText(p[1].definition,{x:6.65,y:y+0.5,w:5.9,h:0.95,fontFace:FONT,fontSize:10,color:BODY,margin:0,valign:"top",lineSpacing:13}); });
})();

// ============================================================ S11 — PERSONA -> TENSION MAP
(()=>{ const s=slide(false);
  eyebrow(s,"The permutation engine \u2014 entry");
  headline(s,N("s11_headline","One persona, many tensions. This is the engine, not a list."));
  s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:M,y:3.0,w:2.7,h:2.4,rectRadius:0.08,fill:{color:PRIMARY},line:{type:"none"}});
  s.addText(personas.primary.name,{x:M+0.2,y:3.9,w:2.3,h:0.7,align:"center",valign:"middle",fontFace:FONT,fontSize:15,bold:true,color:WHITE,margin:0});
  s.addText("persona theme "+((insights.shared_character||{}).persona_theme||""),{x:M+0.2,y:4.6,w:2.3,h:0.3,align:"center",fontFace:FONT,fontSize:9,color:SECDARK,margin:0});
  const rows=insights.chains.map((ch,ci)=>["P"+(ci+1), ch.pillar_name, ch.tension_title, String(ch.media_refs), PC["P"+(ci+1)]]);
  rows.forEach((r,i)=>{ const y=3.0+i*0.83;
    s.addShape(pres.shapes.LINE,{x:M+2.7,y:y+0.36,w:0.7,h:0,line:{color:HAIR,width:1.5}});
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:M+3.4,y,w:9.05,h:0.72,rectRadius:0.06,fill:{color:WHITE},line:{color:HAIR,width:1}});
    s.addShape(pres.shapes.RECTANGLE,{x:M+3.4,y,w:0.1,h:0.72,fill:{color:r[4]},line:{type:"none"}});
    s.addText(r[1],{x:M+3.65,y:y+0.08,w:6.3,h:0.34,fontFace:FONT,fontSize:12.5,bold:true,color:INK,margin:0});
    s.addText(r[2],{x:M+3.65,y:y+0.42,w:7.0,h:0.26,fontFace:FONT,fontSize:9,color:SEC,margin:0});
    s.addText([{text:r[3],options:{bold:true,color:r[4]}},{text:"  posts",options:{color:SOFT}}],{x:M+10.7,y,w:1.6,h:0.72,align:"right",valign:"middle",fontFace:FONT,fontSize:13,margin:0}); });
  s.addText("Each tension below carries its own angle, story and propositions \u2014 the same audience seen three ways.",{x:M,y:5.6,w:SW-2*M,h:0.4,fontFace:FONT,fontSize:10.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ S12 — TENSION COMMONS
(()=>{ const s=slide(false);
  eyebrow(s,N("s12_eyebrow","Tensions across the window"));
  headline(s,N("s12_headline",Object.keys(trends.series).length+" themes carry the category."));
  const items=[["EDU",trends.series.EDU],["CLIN",trends.series.CLIN],["TRUST",trends.series.TRUST],["MENS",trends.series.MENS]];
  items.forEach((it,i)=>{ const y=2.85+i*0.92; const sname=it[1].name, tr=it[1].trend;
    card(s,M,y,SW-2*M,0.8);
    s.addShape(pres.shapes.RECTANGLE,{x:M,y,w:0.12,h:0.8,fill:{color:THEME_COLOR[it[0]]},line:{type:"none"}});
    s.addText(sname,{x:M+0.32,y:y+0.1,w:7.4,h:0.34,fontFace:FONT,fontSize:13,bold:true,color:INK,margin:0});
    s.addText(`${tr.start} \u2192 ${tr.end} per quarter` + (tr.peak>tr.end?`  \u00b7  peak ${tr.peak} (${Q[tr.peak_window]})`:""),
      {x:M+0.32,y:y+0.44,w:7.4,h:0.3,fontFace:FONT,fontSize:10,color:SEC,margin:0});
    const status=tr.status;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:SW-M-2.7,y:y+0.22,w:2.5,h:0.36,rectRadius:0.18,fill:{color:THEME_COLOR[it[0]]},line:{type:"none"}});
    s.addText(status,{x:SW-M-2.7,y:y+0.22,w:2.5,h:0.36,align:"center",valign:"middle",fontFace:FONT,fontSize:9.5,bold:true,color:txtOn(THEME_COLOR[it[0]]),margin:0}); });
  s.addText(N("s12_note","Status computed from each theme's own quarterly series. Cross-specialty noise is excluded."),{x:M,y:6.45,w:SW-2*M,h:0.35,fontFace:FONT,fontSize:9.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ DIVIDER 3 — THE ENGINE
if (SECTION_DIVIDERS) sectionDivider(4,6,"The Engine",
  "Why "+BRAND+" credibly belongs in this space, how it plugs into what's already running, and the persona → tension → angle → story chain behind every pillar.",
  ["Brand permission — what "+BRAND+" can credibly say, and where the category has held back",
   "Integration with existing channels",
   "One insight chain and proposition set per pillar"]);

// ============================================================ S19 — BRAND PERMISSION
(()=>{ const s=slide(false);
  eyebrow(s,"Brand permission");
  headline(s,N("s19_headline","Why "+BRAND+" credibly belongs in each space."));
  pillars.forEach((p,i)=>{ const y=2.8+i*1.13; card(s,M,y,SW-2*M,1.0);
    s.addShape(pres.shapes.RECTANGLE,{x:M,y,w:0.12,h:1.0,fill:{color:PC["P"+(i+1)]},line:{type:"none"}});
    s.addText(p.name,{x:M+0.32,y:y+0.13,w:3.4,h:0.74,valign:"middle",fontFace:FONT,fontSize:13,bold:true,color:INK,margin:0,lineSpacing:15});
    s.addText(p.brand_permission,{x:M+3.9,y:y+0.12,w:8.6,h:0.78,fontFace:FONT,fontSize:11,color:BODY,margin:0,valign:"middle",lineSpacing:14}); });
  s.addText(N("s19_note","Competitor absence is not permission. Each pillar rests on a real "+BRAND+" asset."),{x:M,y:6.3,w:SW-2*M,h:0.4,fontFace:FONT,fontSize:9.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ S20 — INTEGRATION
(()=>{ const s=slide(false);
  eyebrow(s,"Integration with what you already do");
  headline(s,N("s20_headline","A continuation of current content \u2014 not a from-scratch plan."));
  card(s,M,2.8,6.0,3.3);
  s.addText("Today",{x:M+0.3,y:3.05,w:5.4,h:0.35,fontFace:FONT,fontSize:14,bold:true,color:SEC,margin:0});
  const ct=paid.content_types.organic;
  const today=N("today_bullets",(()=>{ const e=Object.entries(ct).sort((a,b)=>b[1]-a[1]); const out=[]; if(e[0])out.push(e[0][0]+" leads organic content ("+e[0][1]+" items)."); if(e[1])out.push(e[1][0]+" is strong ("+e[1][1]+" items)."); out.push("Some themes appear organically but are never amplified in paid."); return out; })());
  today.forEach((t,i)=>{ const y=3.5+i*0.78; s.addShape(pres.shapes.OVAL,{x:M+0.3,y:y+0.05,w:0.1,h:0.1,fill:{color:SEC},line:{type:"none"}});
    s.addText(t,{x:M+0.5,y,w:5.2,h:0.7,fontFace:FONT,fontSize:10.5,color:BODY,margin:0,valign:"top",lineSpacing:14}); });
  card(s,6.95,2.8,5.78,3.3,PRIMARY);
  s.addText("The shift",{x:7.25,y:3.05,w:5.2,h:0.35,fontFace:FONT,fontSize:14,bold:true,color:WHITE,margin:0});
  const shift=N("shift_bullets", pillars.map(p=>"Lean into "+p.name+(p.territory?" \u2014 "+p.territory:"")));
  shift.forEach((t,i)=>{ const y=3.5+i*0.78; s.addShape(pres.shapes.OVAL,{x:7.25,y:y+0.05,w:0.1,h:0.1,fill:{color:WHITE},line:{type:"none"}});
    s.addText(t,{x:7.45,y,w:5.05,h:0.7,fontFace:FONT,fontSize:10.5,color:WHITE,margin:0,valign:"top",lineSpacing:14}); });
})();

// ============================================================ S21-23 — INSIGHT CHAINS
insights.chains.forEach((ch,idx)=>{ const s=slide(false); const c=PC["P"+(idx+1)];
  eyebrow(s,`Insight chain ${idx+1} of 3 \u2014 ${ch.pillar_name}`, c);
  headline(s,`\u201C${ch.story_line}\u201D`, false, 20);
  const steps=[["Persona",insights.shared_character.name+"  (theme "+((insights.shared_character||{}).persona_theme||"")+")",((insights.shared_character||{}).shortDesc||insights.shared_character.name)],
    ["Tension",ch.tension_title+"  (theme "+ch.tension_theme+")",ch.verdict],
    ["Angle",ch.angle_reason+" \u00b7 "+ch.angle_theory,"Rhetorical register: "+ch.angle_type],
    ["Story \u2192 "+ch.story_narrative_title,"story "+ch.story_id,ch.story_summary]];
  steps.forEach((st,i)=>{ const y=2.95+i*0.84; card(s,M,y,8.5,0.74);
    s.addShape(pres.shapes.RECTANGLE,{x:M,y,w:0.1,h:0.74,fill:{color:c},line:{type:"none"}});
    s.addText(st[0],{x:M+0.28,y:y+0.1,w:2.6,h:0.3,fontFace:FONT,fontSize:11,bold:true,color:c,margin:0});
    s.addText(st[1],{x:M+0.28,y:y+0.4,w:5.0,h:0.28,fontFace:FONT,fontSize:9,color:SEC,margin:0});
    s.addText(st[2],{x:3.5,y:y+0.08,w:5.0,h:0.6,fontFace:FONT,fontSize:9.5,color:BODY,margin:0,valign:"middle",lineSpacing:12});
    if(i<3) s.addShape(pres.shapes.LINE,{x:M+0.4,y:y+0.74,w:0,h:0.1,line:{color:HAIR,width:1.5,dashType:"sysDot"}}); });
  // engagement panel
  card(s,9.35,2.95,3.4,3.3,idx===2?CARDNAVY:WHITE); const dark=idx===2;
  s.addText("Validation",{x:9.6,y:3.15,w:3.0,h:0.3,fontFace:FONT,fontSize:11,bold:true,color:dark?"7FB0FF":ACTION,margin:0});
  s.addText(num(ch.engagement),{x:9.6,y:3.5,w:3.0,h:0.7,fontFace:FONT,fontSize:30,bold:true,color:dark?WHITE:INK,margin:0});
  s.addText("engagement on the underlying content",{x:9.6,y:4.2,w:2.95,h:0.5,fontFace:FONT,fontSize:9.5,color:dark?SECDARK:SEC,margin:0,valign:"top",lineSpacing:12});
  s.addText(`${ch.media_refs} / ${ch.media_total} evidence posts`,{x:9.6,y:4.8,w:2.95,h:0.3,fontFace:FONT,fontSize:10,bold:true,color:dark?WHITE:BODY,margin:0});
  if(idx===2) s.addText("Low engagement = low supply. This is the whitespace, confirmed.",{x:9.6,y:5.15,w:2.95,h:0.7,fontFace:FONT,fontSize:9.5,italic:true,color:"7FB0FF",margin:0,valign:"top",lineSpacing:12});
  s.addText("Open story",{x:9.6,y:5.95,w:3.0,h:0.3,fontFace:FONT,fontSize:9.5,bold:true,color:dark?"7FB0FF":ACTION,margin:0});
});

// ============================================================ S24 — PILLARS + PROPOSITION PLATES
(()=>{ const keys=["P1","P2","P3"]; const w=cal.metadata.pillar_weights; const maxRows=5;
  const chunks=Math.max(1,...keys.map(k=>Math.ceil(((props.by_pillar[k]||{}).propositions||[]).length/maxRows)));
  for(let pg=0;pg<chunks;pg++){ const s=slide(false);
    eyebrow(s,"Editorial pillars + propositions"+(chunks>1?"  \u00b7  "+(pg+1)+" / "+chunks:""));
    headline(s,N("s24_headline",PROP_N+" propositions \u2014 every pillar expressed several ways.")+(pg>0?" (continued)":""));
    keys.forEach((k,i)=>{ const x=M+i*4.07; const c=PC[k]; const pil=pillars[i]; const pl=props.by_pillar[k];
      s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y:2.6,w:3.85,h:0.6,rectRadius:0.06,fill:{color:c},line:{type:"none"}});
      s.addText(pil.name,{x:x+0.2,y:2.63,w:2.65,h:0.54,valign:"middle",fontFace:FONT,fontSize:12,bold:true,color:WHITE,margin:0,lineSpacing:13});
      s.addText(Math.round(w[k]*100)+"%",{x:x+2.8,y:2.63,w:0.95,h:0.54,align:"right",valign:"middle",fontFace:FONT,fontSize:16,bold:true,color:WHITE,margin:0});
      s.addText("Insight: \u201C"+pl.story_line+"\u201D",{x:x+0.05,y:3.24,w:3.78,h:0.62,fontFace:FONT,fontSize:8.5,italic:true,color:c,margin:0,valign:"top",lineSpacing:11});
      (pl.propositions||[]).slice(pg*maxRows,(pg+1)*maxRows).forEach((pr,j)=>{ const y=3.94+j*0.50; card(s,x,y,3.85,0.44);
        s.addText([{text:pr.focusType.replace("_"," ")+":  ",options:{bold:true,color:c}},{text:pr.focus,options:{color:BODY}}],
          {x:x+0.16,y:y+0.02,w:3.55,h:0.40,fontFace:FONT,fontSize:8.0,margin:0,valign:"middle",lineSpacing:9}); }); });
    s.addText("Each card = a focus dimension \u00d7 that pillar's insight story = one of the "+PROP_N+" SOMIN propositions"+(PROP_N?" (ids "+Math.min(...PROP_IDS)+"\u2013"+Math.max(...PROP_IDS)+")":"")+". All "+PROP_N+" shown across "+chunks+" plate"+(chunks>1?"s":"")+".",
      {x:M,y:6.5,w:SW-2*M,h:0.35,fontFace:FONT,fontSize:9,italic:true,color:SEC,margin:0}); }
})();

// ============================================================ DIVIDER 4 — CALENDAR & EXECUTION
if (SECTION_DIVIDERS) sectionDivider(5,6,"Calendar & Execution",
  "Turning the engine's output into a dated, ready-to-brief publishing plan.",
  ["The publishing calendar, pillar-weighted across the window",
   "What a lead post actually looks like, with a real brief"]);

// ============================================================ S25 — CALENDAR MATRIX
(()=>{ const s=slide(false);
  eyebrow(s,"The publishing calendar");
  headline(s,"A quarter of posts \u2014 3 a week, 13 weeks, pillar-weighted.");
  // legend
  const keys=["P1","P2","P3"]; keys.forEach((k,i)=>{ const x=M+i*3.0;
    s.addShape(pres.shapes.RECTANGLE,{x,y:2.55,w:0.22,h:0.22,fill:{color:PC[k]},line:{type:"none"}});
    s.addText(pillars[i].name,{x:x+0.3,y:2.5,w:2.6,h:0.3,fontFace:FONT,fontSize:9.5,bold:true,color:INK,margin:0}); });
  s.addText(`${cal.summary.total_posts} posts \u00b7 ${cal.summary.lead_posts} lead posts \u00b7 starts ${cal.metadata.start_date}`,{x:SW-M-4.0,y:2.5,w:4.0,h:0.3,align:"right",fontFace:FONT,fontSize:9.5,color:SEC,margin:0});
  // grid: rows weeks, cols Tue/Thu/Sat
  const days=["TUE","THU","SAT"]; const x0=M, y0=2.9, colW=[1.5,3.5,3.5,3.5], rh=0.253;
  s.addText("Week",{x:x0,y:y0,w:colW[0],h:rh,fontFace:FONT,fontSize:8.5,bold:true,color:SEC,margin:0,valign:"middle"});
  days.forEach((d,i)=>s.addText(d,{x:x0+colW[0]+i*3.5,y:y0,w:3.5,h:rh,align:"center",fontFace:FONT,fontSize:8.5,bold:true,color:SEC,margin:0,valign:"middle"}));
  cal.weeks.forEach((wk,r)=>{ const y=y0+rh+r*rh;
    s.addText(wk.label.replace("WK ","W").replace(" \u00b7 ","·"),{x:x0,y,w:colW[0],h:rh,fontFace:FONT,fontSize:7.5,color:BODY,margin:0,valign:"middle"});
    days.forEach((d,ci)=>{ const post=wk.posts.find(p=>p.day===d); const x=x0+colW[0]+ci*3.5;
      if(post){ const c=PC[post.pillar];
        s.addShape(pres.shapes.RECTANGLE,{x:x+0.03,y:y+0.02,w:3.44,h:rh-0.04,fill:{color:c,transparency:82},line:{type:"none"}});
        s.addShape(pres.shapes.RECTANGLE,{x:x+0.03,y:y+0.02,w:0.06,h:rh-0.04,fill:{color:c},line:{type:"none"}});
        const lead=post.slot==="lead";
        s.addText([{text:(lead?"\u2605 ":"")+post.trigger_label,options:{color:INK,bold:lead}},{text:`  M${post.moment_id}`,options:{color:SOFT}}],
          {x:x+0.14,y,w:3.3,h:rh,valign:"middle",fontFace:FONT,fontSize:6.6,margin:0}); }
    }); });
  s.addText(N("calendar_note","\u2605 = lead post. Each cell carries its SOMIN moment ID; cultural anchors fall inside the window."),
    {x:M,y:y0+rh+cal.weeks.length*rh+0.05,w:SW-2*M,h:0.35,fontFace:FONT,fontSize:8.5,italic:true,color:SEC,margin:0});
})();

// ============================================================ S26 — LEAD-POST EXAMPLES (briefs)
(()=>{ const s=slide(false);
  eyebrow(s,"What a post looks like");
  headline(s,"One lead post per pillar \u2014 message, channel, call to action.");
  const briefs=N("briefs", pillars.map((p,bi)=>{ const ch=insights.chains[bi]||{}; const slot=(cal.weeks.flatMap(w=>w.posts).find(po=>po.pillar==="P"+(bi+1))||{}); return {k:"P"+(bi+1), fmt:"Social", msg:(ch.story_line||p.name||""), cta:"Learn more", why:"Story "+(ch.story_id||"")+(slot.moment_id?" \u00b7 moment "+slot.moment_id:"")+(slot.trigger_id?" / trigger "+slot.trigger_id:"")}; }))
    .slice().sort((a,b)=>String(a.k||"").localeCompare(String(b.k||"")));
  briefs.forEach((b,i)=>{ const x=M+i*4.07; const c=PC[b.k]; const pil=pillars.find(p=>p.id===b.k)||pillars[i]||{}; card(s,x,2.75,3.85,3.85);
    s.addShape(pres.shapes.RECTANGLE,{x,y:2.75,w:3.85,h:0.1,fill:{color:c},line:{type:"none"}});
    s.addText(pil.name,{x:x+0.25,y:2.95,w:3.4,h:0.3,fontFace:FONT,fontSize:11,bold:true,color:c,margin:0});
    s.addText(b.fmt,{x:x+0.25,y:3.27,w:3.4,h:0.3,fontFace:FONT,fontSize:9,italic:true,color:SEC,margin:0});
    s.addText("\u201C"+b.msg+"\u201D",{x:x+0.25,y:3.62,w:3.4,h:1.3,fontFace:FONT,fontSize:11,bold:true,color:INK,margin:0,valign:"top",lineSpacing:15});
    pill(s,b.cta,x+0.25,5.0,3.0);
    s.addText(b.why,{x:x+0.25,y:5.55,w:3.4,h:0.95,fontFace:FONT,fontSize:8,color:SEC,margin:0,valign:"top",lineSpacing:10}); });
})();

// ============================================================ DIVIDER 5 — PROOF & RECOMMENDATIONS
if (SECTION_DIVIDERS) sectionDivider(6,6,"Proof & Recommendations",
  "The evidence behind the plan, what to do next, and the full audit trail back to source.",
  ["Organic vs. paid, and engagement + share-of-voice depth",
   "Recommendations",
   "The audit trail — every ID, traceable"]);

// ============================================================ S27 — ORGANIC vs PAID
(()=>{ const s=slide(false);
  eyebrow(s,"Organic versus paid");
  headline(s,"Paid pushes thought-leadership and product. Community never gets funded.");
  const o=paid.content_types.organic, p=paid.content_types.paid;
  const cats=["Thought Leadership","Product Offering","Educational","Community Engagement","Company Culture"];
  const data=[
    {name:"Organic", labels:cats, values:cats.map(c=>o[c]||0)},
    {name:"Paid", labels:cats, values:cats.map(c=>p[c]||0)}
  ];
  s.addChart(pres.ChartType.bar, data, {
    x:M, y:2.8, w:8.2, h:3.3, barDir:"col", barGrouping:"clustered", chartColors:[PRIMARY,ACTION],
    showValue:true, dataLabelFontSize:8, dataLabelColor:INK, dataLabelFontFace:FONT,
    catAxisLabelFontSize:9, catAxisLabelColor:BODY, catAxisLabelFontFace:FONT,
    valAxisMinVal:0, valAxisLabelFontSize:8.5, valAxisLabelColor:SEC, valGridLine:{color:HAIR,style:"solid",size:1},
    showLegend:true, legendPos:"b", legendFontSize:9, legendFontFace:FONT });
  card(s,9.1,2.8,3.65,3.3);
  s.addText("The gap",{x:9.35,y:3.0,w:3.2,h:0.3,fontFace:FONT,fontSize:12,bold:true,color:ACTION,margin:0});
  s.addText("Community Engagement and Company Culture appear in organic content but are essentially absent from paid (≈0). Relationship-building never gets amplified \u2014 so the whitespace pillar has room in paid as well as organic.",
    {x:9.35,y:3.4,w:3.2,h:2.6,fontFace:FONT,fontSize:11,color:BODY,margin:0,valign:"top",lineSpacing:15});
  s.addText("Counts = SOMIN content items tagged per type (organic n="+Object.values(o).reduce((a,b)=>a+b,0).toLocaleString("en-US")+" \u00b7 paid n="+Object.values(p).reduce((a,b)=>a+b,0).toLocaleString("en-US")+", "+AUDIENCE+").",{x:M,y:6.3,w:8.2,h:0.35,fontFace:FONT,fontSize:9,italic:true,color:SEC,margin:0});
})();

// ============================================================ S28 — ENGAGEMENT + SHARE-OF-VOICE DEPTH (dark)
(()=>{ const s=pres.addSlide(); bg(s,MID); page++; wordmark(s,true); footer(s,page,true);
  eyebrow(s,"Depth \u2014 engagement and share of voice");
  s.addText("Where attention concentrates \u2014 and where it is wide open.",{x:M,y:1.5,w:SW-2*M,h:0.8,fontFace:FONT,fontSize:23,bold:true,color:WHITE,margin:0});
  insights.chains.forEach((ch,i)=>{ const x=M+i*4.07; const c=PC["P"+(i+1)]; card(s,x,2.8,3.85,3.3,CARDNAVY);
    s.addShape(pres.shapes.RECTANGLE,{x,y:2.8,w:3.85,h:0.1,fill:{color:c},line:{type:"none"}});
    s.addText(ch.pillar_name,{x:x+0.28,y:3.0,w:3.3,h:0.6,fontFace:FONT,fontSize:13,bold:true,color:WHITE,margin:0,lineSpacing:15});
    s.addText(num(ch.engagement),{x:x+0.28,y:3.65,w:3.3,h:0.7,fontFace:FONT,fontSize:28,bold:true,color:c==PC.P3?"7FB0FF":WHITE,margin:0});
    s.addText("content engagement",{x:x+0.28,y:4.35,w:3.3,h:0.3,fontFace:FONT,fontSize:9.5,color:SECDARK,margin:0});
    s.addText(`${ch.media_refs} of ${ch.media_total} evidence posts`,{x:x+0.28,y:4.75,w:3.3,h:0.3,fontFace:FONT,fontSize:10,bold:true,color:WHITE,margin:0});
    const _dk=N("depth_ws_keys", ws.themes.slice(0,3).map(t=>t.key)); const wsTheme=ws.themes.find(t=>t.key===_dk[i])||ws.themes[i]||ws.themes[0];
    s.addText([{text:`${wsTheme.brand_share}% `,options:{bold:true,color:WHITE}},{text:"brand share-of-voice",options:{color:SECDARK}}],{x:x+0.28,y:5.2,w:3.3,h:0.3,fontFace:FONT,fontSize:10,margin:0});
    s.addText(i===2?"Lowest engagement, lowest share \u2014 the clearest run.":"High engagement \u2014 a crowded, valuable space.",{x:x+0.28,y:5.55,w:3.3,h:0.5,fontFace:FONT,fontSize:9,italic:true,color:SECDARK,margin:0,valign:"top",lineSpacing:11}); });
})();

// ============================================================ S29 — RECOMMENDATIONS
(()=>{ const s=slide(false);
  eyebrow(s,"Recommendations");
  headline(s,N("recommendations_headline","The priorities, in order."));
  const _rw2={WHITESPACE:0,CONTESTED:1,PARTIAL:2,EMERGING:3,BLOCKED:4};
  const recs=N("recommendations", pillars.map((p,ri)=>({p,c:PC["P"+(ri+1)]})).sort((a,b)=>((_rw2[a.p.verdict.split(" ")[0]]??9)-(_rw2[b.p.verdict.split(" ")[0]]??9))).map(o=>[o.p.name,(o.p.why_now||o.p.territory||""),o.c]));
  recs.forEach((r,i)=>{ const y=2.8+i*0.92; card(s,M,y,SW-2*M,0.8);
    s.addShape(pres.shapes.OVAL,{x:M+0.22,y:y+0.22,w:0.36,h:0.36,fill:{color:r[2]},line:{type:"none"}});
    s.addText(String(i+1),{x:M+0.22,y:y+0.22,w:0.36,h:0.36,align:"center",valign:"middle",fontFace:FONT,fontSize:13,bold:true,color:WHITE,margin:0});
    s.addText(r[0],{x:M+0.8,y:y+0.1,w:4.7,h:0.6,valign:"middle",fontFace:FONT,fontSize:12.5,bold:true,color:INK,margin:0,lineSpacing:14});
    s.addText(r[1],{x:5.7,y:y+0.08,w:6.9,h:0.66,valign:"middle",fontFace:FONT,fontSize:9.5,color:BODY,margin:0,lineSpacing:12}); });
})();

// ============================================================ S30 — AUDIT TRAIL
(()=>{ const s=slide(false);
  eyebrow(s,"Audit trail");
  headline(s,"Every claim traces back to a SOMIN record.");
  // left: IDs columns
  const colX=M, colW=8.4;
  function line(y,label,val,url){ s.addText(label,{x:colX,y,w:2.5,h:0.28,fontFace:FONT,fontSize:9.5,bold:true,color:SEC,margin:0,valign:"middle"});
    s.addText(val,{x:colX+2.4,y,w:colW-2.4,h:0.28,fontFace:FONT,fontSize:9.5,color:url?ACTION:BODY,margin:0,valign:"middle"}); }
  function linkids(y,label,ids,urlfn,suffix){ s.addText(label,{x:colX,y,w:2.5,h:0.28,fontFace:FONT,fontSize:9.5,bold:true,color:SEC,margin:0,valign:"middle"});
    const runs=[]; ids.forEach((id,i)=>{ runs.push({text:String(id),options:{color:ACTION}}); if(i<ids.length-1) runs.push({text:", ",options:{color:BODY}}); });
    if(suffix) runs.push({text:suffix,options:{color:SOFT}});
    s.addText(runs,{x:colX+2.4,y,w:colW-2.4,h:0.28,fontFace:FONT,fontSize:9.5,margin:0,valign:"middle"}); }
  let y=2.66; const dy=0.295;
  const SC=insights.shared_character||{};
  line(y,"Workspace",MARKET+" #"+WSID,"https://cloud.somin.ai/app/a/"+WSID+"/somonitor/content-library"); y+=dy;
  linkids(y,"Trend studies",studies.trend_studies.map(t=>t.id),sUrl,"  \u00b7 "+studies.trend_studies.length+" quarterly windows"); y+=dy;
  if((scope.whitespace_studies||[]).length){ linkids(y,"Whitespace studies",scope.whitespace_studies,sUrl,""); y+=dy; }
  if(scope.paid_study){ line(y,"Paid study",String(scope.paid_study),sUrl(scope.paid_study)); y+=dy; }
  if(SC.persona_theme||SC.persona_title){ line(y,"Persona theme",(SC.persona_theme||"")+(SC.persona_title?" \u00b7 "+SC.persona_title:"")); y+=dy; }
  if(SC.name){ line(y,"Character",(SC.id?SC.id+" \u00b7 ":"")+SC.name); y+=dy; }
  line(y,"Tensions",insights.chains.map(c=>c.tension_theme).join(", ")); y+=dy;
  line(y,"Angles",insights.chains.map(c=>c.angle_id+(c.angle_type?" "+c.angle_type:"")).join(", ")); y+=dy;
  linkids(y,"Stories",insights.chains.map(c=>c.story_id),storyUrl,"  \u00b7 one per pillar"); y+=dy;
  if(props.product){ line(y,"Product",(props.product.id?props.product.id+" \u00b7 ":"")+(props.product.name||"")); y+=dy; }
  if(PROP_N){ line(y,"Propositions",Math.min(...PROP_IDS)+"\u2013"+Math.max(...PROP_IDS)+" ("+PROP_N+")"); y+=dy; }
  if(scope.moments_range){ line(y,"Moments",scope.moments_range); y+=dy; }
  s.addText("Study, story, persona, tension and workspace IDs link to their SOMIN record; character, angle, product and proposition IDs are traceable in workspace #"+WSID+"."
    +(((scope.influencer_panel||{}).profile_names||[]).length ? "  The "+AUDIENCE+" content-proxy panel is named in full in Method Notes, earlier in this deck." : ""),
    {x:colX,y:y+0.04,w:colW,h:0.5,fontFace:FONT,fontSize:8.5,italic:true,color:SEC,margin:0,valign:"top",lineSpacing:11});
  // right: SCOPE box
  card(s,9.1,2.6,3.65,3.95,PRIMARY);
  s.addText("Scope",{x:9.4,y:2.78,w:3.1,h:0.32,fontFace:FONT,fontSize:13,bold:true,color:WHITE,margin:0});
  const sc=N("scope_box",[["Window",scope.window_label||""],["Sources",scope.sources_label||"Organic + paid"],["Audience",AUDIENCE],
    ["Markets",MARKET],["Trends","Prior-year verified"],["Insight chains",insights.chains.length+" pillars"],
    ["Propositions",PROP_N+" generated"],["Calendar",(cal.summary?cal.summary.total_posts+" posts":"")]]);
  sc.forEach((r,i)=>{ const yy=3.18+i*0.3; s.addText(r[0],{x:9.4,y:yy,w:1.35,h:0.28,fontFace:FONT,fontSize:8,bold:true,color:SECDARK,margin:0,valign:"middle"});
    s.addText(String(r[1]),{x:10.7,y:yy,w:1.95,h:0.28,fontFace:FONT,fontSize:8,color:WHITE,margin:0,valign:"middle"}); });
})();

// ============================================================ APPENDIX DIVIDER
(()=>{ const s=pres.addSlide(); bg(s,DEEP); page++; wordmark(s,true); footer(s,page,true);
  s.addText("Appendix",{x:M,y:3.0,w:SW-2*M,h:1.0,fontFace:FONT,fontSize:44,bold:true,color:WHITE,margin:0});
  s.addText("The full creative library rendered from this briefing's insight chains.",{x:M,y:4.05,w:SW-2*M,h:0.5,fontFace:FONT,fontSize:15,color:SECDARK,margin:0});
})();

// ============================================================ CREATIVE LIBRARY (handled by the creative-expressions engine — legacy in-builder grid disabled below)
const EXPR_KEYS=[["P1","TOFU"],["P1","MOFU"],["P1","BOFU"],["P2","TOFU"],["P2","MOFU"],["P2","BOFU"],["P3","TOFU"],["P3","MOFU"],["P3","BOFU"]];
const exprDir="expr";
const haveAll = false; // legacy in-builder Creative Library DISABLED. The library is appended by the creative-expressions engine (unlock.py assemble), which applies its encrypted TOFU/MOFU/BOFU master prompt: emit-prompts builds each render prompt from {persona,subtype,hook}+brand whenever imageConcept is omitted. Single source of truth — see Step 12B.
let exprMeta={};
if(fs.existsSync(`${exprDir}/expressions.json`)) exprMeta=D(`${exprDir}/expressions.json`);
if(haveAll){
  ["P1","P2","P3"].forEach((k,pi)=>{ const s=slide(false); const c=PC[k];
    eyebrow(s,`Creative library \u2014 ${pillars[pi].name}`, c);
    headline(s,`TOFU \u2192 MOFU \u2192 BOFU concepts for \u201C${pillars[pi].name}\u201D.`, false, 19);
    const stages=["TOFU","MOFU","BOFU"]; const labels={TOFU:"Top \u2014 awareness",MOFU:"Middle \u2014 consideration",BOFU:"Bottom \u2014 decision"};
    stages.forEach((st,i)=>{ const x=M+i*4.07; const iw=3.85, ih=2.57;
      s.addImage({path:`${exprDir}/${k}_${st}.png`, x, y:2.7, w:iw, h:ih, rounding:false});
      s.addShape(pres.shapes.RECTANGLE,{x,y:2.7,w:iw,h:0.1,fill:{color:c},line:{type:"none"}});
      const cap=(exprMeta[`${k}_${st}`]&&exprMeta[`${k}_${st}`].caption)||labels[st];
      s.addText(labels[st],{x,y:5.4,w:iw,h:0.3,fontFace:FONT,fontSize:10,bold:true,color:c,margin:0});
      s.addText(cap,{x,y:5.7,w:iw,h:0.9,fontFace:FONT,fontSize:9,color:BODY,margin:0,valign:"top",lineSpacing:11}); }); });
}

const OUT = scope.output || (String(BRAND).replace(/[^A-Za-z0-9]+/g,"_")+"_"+String(MARKET).replace(/[^A-Za-z0-9]+/g,"_")+"_Briefing.pptx");
pres.writeFile({ fileName: OUT }).then(()=>console.log("WROTE", OUT, "· slides:", page, "· creativeLibrary:", haveAll));
