#!/usr/bin/env python3
"""
link_somin.py — post-build step for somin-brand-deck.

pptxgenjs emits broken hyperlink relationships (r:id="rIdundefined") on slides
with multiple links, which fail OOXML validation. So the builder renders the
SOMIN IDs as PLAIN runs, and this script injects VALID hyperlinks afterwards
(python-pptx handles the relationship plumbing correctly), pointing each ID to
its own record on the SOMIN platform.

Linked, individually, wherever they appear:
  - every study ID            -> /app/a/{ws}/studies/{id}
  - every story ID            -> /app/inspire/insights/story/{id}
  - the workspace ID          -> /app/a/{ws}
  - persona-theme & tension IDs -> their source (persona+tension) study
  - each "Open story" affordance -> that pillar's story
Angles, product and proposition IDs have no public per-object URL, so they are
left as plain text (traceable in-workspace) by design.

Usage:
  link_somin.py --deck built.pptx --inputs-dir . --out built_linked.pptx
"""
import argparse, json, re, os, sys
from pptx import Presentation

def load(d, name):
    p = os.path.join(d, name)
    return json.load(open(p)) if os.path.exists(p) else {}

def build_map(inputs_dir):
    studies = load(inputs_dir, "studies_primary.json")
    insights = load(inputs_dir, "insights.json")
    scope = load(inputs_dir, "scope.json")
    ws = scope.get("workspace_id") or (studies.get("workspace") or {}).get("id")
    def s_url(i): return f"https://cloud.somin.ai/app/a/{ws}/studies/{i}"
    def story_url(i): return f"https://cloud.somin.ai/app/inspire/insights/story/{i}"
    ws_url = f"https://cloud.somin.ai/app/a/{ws}/somonitor/content-library"

    token_url = {}
    # ---- studies (trend + prior-year + whitespace + master/paid) ----
    for t in studies.get("trend_studies", []) + studies.get("prior_year_studies", []):
        if t.get("id"): token_url[str(t["id"])] = s_url(t["id"])
    wss = studies.get("whitespace_studies", {})
    if isinstance(wss, dict):
        for v in wss.values():
            if isinstance(v, dict) and v.get("id"): token_url[str(v["id"])] = s_url(v["id"])
    elif isinstance(wss, list):
        for v in wss:
            i = v.get("id") if isinstance(v, dict) else v
            if i: token_url[str(i)] = s_url(i)
    # scope.json commonly carries the real whitespace study ids as a flat list
    # (studies_primary.json doesn't always have its own "whitespace_studies" key)
    for i in (scope.get("whitespace_studies") or []):
        i = i.get("id") if isinstance(i, dict) else i
        if i: token_url.setdefault(str(i), s_url(i))
    master = (studies.get("paid_study") or {}).get("id")
    if master: token_url[str(master)] = s_url(master)
    # ---- stories + persona/tension (link to their source study) ----
    chains = insights.get("chains", [])
    story_seq = []
    for c in chains:
        if c.get("story_id"):
            token_url[str(c["story_id"])] = story_url(c["story_id"])
            story_seq.append(c["story_id"])
        if c.get("tension_theme") and master:
            token_url.setdefault(str(c["tension_theme"]), s_url(master))
    sc = insights.get("shared_character", {})
    if sc.get("persona_theme") and master:
        token_url.setdefault(str(sc["persona_theme"]), s_url(master))
    # ---- workspace ----
    if ws: token_url[str(ws)] = ws_url
    return token_url, story_seq, ws

def compile_patterns(token_url):
    # match each token as a standalone integer (no surrounding digits)
    return [(re.compile(r'(?<!\d)' + re.escape(tok) + r'(?!\d)'), tok, url)
            for tok, url in sorted(token_url.items(), key=lambda kv: -len(kv[0]))]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--deck", required=True)
    ap.add_argument("--inputs-dir", default=".")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    # --inputs-dir must point at the SAME directory build_deck.js was run from (the one holding
    # studies_primary.json etc.) -- not the engagement's project root one level up. Pointing it
    # at the wrong directory doesn't error; load() just returns {} for every missing file, so the
    # token map comes back near-empty and this silently links far fewer IDs than it should (a real
    # regression observed at 47 links -> 18 after a wrong --inputs-dir, with no error to flag it).
    # Fail loudly instead of guessing.
    required = ["studies_primary.json", "scope.json"]
    missing = [f for f in required if not os.path.exists(os.path.join(a.inputs_dir, f))]
    if missing:
        sys.exit(f"link_somin: --inputs-dir '{a.inputs_dir}' is missing {missing} -- point it at the "
                  f"directory build_deck.js was run from (holds studies_primary.json, scope.json, "
                  f"insights.json, etc.), not the engagement's project root. Refusing to run silently "
                  f"with an empty ID map.")

    token_url, story_seq, ws = build_map(a.inputs_dir)
    pats = compile_patterns(token_url)
    if len(token_url) < 3:
        print(f"link_somin: WARNING -- only {len(token_url)} ID(s) resolved from --inputs-dir "
              f"'{a.inputs_dir}'. This is suspiciously low for a real engagement; double-check this "
              f"is the directory build_deck.js actually read from before trusting the link count below.")
    prs = Presentation(a.deck)

    # ---- self-heal pass: strip any hlinkClick whose r:id resolves to a
    # non-hyperlink relationship (e.g. an image). This happens when a slide is
    # built by deep-copying XML from another slide's shapes (chrome/footer
    # mirroring) without dropping the source hlinkClick -- the copied r:id is
    # only meaningful in the ORIGINAL slide's relationship namespace and in the
    # new slide can coincidentally collide with an unrelated relationship
    # (e.g. "somin.ai" ends up pointing at a leaderboard thumbnail). Stripping
    # it here restores the run to plain text so the matching pass below can
    # re-attach the correct hyperlink from the visible text.
    A_NS = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    R_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    stripped_bad = 0
    for slide in prs.slides:
        rels = slide.part.rels
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    for hlink in run._r.findall(f".//{A_NS}hlinkClick"):
                        rid = hlink.get(f"{R_NS}id")
                        if not rid:
                            continue
                        rel = rels.get(rid)
                        if rel is None or "hyperlink" not in rel.reltype:
                            hlink.getparent().remove(hlink)
                            stripped_bad += 1
    if stripped_bad:
        print(f"link_somin: stripped {stripped_bad} corrupted hyperlink(s) (r:id pointed to a non-hyperlink relationship)")

    linked = 0
    bare_url_linked = 0
    open_story_runs = []
    bare_url_pat = re.compile(r'^(https?://\S+)$')
    for slide in prs.slides:
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    txt = run.text or ""
                    stripped = txt.strip()
                    if stripped.lower().startswith("open story"):
                        open_story_runs.append(run)
                        continue
                    # bare literal URLs (e.g. real product-page links shown as plain text on
                    # content-brief cards) -> hyperlink to themselves. Not covered by the
                    # numeric-ID token map above, since the run text IS the destination.
                    m_bare = bare_url_pat.match(stripped)
                    if m_bare:
                        try:
                            run.hyperlink.address = m_bare.group(1)
                            run.font.underline = True
                            bare_url_linked += 1
                        except Exception:
                            pass
                        continue
                    # "somin.ai" attribution runs (footer / hero, sometimes prefixed with a
                    # "· " separator in the same run) -> the SOMIN homepage
                    if stripped.lower().endswith("somin.ai") and "http" not in stripped.lower():
                        try:
                            run.hyperlink.address = "https://somin.ai"
                            run.font.underline = True
                            bare_url_linked += 1
                        except Exception:
                            pass
                        continue
                    # find earliest-matching token in this run
                    best = None
                    for pat, tok, url in pats:
                        m = pat.search(txt)
                        if m and (best is None or m.start() < best[0]):
                            best = (m.start(), url)
                    if best:
                        try:
                            run.hyperlink.address = best[1]
                            # Underline every attached hyperlink, unconditionally. The deck's
                            # link-affordance color deliberately varies by background for
                            # contrast (light card -> ACTION purple, dark card -> a lighter
                            # accent) — without underline, color is the ONLY "this is
                            # clickable" signal, and that made links look randomly
                            # inconsistent (some purple, some the card's plain body color).
                            # Underline makes every link visually unambiguous regardless of
                            # its color or the card behind it.
                            run.font.underline = True
                            linked += 1
                        except Exception:
                            pass
    # "Open story" affordances -> stories in document order
    for i, run in enumerate(open_story_runs):
        if i < len(story_seq):
            run.hyperlink.address = f"https://cloud.somin.ai/app/inspire/insights/story/{story_seq[i]}"
            run.font.underline = True
            linked += 1

    prs.save(a.out)
    total = linked + bare_url_linked
    print(f"link_somin: linked {total} run(s) ({linked} ID-token + {bare_url_linked} bare-URL/somin.ai) across {len(prs.slides._sldIdLst)} slides -> {a.out}")

if __name__ == "__main__":
    main()
