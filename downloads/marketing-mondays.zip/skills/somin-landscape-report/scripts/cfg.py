#!/usr/bin/env python3
"""Loads scope.json — the one file that records what this run read.

scope.json sits in the run directory beside posts.json. It carries the answers to the
ask-first questions, the aggregate the pull has to match, the metric, the expression
files and the thumbnail budget. validate.py reads it; the Sources & scope dialog in
copy.json is written from it. `assets/scope_example.json` is a filled-in example.

Fields
  workspaces[]  {id, label}          every workspace this read covers
  merged        bool                 true when several workspaces were read as one
  source        "organic" | "paid"   PAGES or ADS_LIBRARY
  window        {start, end, label}  YYYY-MM-DD, inclusive
  focal         str                  the client's short brand name, exactly as in posts.json "b"
  aliases       {page name: short}   every page of one brand mapped to one short name
  filterLabel   str                  "" when the read is unfiltered
  aggregate     {posts, likes, comments, shares, reposts}   the step-1 posts-aggregate result
  metricFields  [str]                organic metric, default ["likesCount", "commentsCount"]
  platformBase  str                  SOMIN app base for source links, default https://cloud.somin.ai
  expressions   {concepts, prompts, manifest, images{key: file}}
  thumbnails    {top, box, q}        0 top = thumbnail everything
  output        str                  the HTML file to write

Override the path with LR_SCOPE=other_scope.json; the run directory with LR_ROOT.
"""
import json, os
from pathlib import Path

ROOT = Path(os.environ.get("LR_ROOT") or ".").resolve()
SCOPE_PATH = Path(os.environ.get("LR_SCOPE") or (ROOT / "scope.json"))
HERE = Path(__file__).resolve().parent
ASSETS = HERE.parent / "assets"

DEFAULTS = {
    "workspaces": [], "merged": False, "source": "organic", "window": {},
    "focal": "", "aliases": {}, "filterLabel": "", "aggregate": {},
    "expressions": {}, "thumbnails": {"top": 150, "box": 480, "q": 70}, "metricFields": ["likesCount", "commentsCount"], "platformBase": "https://cloud.somin.ai",
    "output": "landscape_report.html",
}

METRICS = ("likes", "comments", "shares", "reposts")


def load():
    if not SCOPE_PATH.exists():
        raise SystemExit(f"scope.json not found at {SCOPE_PATH}. Copy assets/scope_example.json and fill it in.")
    s = DEFAULTS | json.loads(SCOPE_PATH.read_text(encoding="utf-8"))
    for k in ("start", "end"):
        if not s["window"].get(k):
            raise SystemExit(f"scope.window.{k} is required (YYYY-MM-DD).")
    if s["source"] not in ("organic", "paid"):
        raise SystemExit('scope.source must be "organic" or "paid".')
    if not s["focal"]:
        raise SystemExit("scope.focal is required — the client's short brand name.")
    return s


def theme_path(s):
    """Chart colours only; the page chrome is fixed SOMIN."""
    return ASSETS / "theme_somin.json"


def run_file(name):
    return ROOT / name
