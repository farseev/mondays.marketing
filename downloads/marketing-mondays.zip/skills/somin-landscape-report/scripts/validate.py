#!/usr/bin/env python3
"""The gate. Run it after the pull and again after copy.json is written.

  python3 scripts/validate.py                       # posts against the aggregate
  python3 scripts/validate.py --copy copy.json      # plus every copy and chain check

Checks, in order:
  1  posts.json count equals scope.aggregate.posts, and each metric sum equals the aggregate
  2  every post date sits inside the window; paid records carry an end date
  3  the focal brand is present, and no two labels look like the same brand
  4  no U+FFFD anywhere in posts.json or copy.json (one of those rejects the artifact publish)
  5  copy.focal matches scope; every named brand is a posts.json label; the copy never says DEFY
  6  every finding opens a real post or a SOMIN classification comparison; cited research exists
  7  every moment date sits in the window and equals its post's publication date
  8  direction.insight is a SOMIN insight in research.sources; every mapping and parent resolves;
     every concept image carries a research.images entry rendered by the expressions engine
  9  every image prompt key exists in the expressions manifest, and the manifest passed
 10  every hook in the concepts file is 7 words or fewer

Prints GATE PASS or GATE FAIL with every failing line, and exits non-zero on failure.
Never build a report on a failing gate.
"""
import argparse, json, re, sys
from datetime import date
from pathlib import Path

import cfg


fails, warns = [], []


def fail(msg):
    fails.append(msg)


def warn(msg):
    warns.append(msg)


def d(s):
    return date.fromisoformat(s[:10])


def norm_verdict(v):
    """Case and dash insensitive: the rubric prints caps and an em dash, copy often does not."""
    return re.sub(r"[\s\u2013\u2014-]+", " ", v.strip().lower())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--posts", default="posts.json")
    ap.add_argument("--copy", default=None)
    ap.add_argument("--concepts", default=None)
    ap.add_argument("--manifest", default=None)
    a = ap.parse_args()

    s = cfg.load()
    posts = json.loads(cfg.run_file(a.posts).read_text(encoding="utf-8"))
    agg = s["aggregate"] or {}
    start, end = d(s["window"]["start"]), d(s["window"]["end"])

    # 1 — counts and metric sums
    if agg.get("posts") is None:
        warn("scope.aggregate.posts is empty — the count gate did not run. Fill it from posts-aggregate.")
    elif len(posts) != agg["posts"]:
        fail(f"post count {len(posts)} != aggregate {agg['posts']}")
    for m, key in (("likes", "l"), ("comments", "c"), ("shares", "s"), ("reposts", "rp")):
        if agg.get(m) is None:
            continue
        got = sum(int(r.get(key) or 0) for r in posts)
        if got != agg[m]:
            fail(f"{m} sum {got} != aggregate {agg[m]}")

    # 2 — dates
    out = [r["id"] for r in posts if not (start <= d(r["d"]) <= end)]
    if out:
        fail(f"{len(out)} posts outside the window, first {out[:3]}")
    if s["source"] == "paid":
        noend = [r["id"] for r in posts if not r.get("end")]
        if noend:
            warn(f"{len(noend)} ads with no end date — the metric clips them to the window end")

    # 3 — brands
    brands = sorted({r["b"] for r in posts})
    if s["focal"] not in brands:
        fail(f'focal brand "{s["focal"]}" not in posts.json; labels present: {brands[:8]}')
    norm = lambda b: re.sub(r"[^a-z]", "", b.lower())
    seen = {}
    for b in brands:
        k = norm(b)[:10]
        if k in seen:
            fail(f'two labels look like one brand: "{seen[k]}" and "{b}" — collapse them with --short')
        seen[k] = b

    # 4 — U+FFFD
    for name in (a.posts, a.copy):
        if name and cfg.run_file(name).exists():
            raw = cfg.run_file(name).read_text(encoding="utf-8")
            n = raw.count("�")
            if n:
                fail(f"{name} carries {n} U+FFFD characters — strip them or the artifact publish is rejected")

    copy = None
    if a.copy:
        copy = json.loads(cfg.run_file(a.copy).read_text(encoding="utf-8"))

    if copy:
        ids = {str(r["id"]) for r in posts}
        pubdate = {str(r["id"]): r["d"] for r in posts}
        # 5 — copy against scope
        if copy.get("focal") != s["focal"]:
            fail(f'copy.focal "{copy.get("focal")}" != scope.focal "{s["focal"]}"')
        for k in ("title", "summary", "scope", "findings", "moments", "players", "recommendation", "creative"):
            if not copy.get(k):
                fail(f"copy.{k} is missing — see references/copy-schema.md")
        named = [p.get("brand") for p in copy.get("players") or []] + \
                [e.get("brand") for f in copy.get("findings") or [] for e in f.get("evidence") or [] if e.get("kind") == "monitor"]
        for b in named:
            if b and b not in brands:
                fail(f'copy names brand "{b}", not a label in posts.json')
        missing_players = sorted(set(brands) - {p.get("brand") for p in copy.get("players") or []})
        if missing_players:
            warn(f"no players[] note for {missing_players} — their brand tabs show figures only")
        if re.search(r"\bDEFY\b", json.dumps(copy, ensure_ascii=False)):
            fail("copy.json says DEFY — the platform is SOMIN everywhere in this report")

        research = copy.get("research") or {}
        sources = {x["id"]: x for x in research.get("sources") or []}
        # 6 — findings: every claim opens its evidence
        for f in copy.get("findings") or []:
            got = [str(i) for i in f.get("post_ids") or []]
            miss = [i for i in got if i not in ids]
            if miss:
                fail(f'finding "{f.get("title")}" cites ids not in posts.json: {miss}')
            ev = f.get("evidence") or []
            if not got and not any(e.get("kind") == "monitor" for e in ev):
                fail(f'finding "{f.get("title")}" has no post and no classification comparison behind it')
            if len(got) > 3:
                warn(f'finding "{f.get("title")}" cites {len(got)} posts; the card shows one lead and two supporting')
            for e in ev:
                for sid in e.get("source_ids") or []:
                    if sid not in sources:
                        fail(f'finding "{f.get("title")}" cites research {sid}, absent from research.sources')
                if e.get("kind") == "monitor" and e.get("field") not in ("humanNeed", "appealCategory", "contentTypes", "emotions"):
                    fail(f'finding "{f.get("title")}" compares on {e.get("field")}, not a SOMIN classification dimension')
        for pl in copy.get("players") or []:
            for x in pl.get("posts") or []:
                if str(x.get("id")) not in ids:
                    fail(f'players note for {pl.get("brand")} cites {x.get("id")}, not in posts.json')

        # 7 — moments sit on the day of their post
        if len(copy.get("moments") or []) > 4:
            warn("more than four moments; the chart annotates three or four")
        for M in copy.get("moments") or []:
            dt, pid = M.get("date"), str(M.get("post_id"))
            if not dt or not (start <= d(dt) <= end):
                fail(f"moment date {dt} is outside the window")
            elif pid not in ids:
                fail(f"moment {dt} cites post {pid}, not in posts.json")
            elif pubdate[pid] != dt:
                fail(f"moment {dt} cites post {pid}, published {pubdate[pid]}")

        # 8 — the big idea is a SOMIN insight, and every mapped source exists
        ins = ((copy.get("direction") or {}).get("insight") or {}).get("id")
        if not ins:
            fail("copy.direction.insight is missing — the proposal's idea comes from a SOMIN insight, quoted")
        elif not any(x.get("kind") == "insight" and str(x.get("record_id")) == str(ins) for x in sources.values()):
            fail(f"direction.insight {ins} is not in research.sources as kind insight")
        maps = research.get("mappings") or {}
        for path, sids in maps.items():
            for sid in sids:
                if sid not in sources:
                    fail(f"research mapping {path} cites {sid}, absent from research.sources")
        for need in ("landscape:/recommendation", "creative:/suggestion", "creative:/brief"):
            if not maps.get(need):
                warn(f"research.mappings has nothing for {need} — the page prints it without citations")
        for x in sources.values():
            for parent in x.get("parents") or []:
                if parent not in sources:
                    fail(f"research source {x['id']} names parent {parent}, absent from research.sources")
        # 8b — every concept image comes from the expressions engine
        assets = (copy.get("creative") or {}).get("assets") or []
        imgs = {im.get("asset_index"): im for im in research.get("images") or []}
        for i, asset in enumerate(assets):
            im = imgs.get(i)
            if not im:
                fail(f"creative asset {i} ({asset.get('role')}) has no research.images entry — its creative basis cannot open")
                continue
            if im.get("prompt_source") != "somin_expressions_engine":
                fail(f"creative asset {i} prompt_source is {im.get('prompt_source')!r}; only somin_expressions_engine renders ship")
            if im.get("source_id") not in sources:
                fail(f"creative asset {i} source {im.get('source_id')} is not in research.sources")

    # 9 — manifest
    mpath = a.manifest or (s["expressions"] or {}).get("manifest")
    if mpath and cfg.run_file(mpath).exists():
        man = json.loads(cfg.run_file(mpath).read_text(encoding="utf-8"))
        txt = json.dumps(man)
        if "PASS" not in txt.upper():
            warn(f"{mpath} does not record a PASS result")
        keys = set(re.findall(r'"(P\d+-[A-Z]-\d+)"', txt))
        for key in (s["expressions"] or {}).get("images", {}):
            if keys and key not in keys:
                fail(f"image key {key} is not in {mpath}")
        if copy:
            for im in (copy.get("research") or {}).get("images") or []:
                k = im.get("prompt_key")
                if k and keys and k not in keys:
                    fail(f"concept image {im.get('asset_index')} uses prompt key {k}, absent from {mpath}")
    elif mpath:
        warn(f"manifest {mpath} not found — the report ships without images, and has to say so")

    # 10 — hooks
    cpath = a.concepts or (s["expressions"] or {}).get("concepts")
    if cpath and cfg.run_file(cpath).exists():
        con = json.loads(cfg.run_file(cpath).read_text(encoding="utf-8"))
        for ins in con.get("insights") or []:
            for c in ins.get("concepts") or []:
                w = len(str(c.get("hook") or "").split())
                if w > 7:
                    fail(f'hook "{c.get("hook")}" is {w} words; the gate caps it at 7 (keep the full line in tagline)')

    print(f"posts {len(posts)} · brands {len(brands)} · window {s['window']['start']} to {s['window']['end']} · {s['source']}")
    for w in warns:
        print("WARN  " + w)
    for f in fails:
        print("FAIL  " + f)
    print("GATE FAIL" if fails else "GATE PASS")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
