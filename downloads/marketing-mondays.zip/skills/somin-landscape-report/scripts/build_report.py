#!/usr/bin/env python3
"""Assemble the self-contained SOMIN Landscape Breakdown page.

Usage:
  python3 build_report.py --posts posts.json --copy copy.json \
      --image asset-0=expr/P1-T-01.png --image asset-1=expr/P1-M-01.png \
      [--scope scope.json] [--theme theme_somin.json] \
      [--thumb-top 120 --thumb-box 480 --thumb-q 70] --out report.html

The page is assets/report_template.html: a fixed SOMIN-branded layout (masthead, section rail, two
views "The landscape" / "What to make", the Sources & scope dialog) that renders everything from
one JSON block, `report-data`. This script writes that block.

What the script computes — never type these into copy.json:
  profiles[]   one per brand short name (aliases already applied in posts.json `b`), with posts,
               response, median per measured post, complete/partial/missing metric counts, the
               top-5 share, per-field coverage, the platform split and the SOMIN classification
               dimensions (customer needs, appeal, content type, emotions)
  totals       the same across the whole read
  daily[]      every date in the window, with per-brand posts and response
  posts[]      every post, with values per metric field, response, platform label, title, thumbnail
  metric       organic: likes + comments (scope.metricFields overrides); paid: active ad-days
  coverage, chartMissingNote, retrievedAt, storageKey, sharing, colours
  findings[].evidence[kind=monitor].groups   the classification comparison behind a finding
  research.sources[].url                     SOMIN platform links when the copy leaves them out

What copy.json supplies (see references/copy-schema.md): the words, the post ids each claim rests
on and the SOMIN research records. Brands are named by their short name; the script maps them to ids.
"""
import argparse, base64, hashlib, io, json, os, re, statistics, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote

HERE = Path(__file__).resolve().parent
ASSETS = HERE.parent / "assets"
TEMPLATE = ASSETS / "report_template.html"

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "--break-system-packages", "pillow"])
    from PIL import Image

FIELD_KEYS = {"likesCount": "l", "commentsCount": "c", "sharesCount": "s", "repostsCount": "rp",
              "videoViewsCount": "v", "adDays": None}
METRIC_LABELS = {
    ("likesCount", "commentsCount"): "Recorded likes and comments",
    ("likesCount", "commentsCount", "sharesCount"): "Recorded likes, comments and shares",
    ("likesCount", "commentsCount", "sharesCount", "repostsCount"): "Recorded likes, comments, shares and reposts",
    ("adDays",): "Active ad-days",
}
DIMENSIONS = [("humanNeed", "Customer needs"), ("appealCategory", "Appeal"),
              ("contentTypes", "Content type"), ("emotions", "Emotions")]
DIM_MEANING = {
    "humanNeed": "SOMIN's customer-need classification of the post.",
    "appealCategory": "SOMIN's appeal classification of the post.",
    "contentTypes": "SOMIN's content-type classification of the post.",
    "emotions": "SOMIN's emotion classification of the post.",
}
FOCAL_COLOUR = "#1F8A70"
RIVAL_RAMP = ["#16201F", "#5E8F9B", "#9BA8A6", "#3E6B78", "#A7C7BF", "#6B7A78", "#2DBF9C", "#2A3635", "#8FA8A3", "#C9D1D0"]
SOURCE_LABELS = {"study": "Open study in SOMIN", "insight": "Open insight in SOMIN",
                 "supporting_posts": "View supporting posts in SOMIN", "proposition_set": "Open proposition set in SOMIN"}


# ---------------------------------------------------------------- images
def to_datauri(raw, box, q=72, fmt="JPEG"):
    im = Image.open(io.BytesIO(raw))
    im = im.convert("RGB") if fmt == "JPEG" else im
    im.thumbnail(box)
    buf = io.BytesIO()
    im.save(buf, fmt, quality=q, optimize=True)
    return f"data:image/{fmt.lower()};base64," + base64.b64encode(buf.getvalue()).decode()


def fetch(url):
    if not url:
        return None
    if url.startswith("data:"):
        return url
    p = Path(url)
    if p.exists():
        return p.read_bytes()
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        tmp = tf.name
    r = subprocess.run(["curl", "-sSfL", "-m", "30", "-o", tmp, url], capture_output=True)
    data = Path(tmp).read_bytes() if r.returncode == 0 else None
    os.unlink(tmp)
    return data


def thumb(url, box, q):
    try:
        raw = fetch(url)
        if isinstance(raw, str):
            return raw
        return to_datauri(raw, box, q) if raw else None
    except Exception:
        return None


# ---------------------------------------------------------------- helpers
def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def iso(d):
    return d.isoformat()


def median(xs):
    return statistics.median(xs) if xs else None


def post_title(caption, brand):
    cap = (caption or "").strip()
    if not cap:
        return f"{brand} post"
    first = re.split(r"(?<=[.!?])\s|\n", cap, maxsplit=1)[0].strip()
    return first if len(first) <= 90 else first[:87].rstrip() + "…"


def stats_for(rows, fields):
    """Totals, medians and coverage for a set of report posts."""
    resp = [r["response"] for r in rows if r["response"] is not None]
    complete = [r for r in rows if all(r["values"].get(f) is not None for f in fields)]
    partial = [r for r in rows if r not in complete and any(r["values"].get(f) is not None for f in fields)]
    total = sum(resp)
    top5 = sum(sorted(resp, reverse=True)[:5])
    return {
        "posts": len(rows),
        "response": total if resp else (0 if rows else None),
        "median": median([r["response"] for r in complete]),
        "completePosts": len(complete),
        "partialPosts": len(partial),
        "missingPosts": len(rows) - len(complete) - len(partial),
        "top5Share": (top5 / total) if total else None,
        "fieldCoverage": {f: {"known_posts": sum(1 for r in rows if r["values"].get(f) is not None),
                              "missing_posts": sum(1 for r in rows if r["values"].get(f) is None),
                              "raw_fallback_posts": 0} for f in fields},
    }


def dims_for(rows, raw_by_id):
    out = []
    for field, title in DIMENSIONS:
        classified = [r for r in rows if raw_by_id[r["id"]].get(field)]
        counts = {}
        for r in classified:
            for lab in raw_by_id[r["id"]][field]:
                counts.setdefault(lab, []).append(r["id"])
        labels = sorted(counts.items(), key=lambda kv: (-len(kv[1]), kv[0]))
        out.append({"field": field, "title": title, "published_posts": len(rows), "classified_posts": len(classified),
                    "labels": [{"label": k, "post_count": len(v), "share_of_classified_posts": len(v) / len(classified),
                                "post_ids": v} for k, v in labels[:6]]})
    return out


def platform_url(base, ws, kind, rec_id, scope_bits):
    if not base or rec_id is None:
        return None, None
    if kind == "study" and ws:
        return f"{base}/app/a/{ws}/studies/{rec_id}", "study"
    if kind == "insight":
        return f"{base}/app/inspire/insights/story/{rec_id}", "insight"
    if kind in ("persona", "tension", "relevance") and ws:
        q = (f"themeId={rec_id}&dateRange={scope_bits['start']},{scope_bits['end']}"
             f"&profiles={quote(json.dumps(scope_bits['profiles'], separators=(',', ':')))}"
             f"&source={quote(json.dumps(scope_bits['source']))}&dateBreakdown=DAILY&pageSize=20&page=0&sort=date&sortDir=DESC")
        return f"{base}/app/a/{ws}/somonitor/content-library?{q}", "supporting_posts"
    return None, None


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--posts", required=True)
    ap.add_argument("--copy", required=True)
    ap.add_argument("--scope", default=os.environ.get("LR_SCOPE") or "scope.json")
    ap.add_argument("--theme", default=None, help="only its brandColors / rivalRamp / focalColor are read")
    ap.add_argument("--image", action="append", default=[], help="asset-id=path-or-url (one per creative asset)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--no-thumbs", action="store_true")
    ap.add_argument("--thumb-top", type=int, default=150, help="embed thumbnails for the top N posts plus every cited and focal post; 0 = all")
    ap.add_argument("--thumb-box", type=int, default=480)
    ap.add_argument("--thumb-q", type=int, default=70)
    a = ap.parse_args()

    raw_posts = load_json(a.posts)
    copy = load_json(a.copy)
    scope = load_json(a.scope) if Path(a.scope).exists() else {}
    theme = load_json(a.theme) if a.theme else (load_json(ASSETS / "theme_somin.json"))

    win = scope.get("window") or {}
    start = date.fromisoformat(win.get("start") or copy["scope"]["start"])
    end = date.fromisoformat(win.get("end") or copy["scope"]["end"])
    paid = (scope.get("source") or copy.get("mode") or "organic") == "paid"
    fields = ["adDays"] if paid else list(scope.get("metricFields") or copy.get("metricFields") or ["likesCount", "commentsCount"])
    label = copy.get("metricLabel") or METRIC_LABELS.get(tuple(fields)) or " + ".join(fields)

    # ---- brands -> ids (the SOMIN profile id with most posts carries the brand)
    by_brand = {}
    for r in raw_posts:
        by_brand.setdefault(r["b"], {}).setdefault(str(r.get("pid") or r["b"]), 0)
        by_brand[r["b"]][str(r.get("pid") or r["b"])] += 1
    brand_id = {}
    for b, pids in by_brand.items():
        pid = max(pids, key=pids.get)
        brand_id[b] = pid if re.fullmatch(r"[A-Za-z0-9_-]+", pid) else "b" + hashlib.md5(b.encode()).hexdigest()[:8]
    all_pids = sorted({int(p) for pids in by_brand.values() for p in pids if str(p).isdigit()})

    def bid(name):
        if name in brand_id:
            return brand_id[name]
        if name in brand_id.values():
            return name
        raise SystemExit(f"copy names a brand not in posts.json: {name!r}. Brands: {sorted(brand_id)}")

    # ---- posts
    posts, raw_by_id = [], {}
    for r in raw_posts:
        pid = str(r["id"])
        raw_by_id[pid] = r
        if paid:
            st = max(date.fromisoformat(r["d"]), start)
            en = min(date.fromisoformat(r["end"]) if r.get("end") else end, end)
            values = {"adDays": max((en - st).days + 1, 0)}
        else:
            miss = set(r.get("miss") or [])
            values = {}
            for f in fields:
                k = FIELD_KEYS.get(f)
                v = r.get(k) if k else r.get(f)
                values[f] = None if (f in miss or v is None) else int(v)
        known = [v for v in values.values() if v is not None]
        posts.append({
            "id": pid, "profile": brand_id[r["b"]], "platform": r.get("st") or (r.get("p") or "other").lower(),
            "date": r["d"], "caption": r.get("cap") or "", "title": r.get("title") or post_title(r.get("cap"), r["b"]),
            "thumbnail": r.get("thumb"), "video": r.get("video"), "permalink": r.get("u"),
            "values": values, "response": sum(known) if known else None,
            "format": r.get("fmt"), "platformLabel": r.get("p") or "Other",
        })
    posts.sort(key=lambda p: (p["date"], p["id"]), reverse=True)
    post_ids = {p["id"] for p in posts}

    # ---- profiles, totals, daily
    names = {v: k for k, v in brand_id.items()}
    profiles = []
    for b, pid in brand_id.items():
        rows = [p for p in posts if p["profile"] == pid]
        plats = {}
        for p in rows:
            plats.setdefault(p["platformLabel"], []).append(p)
        prof = {"id": pid, "name": b, **stats_for(rows, fields),
                "platforms": sorted(({"name": n, "sourceTypes": sorted({p["platform"] for p in ps}), **stats_for(ps, fields)}
                                     for n, ps in plats.items()), key=lambda x: -(x["response"] or 0)),
                "monitorDimensions": [] if paid else dims_for(rows, raw_by_id)}
        profiles.append(prof)
    # source order = response order, so colours and references stay stable
    profiles.sort(key=lambda p: -(p["response"] or 0))
    totals = stats_for(posts, fields)

    daily, d = [], start
    while d <= end:
        day = [p for p in posts if p["date"] == iso(d)]
        daily.append({"date": iso(d), "posts": len(day), "response": sum(p["response"] or 0 for p in day),
                      "profiles": [{"profile": pr["id"], "posts": sum(1 for p in day if p["profile"] == pr["id"]),
                                    "response": sum(p["response"] or 0 for p in day if p["profile"] == pr["id"])} for pr in profiles]})
        d += timedelta(days=1)

    # ---- colours: focal teal, rivals on the SOMIN ramp in fixed response order
    focal = bid(copy["focal"])
    colours, ramp = dict(theme.get("brandColors") or {}), iter(theme.get("rivalRamp") or RIVAL_RAMP)
    colours = {bid(k) if k in brand_id else k: v for k, v in colours.items()}
    for pr in profiles:
        if pr["id"] not in colours:
            colours[pr["id"]] = theme.get("focalColor", FOCAL_COLOUR) if pr["id"] == focal else next(ramp, "#9BA8A6")

    # ---- copy -> data
    def check_ids(ids, where):
        bad = [i for i in ids if str(i) not in post_ids]
        if bad:
            print(f"WARNING {where}: post ids not in posts.json: {bad}")
        return [str(i) for i in ids]

    findings = []
    for i, f in enumerate(copy.get("findings") or []):
        f = dict(f)
        f.setdefault("id", f"finding-{i+1}")
        f["post_ids"] = check_ids(f.get("post_ids") or [], f["id"])
        ev = []
        for item in f.get("evidence") or []:
            if item.get("kind") != "monitor":
                ev.append(item)
                continue
            pid = bid(item["brand"]) if item.get("brand") else None
            plat = item.get("platform")
            rows = [p for p in posts if (not pid or p["profile"] == pid) and (not plat or p["platformLabel"] == plat)]
            classified = [p for p in rows if raw_by_id[p["id"]].get(item["field"])]
            complete = [p for p in classified if all(v is not None for v in p["values"].values())]
            has = [p for p in complete if item["label"] in raw_by_id[p["id"]][item["field"]]]
            hasnt = [p for p in complete if p not in has]
            dim = dict(DIMENSIONS).get(item["field"], item["field"])
            measure = item.get("measure", "median")
            agg = (lambda xs: median([p["response"] for p in xs])) if measure == "median" else (lambda xs: sum(p["response"] for p in xs))
            ev.append({
                "kind": "monitor", "field": item["field"], "dimension": dim, "label": item["label"],
                "profile_id": pid, "source_type": None, "format": None,
                "scope_label": " · ".join([names.get(pid, "All brands"), plat or "All platforms"]),
                "measure": measure, "title": f"{'Median' if measure == 'median' else 'Total'} {label.lower()}",
                "groups": [{"label": f'Posts with {dim.lower()} "{item["label"]}"', "posts": len(has), "value": agg(has) if has else None, "post_ids": [p["id"] for p in has]},
                           {"label": f'Other classified posts without "{item["label"]}"', "posts": len(hasnt), "value": agg(hasnt) if hasnt else None, "post_ids": [p["id"] for p in hasnt]}],
                "measurement_title": f"{dim}: {item['label']}",
                "semantics": {"field_title": dim, "meaning": DIM_MEANING.get(item["field"], ""),
                              "members": f'Posts with {dim.lower()} "{item["label"]}"', "without_label": f'Other classified posts without "{item["label"]}"'},
                "context_title": "", "explanation": item.get("explanation", ""),
                "classified_posts": len(complete), "published_posts": len(rows),
                "excluded_incomplete_posts": len(classified) - len(complete), "unclassified_posts": len(rows) - len(classified),
            })
        f["evidence"] = ev
        f.setdefault("takeaway", "")
        findings.append(f)

    players = []
    for pl in copy.get("players") or []:
        pl = dict(pl)
        pl["profile_id"] = bid(pl.pop("brand")) if "brand" in pl else pl["profile_id"]
        for x in pl.get("posts") or []:
            x["id"] = check_ids([x["id"]], "players")[0]
        players.append(pl)
    have = {p["profile_id"] for p in players}
    for pr in profiles:  # every brand tab needs a note; an empty one is printed as such
        if pr["id"] not in have:
            print(f"WARNING no players[] entry for {pr['name']} — its tab will show figures only")
            players.append({"profile_id": pr["id"], "summary": "", "decision": "", "posts": []})

    moments = []
    for m in copy.get("moments") or []:
        m = dict(m)
        m["post_id"] = check_ids([m["post_id"]], "moments")[0]
        m.setdefault("peak_post_id", m["post_id"])
        if not (iso(start) <= m["date"] <= iso(end)):
            print("WARNING moment outside window:", m["date"])
        moments.append(m)

    creative = dict(copy["creative"])
    creative.setdefault("brand", names[focal])
    creative["source_ids"] = check_ids(creative.get("source_ids") or [], "creative.source_ids")
    for k in ("propositions", "reasoning", "execution", "brief", "moments"):
        creative.setdefault(k, [])
    for r in creative["reasoning"]:
        r["post_ids"] = check_ids(r.get("post_ids") or [], "creative.reasoning")
    images = {}
    img_src = dict(s.split("=", 1) for s in a.image)
    assets = []
    for i, asset in enumerate(creative.get("assets") or []):
        asset = dict(asset)
        asset.setdefault("id", f"asset-{i}")
        src = img_src.get(asset["id"]) or img_src.get(asset.get("image", ""))
        raw = fetch(src) if src else None
        if not raw:
            print(f"WARNING no image for {asset['id']} — the asset is dropped. A hand-written prompt is not a fallback.")
            continue
        if isinstance(raw, str):
            images[asset["id"]] = raw
        else:
            im = Image.open(io.BytesIO(raw))
            asset.setdefault("imageWidth", im.width)
            asset.setdefault("imageHeight", im.height)
            images[asset["id"]] = to_datauri(raw, (1024, 1536), 82)
        asset.setdefault("filename", f"concept-{i+1}.jpg")
        asset.setdefault("disclosure", "")
        asset.setdefault("format", "2:3 portrait image")
        assets.append(asset)
    creative["assets"] = assets

    # ---- research: SOMIN links where the copy leaves them out
    research = dict(copy.get("research") or {"sources": [], "mappings": {}, "images": []})
    base = scope.get("platformBase", "https://cloud.somin.ai").rstrip("/")
    ws = str((scope.get("workspaces") or [{}])[0].get("id") or "") or None
    bits = {"start": (copy.get("studyWindow") or {}).get("start", iso(start)),
            "end": (copy.get("studyWindow") or {}).get("end", iso(end)),
            "profiles": all_pids, "source": ["ADS_LIBRARY" if paid else "PAGES"]}
    for s in research.get("sources", []):
        s.setdefault("post_ids", []); s.setdefault("parents", []); s.setdefault("finding_ids", [])
        s["post_ids"] = [str(x) for x in s["post_ids"]]
        if not s.get("url"):
            url, kind = platform_url(base, ws, s["kind"], s.get("record_id"), bits)
            if url:
                s["url"], s["url_kind"], s["url_label"] = url, kind, SOURCE_LABELS[kind]
        elif not s.get("url_label"):
            s["url_label"] = SOURCE_LABELS.get(s.get("url_kind"), "Open source in SOMIN")
    known_src = {s["id"] for s in research.get("sources", [])}
    for path, ids in (research.get("mappings") or {}).items():
        for sid in ids:
            if sid not in known_src:
                print(f"WARNING research mapping {path} cites unknown source {sid}")
    for im in research.get("images", []):
        im.setdefault("url_label", SOURCE_LABELS.get(im.get("url_kind"), "Open creative source in SOMIN"))
    research.setdefault("mappings", {}); research.setdefault("images", [])

    # ---- thumbnails: data URIs, because artifact pages cannot load remote images
    if not a.no_thumbs:
        cited = set()
        for f in findings:
            cited |= set(f["post_ids"])
            for e in f["evidence"]:
                if e["kind"] == "monitor":
                    for g in e["groups"]:
                        cited |= set(g["post_ids"][:3])
        for pl in players:
            cited |= {x["id"] for x in pl["posts"]}
        cited |= {m["post_id"] for m in moments} | set(creative["source_ids"])
        for r in creative["reasoning"]:
            cited |= set(r["post_ids"])
        for s in research.get("sources", []):
            cited |= set(s["post_ids"]) | {str(x) for x in s.get("example_post_ids") or []}
        for pr in profiles:  # each brand tab opens on its top posts
            cited |= {p["id"] for p in sorted((p for p in posts if p["profile"] == pr["id"]), key=lambda p: -(p["response"] or 0))[:3]}
        top = {p["id"] for p in sorted(posts, key=lambda p: -(p["response"] or 0))[: a.thumb_top]} if a.thumb_top else post_ids
        want = cited | top | ({p["id"] for p in posts if p["profile"] == focal} if a.thumb_top else set())
        box = (a.thumb_box, a.thumb_box)
        def one(p):
            return thumb(p["thumbnail"], box, a.thumb_q) if p["id"] in want and p["thumbnail"] else None
        with ThreadPoolExecutor(16) as ex:
            got = list(ex.map(one, posts))
        n = 0
        for p, t in zip(posts, got):
            if t:
                p["thumbnail"] = t; n += 1
            elif p["id"] in want and p["thumbnail"]:
                print(f"WARNING thumbnail failed for cited post {p['id']}")
    else:
        n = 0

    # ---- coverage lines
    fc = totals["fieldCoverage"]
    if paid:
        coverage = f"{totals['posts']:,} ads in the selected scope. Active ad-days count each day an ad ran inside the window."
        missing_note = ""
    else:
        parts = [f"{totals['posts']:,} posts in the selected scope."]
        for f in fields:
            k, m_ = fc[f]["known_posts"], fc[f]["missing_posts"]
            nm = {"likesCount": "Like", "commentsCount": "Comment", "sharesCount": "Share", "repostsCount": "Repost"}.get(f, f)
            parts.append(f"{nm} counts are available for all {k:,} posts." if not m_ else f"{nm} counts are available for {k:,} posts and unavailable for {m_:,} posts.")
        parts.append(f"Medians use {totals['completePosts']:,} posts with every selected counter available.")
        if totals["partialPosts"]:
            parts.append("Known values from partial posts remain in totals.")
        coverage = " ".join(parts)
        missing_note = ("Dates with unavailable response counts are plotted at zero. Original missing values remain unmeasured "
                        "in the source records and are excluded from medians.") if totals["partialPosts"] or totals["missingPosts"] else ""

    sc = copy["scope"]
    data = {
        "scope": {"name": sc["name"], "start": iso(start), "end": iso(end), "relationship": sc.get("relationship", "")},
        "title": copy["title"], "summary": copy["summary"],
        "timeline": copy.get("timeline") or {}, "comparison": copy.get("comparison") or {"title": "", "body": ""},
        "focal": focal, "focalReason": copy.get("focalReason", ""),
        "metric": {"fields": fields, "label": label, "sharePath": None},
        "retrievedAt": copy.get("retrievedAt") or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "coverage": copy.get("coverage") or coverage, "coverageNotes": copy.get("coverageNotes", ""),
        "chartMissingNote": copy.get("chartMissingNote", missing_note),
        "contextSources": copy.get("contextSources") or [],
        "profiles": profiles, "totals": totals, "daily": daily, "posts": posts,
        "findings": findings, "players": players, "moments": moments,
        "monitorDimensions": [] if paid else [f for f, _ in DIMENSIONS],
        "recommendation": copy["recommendation"], "creative": creative, "images": images,
        "storageKey": hashlib.sha1((sc["name"] + iso(start) + iso(end)).encode()).hexdigest()[:20],
        "research": research,
        "sharing": {"title": f"{sc['name']} | SOMIN Landscape Breakdown", "description": copy["title"]},
        "colors": colours,
    }
    if copy.get("direction"):
        data["direction"] = copy["direction"]

    tpl = TEMPLATE.read_text(encoding="utf-8")
    esc = lambda s: s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")
    blob = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html = (tpl.replace("__TITLE__", esc(f"{sc['name']} | Landscape Breakdown"))
               .replace("__OG_TITLE__", esc(data["sharing"]["title"]))
               .replace("__DESCRIPTION__", esc(copy["title"]))
               .replace("__REPORT_DATA__", blob))
    if "�" in html:
        print("WARNING U+FFFD in the page — strip it at extraction; the artifact publish rejects it")
    Path(a.out).write_text(html, encoding="utf-8")
    size = os.path.getsize(a.out) / 1e6
    print(f"wrote {a.out} ({size:.1f} MB): {len(posts)} posts, {len(profiles)} brands, {n} embedded thumbnails, "
          f"{len(assets)} concept images, {len(findings)} findings, {len(moments)} moments")
    if focal not in {p["id"] for p in profiles}:
        print("WARNING focal brand has no posts")
    if size > 15.5:
        print("WARNING page is over the 16 MB artifact limit — lower --thumb-top / --thumb-box")


if __name__ == "__main__":
    main()
