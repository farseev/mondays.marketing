#!/usr/bin/env python3
"""Turn raw SOMIN posts-search results into compact report records.

posts-search returns very large post objects (full feature extraction, raw
platform data). When a result is too big for the conversation the harness
saves it to a file; point this script at those files (or at JSON you saved
yourself) and it writes one small record per post.

Usage:
  python3 extract_posts.py --out posts.json [--source organic|paid] \
      [--short "Long Profile Name=Short"]... raw1.json raw2.json ...

Each input file may be: a posts-search response ({"items": [...]}) , a bare
list of post objects, or a file holding several responses concatenated.
Duplicates (same post id) are dropped. Records are written sorted by date.
"""
import argparse, json, re, sys
from pathlib import Path


def iter_posts(obj):
    if isinstance(obj, dict):
        if "items" in obj and isinstance(obj["items"], list):
            yield from obj["items"]
        elif "id" in obj and "metrics" in obj:
            yield obj
        else:
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    yield from iter_posts(v)
    elif isinstance(obj, list):
        for x in obj:
            yield from iter_posts(x)


def load_any(path):
    txt = Path(path).read_text(encoding="utf-8", errors="replace")
    try:
        return [json.loads(txt)]
    except json.JSONDecodeError:
        pass
    # tool-result files sometimes wrap JSON in text; pull every top-level JSON object out
    out, dec, i = [], json.JSONDecoder(), 0
    while True:
        m = re.search(r"[\[{]", txt[i:])
        if not m:
            break
        try:
            obj, end = dec.raw_decode(txt[i + m.start():])
            out.append(obj)
            i += m.start() + end
        except json.JSONDecodeError:
            i += m.start() + 1
    return out


def first_image(cr):
    if not cr:
        return None
    for im in cr.get("images") or []:
        if im.get("url"):
            return im["url"]
    for ch in cr.get("children") or []:
        u = first_image(ch)
        if u:
            return u
    return None


def click_above(cr):
    if not cr:
        return None
    cs = (cr.get("data") or {}).get("clickability_score") or {}
    for v in cs.values():
        if isinstance(v, dict) and "ABOVE_AVERAGE" in v:
            return round(v["ABOVE_AVERAGE"], 3)
    for ch in cr.get("children") or []:
        c = click_above(ch)
        if c is not None:
            return c
    return None


def platform_label(p):
    st = (p.get("sourceType") or "").lower()
    pl = " ".join((p.get("rawData") or {}).get("placement") or []).upper()
    if "STORIES" in pl or p.get("type") == "STORY":
        return "Instagram Story" if "instagram" in st or "INSTAGRAM" in pl else "Story"
    for key, lab in [("linkedin", "LinkedIn"), ("instagram", "Instagram"), ("facebook", "Facebook"),
                     ("tiktok", "TikTok"), ("telegram", "Telegram"), ("google", "Google Ads"),
                     ("threads", "Threads"), ("messenger", "Messenger")]:
        if key in st or key.upper() in pl:
            return lab
    return st or "Other"


def post_url(p):
    rd = p.get("rawData") or {}
    for k in ("postUrl", "url", "permalink", "adSnapshotUrl", "ad_snapshot_url"):
        if rd.get(k):
            return rd[k]
    if rd.get("code"):
        return f"https://www.instagram.com/p/{rd['code']}/"
    return None


def as_list(v):
    if not v:
        return []
    if isinstance(v, str):
        return [v]
    return [x if isinstance(x, str) else (x.get("name") or x.get("label") or str(x)) for x in v]


def video_url(p, cr):
    rd = p.get("rawData") or {}
    for k in ("videoUrl", "video_url"):
        if rd.get(k):
            return rd[k]
    for v in (cr or {}).get("videos") or []:
        if v.get("url"):
            return v["url"]
    return None


def compact(p, short):
    m = p.get("metrics") or {}
    rd = p.get("rawData") or {}
    f = p.get("feature") or {}
    cr = (p.get("creatives") or [None])[0]
    texts = (cr or {}).get("texts") or []
    cap = re.sub(r"\s+", " ", (texts[0].get("content") if texts else "") or "").replace("\ufffd", "").strip()
    name = (p.get("profile") or {}).get("name") or "Unknown"
    # a counter the platform did not return stays missing: it is not a zero
    miss = [k for k in ("likesCount", "commentsCount", "sharesCount", "repostsCount") if m.get(k) is None]
    return {
        "id": p.get("id"),
        "pid": (p.get("profile") or {}).get("id"),
        "b": short.get(name, name),
        "d": (p.get("postDate") or "")[:10],
        "end": (p.get("endDate") or "")[:10] or None,
        "p": platform_label(p),
        "st": (p.get("sourceType") or "").lower() or None,
        "type": p.get("type"),
        "fmt": (p.get("type") or "").lower() or None,
        "l": m.get("likesCount") or 0,
        "rx": m.get("reactionsCount"),
        "c": m.get("commentsCount") or 0,
        "s": m.get("sharesCount") or 0,
        "rp": m.get("repostsCount") or 0,
        "miss": miss,
        "v": m.get("viewsCount") or m.get("playCount") or m.get("videoViewsCount") or rd.get("play_count"),
        "u": post_url(p),
        "thumb": first_image(cr),
        "video": video_url(p, cr),
        "cap": cap[:600],
        "tp": f.get("topic") or "",
        "ct": as_list(f.get("contentTypes")),
        # the four SOMIN classification dimensions the brand tabs and monitor comparisons read
        "humanNeed": as_list(f.get("humanNeed")),
        "appealCategory": as_list(f.get("appealCategory")),
        "contentTypes": as_list(f.get("contentTypes")),
        "emotions": as_list(f.get("emotions")),
        "occ": f.get("occasion") or [],
        "prod": f.get("mainProduct") or [],
        "click": click_above(cr),
        "countries": p.get("countries"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--short", action="append", default=[], help='"Profile Name=Short label"')
    ap.add_argument("files", nargs="+")
    a = ap.parse_args()
    short = dict(s.split("=", 1) for s in a.short)
    seen, rows = set(), []
    for fp in a.files:
        for obj in load_any(fp):
            for p in iter_posts(obj):
                if p.get("id") in seen:
                    continue
                seen.add(p.get("id"))
                rows.append(compact(p, short))
    rows.sort(key=lambda r: (r["d"], r["b"]))
    Path(a.out).write_text(json.dumps(rows, ensure_ascii=False, indent=0))
    by = {}
    for r in rows:
        by.setdefault(r["b"], [0, 0, 0, 0, 0])
        o = by[r["b"]]
        o[0] += 1; o[1] += r["l"]; o[2] += r["c"]; o[3] += r["s"]; o[4] += r["rp"]
    print(f"{len(rows)} posts -> {a.out}")
    for b, o in sorted(by.items()):
        print(f"  {b}: posts={o[0]} likes={o[1]} comments={o[2]} shares={o[3]} reposts={o[4]}")


if __name__ == "__main__":
    sys.exit(main())
