#!/usr/bin/env python3
"""Compute every figure the landscape report states, from posts.json.

Usage:
  python3 analyze.py posts.json --mode organic|paid --start YYYY-MM-DD --end YYYY-MM-DD \
      [--focal "Brand short name"] [--market India] [--out analysis.json]

Organic metric  = the report metric, default likes + comments (--fields to change), per post,
                  counted on the post's publish date (same fields posts-aggregate sums).
Paid metric     = active ad-days = for each ad, the days between its start (postDate)
                  and its end (endDate, or the window end if still running), clipped to
                  the window. Daily series = ads live that day; bars show launches too.

Writes analysis.json and prints a summary. Quote numbers in the copy only from here.
"""
import argparse, json, collections
from datetime import date, timedelta


def d(s):
    return date.fromisoformat(s[:10])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("posts")
    ap.add_argument("--mode", choices=["organic", "paid"], default="organic")
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--focal")
    ap.add_argument("--market", action="append", default=[], help="term to count mentions of (repeatable)")
    ap.add_argument("--peaks", type=int, default=4)
    ap.add_argument("--fields", default="likesCount,commentsCount",
                    help="organic metric fields, the same list build_report.py uses (scope.metricFields)")
    ap.add_argument("--out", default="analysis.json")
    a = ap.parse_args()
    rows = json.load(open(a.posts))
    S, E = d(a.start), d(a.end)
    days = [(S + timedelta(i)).isoformat() for i in range((E - S).days + 1)]

    daily = {k: {"m": 0, "n": 0, "live": 0} for k in days}
    for r in rows:
        if a.mode == "organic":
            key = {"likesCount": "l", "commentsCount": "c", "sharesCount": "s", "repostsCount": "rp"}
            r["m"] = sum(int(r.get(key[f]) or 0) for f in a.fields.split(","))
            if r["d"] in daily:
                daily[r["d"]]["m"] += r["m"]; daily[r["d"]]["n"] += 1
        else:
            st = max(d(r["d"]), S)
            en = min(d(r["end"]) if r.get("end") else E, E)
            r["m"] = max((en - st).days + 1, 0)
            for i in range(r["m"]):
                k = (st + timedelta(i)).isoformat()
                if k in daily:
                    daily[k]["live"] += 1; daily[k]["m"] += 1
            if r["d"] in daily:
                daily[r["d"]]["n"] += 1
    T = sum(r["m"] for r in rows) or 1

    brands = collections.OrderedDict()
    for r in sorted(rows, key=lambda r: -r["m"]):
        o = brands.setdefault(r["b"], {"posts": 0, "m": 0, "platforms": collections.Counter(), "top": None})
        o["posts"] += 1; o["m"] += r["m"]; o["platforms"][r["p"]] += 1
        if o["top"] is None:
            o["top"] = {"id": r["id"], "m": r["m"], "d": r["d"], "tp": (r.get("tp") or "")[:120]}
    blist = sorted(brands.items(), key=lambda x: -x[1]["m"])
    by_brand = [{"brand": b, "posts": o["posts"], "m": o["m"], "share": round(o["m"] / T * 100, 1),
                 "per_post": round(o["m"] / o["posts"], 1), "platforms": dict(o["platforms"]), "top": o["top"]}
                for b, o in blist]

    peak = sorted(days, key=lambda k: -daily[k]["m"])[: a.peaks]
    peak_days = []
    for k in sorted(peak):
        top = sorted([r for r in rows if r["d"] == k], key=lambda r: -r["m"])[:4]
        peak_days.append({"date": k, "m": daily[k]["m"], "n": daily[k]["n"],
                          "top": [{"id": r["id"], "b": r["b"], "m": r["m"], "tp": (r.get("tp") or "")[:100]} for r in top]})
    peak_share = round(sum(daily[k]["m"] for k in peak) / T * 100, 1)

    ct = collections.defaultdict(lambda: [0, 0])
    for r in rows:
        for c in r.get("ct") or []:
            ct[c][0] += 1; ct[c][1] += r["m"]
    content_types = sorted([{"type": k, "posts": v[0], "avg": round(v[1] / v[0], 1)} for k, v in ct.items() if v[0] >= 3],
                           key=lambda x: -x["posts"])

    pf = collections.defaultdict(lambda: [0, 0])
    for r in rows:
        pf[r["p"]][0] += 1; pf[r["p"]][1] += r["m"]
    platforms = {k: {"posts": v[0], "m": v[1], "avg": round(v[1] / v[0], 1)} for k, v in pf.items()}

    top_posts = [{"id": r["id"], "b": r["b"], "d": r["d"], "p": r["p"], "m": r["m"], "tp": (r.get("tp") or "")[:110]}
                 for r in sorted(rows, key=lambda r: -r["m"])[:25]]

    focal = None
    if a.focal:
        fr = [r for r in rows if r["b"] == a.focal]
        if fr:
            fct = collections.defaultdict(lambda: [0, 0])
            for r in fr:
                for c in r.get("ct") or ["(untagged)"]:
                    fct[c][0] += 1; fct[c][1] += r["m"]
            rank = [b["brand"] for b in by_brand].index(a.focal) + 1
            focal = {"brand": a.focal, "rank": rank, "posts": len(fr), "m": sum(r["m"] for r in fr),
                     "share": round(sum(r["m"] for r in fr) / T * 100, 1),
                     "content_types": sorted([{"type": k, "posts": v[0], "avg": round(v[1] / v[0], 1)} for k, v in fct.items()], key=lambda x: -x["posts"]),
                     "posts_ranked": [{"id": r["id"], "d": r["d"], "p": r["p"], "m": r["m"], "tp": (r.get("tp") or "")[:100], "occ": r.get("occ")} for r in sorted(fr, key=lambda r: -r["m"])]}

    mentions = {}
    for term in a.market:
        t = term.lower()
        hit = [r for r in rows if t in ((r.get("cap") or "") + " " + (r.get("tp") or "")).lower()]
        mentions[term] = {"posts": len(hit), "m": sum(r["m"] for r in hit),
                          "by_brand": dict(collections.Counter(r["b"] for r in hit)),
                          "ids": [r["id"] for r in sorted(hit, key=lambda r: -r["m"])]}

    out = {"mode": a.mode, "metric": "interactions" if a.mode == "organic" else "active ad-days",
           "window": {"start": a.start, "end": a.end, "days": len(days)},
           "totals": {"posts": len(rows), "brands": len(by_brand), "m": T,
                      "platform_posts": {k: v["posts"] for k, v in platforms.items()}},
           "by_brand": by_brand, "daily": [{"date": k, **daily[k]} for k in days],
           "peak_days": peak_days, "peak_share": peak_share, "content_types": content_types,
           "platforms": platforms, "top_posts": top_posts, "focal": focal, "mentions": mentions}
    json.dump(out, open(a.out, "w"), indent=1, ensure_ascii=False)

    print(f"{out['metric']}: total {T:,} from {len(rows)} posts, {len(by_brand)} brands, {len(days)} days")
    for b in by_brand:
        print(f"  {b['brand']:<28} posts {b['posts']:>4}  {b['m']:>8,}  {b['share']:>5}%  per post {b['per_post']}")
    print(f"top {a.peaks} days = {peak_share}% :", ", ".join(f"{p['date']} ({p['m']:,})" for p in peak_days))
    for p in top_posts[:10]:
        print(f"  {p['m']:>7,} {p['d']} {p['b'][:18]:<18} {p['p']:<10} {p['tp'][:70]}")
    if focal:
        print(f"focal {focal['brand']}: rank {focal['rank']}, {focal['posts']} posts, {focal['share']}%")
    for k, v in mentions.items():
        print(f"mentions '{k}': {v['posts']} posts, {v['m']:,}, {v['by_brand']}")
    print(f"-> {a.out}")


if __name__ == "__main__":
    main()
