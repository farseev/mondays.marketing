# somin-landscape-report

The SOMIN Landscape Breakdown: one self-contained, clickable HTML page in SOMIN's portfolio-report
format, branded SOMIN. `SKILL.md` is the instruction set; `scripts/` runs the pipeline; `assets/` holds
the page template, chart colours, a worked scope file, a worked copy file and the expression examples
(all for a fictional "Example Toys" portfolio); `references/` holds the schema, writing, expressions,
research-provenance, filter, paid-mode, QA and run-lesson notes.

Quick run, from a directory holding `scope.json` and the harvested posts:

```bash
S=/path/to/somin-landscape-report/scripts
python3 $S/extract_posts.py --out posts.json --short "Long name=Short" raw_*.json
python3 $S/validate.py                                   # counts gate, must PASS
python3 $S/analyze.py posts.json --mode organic --start 2026-09-04 --end 2026-10-01 \
        --focal "Example Toys" --out analysis.json
# pull the SOMIN study, insight and proposition; write copy.json; render the expressions (if installed)
python3 $S/validate.py --copy copy.json                  # copy + research + image gate, must PASS
python3 $S/build_report.py --posts posts.json --copy copy.json --scope scope.json \
        --image asset-0=expr/P611-T-01.png --image asset-1=expr/P611-M-01.png \
        --out report.html
```

The fictional example files pass `validate.py --copy` and render through `build_report.py` with no page
errors. Concept images need the separate `somin-creative-expressions` skill; without it the report ships
without them and says so.
