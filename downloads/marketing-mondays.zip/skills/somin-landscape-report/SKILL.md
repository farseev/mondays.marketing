---
name: "somin-landscape-report"
description: Build an organic or paid competitive Landscape Breakdown as one self-contained, fully clickable HTML page from SOMIN workspaces, in the exact format of SOMIN's portfolio Landscape Breakdown and in the SOMIN brand. Two views - "The landscape" (overview with share-of-response bars and stats, 01 the activity timeline with annotated peaks, 02 the findings, 03 the brands, 04 the recommendation) and "What to make" (the suggestion, why this idea, example posts with SOMIN expressions, the creator brief) - plus a Sources & scope dialog with numbered SOMIN research citations. Use for "landscape report", "landscape breakdown", "landscape audit", "organic landscape", "competitor review", "the portfolio-style report", "share of voice dashboard", "what are competitors posting", "month in review of a workspace", or a read of one brand against its set. Always asks which workspaces the read covers and whether it is organic or paid before pulling anything.
---

# SOMIN landscape report

One page, two views, in the format of SOMIN's portfolio Landscape Breakdown, branded SOMIN
throughout.

- **The landscape** — Overview (scope line, headline, standfirst, share-of-response bars with a
  Response / Publishing volume switch, stats strip) → **01 The activity** (multi-brand line chart of
  daily response with numbered peak markers, publications-per-day bars, a highest-response card, three
  or four moment cards, exact chart values) → **02 The findings** (three numbered findings, each with a
  lead post, a takeaway, SOMIN research citations and supporting posts, optionally a SOMIN
  classification comparison) → **03 The brands** (a tab per brand: summary, publications / response /
  median, response by platform, "What to take forward", supporting posts, SOMIN classifications) →
  **04 The recommendation** (the direction, the brand connection, the selected SOMIN insight).
- **What to make** — the concept title and lead image → **01 The suggestion** (the idea and how it
  unfolds) → **02 Why this idea** (rationale, selected SOMIN insight, the findings it builds on,
  supporting research, propositions to develop, who it is for) → **03 Example posts** (SOMIN expression
  images with editable captions, copy and download) → **04 Creator brief** (copy or download as .txt).
- **Sources & scope** dialog — scope, metric coverage, how to read the figures, the per-brand
  completeness table, context sources, every SOMIN research record numbered [1]…[n] with its link,
  the generated images, evidence notes and post data downloads.

**Brand.** The chrome is fixed SOMIN (`somin-brand-guideline`): the SOMIN wordmark ("SO" teal + "MIN"
white on the dark masthead, ink in the footer), teal `#2DBF9C`, body-safe teal `#1F8A70` for links,
eyebrows and buttons, teal-black `#16201F`, white page, teal-tinted greys, Montserrat. Chart colours
come from `assets/theme_somin.json`: the focal brand `#1F8A70`, the rest on a teal-family ramp in
response order. Client brand colours never replace the chrome.

**Platform name.** The platform is **SOMIN** everywhere: "Based on SOMIN", "SOMIN persona", "Selected
SOMIN insight", "SOMIN post 683…", "SOMIN-generated concept image", "Open study in SOMIN", links to
`cloud.somin.ai`. The legacy platform name DEFY never appears; `validate.py` fails a copy file that says it, and the
template carries none.

The skill ships the plumbing; you supply the judgement. **Every number comes from a script, never from
your head. Every image comes from the expressions engine, never from a prompt you wrote. The idea comes
from a SOMIN insight, quoted, never from your own copywriting.**

## Ask first — two questions, always

Before any pull, ask with `AskUserQuestion`. Run `workspaces-list` first so the options are real names.

1. **Which workspaces should the read cover?** One workspace (name it); several merged into one
   landscape (posts deduped by id, the merge stated in `scope.relationship`); or "the largest", in
   which case compare `posts-aggregate` counts over the window and say which you picked and why.
2. **Organic or paid?** Organic reads `source: "PAGES"`, metric **recorded likes and comments**
   (`scope.metricFields` can add shares). Paid reads `source: "ADS_LIBRARY"`, metric **active ad-days**
   clipped to the window. Never pooled. See `references/paid-mode.md`.

Then confirm the rest or take the defaults: focal brand (the brand in the workspace name), window (the
28 days ending yesterday), filter (none). Give the one-line reading you took at the top of your reply.

## The run record

`scope.json` in the run directory (`assets/scope_example.json` is filled in; `scripts/cfg.py`
documents every field): workspaces, source, window, focal, aliases, metricFields, aggregate,
platformBase, expressions, thumbnails, output.

## Workflow

Keep a task list: ask → resolve → pull → gate → analyse → research → write → idea → expressions →
build → QA → publish.

### 1. Resolve scope
`workspaces-list` → ids. `profiles-list` per workspace → brands and profile ids. Give each brand one
short display name and put **every page of a brand under it** (`scope.aliases`). **Always pass `source`
and `profileIds`** to `posts-aggregate` and `posts-search`. Write the aggregate into `scope.aggregate`.

### 2. Pull every post
Read `references/filters.md`. `posts-search` objects are ~4k tokens each, so never page them through
your own context: delegate to 2–3 subagents (a group of profiles each, `pageSize` 50, `sortBy: "date"`,
page until a short page), point `scripts/extract_posts.py` at the saved files, reply with counts only.
Merge with `extract_posts.py --out posts.json --short "Long name=Short" …`. The extractor keeps the
four SOMIN classification dimensions the brand tabs read (`humanNeed`, `appealCategory`,
`contentTypes`, `emotions`), the source type, video URL, and which counters were not returned (`miss`) —
a missing like count stays missing, it is not a zero.

### 3. Gate
`python3 scripts/validate.py` must print **GATE PASS** (count and sums equal the aggregate, dates in the
window, focal present, no duplicate labels, no U+FFFD). Never analyse on a failing gate.

### 4. Analyse
`python3 scripts/analyze.py posts.json --mode organic|paid --start … --end … --focal "<short>" --out analysis.json`
(`--fields` matches `scope.metricFields`). Share by brand, the daily series, the peak days, top posts,
content types, platforms. For any other cut, write a short script over `posts.json`. Every figure in
the copy comes from a script output.

### 5. SOMIN research
Pull the workspace's study for the window with `studies-list` / `studies-get`: personas, tensions,
relevance themes. Pull insights with `stories-list`, angles and characters behind them, and the
proposition set with `propositions-list`. Each record you cite becomes one `research.sources[]` entry
with its real id, its own words in `text`, and `parents` naming what it was built from. Read
`references/brief-provenance.md`.

### 6. Write the story
Read `references/writing-guide.md`, then write `copy.json` against `references/copy-schema.md` and
`assets/example_copy.json`: headline and standfirst, the comparison title, the timeline paragraph,
three or four moments (each on the publication date of its post), three findings (title, body with the
figures, takeaway, a lead post and up to two supporting, research citations; one may carry a SOMIN
classification comparison the builder computes), one players note per brand (summary, "what to take
forward", three posts), the recommendation. Map every claim to its research sources in
`research.mappings`.

### 7. The idea is a SOMIN insight
`direction.insight` is the insight that explains the findings, quoted with its id; `direction.proposition`
is the SOMIN proposition that grounds it in the brand. The creative (title, suggestion, how it unfolds,
why, reasoning, brief) applies them. If no insight carries the direction, the direction is not earned.

### 8. Expressions, not hand-written prompts
Read `references/expressions.md`. Concepts from the selected insight and proposition → the
the `somin-creative-expressions` skill's `unlock.py emit-prompts` (a separate SOMIN add-on, if installed) → `check_prompts.py --write-manifest` must **PASS**
→ render each prompt with `SOMIN:image-generate` (1024x1536). One `creative.assets[]` entry per image
(awareness / consideration roles, caption, alt, intended use) and one `research.images[]` entry with
the prompt key, `prompt_source: "somin_expressions_engine"`, funnel stage and the generation reference.
If the engine is not installed or cannot run, the report ships without concept images and says so.

### 9. The creator brief
`creative.brief[]` (Idea, Audience, Content requirements) and `creative.execution[]`. Check whether
creator content exists (`profiles-list`, classify each profile); with creators present, take format and
audience lines from the somin-influencer-deck pipeline (separate SOMIN skill, if installed); without, say so in `coverageNotes`. Map the
brief to its sources under `creative:/brief`.

### 10. Gate the copy, then build
```
python3 scripts/validate.py --copy copy.json
python3 scripts/build_report.py --posts posts.json --copy copy.json --scope scope.json \
    --image asset-0=expr/P3551-T-01.png --image asset-1=expr/P3551-M-01.png \
    --thumb-top 150 --thumb-box 480 --thumb-q 70 --out <slug>.html
```
The builder computes every figure on the page (profiles, medians, coverage, platform splits,
classification counts, the daily series, comparison groups), maps brand names to ids, adds SOMIN links
to research records that lack one, embeds the concept images and thumbnails as data URIs, and writes
the one `report-data` block the template renders. Fix every WARNING it prints.

### 11. QA, then publish
Work through `references/qa.md`: render with Playwright at 1280px and 400px, both views and the
Sources & scope dialog, no page errors, no horizontal scroll; `grep -cw DEFY` the page (0). Then
load `artifact-design`, publish with the `Artifact` tool (icon `chart`), and deliver the file with
`SendUserFile`.

## Rules that keep the report honest

- **One channel per report.** Organic and paid are never pooled.
- **A page name is never a country.** Markets come from country workspaces and ad-level country codes.
- **Missing is not zero.** Uncounted fields stay unmeasured; medians use complete posts only, and the
  Sources & scope dialog prints the coverage.
- **Every claim opens its evidence.** Bars open the brand, peaks and moments open the post, findings
  open their posts and numbered SOMIN sources, the idea opens its insight and proposition, each image
  opens its creative basis.
- **SOMIN, not DEFY.** In copy, links, labels and file names.
- **Nothing is invented.** No number, persona, insight or image without a pull behind it.

## Files
- `scripts/cfg.py` — loads `scope.json`.
- `scripts/extract_posts.py` — raw `posts-search` output → compact records with classifications.
- `scripts/validate.py` — the gate: counts, window, labels, encoding, copy, research, images, manifest.
- `scripts/analyze.py` — every stated figure; organic and paid modes.
- `scripts/build_report.py` — posts + copy + images → one self-contained page.
- `assets/report_template.html` — the Landscape Breakdown page in SOMIN brand; renders from
  `report-data`. Never hand-edit numbers or copy into it.
- `assets/theme_somin.json` (chart colours), `assets/scope_example.json`, `assets/example_copy.json`
  (a fictional Example Toys run that fills every field), `assets/expr/` (worked expression inputs).
- `references/copy-schema.md`, `writing-guide.md`, `expressions.md`, `brief-provenance.md`,
  `filters.md`, `paid-mode.md`, `qa.md`, `run-lessons.md`.
