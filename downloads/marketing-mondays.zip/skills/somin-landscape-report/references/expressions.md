# Expressions and their creative basis

The engine ships in the separate `somin-creative-expressions` skill. If it is not installed, skip this
file: the report ships without concept images and says so in `coverageNotes`.

Every concept image in "What to make" is a **SOMIN expression**: its prompt is built by the encrypted
expressions engine from the selected SOMIN insight and proposition, it passes the provenance gate, and
the page lets a reader open its creative basis. An image without that basis does not go in the report.

## What the page shows for each image

- **03 Example posts** — the image, its role ("Awareness: the conversation", "Consideration: the
  craft"), format and funnel tag (TOFU / MOFU), the rationale, the intended use, an editable caption,
  copy and download.
- **Image & creative basis** (dialog) — "SOMIN-generated concept image · TOFU", the SOMIN concept it was
  built from, quoted in full with its reference, "Open proposition set in SOMIN", and the generation
  reference (the image-generate URL).
- **Sources & scope → Generated images** — every image listed with its basis.

## What you write for it

`creative.assets[i]` — role, rationale, caption, alt, format, requestedFormat.
`research.images[i]` — `asset_index`, `source_id` and `concept_id` (the SOMIN concept / proposition
record), `insight_id`, `prompt_key` (the manifest key, e.g. `P3551-T-01`), `prompt_source:
"somin_expressions_engine"`, `funnel`, `reference` (the URL image-generate returned), and the
proposition-set `url`. `validate.py` fails an asset without this entry, a prompt source other than the
engine, or a prompt key absent from the manifest.

Two images is the format: an awareness image (TOFU) and a consideration image (MOFU), both 2:3
portrait, both from the same insight and proposition.

## How to produce it

```
# 1. author the concepts file from the selected insight (one concept per image)
#    insights[] -> {pillar_id, pillar, persona:{name, theme_id}, concepts:[{type, subtype, hook, tagline}]}
python3 <somin-creative-expressions>/scripts/unlock.py emit-prompts \
  --concepts concepts.json --select all --brand brand.json --out _expr_prompts.json

# 2. gate it; PASS is required before any render
python3 <somin-creative-expressions>/scripts/check_prompts.py \
  --concepts concepts.json --prompts _expr_prompts.json \
  --write-manifest expressions_manifest.json

# 3. render each prompt with SOMIN image-generate (load it with ToolSearch first),
#    save as <key>.png, then re-run the gate with --images-dir to confirm the files
# 4. build, passing each image under its asset id
python3 scripts/build_report.py ... --image asset-0=expr/P3551-T-01.png --image asset-1=expr/P3551-M-01.png
```

Notes from a live run:
- The engine needs its key. `scripts/.enginekey` does not always survive a skill sync; set
  `EXPRESSIONS_KEY` in the environment instead.
- Hooks are capped at **7 words** (gate check C6). Keep the full line in `tagline`.
- Pass palette values **without** the leading `#`; the engine adds it.
- Colours, fonts and the brand name are the only brand tokens the template consumes.
- A medical render needs a safety clause appended to the prompt after the gate. Appending is allowed
  (the same way brand-locking appends); say so in that asset's `disclosure`, which prints under the image.
- The concept image keeps the client's brand look; the page around it stays SOMIN.
