# Resolving a vertical / filter

Default: no filter — every post from every profile in the workspace for the chosen source.

Apply the same filter to `posts-aggregate` (gate) and every `posts-search` call, and describe it in `meta.filterLabel` and the scope dialog.

| User says | Parameter |
|---|---|
| a platform ("Instagram only", "LinkedIn") | `platforms: ["INSTAGRAM"]` (organic: FACEBOOK, INSTAGRAM, INSTAGRAM_STORIES, TIKTOK, LINKEDIN, TELEGRAM; paid adds THREADS, MESSENGER, AD_NETWORK, GOOGLE_ADS) |
| a subset of brands | `profileIds: [...]` from `profiles-list` |
| a vertical / product line / theme ("urology", "sunscreen", "EV") | concept `filters`, e.g. `[{"key":"MAIN_PRODUCT","values":[...]}]` or `TOPIC_CATEGORY`, `INTERESTS`, `PRODUCT_TYPE`, `GOODS_SERVICES`. First call `concepts-search` in the workspace to see which values actually exist, and pick the ones that match. |
| an audience ("for surgeons", "Gen Z") | `AUDIENCES`, `PROFESSION`, `AGE_GROUP` filters |
| a language / market | `LANG`, `GEOGRAPHY_RECOGNITION`; or `--market <term>` in analyze.py for caption mentions |
| a label the team applied | `labels: [...]` |
| complex logic (A or (B and C)) | `advanced` tree (up to 5 levels) |

A different SOMIN workspace per vertical (e.g. "Urology", "ENT") is often cleaner than a concept filter — check `workspaces-list` first and offer it if the vertical has its own workspace.

Concept filters depend on SOMIN's classification; report how many posts the filter kept vs the unfiltered total, and spot-check 3–5 kept posts' topics before writing.
