# Paid mode (ADS_LIBRARY)

Ad-library records rarely carry likes/comments, so "interactions" would be near zero. Paid mode switches the metric (`scope.source: "paid"`; the builder sets `metric.fields` to `["adDays"]` and the label to "Active ad-days"):

- **Active ad-days** = for each ad, days from `postDate` to `endDate` (or the window end if still running), clipped to the window. It approximates sustained paid presence; it is not spend or reach. Say so in the scope dialog.
- Share bars and the stats strip show active ad-days. Write "ads" where the copy says posts.
- The activity chart plots each ad's ad-days on its launch date; the bars count launches. Moments are launch days that started the longest-running ads — describe what launched.
- Lessons draw on what the long-running ads have in common (an ad kept live for weeks is the advertiser's own performance signal), content-type mix, formats, offers (`PERKS_INCENTIVE` concept), and creative clickability (`click` field = SOMIN predicted ABOVE_AVERAGE probability).
- Before trusting the metric, inspect 3 raw ad records: confirm `endDate` is populated for stopped ads. If the workspace's ads carry real likes/comments, you may add them as a secondary figure, but keep ad-days as the headline metric.
- Google Ads records may lack dates or thumbnails; note gaps in scope.

- The brand tabs show no SOMIN classification cards in paid mode, and findings carry no monitor comparison; cite posts and research instead.
