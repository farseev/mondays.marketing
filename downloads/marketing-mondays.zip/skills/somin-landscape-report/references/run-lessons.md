# Lessons from live runs

Everything here cost time once. The fix is in the scripts; this is why it is there.

**Thumbnails blow the artifact limit.** A 4,126-post page with every thumbnail came out at 72 MB. The
limit is 16 MB. The builder embeds thumbnails only for the top `--thumb-top` posts plus every cited,
moment, brand-tab and focal-brand post; past roughly 2,000 posts use `--thumb-top 300 --thumb-box 320
--thumb-q 62`. Posts without an embedded thumbnail show "Source preview unavailable" and still open.

**Missing counters.** Instagram stories and some reels return no like count. A missing counter is not
a zero: the extractor records it in `miss`, the builder keeps it out of medians and prints the coverage
in Sources & scope. One portfolio read had like counts for 217 of 280 posts.

**Charset.** The template opens with `<meta charset="utf-8">`. Without it the page shows mojibake at
narrow widths, where the browser re-sniffs the encoding.

**DEFY leaking in.** The format came from a DEFY-branded page. SOMIN research records and copied
wording can still carry the old name. The gate fails a copy file that says DEFY; grep the built page
before publishing.

**U+FFFD.** One replacement character anywhere in the page and the artifact publisher rejects the file.
Strip it while extracting posts, and the gate checks again.

**Aggregate under-counting.** `posts-aggregate` without `profileIds` has been seen to return 187 where
the real count was 203. Always pass `source` and every profile id, to the aggregate and to the search.

**Harvest double counting.** When one read is assembled from two queries — a concept tree plus a
hashtag pass, or several workspaces merged — dedupe on the post id before counting. Overlap between
the two passes inflated one category from 41 to 67 posts before the dedupe went in.

**The expressions engine key.** `scripts/.enginekey` in the somin-creative-expressions skill (if installed) does not
always survive a skill sync. When `unlock.py` reports a missing key, ask the user for it and set
`EXPRESSIONS_KEY` in the environment; do not write it to a file in the run directory, and tell the user
to rotate it if it has passed through a transcript.

**The hook cap.** Gate check C6 rejects a hook over 7 words. Write the short hook and keep the full
line in `tagline`.

**Palette values for the engine.** Hex without the leading `#`. The engine adds it, and a value that
arrives with one comes back as `##095BC6`.

**image-generate 502.** It happens. Wait about a minute and retry the same prompt; nothing needs
rebuilding.

**A skill proposal only replaces SKILL.md.** Scripts, assets and references do not travel with it. When
a run improves a script or a template, hand over the packaged `.skill` archive as well, or the next run
picks up the old file and the instructions stop matching the code.
