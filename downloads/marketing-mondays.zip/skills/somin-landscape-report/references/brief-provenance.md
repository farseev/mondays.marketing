# The idea and the brief — where each one comes from

Two parts of "What to make" look like copywriting and are not. The idea applies a SOMIN insight through
a SOMIN proposition. The creator brief is traceable line by line. The page makes both checkable: every
block carries numbered SOMIN citations ("Based on SOMIN [9] [11]") that open the original wording.

## The idea is a SOMIN insight, quoted

- Read the workspace's insights with `stories-list` (and `studies-get` for the study behind them). The
  insight that explains the findings — whose persona and relevance themes the findings already cite —
  is the one. Put it in `direction.insight` with its id and its own words, and in `research.sources`
  as `insight-<id>`, with `parents` naming its character, angle and relevance theme.
- Read the proposition set with `propositions-list`. The proposition that connects the insight to the
  brand goes in `direction.proposition` (title, insightIntegration, productConnection, sampleTagline,
  consumerTakeaway) and in `research.sources` as `concept-<id>`.
- The page prints "Selected SOMIN insight [n]" under 04 The recommendation and under 02 Why this idea,
  and "The brand connection" from `productConnection`.
- If no insight carries the direction, the direction is not earned. Go back to the data.

## The research chain

Build `research.sources` in citation order, study first: study → personas → tension → relevance themes
→ character → angle → insight → product → concept. Each entry's `text` is the SOMIN record's own words,
title line first; `parents` link it to what it was built from, so a reader can walk from the idea back
to the study. `research.mappings` says which sources each block cites; the page prints those numbers.

## The brief

`creative.brief[]` holds Idea, Audience and Content requirements; `creative.execution[]` holds how it
unfolds. Map the brief to its sources under `creative:/brief` (and `creative:/brief/<i>` for a single
line). Rules:

- **Audience** comes from the SOMIN persona the idea targets — name it, quote what drives it.
- **Content requirements** take format and length from the landscape's own figures (what performed on
  which platform) and platform conventions; say plainly which is which.
- **Creator layer.** Check whether creator content exists: `profiles-list` on every workspace in scope,
  classify each profile (company page, association, publisher, individual creator). With creators
  present, run the somin-influencer-deck pipeline (a separate SOMIN skill, if installed) and take format and audience lines from it. Without,
  say so in `coverageNotes`, naming how many workspaces and profiles were checked.
- Never write a number into the brief that no script or SOMIN record produced.
