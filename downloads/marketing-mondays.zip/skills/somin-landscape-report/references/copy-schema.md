# copy.json schema

`copy.json` holds the words, the post ids each claim rests on and the SOMIN research records. Every
figure on the page (shares, medians, coverage, platform splits, classification counts, the daily series,
comparison groups) is computed by `build_report.py` from `posts.json`; never type a computed field here.
Plain text only, no markdown. Brands are named by their short name exactly as in `posts.json` `b`.
`../assets/example_copy.json` is a complete worked file (a fictional Example Toys portfolio run).

```
scope            {name, relationship}
                 name: "Example Toys portfolio". relationship: one sentence on how the brands relate
                 ("Four Example Toys accounts: the corporate brand and three of its franchises…").
                 Dates come from scope.json.
title            the headline (h1), one sentence a client could repeat
summary          the standfirst, 3–5 sentences, ending "The opportunity: …"
comparison       {title, body}   beside the share bars; title is the finding the bars show
timeline         {title, body}   01 The activity; body names the dated events behind the peaks
focal            the client's brand short name (must equal scope.focal)
focalReason      one line on why this brand is the focus
contextSources[] {title, url}    outside sources for the events named (press, the brand's own site)
coverageNotes    what the SOMIN studies cover, any creator-layer gap, any rejected study
studyWindow?     {start, end} of the SOMIN study, when it differs from the post window (used in links)
retrievedAt?     ISO timestamp of the pull; defaults to build time
metricFields?    overrides scope.metricFields; metricLabel? overrides the computed label

moments[]        3–4 {date, title, body, post_id}
                 date = the post's publication date; title = what happened, as a news line;
                 body = one line. The chart numbers them in this order.

findings[]       3 {id, title, body, takeaway, post_ids[], evidence[]}
                 title: the finding as a statement with its number ("Two Captain Nova posts gave
                 Example Toys 99% of its response"). body: 3–6 sentences with the figures and the medians compared.
                 takeaway: one sentence, printed as the pull line.
                 post_ids: lead post first, then up to two supporting.
                 evidence[]:
                   {kind: "research", source_ids: [research ids]}     printed as SOMIN tension/persona panels
                   {kind: "monitor", field, label, brand, platform?, measure?: "median", explanation}
                     field ∈ humanNeed | appealCategory | contentTypes | emotions;
                     the builder computes the "with label" vs "other classified posts" comparison.

players[]        one per brand {brand, summary, decision, posts: [{id, label, note}] ×3}
                 summary: what the brand is in this landscape. decision: "What to take forward".

recommendation   {title, body, productConnection, why}
                 title: 04 headline, the direction as an instruction. productConnection: the brand
                 fact from the SOMIN proposition. why: the evidence in two or three sentences.

direction        {insight: {id, text, summary}, proposition: {id, title, summary, insightIntegration,
                  productConnection, sampleTagline, consumerTakeaway}, source_ids: [insight id, concept id]}
                 the SOMIN insight and proposition, quoted from stories-list / propositions-list.

creative
  brand, title          the concept name, ≤ 6 words ("Who Keeps Him True")
  suggestion            01 The idea, one paragraph a producer could shoot from
  execution[]           4 {title, text}   "How it unfolds"
  why                   02 Why this idea, applying the insight through the proposition
  source_ids[]          post ids printed as chips under "Why this idea"
  finding_ids[]         the findings it builds on (printed as links back)
  reasoning[]           3 {label, text, post_ids}: "What the research shows", "Who it is for",
                        "Why this direction"
  propositions[]        {title, body, source_ids}   "Propositions to develop"
  moments[]?            {title, body, source_ids}   "Moments to use this idea"
  assets[]              one per concept image, in order:
                        {id: "asset-0", role: "Awareness: the conversation", rationale, caption, alt,
                         format: "2:3 portrait image", requestedFormat: "Instagram portrait image / Reel cover",
                         filename?, disclosure?}
                        the image file is passed as --image asset-0=<file>
  brief[]               {label, text} — Idea, Audience, Content requirements

research
  sources[]   {id, kind, record_id, text, parents[], post_ids[], finding_ids[], url?, url_kind?, url_label?}
              id: "<kind>-<record_id>" (study-2010, persona-10071, tension-10073, relevance-10072,
              character-402, angle-502, insight-611, product-93, concept-1211).
              text: the record's own words, title line first. parents: what it was built from.
              Order = citation numbers [1]…[n]; put the study first.
              Leave url out for study, persona, tension, relevance and insight: the builder links them
              to cloud.somin.ai. Give the proposition-set url yourself (url_kind "proposition_set").
  mappings    {"<view>:/<path>": [source ids]} — which sources each block cites. Paths the page reads:
              landscape:/title, landscape:/summary, landscape:/comparison, landscape:/timeline,
              landscape:/findings/<i>, landscape:/players, landscape:/recommendation,
              creative:/title, creative:/suggestion, creative:/why, creative:/execution,
              creative:/brief, creative:/brief/<i>, creative:/assets/<i>
  images[]    one per asset {asset_index, source_id, concept_id, insight_id, prompt_key,
              prompt_source: "somin_expressions_engine", funnel: TOFU|MOFU|BOFU,
              reference: the image-generate URL, url?, url_kind?}
```

Brand name → id, colours, coverage lines, `storageKey`, `sharing` and every number are filled by the
builder. A brand with no `players[]` entry still gets its tab, with figures only (the builder warns).
