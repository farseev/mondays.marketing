# Writing guide — the Landscape Breakdown voice

The format is SOMIN's portfolio Landscape Breakdown. It reads as a strategist's argument: every headline is a
finding, every finding has a number, every number opens the posts behind it, and every interpretation
cites the SOMIN record it rests on.

## Voice
- Short declarative sentences, present tense for findings, past tense for what happened in the window.
- Sentence case. No hype words ("unlock", "leverage", "game-changing"). No "X, not Y" constructions.
- Name people's roles, dates, formats and characters specifically ("two Nova Rangers designers riding
  a new theme-park attraction", not "behind-the-scenes content").
- Say "recorded likes and comments" (or the metric label) the first time; "response" after that.
- The platform is SOMIN: "SOMIN's Fandom Enthusiast persona", "SOMIN's relevance research says…".

## Section formulas

| Block | Formula | Example (fictional Example Toys run) |
|---|---|---|
| `title` | What the period belonged to, in one line. | "Example Toys' September belonged to what Captain Nova stands for, and the people behind him" |
| `summary` | Context (the events) → where the focal brand earned its response → what the audience responded to → "The opportunity: …" | ends "The opportunity: make Example Toys' teams the visible keepers of the characters fans love." |
| `comparison.title` | Who carries the volume; who carries the response. | "Franchise accounts carry the volume; Example Toys carries the moments of meaning" |
| `timeline.title` | Where response peaked, around what. | "Response peaked around Captain Nova" |
| `timeline.body` | The dated events, in order, and the one peak not tied to them. | |
| `moments[]` | title = the post as a news line; body = one line of what happened. | "Example Toys statement on Captain Nova" / "Example Toys says recent posts used Captain Nova's likeness without permission." |
| `findings[].title` | A statement carrying its number. | "Two Captain Nova posts gave Example Toys 99% of its response" |
| `findings[].body` | How many posts, the share, the median against the rest, the strongest example, what SOMIN's research reads into it. | "…a median of 143,490 against 77 for everything else." |
| `findings[].takeaway` | What the audience does or wants, in one sentence. | "Example Toys' audience turns up in force when the company acts as the guardian of what its characters mean." |
| `players[].summary` | The brand's role in this landscape and what drove its figures. | "The most consistent performer, with a high Instagram median built on an ongoing story…" |
| `players[].decision` | "What to take forward", ≤ 20 words. | "Serialised story keeps fans returning without depending on one event." |
| `recommendation.title` | The direction as an instruction. | "Make Example Toys' teams the visible keepers of the characters fans love" |
| `creative.title` | A name a team would use internally, ≤ 6 words. | "Who Keeps Him True" |
| `creative.suggestion` | The scene, the people, what happens, what the viewer gets. | |
| `creative.execution[]` | Four steps: invite → set up → show → hand back. | "Invite fans to bring their Captain Nova" |
| `assets[].caption` | Hook → what happened → an invitation to the audience. | "…Share your Captain Nova in the comments." |

## What makes the idea good
- **It comes from the findings.** `creative.why` and `finding_ids` name the findings it builds on.
- **It applies a SOMIN insight through a SOMIN proposition**, both quoted with ids in `direction`.
- **It fits the focal brand's real assets** — its people, products, formats and what already works in
  its everyday content.
- **Participation is built in** — the audience is invited to answer, share or bring something.
- **Repeatable** — a format that can run again, not a one-off ad.

## Claims discipline
- Every number traces to `analysis.json` or a script over `posts.json`. Whole % in prose; medians as the
  script prints them.
- "Most", "only", "almost all" must be literally true in the data.
- Don't infer reach, sales or sentiment; this data is recorded interactions (organic) or ad-days (paid).
- Say what the data can't show: missing counters, late-window posts with less time to accrue, global
  pages read as local.
- Regulated categories: no outcome or superiority claims in captions; consent and approval lines in the
  brief's content requirements.
