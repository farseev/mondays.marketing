# QA — what to check before publishing

**The gate.** `python3 scripts/validate.py --copy copy.json` prints GATE PASS: post count and metric
sums equal the aggregate, dates in the window, every cited post and research id exists, moments sit on
their post's date, the idea is a SOMIN insight, every concept image has an engine-rendered research
entry, the copy never says DEFY. Never build on a failing gate.

**The build.** `build_report.py` prints no WARNING: no unknown post ids, no moment outside the window,
no asset without an image, no failed thumbnail for a cited post, no brand without a players note
(or say why), the page under 16 MB.

**SOMIN, not the legacy name DEFY.** `grep -cw DEFY <page>.html` returns 0 (word match; embedded base64 can contain the letters). The masthead and footer carry the SOMIN
wordmark ("SO" teal, "MIN" white on dark / ink on light, joined, no tracking). Source links point at
`cloud.somin.ai`; labels read "Open study in SOMIN", "SOMIN post …", "SOMIN-generated concept image".

**Brand.** Teal family only. Focal brand `#1F8A70`; rivals on the teal ramp from `theme_somin.json`;
no red, orange or yellow anywhere, including chart lines.

**Channels.** One report is organic or paid. The metric label, the stats strip and the dialog's "How to
read the figures" agree.

**Numbers.** Re-read each number in `copy.json` against `analysis.json` and the page itself (the share
bars, the stats strip, the brand tabs and the finding comparisons are computed — the prose must match
them).

**Coverage.** Open Sources & scope: the coverage line, the completeness table and the missing-data note
are present when counters were not returned.

**Research.** Click three numbered citations; each opens the original SOMIN wording and its link. The
idea's insight and proposition open from "Selected SOMIN insight" and "Propositions to develop".

**Images.** Each concept image opens "Image & creative basis" with its SOMIN concept and generation
reference. No hand-written prompt.

**Render.** Playwright at 1280px and 400px: the landscape view, the What to make view and the Sources &
scope dialog. No page errors, no horizontal scroll, peak markers and axis labels readable, the brand
tabs switch, a moment card opens its post, captions copy and the brief downloads.

**Encoding.** No U+FFFD; the publish rejects a page carrying one.
