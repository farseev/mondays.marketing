---
name: insight-creation-brand
description: BRIEFING variant of insight-creation. Generates the creative DNA for a pillar — a named character, a strategic angle, and a finished insight story via SOMIN's persona-create_characters, theme-generate_angles, story-create — and EXPOSES the full Persona → Tension → Angle → Story chain WITH all IDs and the one-persona-maps-to-many-tensions layering, because the brand briefing shows the permutation engine and keeps the audit trail. Use when building the rigour-led cross-market briefing (somin-brand-deck). For the agency pitch (collapse to a single suppressed-ID statement) use insight-creation-agency (separate SOMIN skill, if installed). Depends on persona-tension-discovery and whitespace-analysis or trend-analysis. Run once per (persona, tension) pair.
---

# Insight Creation — Briefing variant (expose the chain)

Persona × Tension × Angle → Story. The creative seed for one pillar of a campaign. Call once per insight chain — typically 3 times in a briefing (one per editorial pillar).

## Briefing stance — expose the chain, keep the IDs

This variant feeds the **brand briefing** (`somin-brand-deck`), where the persona→tension→angle→story chain is shown to the client as the permutation engine. So:
- **Keep and surface every ID and the character name.** The chain trace (persona theme → character → tension theme → angle → story) appears on the engine/insight-chain slides and in the audit trail — it is the credibility argument, not an implementation detail.
- **Show the one-to-many layering.** One persona maps to many tensions, each tension to angles and a story. Across pillars, present the shared persona once and fan the tensions/angles/stories beneath it — never as a flat, disconnected list.
- Output the full chain exactly as the 4-step workflow returns it; do not collapse or suppress anything.

For the agency pitch (one suppressed-ID statement) use `insight-creation-agency` (separate SOMIN skill, if installed).

## When to use

- Persona + tension studies already exist
- User wants the creative seed: "what's our character", "what angle should we run", "turn this tension into a story"
- Building the strategic backbone for a campaign or pillar

## When NOT to use

- Studies don't exist → **persona-tension-discovery** first
- User hasn't chosen which tension → **whitespace-analysis** or **trend-analysis** first
- User wants finished ad copy → this skill produces the seed; copywriting is downstream
- User wants to test multiple angles in parallel → run this skill multiple times (one per angle type); don't merge them

## Required inputs

| Input | Source | Why |
|---|---|---|
| Persona theme ID | `persona` report theme from SOMIN study | Enrich character from this cluster |
| Tension theme ID | `tensions` report theme from SOMIN study | Anchor insight to this friction |
| Angle type | `psychological` / `sociological` / `economic` / `behavioural_economic` | Rhetorical framing |
| Workspace ID | If user wants moment-generation as follow-up | Scopes downstream |

If any of the first three are missing — **stop and ask**. These are the user's creative decisions, not the skill's.

## The 4-step workflow

### 1 — Create the character
```
SOMIN:persona-create_characters({personaIds: [<persona_theme_id>]})
```
Returns: `id`, `name` (e.g. "Riley Gearhart"), `description`, `traits`, `personaId`. Capture all of these; the character `id` is the input to Step 3.

**Reproducibility rule:** if the user has named a character in prior context, reuse the existing character ID. Do NOT regenerate — character generation has high variance and a re-run produces inconsistent downstream creative.

### 2 — Generate strategic angles for the tension
```
SOMIN:theme-generate_angles({themeIds: [<tension_theme_id>], angleTypes: [<angle_type>]})
```
Returns one or more angle objects per requested type. Each has: `id`, `name`, `description`, `themeId`, `angleType`.

**Selection rule:** if user requested a specific type, generate only that type. If exploring, generate all four — then STOP and let the user pick before Step 3.

See `references/angle-types.md` for when to pick each angle type.

### 3 — Create the story
```
SOMIN:story-create({
  characterId: <from Step 1>,
  angleId:     <from Step 2>
})
```
Returns: `id`, `name` ("Aina's Journey"), `summary` (the actual insight statement), `characterId`, `angleId`, plus engagement metrics and evidence post IDs.

### 4 — Return the chain
Output the full Persona → Tension → Angle → Story chain with all IDs preserved. See `references/output-template.md`.

## Reproducibility — the audit chain

A complete chain trace:
```
WORKSPACE: 1236
PERSONA: theme 10051 (Melodic Pathfinder) ← study 2005 (M04)
CHARACTER: id 401 (Aina Lim) ← persona 10051
TENSION: theme 10052 (Bridging Gap in Early Childhood Arts) ← study 2005
ANGLE: id 501 (Holistic development via the Multiple Intelligences theory) ← theme 10052, angleType=psychological
STORY: id 601 (Aina's Journey)
```

This trace is what proposition-creation, moment-generation, and content-brief-from-moment all consume.

## Multi-chain orchestration

For a 3-pillar editorial calendar (typical SOMIN deck), run insight-creation 3 times — one per (persona, tension) pair. Three separate orchestrations, three independent stories. Don't try to bundle in one call; the tools work one chain at a time.

## Common failure modes

| Failure | Cause | Fix |
|---|---|---|
| Character regenerated with different traits | Same persona ID re-run | Reuse cached character ID across the engagement |
| Story summary doesn't match tension | Wrong angle for the tension's emotional register | Re-run Step 2 with a different angle type |
| Empty `evidence` array | Source tension has no underlying posts | Tension wasn't viable; pick another |
| User wants "all 4 angles" | Confusion about workflow | Generate all 4 in Step 2 only; do NOT advance all 4 to Step 3 |

## Token discipline

- Capture IDs first, full text second. The IDs are what downstream skills need.
- Story `summary` is the most valuable field — paste only the summary into context, not the full SOMIN object.
- For 3-chain orchestration, write each chain's output to disk; pass file paths to proposition-creation.
