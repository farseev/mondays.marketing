# Output Template — Insight Chain

The full Persona → Tension → Angle → Story chain with audit IDs preserved.

## Structure

```
CHAIN <NN> · <PILLAR_NAME>:
  WORKSPACE: <id>
  PERSONA: theme <id> (<name>)
    ← from study <id> · <window>
    Summary: <short paraphrase>
  CHARACTER: id <id> (<name>)
    ← persona <id>
    Traits: <comma-separated>
    Description: <short paraphrase>
  TENSION: theme <id> (<name>)
    ← from study <id>
    Summary: <short paraphrase>
  ANGLE: id <id> (<name>)
    ← theme <id> · angleType <type>
    Description: <short paraphrase>
  STORY: id <id> (<name>)
    Summary: <THE INSIGHT STATEMENT — keep verbatim, this is the gold>
    Evidence engagement: <N>
    Evidence media: <N of total>
```

## Filled example — Example Academy Music chain

```
CHAIN 01 · MUSIC:
  WORKSPACE: 1236
  PERSONA: theme 10051 (Melodic Pathfinder)
    ← from study 2005 · M04 Apr 2026
    Summary: Deep passion for music + arts; aspirations around personal growth and creative expression.
  CHARACTER: id 401 (Aina Lim)
    ← persona 10051
    Traits: Curiosity, Self-expression, Discipline, Connection
    Description: 12-year-old Singapore student exploring piano + ballet; parent-driven enrolment but child-driven engagement.
  TENSION: theme 10052 (Bridging the Gap: Creating Engaging Early Childhood Development Programs)
    ← from study 2005
    Summary: Parents struggle to find arts programmes that build creativity AND discipline AND life skills holistically.
  ANGLE: id 501 (Holistic Development via Multiple Intelligences)
    ← theme 10052 · angleType psychological
    Description: Frame the offering as serving the child's whole self-concept — not just a skill, but the development of identity across intelligences.
  STORY: id 601 (Aina's Journey)
    Summary: Holistic growth flourishes where heart and art interlace.
    Evidence engagement: 120
    Evidence media: 6 of 49
```

## Why this format

- **Every ID preserved** = the audit chain runs back to source studies
- **One-line summaries** = enough context for downstream skills (proposition-creation, moment-generation) without paste-bombing the full SOMIN object
- **STORY summary verbatim** = the insight statement is the only field that must NOT be paraphrased; it's the campaign's anchor sentence
- **Evidence metrics** = signal of how grounded the story is; <2 evidence posts = weak story, worth flagging

## Multi-chain output

For 3-pillar SOMIN decks, output 3 chains stacked:
```
CHAIN 01 · MUSIC: ...
CHAIN 02 · QUIET WORK: ...
CHAIN 03 · MOTHERS: ...
```

Each chain is independent — different persona ID, different tension ID, different character, different story. The three are unified only by being in the same workspace and engagement.
