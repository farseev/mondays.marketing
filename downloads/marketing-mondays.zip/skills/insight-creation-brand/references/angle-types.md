# Strategic Angle Types

SOMIN's `theme-generate_angles` supports four angle types. Each is grounded in a different theoretical tradition and produces a different rhetorical framing of the same tension.

## psychological

**Tradition:** cognitive and emotional psychology — identity, self-concept, belonging, aspiration, fear, hope.

**When to use:**
- Self-expression tensions ("Who am I when I do X?")
- Belonging tensions ("Am I part of this tribe?")
- Aspiration tensions ("Who do I want to become?")
- Validation tensions ("Will this be seen?")
- Internal-state tensions (anxiety, hope, longing, pride)

**Example angle output:** "Holistic Development via Multiple Intelligences" applied to a music+ballet tension — frames the offering as serving the child's whole self-concept, not a single skill.

**Use when:** the tension is mostly about how the audience feels about themselves or wants to be seen.

## sociological

**Tradition:** group dynamics, status, culture, generation, in-group / out-group.

**When to use:**
- Status tensions ("Where do I rank?")
- Community / tribe tensions ("Do I belong to this group?")
- Generational tensions ("Boomers vs Gen Z framing")
- Cultural tensions ("What does this mean here, now?")
- Public-display tensions ("What signals does this send to others?")

**Example angle output:** "Cultural Custodianship" applied to a heritage tension — frames the audience as a custodian of a tradition, with implicit status from that role.

**Use when:** the tension is about the audience's relationship to a group, not their relationship to themselves.

## economic

**Tradition:** rational utility, value, cost, scarcity, ROI.

**When to use:**
- Price / access tensions
- Scarcity tensions ("Limited supply, limited time")
- ROI tensions ("Is this worth it?")
- Efficiency tensions ("Why am I paying for this when X is free?")
- Comparison tensions ("This vs that")

**Example angle output:** "Compounding Returns of Early Investment" applied to a parental-spending tension — frames the cost as an investment with measurable future yield.

**Use when:** the tension is mostly about value-for-money or scarcity.

## behavioural_economic

**Tradition:** cognitive biases, decision shortcuts, framing, anchoring, defaults.

**When to use:**
- Choice-overload tensions ("Too many options, can't decide")
- Decision-fatigue tensions
- Default-setting tensions ("What should the smart default be?")
- Anchoring tensions ("What's the right reference point?")
- Framing tensions (the same fact reads differently in different framings)

**Example angle output:** "Smart Default" applied to a class-selection tension — frames the offering as the default choice that eliminates evaluation overhead.

**Use when:** the tension is about how the audience makes a decision, not about how they feel.

## Decision flowchart

```
Is the tension primarily about the audience's INTERNAL STATE?
  YES → psychological
  NO  →
       Is it about the audience's RELATIONSHIP TO A GROUP?
         YES → sociological
         NO  →
              Is it about MONEY, ACCESS, or VALUE?
                YES → economic
                NO  → behavioural_economic
```

## Multiple-angle exploration

When the user wants to see options before deciding, run `theme-generate_angles` with `angleTypes: [psychological, sociological, economic, behavioural_economic]` to get one of each. Present all four. Let the user pick. Do NOT advance all four through story-create — that generates four parallel stories that all compete for the same campaign slot.

## Common pairings observed in real workspaces

| Tension type | Best angle type | Why |
|---|---|---|
| Recognition / validation | psychological | Internal state |
| Heritage / craft | sociological | Cultural custodianship |
| Practical knowledge gap | behavioural_economic | Decision shortcut |
| Premium access | economic + sociological | Value + status duality |
| Quiet work / discipline | psychological | Identity through effort |
| Mothers / unsung labour | psychological + sociological | Internal validation + visible recognition |
