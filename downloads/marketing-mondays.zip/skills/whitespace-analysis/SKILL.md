---
name: whitespace-analysis
description: Identify strategic whitespace by comparing tension studies across cohorts (audience demand, brand voice, competitor coverage) at a snapshot in time, producing a verdict per tension. Use whenever the user asks "where's the whitespace", "what can we own", "where are rivals not present", "what's contested vs open", "build the competitive landscape", "compare what audiences want vs what brands publish". Depends on persona-tension-discovery. Runs best with three cohort studies but works with two. Maps themes semantically across cohorts, computes share-of-voice per cohort, applies a 6-verdict rubric (WHITESPACE / CONTESTED / BLOCKED / AUDIENCE LEFT / PARTIAL / EMERGING). Snapshot only — for time-series use trend-analysis. CRITICAL when cohorts have very different sample sizes — use dual proportional charts, never shared % axes.
---

# Whitespace Analysis

Snapshot competitive landscape. Compares audience demand vs brand voice vs competitor coverage at one point in time; produces a 6-verdict map per tension.

## When to use

- "Where's the whitespace?"
- "What can we own?"
- "Where are rivals not present?"
- "What's contested vs open?"
- "Build me a competitive landscape"
- "Compare what audiences want vs what brands publish"

## When NOT to use

- Single cohort only → run **persona-tension-discovery** first to get more cohorts
- Time-series trend question → **trend-analysis**
- Turn whitespace into creative concept → produce whitespace first, then **insight-creation**
- Charts / slides → packaging concern outside this skill

## Required inputs

**Three cohort studies, same time window (FULL coverage mode — preferred):**
1. **Brand voice** — single brand profile only
2. **Competitor cohort** — competitor profiles only (any count — SOMIN handles 3–20+)
3. **Audience proxy** — a third cohort that represents the audience's voice. Typically pulled from a separate workspace of influencer/creator profiles filtered by audience concept (e.g. `AUDIENCES = "Car Lovers"`). See the worked lubricants pattern: brand+comp in workspace A, influencer panel in workspace B.

**Two-cohort fallback (PARTIAL coverage mode):** if no audience proxy is available, brand-vs-competitor still works but the analysis lacks the demand-side check. Note the limitation in output — without the audience cohort you can't distinguish AUDIENCE LEFT (brand abandoned demand) from BLOCKED (no demand exists). **In PARTIAL mode you may NOT emit a WHITESPACE verdict.** Whitespace is a claim that creators publish heavily toward a theme while the brand *category* does not — and you cannot evidence the first half without the audience-directed content cohort. The strongest verdict available in two-cohort mode is **POSSIBLE WHITESPACE — UNVERIFIED** (brand and competitors both LOW, audience-directed content unknown), which downstream skills must render as a hypothesis to test, never as confirmed open territory.

## The 6-verdict rubric

| Verdict | Audience | Brand | Competitor | Action |
|---|---|---|---|---|
| **WHITESPACE** | HIGH | LOW | LOW | Claim it |
| **AUDIENCE LEFT** | HIGH | LOW | MEDIUM/HIGH | Recover it (we abandoned demand) |
| **PARTIAL** | HIGH | MEDIUM | LOW/MEDIUM | Defensible, deepen |
| **CONTESTED** | HIGH | HIGH | HIGH | Differentiate hard or exit |
| **BLOCKED** | MEDIUM/HIGH | MEDIUM/HIGH | HIGH | Don't enter; competitors own it |
| **EMERGING** | LOW (rising) | LOW | LOW | Test bet; cheap to claim early |

Thresholds:
- HIGH = >20% of own-cohort share
- MEDIUM = 5–20%
- LOW = <5%

See `references/verdict-rules.md` for the full rubric with edge cases (tied share, missing cohorts, near-threshold values).

## Brand inactivity is NOT whitespace — the cardinal rule

A strand where the **brand alone** is absent is never whitespace. Whitespace requires two things at once: **(1)** audience-directed content (creators) is HIGH on the theme, AND **(2)** the brand *category* — the brand AND its competitors — is LOW. Only when creators are publishing heavily into a theme that no brand in the category serves is the territory genuinely open.

Reading brand-LOW on its own as "whitespace" is the single most common and most damaging error this skill exists to prevent:

- **Brand LOW + competitors MEDIUM/HIGH is never whitespace.** Depending on the audience signal it is CONTESTED, BLOCKED, or AUDIENCE LEFT — and the brand's absence may be a *deliberate strategic choice* (a space it tried and exited, a space off-brand for it, or a space with a permission problem), not an oversight to correct. The verdict must reflect that competitors are present; the action is "differentiate / recover / stay out," not "claim open ground."
- **Audience/creator LOW means there is no whitespace to claim, even if every brand is absent.** A theme nobody — creators or brands — publishes toward is an empty strand, not an opportunity. WHITESPACE requires the audience-directed content signal to be HIGH (or, for EMERGING, LOW-but-rising). A blank row is not a gap.
- **Absence is evidence of a content-supply gap, not of unmet demand.** Per the SOMIN measurement scope, a whitespace gap is a *content-supply* gap (creators publish, the category does not). Never upgrade it to "unmet audience demand."

Before emitting any WHITESPACE verdict, confirm on the record: creator/audience share HIGH **and** brand share LOW **and** competitor share LOW. If any of the three fails, it is not whitespace — pick the rubric verdict that matches the actual three-cohort shares.

## The workflow

### 1 — Retrieve cohort studies
```
SOMIN:studies-get({studyIds: [audience_id, brand_id, competitor_id], reportTypes: ["tensions"]})
```

### 2 — Align themes across cohorts (semantic, summary-based)
Same alignment principle as trend-analysis. See `references/alignment-rules.md` (shared with trend-analysis).

### 3 — Compute share-of-voice per cohort
For each aligned tension × each cohort: `sampleSize / totalSize` as %. Empty cells = 0%.

### 4 — Check sample-size proportionality — CRITICAL STEP
Before applying the rubric, check the ratio of cohort sample sizes:
- If `max(n) / min(n)` < 5 → safe to compare shares directly
- If ratio is 5–25 → use dual proportional charts in any visual, note the disparity in commentary
- If ratio is >25 → the small cohort's share is statistically unreliable; explicitly flag

See `references/sample-size-honesty.md` for the visual treatment rules that downstream skills (somin-brand-deck, or somin-agency-deck if installed) must follow.

### 5 — Apply the verdict rubric
For each tension, compare the three cohort shares against the rubric thresholds.

### 6 — Produce the verdict map
See `references/output-template.md` for the structured output consumed by insight-creation and somin-brand-deck (and somin-agency-deck, if installed).

## Worked example — Example Academy May 2026

Three-cohort setup:
- Audience demand: influencer panel filtered by Parents/Families segment (n≈150)
- Brand voice: Example Academy profile only (n=4) ← **tiny cohort, see sample-size rules**
- Competitor cohort: 4 ballet academies (n=200)

Verdicts produced:
- Music As Life Enrichment: WHITESPACE (audience medium, brand 0, competitor 1%)
- Mothers / Caregivers: PARTIAL → CLAIM (audience high, brand 0, competitor 12%)
- Quiet Work / Discipline: PARTIAL → CLAIM (cresting in trend data)
- Training Gap (commons): BLOCKED (audience high, brand 75%, competitor 49% — everyone runs it)

Visual treatment (see slide 12 in deck): two charts side-by-side, n=200 chart with 0–100 x-axis, n=4 chart with 0–4 x-axis. Never shared % axis.

## Common failure modes

- **False equivalence on visuals** — plotting "Example Academy 75% of 4 posts" next to "Competitor 49% of 200 posts" on a shared % axis. Same percentage, fundamentally different evidence. ALWAYS use dual proportional charts in visuals. See `references/sample-size-honesty.md`.
- **Missing cohort treated as zero** — if audience proxy doesn't exist, mark tensions as "audience: unknown", not "audience: 0%".
- **Alignment drift** — same tension classified differently between trend and whitespace analyses. Use the same alignment keys across both.
- **Brand-inactive strand mislabelled as whitespace** — colouring a theme as WHITESPACE because the *brand* is absent, while competitors are actually present (CONTESTED/BLOCKED) or while no creators publish toward it (empty strand). Whitespace needs creators HIGH **and** brand-category (brand + competitors) LOW; brand-LOW alone is often a deliberate strategic choice, not open ground. See "Brand inactivity is NOT whitespace" above. In two-cohort PARTIAL mode, downgrade to POSSIBLE WHITESPACE — UNVERIFIED.

## Token discipline

- Don't paste study JSON. Extract the matrix to a working file.
- The verdict computation is deterministic — can run as a script if needed (scripts/verdict_solver.py — not yet implemented; current version is reasoning-based).
