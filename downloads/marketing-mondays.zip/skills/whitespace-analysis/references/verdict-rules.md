# 6-Verdict Rubric — Full Rules

For each aligned tension across the 3 cohorts, classify into exactly one verdict.

## Thresholds

| Label | Share |
|---|---|
| HIGH | >20% of own-cohort total |
| MEDIUM | 5–20% |
| LOW | <5% |

## The 6 verdicts

### WHITESPACE — claim it
- Audience: HIGH (or MEDIUM with rising signal from trend-analysis)
- Brand: LOW
- Competitor: LOW

Best whitespace candidates are tensions where there is real audience demand (HIGH or rising) but nobody — neither the brand nor competitors — is serving it.

### AUDIENCE LEFT — recover it
- Audience: HIGH
- Brand: LOW
- Competitor: MEDIUM or HIGH

The brand walked away from demand. Competitors now serve it. Re-entry is possible but harder than fresh whitespace.

### PARTIAL — defensible, deepen
- Audience: HIGH
- Brand: MEDIUM
- Competitor: LOW or MEDIUM

The brand has some presence in a high-demand area where competitors aren't fully present. Deepen the position rather than spread thin elsewhere.

### CONTESTED — differentiate hard or exit
- Audience: HIGH
- Brand: HIGH
- Competitor: HIGH

Everyone is fighting for the same audience demand. Either find a sharply differentiated angle, or redirect budget elsewhere.

### BLOCKED — don't enter
- Audience: MEDIUM or HIGH
- Brand: MEDIUM or HIGH
- Competitor: HIGH

Competitors dominate. Even if the brand has some presence, the noise floor is too high to break through with marginal investment.

### EMERGING — test bet, cheap to claim
- Audience: LOW (but trend = RISING or EMERGING from trend-analysis)
- Brand: LOW
- Competitor: LOW

The conversation hasn't crystallised yet. Cheap to claim early; will resolve to WHITESPACE or CONTESTED as it matures.

## Edge cases

### Tied or near-threshold values
- Competitor at 21% (just over HIGH threshold) and brand at 19% (just under HIGH) → treat as CONTESTED, not BLOCKED. The marginal difference is noise.
- Audience and competitor both at 6% (just over MEDIUM) → classify cautiously; could be EMERGING if trend supports.

### Missing cohort
- No audience proxy → can only distinguish CONTESTED vs BLOCKED (where brand+comp both HIGH), or "potentially WHITESPACE" (where both LOW). Mark these as REQUIRES_AUDIENCE_VALIDATION.
- No brand cohort → not possible to analyse for this brand. Report which competitor owns each tension instead.

### Very small brand sample (n<10)
Brand share-of-voice numbers become unreliable. Don't trust "75% of 4 posts" as equivalent to "49% of 200 posts" in the verdict. Use the LOW threshold liberally for tiny-cohort brands; the absolute count (3 out of 4 posts vs 0 out of 4) carries more signal than the percentage.

See `references/sample-size-honesty.md` for the visualisation implications.

### Cultural / seasonal tensions
If a tension's audience share is HIGH but the time window includes a known cultural peak (e.g. Children's Day in a study covering October in Singapore), check whether the demand is structural or event-driven. Event-driven peaks shouldn't be classified WHITESPACE — they're SINGLE-SHOT opportunities.

## Combining with trend-analysis output

If both analyses run, the trend status reshuffles verdicts:
- WHITESPACE + trend RISING → strongest claim
- WHITESPACE + trend DECAYED → don't bother; demand is fading
- BLOCKED + trend FALLING → opportunity opening
- PARTIAL + trend RISING → urgent; lean in
- CONTESTED + trend RISING → market growing fast enough that even contested entry can pay off
- EMERGING (trend) + LOW everywhere (whitespace) → the canonical test-bet candidate

## Output rules

Every verdict must show its three cohort share values explicitly. Don't say "PARTIAL — claim Mothers"; say "PARTIAL (audience 38%, brand 0%, competitor 12% → claim Mothers before competitors expand)".
