# Theme Alignment Across Cohorts

Same principle as trend-analysis: theme IDs differ across studies even when the underlying tension is the same. Alignment is semantic, summary-based.

For the full alignment heuristics (when to merge, when to split, near-matches, single-appearance outliers), see the trend-analysis skill's `references/alignment-rules.md`. This file covers only the whitespace-specific cases.

## Whitespace-specific alignment

In trend-analysis you align the SAME cohort across DIFFERENT windows. In whitespace-analysis you align DIFFERENT cohorts at the SAME window. The semantic mapping is the same; the cohort framing differs.

## What "the same tension" means across cohorts

The audience cohort might title it "What Drivers Wish They Knew", the brand might title it "Maintenance Education", the competitor might title it "Care Tips". Different titles, same underlying tension: practical-knowledge gap in vehicle maintenance.

The mapping is valid when the underlying audience need or strategic concern is the same, even if the language differs.

## Allowed in whitespace mapping

- **A tension appearing in only 1 or 2 cohorts.** This is often the most important signal. A tension that audience demands but brand and competitors don't cover is by definition WHITESPACE.
- **Merging two themes within one cohort.** If the competitor study returns "Maintenance Education" and "Care Tips" as separate themes but their summaries describe the same friction, merge them and add up the sample sizes.

## Not allowed

- **Inventing a theme.** If a cohort study has no theme matching the underlying tension, that cohort's share is `0`, not an estimate.
- **Matching by title alone.** Titles are generative — they drift.
- **Matching a single brand voice item to a competitor cluster** without reading the summaries.

## Mapping audit trail

For every aligned tension, the output should show the source theme IDs from each cohort:

```
TENSION: Maintenance Knowledge Gap
  AUDIENCE: theme 10014 (study 2004), sampleSize 9/17 (53%)
  BRAND:    theme 10011 (study 2002), sampleSize 44/150 (29%)
  COMPETITOR: theme 10023 (study 2003), sampleSize 30/200 (15%)
  MAPPING_BASIS: All three summaries describe the same friction (drivers wanting trusted practical maintenance information; brands attempting to provide it; competitors doing limited coverage).
```

This trail is what makes the analysis reproducible.

## Worked example — Example Lubricants Q3 2026 mapping

| Underlying tension | Audience (2004) | Brand (2002) | Competitor (2003) |
|---|---|---|---|
| Excitement / Motorsport thrill | 10032 (18/40) | 10012 (35/150) | 10022 (111/200) |
| Maintenance / Reliability | — (absent) | 10011 (44/150) | 10023 (30/200) |
| Performance literacy | 10033 (4/40) | — (absent) | 10021 (53/200) |
| Personal Expression / Luxury | 10031 (11/40) | 10013 (6/150) | — (absent) |

The verdicts:
- Excitement → BLOCKED (everyone runs it heavy)
- Maintenance → AUDIENCE LEFT (brand+comp push it but audience doesn't engage)
- Performance literacy → PARTIAL → CLAIM (audience small but real; comp big; brand absent)
- Personal Expression → PARTIAL (audience moderate; brand small; comp absent)
