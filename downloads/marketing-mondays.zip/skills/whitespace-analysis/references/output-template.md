# Output Template — Whitespace Analysis

Canonical structured output consumed by insight-creation, somin-brand-deck, and the audit-trail slide.

## Top-level structure

```
WHITESPACE_ANALYSIS:
  market: <client or market name>
  window: <date range, e.g. "Last 90 days as of 2026-05-16">
  coverage_mode: full | partial | insufficient
  cohort_sample_sizes:
    audience:   <N>
    brand:      <N>
    competitor: <N>
  disparity_ratio: <max(n)/min(n) — flag if >5>
  source_studies:
    - {role: audience,   study_id: <N>, totalSize: <N>, profile_count: <N>}
    - {role: brand,      study_id: <N>, totalSize: <N>, profile_count: <N>}
    - {role: competitor, study_id: <N>, totalSize: <N>, profile_count: <N>}

  tensions:
    - name: <underlying tension name>
      verdict: WHITESPACE | CONTESTED | BLOCKED | AUDIENCE_LEFT | PARTIAL | EMERGING
      confidence: HIGH | MEDIUM | LOW
      audience:   {theme_id: <N>, theme_name: "<...>", sampleSize: <N>, share_pct: <X.X>}
      brand:      {theme_id: <N>, theme_name: "<...>", sampleSize: <N>, share_pct: <X.X>}
      competitor: {theme_id: <N>, theme_name: "<...>", sampleSize: <N>, share_pct: <X.X>}
      notes:
        - "<borderline calls, missing-data warnings, mapping merges>"
```

A missing cohort renders as `null` for the whole cohort object (Partial coverage mode):
```
audience: null   # the audience proxy study didn't exist
```

A missing **theme** within an existing cohort renders as `0`:
```
brand: {theme_id: null, sampleSize: 0, share_pct: 0.0}
```

## Filled example — Example Academy May 2026 (3-cohort, large disparity)

```
WHITESPACE_ANALYSIS:
  market: Example Arts Academy (workspace 1236)
  window: Last 90 days as of 2026-05-16
  coverage_mode: full
  cohort_sample_sizes:
    audience:   150   # influencer panel filtered AUDIENCES=Parents
    brand:      4     # Example Academy profile only
    competitor: 200   # 4 ballet academies
  disparity_ratio: 50  # ⚠ FLAG: brand cohort too small for direct % comparison
  source_studies:
    - {role: audience,   study_id: 2008, totalSize: 150, profile_count: 14}
    - {role: brand,      study_id: 2006, totalSize: 4,   profile_count: 1}
    - {role: competitor, study_id: 2007, totalSize: 200, profile_count: 4}

  tensions:
    - name: Training Gap (commons)
      verdict: BLOCKED
      confidence: HIGH
      audience:   {theme_id: 10065, theme_name: "Foundational training access", sampleSize: 88, share_pct: 58.7}
      brand:      {theme_id: 10061, theme_name: "Bridging Training",            sampleSize: 3,  share_pct: 75.0}
      competitor: {theme_id: 10062, theme_name: "Empowering Dancers",           sampleSize: 98, share_pct: 49.0}
      notes:
        - "Example Academy 75% is 3 of 4 posts — directionally meaningful but small sample"
        - "Everyone runs this; commoditised commons"

    - name: Mothers / Unsung Caregivers
      verdict: PARTIAL
      confidence: HIGH
      audience:   {theme_id: 10066, theme_name: "Parent recognition",  sampleSize: 38, share_pct: 25.3}
      brand:      {theme_id: null,  theme_name: null,                  sampleSize: 0,  share_pct: 0.0}
      competitor: {theme_id: 10063, theme_name: "Unsung Mothers",      sampleSize: 24, share_pct: 12.0}
      notes:
        - "Rising in trend analysis (38% M12); Example Academy entry recommended before competitors expand"

    - name: Music As Life Enrichment
      verdict: WHITESPACE
      confidence: HIGH
      audience:   {theme_id: 10067, theme_name: "Music in family life",  sampleSize: 22, share_pct: 14.7}
      brand:      {theme_id: null, sampleSize: 0, share_pct: 0.0}
      competitor: {theme_id: 10064, theme_name: "Music",                 sampleSize: 2,  share_pct: 1.0}
      notes:
        - "Only Example Academy has music programmes in cohort; competitors are ballet-only"
        - "Structural whitespace — claim immediately"
```

## Why this format

- **disparity_ratio** flags when downstream visualisations must use dual proportional charts
- **source_studies** + theme IDs = the audit trail
- **share_pct** alongside `sampleSize` = the auditable evidence number
- **confidence** + **notes** = the honesty layer; downstream skills must not hide low-confidence verdicts behind clean-looking outputs
- **null vs 0 distinction** preserves "we didn't measure" vs "we measured and got zero"
