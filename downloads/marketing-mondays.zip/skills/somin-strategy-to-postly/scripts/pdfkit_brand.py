#!/usr/bin/env python3
"""Shared helpers: brand-styled HTML pages rendered to PDF with Chromium (Playwright).

Chromium is used because it handles variable and custom brand fonts correctly.
Install if missing:  pip install playwright && playwright install chromium
"""
import html
import json
import os
import pathlib
import sys
import tempfile

REQUIRED_COLORS = ["primary", "paper", "ink", "tint", "muted", "line"]


def esc(s):
    return html.escape(str(s), quote=True)


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def furl(path):
    p = pathlib.Path(path)
    if not p.exists():
        raise SystemExit(f"Missing file: {path}. Customer documents use only files that exist (Figma exports, the client's logo). Do not substitute placeholders.")
    return p.resolve().as_uri()


def check_brand(b):
    missing = [k for k in REQUIRED_COLORS if k not in (b.get("colors") or {})]
    if missing:
        raise SystemExit("brand.json is missing colours: " + ", ".join(missing) +
                         ". Take them from the client's brand guideline; do not guess. If there is no guideline, ask for it.")
    if not b.get("logo"):
        raise SystemExit("brand.json has no logo path. Ask the client for the logo file.")
    if not b.get("source"):
        raise SystemExit("brand.json needs 'source': the brand guideline file the values came from.")
    if not b.get("name"):
        raise SystemExit("brand.json needs 'name'.")


CSS = """
@@FACES@@
@page{size:@@W@@mm @@H@@mm;margin:0}
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:#fff}
body{font-family:'@@BF@@',Arial,Helvetica,sans-serif;color:@@INK@@;font-size:11pt;line-height:1.5}
.page{width:@@W@@mm;height:@@H@@mm;padding:16mm 18mm 18mm;position:relative;overflow:hidden;
  break-after:page;page-break-after:always;background:@@PAPER@@}
.page:last-child{break-after:auto;page-break-after:auto}
h1,h2,h3,.kicker,.stat .v,th{font-family:'@@HF@@',Arial,Helvetica,sans-serif}
.kicker{font-size:8.5pt;letter-spacing:.14em;text-transform:uppercase;font-weight:700;color:@@PRIMARY@@;margin:0 0 3mm;max-width:@@TITLEW@@mm}
h1{font-size:25pt;line-height:1.12;font-weight:@@HW@@;margin:0 0 7mm;color:@@INK@@;max-width:@@TITLEW@@mm}
h2{font-size:13pt;font-weight:700;margin:0 0 2mm}
p{margin:0 0 4mm}.lead{font-size:13pt}.small{font-size:9pt;color:@@MUTED@@}
ul{margin:0 0 4mm;padding-left:5mm}li{margin-bottom:2mm}
.stats{display:flex;gap:6mm;margin:0 0 6mm}
.stat{flex:1;background:@@TINT@@;border-radius:3mm;padding:5mm}
.stat .v{font-size:26pt;font-weight:@@HW@@;color:@@PRIMARY@@;line-height:1}
.stat .l{font-size:9.5pt;margin-top:2mm}
table{border-collapse:collapse;width:100%;font-size:9pt;margin:0 0 4mm}
th{background:@@PRIMARY@@;color:#fff;text-align:left;padding:2mm 3mm}
td{padding:2mm 3mm;border-bottom:.3mm solid @@LINE@@;vertical-align:top}
.callout{background:@@PRIMARY@@;color:#fff;border-radius:3mm;padding:5mm 6mm;margin:0 0 5mm}
figure{margin:0 0 4mm}figure img{display:block;border-radius:2mm;max-width:100%}
figcaption{font-size:8.5pt;color:@@MUTED@@;margin-top:1.5mm}
.row{display:flex;gap:5mm;align-items:flex-start}.row figure{flex:1}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:8mm}
.pre{white-space:pre-wrap}
.logo{position:absolute;top:10mm;right:12mm;width:@@LW@@mm;height:@@LW@@mm;object-fit:contain}
.footer{position:absolute;left:18mm;right:18mm;bottom:8mm;font-size:8pt;color:@@MUTED@@;display:flex;justify-content:space-between}
.cover{background:@@PRIMARY@@;color:#fff;padding:22mm}
.cover h1{color:#fff;font-size:34pt}.cover .kicker{color:rgba(255,255,255,.85)}
.cover .small{color:rgba(255,255,255,.8)}
.chip{display:inline-block;background:#fff;border-radius:4mm;padding:@@CS@@mm;margin-bottom:16mm}
.chip img{display:block;width:@@LW2@@mm;height:@@LW2@@mm;object-fit:contain}
.post{display:flex;gap:6mm;padding:4mm 0;border-bottom:.3mm solid @@LINE@@}
.post img{width:50mm;height:62.5mm;object-fit:cover;border-radius:2mm;flex:none}
.post .d{flex:1}.post .meta{font-weight:700;margin-bottom:2mm}
.post .cap{white-space:pre-wrap;font-size:8.5pt;line-height:1.45}
.post .note{margin-top:2mm;font-size:8.5pt;background:@@TINT@@;border-radius:2mm;padding:1.5mm 2.5mm}
.opt{display:flex;gap:4mm;align-items:flex-start;margin:0 0 5mm}
.box{width:6mm;height:6mm;border:.5mm solid @@INK@@;border-radius:1mm;flex:none;margin-top:.5mm}
.sig{border-bottom:.3mm solid @@INK@@;height:12mm;margin-bottom:2mm}
.siglabel{font-size:8.5pt;color:@@MUTED@@;margin-bottom:6mm}
"""


def css(b, landscape=True):
    c = b["colors"]
    f = b.get("fonts") or {}
    hf = f.get("heading", "Helvetica Neue")
    bf = f.get("body", hf)
    faces = ""
    for role, fam in (("heading", hf), ("body", bf)):
        p = (f.get("files") or {}).get(role)
        if p:
            faces += f"@font-face{{font-family:'{fam}';src:url('{furl(p)}');font-weight:100 900;font-style:normal}}\n"
    w, h = (297, 210) if landscape else (210, 297)
    lw = float(b.get("logo_width_mm", 14))
    cs = float(b.get("logo_clear_space_ratio", 0.125)) * lw
    rep = {"FACES": faces, "W": w, "H": h, "PRIMARY": c["primary"], "PAPER": c["paper"], "INK": c["ink"],
           "TINT": c["tint"], "MUTED": c["muted"], "LINE": c["line"], "HF": hf, "BF": bf,
           "HW": int(f.get("heading_weight", 800)), "LW": lw, "LW2": lw * 2, "CS": cs,
           "TITLEW": (230 if landscape else 150)}
    out = CSS
    for k, v in rep.items():
        out = out.replace(f"@@{k}@@", str(v))
    return out


def page_html(inner, b, num, label="Page", cover=False):
    logo_src = furl(b["logo"])
    if cover:
        chip = f"<div class='chip'><img src='{logo_src}' alt=''></div>" if b.get("logo_on_chip", True) else f"<img src='{logo_src}' alt='' style='width:{float(b.get('logo_width_mm', 14)) * 2}mm;margin-bottom:16mm;display:block'>"
        return f"<section class='page cover'>{chip}{inner}</section>"
    foot = f"<div class='footer'><span>{esc(b['name'])}</span><span>{esc(label)} {num}</span></div>"
    return f"<section class='page'><img class='logo' src='{logo_src}' alt=''>{inner}{foot}</section>"


def render_blocks(blocks):
    out = []
    for blk in blocks:
        t = blk.get("type")
        if t == "paragraph":
            out.append(f"<p class='{esc(blk.get('style', ''))}'>{esc(blk['text'])}</p>")
        elif t == "bullets":
            out.append("<ul>" + "".join(f"<li>{esc(i)}</li>" for i in blk["items"]) + "</ul>")
        elif t == "stats":
            out.append("<div class='stats'>" + "".join(
                f"<div class='stat'><div class='v'>{esc(i['value'])}</div><div class='l'>{esc(i['label'])}</div></div>" for i in blk["items"]) + "</div>")
        elif t == "table":
            head = "".join(f"<th>{esc(h)}</th>" for h in blk["head"])
            rows = "".join("<tr>" + "".join(f"<td>{esc(c)}</td>" for c in r) + "</tr>" for r in blk["rows"])
            out.append(f"<table><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table>")
        elif t == "image":
            h = f"height:{blk['height_mm']}mm;width:auto;" if blk.get("height_mm") else ""
            cap = f"<figcaption>{esc(blk['caption'])}</figcaption>" if blk.get("caption") else ""
            out.append(f"<figure><img src='{furl(blk['path'])}' style='{h}' alt=''>{cap}</figure>")
        elif t == "image_row":
            h = f"height:{blk['height_mm']}mm;width:auto;" if blk.get("height_mm") else ""
            caps = blk.get("captions") or [""] * len(blk["paths"])
            figs = "".join(f"<figure><img src='{furl(p)}' style='{h}' alt=''>" + (f"<figcaption>{esc(c)}</figcaption>" if c else "") + "</figure>"
                           for p, c in zip(blk["paths"], caps))
            out.append(f"<div class='row'>{figs}</div>")
        elif t == "callout":
            out.append(f"<div class='callout'>{esc(blk['text'])}</div>")
        elif t == "columns":
            out.append("<div class='cols'>" + "".join(f"<div>{render_blocks(c)}</div>" for c in blk["cols"]) + "</div>")
        else:
            raise SystemExit(f"Unknown block type: {t}")
    return "".join(out)


def render_pdf(pages_html, b, out_pdf, landscape=True):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise SystemExit("Playwright is required: pip install playwright && playwright install chromium")
    doc = f"<!doctype html><html><head><meta charset='utf-8'><style>{css(b, landscape)}</style></head><body>{''.join(pages_html)}</body></html>"
    tmp = tempfile.mkdtemp(prefix="pdfkit_")
    hp = os.path.join(tmp, "doc.html")
    with open(hp, "w", encoding="utf-8") as f:
        f.write(doc)
    os.makedirs(os.path.dirname(os.path.abspath(out_pdf)), exist_ok=True)
    with sync_playwright() as p:
        br = p.chromium.launch()
        pg = br.new_page()
        pg.goto(pathlib.Path(hp).as_uri())
        pg.evaluate("document.fonts.ready.then(() => true)")
        pg.wait_for_timeout(300)
        n = pg.evaluate("document.querySelectorAll('.page').length")
        overflow = pg.evaluate("[...document.querySelectorAll('.page')].map((p,i)=>(p.scrollHeight>p.clientHeight+2||p.scrollWidth>p.clientWidth+2)?i+1:0).filter(Boolean)")
        pg.pdf(path=out_pdf, prefer_css_page_size=True, print_background=True)
        br.close()
    from pypdf import PdfReader
    real = len(PdfReader(out_pdf).pages)
    return n, real, overflow
