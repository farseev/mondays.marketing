#!/usr/bin/env python3
"""Customer approval document -> PDF (portrait, brand-styled).

  build_approval_pdf.py approval.json --brand brand.json --out approval.pdf [--per-page 3]

Build it from the verified Postly queue after scheduling. Technical IDs appear only in the final reference table.
"""
import argparse
import json
import sys
from collections import Counter
from datetime import date
from pdfkit_brand import check_brand, esc, furl, load_json, page_html, render_pdf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("approval")
    ap.add_argument("--brand", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--per-page", type=int, default=3)
    a = ap.parse_args()
    d, b = load_json(a.approval), load_json(a.brand)
    check_brand(b)
    posts = sorted(d["posts"], key=lambda p: (p["date"], p["time"], p["platform"]))
    if not posts:
        sys.exit("No posts to show.")
    tz = d.get("timezone", "")
    plat = Counter(p["platform"] for p in posts)
    def nice(iso):
        x = date.fromisoformat(iso)
        return f"{x.day} {x.strftime('%b')}"
    d0, d1 = date.fromisoformat(posts[0]["date"]), date.fromisoformat(posts[-1]["date"])
    stats = [{"value": str(len(posts)), "label": "posts scheduled"},
             {"value": str(len(plat)), "label": "platform" + ("s" if len(plat) != 1 else "") + ": " + ", ".join(plat)},
             {"value": f"{(d1 - d0).days + 1} days", "label": f"{nice(posts[0]['date'])} to {nice(posts[-1]['date'])} ({tz})"}]
    from pdfkit_brand import render_blocks
    deadline = f" Please reply by {esc(d['change_deadline'])}." if d.get("change_deadline") else ""
    contact = esc(d.get("contact", "your account contact"))
    summary = (f"<div class='kicker'>{esc(d.get('client', b['name']))} - {esc(d.get('campaign', 'Content'))}</div><h1>Content approval</h1>"
               + render_blocks([{"type": "stats", "items": stats}])
               + "<h2>What happens next</h2>"
               + f"<p>All {len(posts)} posts on the following pages are already scheduled and will publish automatically at the dates and times shown ({esc(tz)}), unless we change or pause them.</p>"
               + f"<p>To change, pause or remove a post, tell {contact} the post number.{deadline}</p>"
               + f"<p class='small'>Prepared {esc(d.get('prepared', ''))}. Captions and images are exactly as scheduled.</p>")
    pages = [page_html(summary, b, 1, label="Page")]
    n = 2
    for i in range(0, len(posts), a.per_page):
        chunk = posts[i:i + a.per_page]
        rows = ""
        for p in chunk:
            note = f"<div class='note'>{esc(p['note'])}</div>" if p.get("note") else ""
            rows += (f"<div class='post'><img src='{furl(p['image'])}' alt=''><div class='d'>"
                     f"<div class='meta'>Post {esc(p['n'])} - {esc(p['platform'])}{(' - ' + esc(p['account'])) if p.get('account') else ''}</div>"
                     f"<div class='small'>{esc(p['date'])} at {esc(p['time'])} ({esc(tz)})</div>"
                     f"<div class='cap'>{esc(p['caption'])}</div>{note}</div></div>")
        span = nice(chunk[0]["date"]) if chunk[0]["date"] == chunk[-1]["date"] else f"{nice(chunk[0]['date'])} to {nice(chunk[-1]['date'])}"
        inner = f"<div class='kicker'>Scheduled {span}</div>{rows}"
        pages.append(page_html(inner, b, n))
        n += 1
    if d.get("to_confirm"):
        inner = ("<div class='kicker'>Before approving</div><h1>Needs your confirmation</h1>"
                 "<p>These statements or events appear in the content. Please confirm each is accurate, or tell us to change it.</p>"
                 + render_blocks([{"type": "bullets", "items": d["to_confirm"]}]))
        pages.append(page_html(inner, b, n))
        n += 1
    sign = ("<div class='kicker'>Sign-off</div><h1>Your decision</h1>"
            "<div class='opt'><div class='box'></div><div>Approve all posts as shown</div></div>"
            "<div class='opt'><div class='box'></div><div>Approve with changes (list post numbers and changes below)</div></div>"
            "<div class='opt'><div class='box'></div><div>Do not approve</div></div>"
            "<div class='sig' style='height:30mm'></div><div class='siglabel'>Changes or comments</div>"
            "<div class='sig'></div><div class='siglabel'>Name</div><div class='sig'></div><div class='siglabel'>Date</div>"
            "<div class='sig'></div><div class='siglabel'>Signature</div>")
    pages.append(page_html(sign, b, n))
    n += 1
    per = 30
    ref_start = n
    for i in range(0, len(posts), per):
        rows = [[p["n"], p["platform"], f"{p['date']} {p['time']}", p.get("postly_id", ""), p.get("status", "scheduled")] for p in posts[i:i + per]]
        inner = ("<div class='kicker'>Reference</div><h2>Scheduling reference (for the team)</h2>"
                 + render_blocks([{"type": "table", "head": ["#", "Platform", "Publishes", "Scheduler ID", "Status"], "rows": rows}]))
        pages.append(page_html(inner, b, n))
        n += 1
    count, real, overflow = render_pdf(pages, b, a.out, landscape=False)
    with open(a.out + ".meta.json", "w", encoding="utf-8") as f:
        json.dump({"pages": real, "appendix_start": ref_start}, f)
    print(f"Wrote {a.out}: {real} pages, {len(posts)} posts")
    if overflow:
        sys.exit(f"Page(s) {overflow} overflow. Use --per-page 2 or shorten the notes.")
    if real != count:
        sys.exit(f"PDF has {real} pages but {count} were designed: content spilled over.")


if __name__ == "__main__":
    main()
