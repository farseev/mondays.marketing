#!/usr/bin/env python3
"""Deterministic guards for the strategy-to-Postly pipeline.

  plan_guard.py intake   intake.json   [--now ISO] [--out plan.json]
  plan_guard.py schedule schedule.json [--now ISO]

intake   : lists what must still be asked, computes calendar slots, caps the number
           of creatives at the calendar length, checks the first-post lead time.
           Exit 2 = required items missing (ask the user).
schedule : validates schedule.json before anything is sent to Postly.
           Exit 1 = errors (fix them). Warnings do not fail.
"""
import argparse
import json
import re
import sys
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

LEAD_HOURS = 3
LATEST_FIRST_HOUR = 21
MIN_CROSS_PLATFORM_GAP_DAYS = 7
CAPTION_LIMITS = {"x": 280, "instagram": 2200, "facebook": 63206, "linkedin": 3000,
                  "tiktok": 2200, "threads": 500}
DEFAULT_TIMES = {"facebook": "19:00", "instagram": "11:00", "x": "13:00",
                 "linkedin": "09:00", "tiktok": "19:00", "threads": "12:00"}


def norm(name):
    n = str(name).strip().lower()
    return {"twitter": "x", "x (twitter)": "x", "fb": "facebook", "ig": "instagram"}.get(n, n)


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def tz_of(name):
    try:
        return ZoneInfo(name)
    except Exception:
        sys.exit(f"Unknown timezone '{name}'. Use an IANA name such as Asia/Singapore.")


def now_in(tz, iso):
    if iso:
        d = datetime.fromisoformat(iso)
        return d if d.tzinfo else d.replace(tzinfo=tz)
    return datetime.now(tz)


def hhmm(s):
    h, m = s.split(":")
    return int(h), int(m)


def show(title, lines):
    if lines:
        print(f"\n{title}")
        for line in lines:
            print(f"  - {line}")


def cmd_intake(a):
    cfg = load(a.file)
    asks, decisions, notes = [], [], []

    def need(cond, msg):
        if not cond:
            asks.append(msg)

    need(cfg.get("client"), "Client name, and which SOMIN workspace holds their data")
    need(cfg.get("brand_guideline"), "The client's brand guideline (file or link). Customer-facing material cannot be made without it")
    an = cfg.get("analysis") or {}
    need(an.get("start") and an.get("end"), "Date of analysis: start and end of the window to analyse")
    cr = cfg.get("creatives_requested")
    need(isinstance(cr, int) and cr > 0, "Number of creatives to produce")
    cal = cfg.get("calendar") or {}
    need(cal.get("start") and cal.get("end"), "Content calendar start and end dates")
    need(cal.get("timezone"), "Timezone for posting times")
    plats = cal.get("platforms") or []
    need(plats, "Platforms for the content calendar")
    fg = cfg.get("figma") or {}
    need(fg.get("assets_url"), "Figma file with the client's finalized layouts and assets")
    templates = {norm(k): v for k, v in (fg.get("templates") or {}).items()}

    for p in plats:
        n = norm(p.get("name", ""))
        if not templates.get(n):
            asks.append(f"Figma template for {n} (frame link). Without it nothing can be built for {n}")
        if p.get("connected") is False:
            decisions.append(f"{n} is not connected in Postly: ask the user to connect it, or drop {n} from the calendar. Never schedule to it")
        elif p.get("connected") is None:
            notes.append(f"{n}: connection to Postly not checked yet. Run postly_list_social_accounts and record it")

    plan = {"ok": False}
    if cal.get("start") and cal.get("end") and cal.get("timezone") and plats:
        tz = tz_of(cal["timezone"])
        start, end = date.fromisoformat(cal["start"]), date.fromisoformat(cal["end"])
        days = (end - start).days + 1
        if days < 1:
            asks.append("Calendar end date is before the start date")
        else:
            slots = {norm(p["name"]): days * int(p.get("posts_per_day", 1)) for p in plats}
            total = sum(slots.values())
            unique_needed = max(slots.values())
            plan.update({"days": days, "slots": slots, "total_slots": total, "unique_needed": unique_needed})
            if isinstance(cr, int):
                produce = min(cr, total)
                plan["creatives_to_produce"] = produce
                if cr > total:
                    notes.append(f"{cr} creatives requested but the calendar holds {total} slots: produce {produce} only. Never produce more than the calendar can use")
                if produce < unique_needed:
                    decisions.append(f"Only {produce} creatives for up to {unique_needed} posts on one platform: reuse creatives (spaced 7+ days apart) or shorten the calendar?")
            now = now_in(tz, a.now)
            earliest = now + timedelta(hours=LEAD_HOURS)
            plan["now"] = now.isoformat()
            if start < now.date():
                asks.append(f"Calendar start {start} is already in the past (now is {now:%Y-%m-%d %H:%M} {cal['timezone']}). Which start date?")
            else:
                for p in plats:
                    n = norm(p["name"])
                    t = p.get("time") or DEFAULT_TIMES.get(n, "12:00")
                    h, m = hhmm(t)
                    first = datetime(start.year, start.month, start.day, h, m, tzinfo=tz)
                    if first < earliest:
                        cand = (earliest + timedelta(minutes=59)).replace(minute=0, second=0, microsecond=0)
                        if cand.date() == start and cand.hour <= LATEST_FIRST_HOUR:
                            notes.append(f"{n}: first post at {t} is under {LEAD_HOURS}h away. Use {cand:%H:%M} on {start} for post 1 only, then {t} daily (or ask)")
                        else:
                            decisions.append(f"{n}: no suitable slot left on {start} (need {LEAD_HOURS}h lead). Start {start + timedelta(days=1)} instead, keeping the end date (one fewer slot)?")
                    elif first - now < timedelta(hours=48):
                        notes.append(f"{n}: first post is under 48h away. The customer cannot review the approval PDF before it goes live; offer to move the start")
            plan["ok"] = not asks

    print(f"\nINTAKE CHECK - {cfg.get('client', '(no client)')}")
    show("ASK THE USER (stop until answered):", asks)
    show("DECISIONS FOR THE USER:", decisions)
    show("NOTES:", notes)
    if plan.get("days"):
        print(f"\nPLAN: {plan['days']} days | slots per platform {plan['slots']} | total {plan['total_slots']} | "
              f"creatives to produce {plan.get('creatives_to_produce', '?')}")
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump({"asks": asks, "decisions": decisions, "notes": notes, "plan": plan}, f, indent=2)
    sys.exit(2 if asks else 0)


def numbers_in(text):
    return set(re.findall(r"\d+(?:[.,]\d+)*", text))


def cmd_schedule(a):
    cfg = load(a.file)
    cal = cfg["calendar"]
    tz = tz_of(cfg.get("timezone") or cal.get("timezone", "UTC"))
    now = now_in(tz, a.now)
    start, end = date.fromisoformat(cal["start"]), date.fromisoformat(cal["end"])
    days = (end - start).days + 1
    ppd = {norm(p["name"]): int(p.get("posts_per_day", 1)) for p in cal["platforms"]}
    errors, warns = [], []
    posts = cfg["posts"]
    by = {}
    for p in posts:
        by.setdefault(norm(p["platform"]), []).append(p)

    for pl in by:
        if pl not in ppd:
            errors.append(f"{pl}: posts exist for a platform that is not in the calendar")
    for pl, n in ppd.items():
        exp, got = days * n, len(by.get(pl, []))
        if got > exp:
            errors.append(f"{pl}: {got} posts for {exp} calendar slots. Never exceed the calendar")
        elif got < exp:
            warns.append(f"{pl}: {got} posts for {exp} slots")

    allowed = cfg.get("allowed_figures")
    allowed_tokens = set()
    for f in allowed or []:
        allowed_tokens |= numbers_in(str(f))
    if allowed is None:
        warns.append("no allowed_figures list: numbers in captions cannot be checked against client sources")

    firsts, seen_slot = [], set()
    key_dates = {}
    for p in posts:
        pl = norm(p["platform"])
        d = date.fromisoformat(p["date"])
        h, m = hhmm(p["time"])
        dt = datetime(d.year, d.month, d.day, h, m, tzinfo=tz)
        firsts.append(dt)
        tag = f"#{p.get('n', '?')} {pl} {p['date']}"
        if not (start <= d <= end):
            errors.append(f"{tag}: outside the calendar {start}..{end}")
        slot = (pl, p["date"], p["time"])
        if slot in seen_slot:
            errors.append(f"{tag}: duplicate slot")
        seen_slot.add(slot)
        cap = p.get("caption", "")
        lim = CAPTION_LIMITS.get(pl)
        if lim and len(cap) > lim:
            errors.append(f"{tag}: caption is {len(cap)} characters, limit for {pl} is {lim}")
        if pl == "instagram" and cap.count("#") > 30:
            errors.append(f"{tag}: more than 30 hashtags")
        if not p.get("image"):
            errors.append(f"{tag}: no image")
        else:
            import os
            if not os.path.exists(p["image"]):
                errors.append(f"{tag}: image file not found: {p['image']}")
        if not p.get("creative_key"):
            errors.append(f"{tag}: no creative_key")
        else:
            key_dates.setdefault(p["creative_key"], []).append((pl, d))
        if re.search(r"\bweekly\b", cap, re.I) and ppd.get(pl, 1) >= 1 and days >= 7 and cfg.get("cadence", "daily") == "daily":
            warns.append(f"{tag}: caption says 'weekly' on a daily calendar")
        if allowed is not None:
            extra = sorted(numbers_in(cap) - allowed_tokens)
            if extra:
                warns.append(f"{tag}: figures not in allowed_figures: {', '.join(extra)}. Trace them to a client source or remove")

    for key, lst in key_dates.items():
        pls = [x[0] for x in lst]
        if len(pls) != len(set(pls)):
            errors.append(f"creative {key} repeats within one platform")
        for i in range(len(lst)):
            for j in range(i + 1, len(lst)):
                gap = abs((lst[i][1] - lst[j][1]).days)
                if gap < MIN_CROSS_PLATFORM_GAP_DAYS:
                    warns.append(f"creative {key} appears on {lst[i][0]} and {lst[j][0]} only {gap} day(s) apart (want {MIN_CROSS_PLATFORM_GAP_DAYS}+)")

    for pl, lst in by.items():
        times = sorted({p["time"] for p in lst})
        if len(times) > 1:
            warns.append(f"{pl}: posting times vary {times}. Fine only where a post needs a different slot")

    if firsts:
        lead = min(firsts) - now
        if lead < timedelta(hours=LEAD_HOURS):
            errors.append(f"first post is {lead.total_seconds() / 3600:.1f}h from now ({now:%Y-%m-%d %H:%M}); need at least {LEAD_HOURS}h")
        elif lead < timedelta(hours=48):
            warns.append(f"first post is {lead.total_seconds() / 3600:.0f}h away: the customer cannot review before it goes live")

    print(f"\nSCHEDULE CHECK - {len(posts)} posts, now {now:%Y-%m-%d %H:%M} {tz.key}")
    show("ERRORS (fix before scheduling):", errors)
    show("WARNINGS:", warns)
    if not errors:
        print("\nNo blocking errors. Show the plan table and wait for the user's go before scheduling.")
    sys.exit(1 if errors else 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    i = sub.add_parser("intake")
    i.add_argument("file")
    i.add_argument("--now")
    i.add_argument("--out")
    s = sub.add_parser("schedule")
    s.add_argument("file")
    s.add_argument("--now")
    a = ap.parse_args()
    {"intake": cmd_intake, "schedule": cmd_schedule}[a.cmd](a)


if __name__ == "__main__":
    main()
