#!/usr/bin/env python3
"""QA for customer PDFs.

  check_pdf.py file.pdf [--max-pages 10] [--appendix-from N]

- page count within the limit
- no technical identifiers (study/story/theme/cluster/angle/persona/moment/proposition/workspace IDs)
  on pages before the appendix (appendix start is read from <file>.meta.json or --appendix-from)
- no empty pages
Exit 1 on any failure.
"""
import argparse
import json
import os
import re
import sys
from pypdf import PdfReader

ID_RE = re.compile(r"\b(?:study|story|theme|cluster|angle|persona|character|moment|trigger|proposition|workspace)\s*(?:id\s*)?#?\s*\d{3,}\b", re.I)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--max-pages", type=int)
    ap.add_argument("--appendix-from", type=int)
    a = ap.parse_args()
    r = PdfReader(a.pdf)
    n = len(r.pages)
    errors, warns = [], []
    if a.max_pages and n > a.max_pages:
        errors.append(f"{n} pages exceeds the limit of {a.max_pages}")
    app = a.appendix_from
    meta = a.pdf + ".meta.json"
    if app is None and os.path.exists(meta):
        app = json.load(open(meta)).get("appendix_start")
    for i, pg in enumerate(r.pages, 1):
        text = pg.extract_text() or ""
        if len(text.strip()) < 15:
            warns.append(f"page {i}: almost no extractable text")
        if app is not None and i < app:
            hits = ID_RE.findall(text)
            if hits:
                errors.append(f"page {i}: technical identifiers before the appendix: {sorted(set(h.strip() for h in hits))[:4]}")
    if app is None:
        warns.append("appendix start unknown: technical-ID check skipped (pass --appendix-from N for reports)")
    print(f"{a.pdf}: {n} pages; appendix from page {app}")
    for w in warns:
        print("WARNING:", w)
    for e in errors:
        print("ERROR:", e)
    if errors:
        sys.exit(1)
    print("PASS")


if __name__ == "__main__":
    main()
