#!/usr/bin/env python3
"""Customer strategy report -> PDF, brand-styled, hard page limit.

  build_report_pdf.py report.json --brand brand.json --out report.pdf [--max-pages 10]

Page 1 is the cover. Body pages come next, then appendix pages (technical detail).
The appendix counts inside the page limit. Overflowing pages are an error.
"""
import argparse
import json
import sys
from pdfkit_brand import check_brand, esc, load_json, page_html, render_blocks, render_pdf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("report")
    ap.add_argument("--brand", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-pages", type=int, default=10)
    a = ap.parse_args()
    rep, b = load_json(a.report), load_json(a.brand)
    check_brand(b)
    body, app = rep.get("pages", []), rep.get("appendix_pages", [])
    total = 1 + len(body) + len(app)
    if total > a.max_pages:
        sys.exit(f"Report would be {total} pages (cover + {len(body)} body + {len(app)} appendix); the limit is {a.max_pages}. "
                 "Cut or merge pages. Extra technical detail goes in a separate file, not the report.")
    if not app:
        print("WARNING: no appendix_pages. Technical details (sources, IDs, definitions, caveats) belong in an appendix.")
    pages = []
    cover = (f"<div class='kicker'>{esc(rep.get('client', b['name']))}</div><h1>{esc(rep['title'])}</h1>"
             f"<p class='lead'>{esc(rep.get('subtitle', ''))}</p><p class='small'>{esc(rep.get('date', ''))}</p>")
    pages.append(page_html(cover, b, 1, cover=True))
    n = 2
    for pg in body:
        inner = f"<div class='kicker'>{esc(pg.get('kicker', ''))}</div><h1>{esc(pg['title'])}</h1>" + render_blocks(pg.get("blocks", []))
        pages.append(page_html(inner, b, n))
        n += 1
    appendix_start = n if app else None
    for pg in app:
        inner = f"<div class='kicker'>Appendix</div><h1>{esc(pg['title'])}</h1>" + render_blocks(pg.get("blocks", []))
        pages.append(page_html(inner, b, n))
        n += 1
    count, real, overflow = render_pdf(pages, b, a.out, landscape=True)
    meta = {"pages": real, "appendix_start": appendix_start, "max_pages": a.max_pages}
    with open(a.out + ".meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f)
    print(f"Wrote {a.out}: {real} pages (limit {a.max_pages}), appendix starts on page {appendix_start}")
    if overflow:
        sys.exit(f"Page(s) {overflow} overflow their area. Cut words or move content to a page with room; do not shrink the type.")
    if real != count:
        sys.exit(f"PDF has {real} pages but {count} were designed: content spilled onto extra pages.")
    if real > a.max_pages:
        sys.exit(f"{real} pages exceeds the {a.max_pages}-page limit.")


if __name__ == "__main__":
    main()
