# Building creatives in Figma (no generated imagery)

Everything visual comes from nodes that already exist in the client's Figma. If it is not there, ask.

## 1. Audit (read-only)

Record in `figma_inventory.json`: logo variants (and the guideline's size/clear-space/background rules), product photos, people photos, icons, backgrounds, the template frame for each network (name, node ID, width x height, text layer names, the image slot), the font families in use, and any finalized layouts to use as the style reference.

```js
// read-only inventory of frames on the current page
const pg = figma.currentPage;
return pg.findAll(n => n.type === 'FRAME' || n.type === 'COMPONENT').slice(0, 300).map(n => ({
  id: n.id, name: n.name, w: Math.round(n.width), h: Math.round(n.height), parent: n.parent && n.parent.name,
  hasImage: 'fills' in n && Array.isArray(n.fills) && n.fills.some(f => f.type === 'IMAGE'),
  texts: n.findAllWithCriteria({ types: ['TEXT'] }).map(t => t.name + ': ' + t.characters.slice(0, 30))
}));
```
Take a screenshot (`get_screenshot`) of each template and a few finalized layouts so you see the real look.

## 2. Ask for what is missing

Write the message with specifics: "No Instagram template frame found. Needed for creatives 1-12. Please add one or point me to it." Same for missing product or people photos, icons and logo variants. Do not proceed for that platform or concept until answered.

## 3. Brief per creative (`creatives.json`)

`{key, platform, template_node, pillar, funnel, headline, support, cta, assets:[node ids], sources:[where each claim comes from], needs_confirmation:[...]}`.

Copy comes from the strategy; facts come only from client-provided sources. Anything that has no source is not written. Match the cadence in copy to the calendar (do not write "weekly" for a daily calendar).

## 4. Build (verify on one frame before doing the rest)

Duplicate the platform's template, fill its text layers, reuse an existing image fill. Patterns (check each on a single frame first; adapt layer names to the template):

```js
const tpl = await figma.getNodeByIdAsync('TEMPLATE_ID');
const section = await figma.getNodeByIdAsync('SECTION_ID');
const f = tpl.clone(); section.appendChild(f);
f.name = 'R1-001_KEY_PILLAR_FUNNEL_FB-1080x1350';  // naming per SKILL.md Stages 3 and 5
// load every font used by the text layers before editing
for (const t of f.findAllWithCriteria({ types: ['TEXT'] })) {
  for (const fn of t.getRangeAllFontNames(0, Math.max(1, t.characters.length))) await figma.loadFontAsync(fn);
}
f.findOne(n => n.type === 'TEXT' && n.name === 'HEADLINE').characters = 'Headline text';
const src = await figma.getNodeByIdAsync('ASSET_NODE_ID');        // an existing node with the photo
const slot = f.findOne(n => n.name === 'VISUALS');
slot.fills = src.fills;                                            // reuses the same image; nothing is uploaded
```

Rules while building:
- Do not resize a template frame. Do not edit, move or delete originals.
- Do not add or redraw a logo. The template's logo placement stands; follow the guideline's logo rules.
- Do not use `upload_assets` for outside images. If the client has new assets, they must be added to the Figma and the audit repeated.
- Check text fit after setting text (`t.height` against the area it must stay in). Shorten the copy before shrinking type below the template's minimum.
- Leave no placeholder text (HEADLINE, LOGO, CTA) in any frame.

## 5. Name, place, verify

- Put new frames in a new section named for the campaign. One frame per creative, named per SKILL.md: candidates `R<N>-<NNN>_<key>_<pillar>_<funnel>_<NETWORK>-<WxH>`, finals `NNN_TOP-PERFORMER_<score>_<key>_<pillar>_<funnel>_<NETWORK>-<WxH>`.
- Programmatic check: frame count equals the plan, names unique, every image slot has an image fill, no placeholder text.
- Screenshot every frame (or a contact sheet) and look at it: text fit, logo clear space, no cropped product.
- Write the node ID of each frame into `creatives.json`.

## 6. Export

`get_screenshot` for a frame node with `maxDimension` equal to the frame's longer side returns a short-lived PNG URL. Download it right away for the PDFs and the approval document; pass the URL straight to Postly or SOMIN when scheduling or uploading.

## Environment notes
- `use_figma` needs the `figma-use` guidance loaded first (`get_figma_skill`).
- Fonts must be loaded before changing `characters`.
- Upload URLs from `upload_assets` expire in about 10 minutes (not used in this pipeline).
