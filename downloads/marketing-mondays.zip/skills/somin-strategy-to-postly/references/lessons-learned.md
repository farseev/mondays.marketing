# Lessons from the first run (each one is now a rule)

- **Generated images invented facts**: prices, percentages, customer counts, star ratings, stray concept numbers; 32 of 108 had to be re-rendered, and one still carried an illustrative chart. Generated people, scenes and products also carry copyright and likeness risk. -> Rule 1 and rule 3: only Figma elements; ask when something is missing.
- **Concepts assumed assets that did not exist** (people, scenes, a video and carousel calendar when only static layouts existed). -> Audit Figma first (Stage 1); build the calendar only from formats that exist.
- **SOMIN scoring never started in 36+ minutes.** Waiting blocked the pipeline. -> Rule 4 and Stage 4: one hour per round, report the delay, then build another round or ask; never silently continue unscored.
- **Date arithmetic was wrong**: a "30 Sep to 27 Oct, exactly 30 posts" request is 28 days; the sandbox clock was UTC while the client was UTC+8, so "today" was misjudged. -> Day count back to the user; "now" in the client's timezone; `plan_guard.py`.
- **Caption said "weekly" on a daily calendar.** -> Copy follows calendar cadence; `plan_guard.py schedule` warns.
- **Platforms assumed connected**: only one of three was. -> Check Postly yourself; schedule only connected accounts; ask about the rest.
- **Strategy QA found overclaims**: a bet labelled whitespace that creators did not publish, trend labels chosen by eye, audience described as people, a technical-ID leak. -> `strategy-quality.md`; `check_pdf.py` for IDs before the appendix.
- **Postly media import is asynchronous**: 202 first, 200 on the repeat, and occasional 504s, with `post_mutated: false`. -> Repeat the identical call; ledger after each post; verify against the queue.
- **Scheduling came before approval**, so the customer may not see a post before it goes live. -> Say it in the approval PDF; warn when the first post is under 48 hours away.
- **A turn can end mid-run.** Keep a ledger and `intake.json`; "continue" resumes from them.
- **Variable fonts break simple PDF libraries.** -> PDFs are rendered with Chromium (`scripts/pdfkit_brand.py`).
- **Shell gotcha**: the sandbox shell does not expand `{a,b}` in `mkdir`; use separate paths.
