# Customer PDFs

Both PDFs are customer-facing, so both follow the client's brand guideline (rule 6) and use only images exported from the client's Figma frames.

## brand.json (from the guideline; do not guess)

```json
{
  "name": "Example Client",
  "source": "Example_Brand_Manual.pdf",
  "colors": {"primary": "#0D589A", "paper": "#FFFDFE", "ink": "#0D2A45", "tint": "#E6EEF6", "muted": "#6B7A8C", "line": "#C9D6E3"},
  "fonts": {"heading": "Montserrat", "body": "Montserrat", "heading_weight": 800,
            "files": {"heading": "/path/Montserrat.ttf", "body": "/path/Montserrat.ttf"}},
  "logo": "/path/logo.png",
  "logo_width_mm": 14,
  "logo_clear_space_ratio": 0.125,
  "logo_on_chip": true
}
```
Colours, fonts, logo, minimum size and clear space come from the guideline. `source` names the guideline file. The scripts refuse to run without colours, logo and source. If the guideline forbids certain logo backgrounds or sizes, set the values to respect that (for example `logo_on_chip` for a logo that must sit on white). Font files are optional; without them the PDF uses the installed font of that name, else a neutral sans.

## Strategy report (max 10 pages including the appendix)

Plain language. One idea per page. Lead with the answer. The body must not contain study, theme, story, cluster, angle or persona IDs, tool names or SOMIN jargon; those belong in the appendix.

| Page | Content |
|---|---|
| 1 | Cover |
| 2 | The answer: headline finding, three numbers, the recommendation |
| 3 | Who the content is for (audience, creator panel in one line) |
| 4 | How competitors perform (one chart or table) |
| 5 | Where the space is open (verdicts in plain words) |
| 6 | What is changing over time |
| 7 | The strategy: pillars and why |
| 8 | Creative direction: sample creatives from Figma |
| 9 | Calendar overview, what we need from you |
| 10 | Appendix: sources, definitions, caveats, IDs |

Fewer pages is fine; more is not. Plain-word verdicts: WHITESPACE = "open space nobody serves", CONTESTED = "crowded", BLOCKED = "owned by one competitor", AUDIENCE LEFT = "others serve it, you do not", EMERGING = "early signal, not yet proven", PARTIAL = "covered in some channels only". Keep the original labels in the appendix.

Anything you could not verify goes in a "What we still need from you" box on page 9, and in the appendix as a caveat.

### report.json

```json
{"title": "...", "subtitle": "...", "client": "...", "date": "...",
 "pages": [{"kicker": "The answer", "title": "...", "blocks": [
    {"type": "paragraph", "text": "...", "style": "lead"},
    {"type": "stats", "items": [{"value": "3x", "label": "..."}]},
    {"type": "bullets", "items": ["...", "..."]},
    {"type": "table", "head": ["A", "B"], "rows": [["..", ".."]]},
    {"type": "image", "path": "/path/frame.png", "caption": "...", "height_mm": 90},
    {"type": "image_row", "paths": ["a.png", "b.png"], "captions": ["", ""], "height_mm": 70},
    {"type": "callout", "text": "..."},
    {"type": "columns", "cols": [[{"type": "paragraph", "text": "..."}], [{"type": "bullets", "items": ["..."]}]]}
 ]}],
 "appendix_pages": [{"title": "Appendix: technical details", "blocks": [ ... ]}]}
```
`python scripts/build_report_pdf.py report.json --brand brand.json --out outputs/report.pdf [--max-pages 10]` then `python scripts/check_pdf.py outputs/report.pdf --max-pages 10`. If the build says a page overflows, cut words or split the content onto a page you have spare; do not shrink type. Overflow technical detail goes to `outputs/technical_detail.json` or `.csv`, delivered separately.

## Approval document

Built after scheduling, from the verified Postly queue. Sections: cover and summary (counts, platforms, dates, timezone, status), what happens next (already scheduled, publishes automatically unless changed, how to request a change or pause, until when), one entry per post (image, date, time, platform, full caption exactly as scheduled), items needing client confirmation, sign-off page (approve all / approve with changes / do not approve, name, date, signature), and a reference table with Postly IDs.

`approval.json`:
```json
{"client": "...", "campaign": "...", "prepared": "...", "timezone": "Asia/Singapore",
 "contact": "name and email for changes", "change_deadline": "...",
 "to_confirm": ["claim or event that needs the client's confirmation"],
 "posts": [{"n": 1, "date": "2026-09-30", "time": "19:00", "platform": "Facebook", "account": "Page name",
            "image": "/path/frame.png", "caption": "...", "postly_id": "...", "status": "scheduled", "note": ""}]}
```
`python scripts/build_approval_pdf.py approval.json --brand brand.json --out outputs/approval.pdf [--per-page 3]`.

State only what is true: "scheduled" means accepted by Postly. Do not write "published".
