# Strategy stage: quality rules

Run the analysis steps of `somin-brand-deck`; these rules sit on top. Each one comes from a defect the QA gate found in a first run.

## Derive, do not assert
- **Whitespace verdicts follow the rubric mechanically.** Compute each strand's share within its own cohort (creators, brand, competitors) and classify HIGH (>20%), MEDIUM (5-20%), LOW (<5%). WHITESPACE needs creators HIGH with brand and competitors LOW. Otherwise use the nearest rubric row (CONTESTED, BLOCKED, AUDIENCE LEFT, EMERGING, PARTIAL). A strand with no signal in any cohort gets no verdict. Brand inactivity alone is not whitespace.
- **Trend statuses are computed** from the monthly series (mean share and coefficient of variation; one-window spikes are SINGLE-SHOT), not picked by eye. If the prior year is too thin to verify a direction, label it UNVERIFIED.
- **Compare shares, not raw counts**, when cohorts differ in size. Report engagement per post, not totals.
- Chart ingestion artefacts (a volume jump when profiles were added) are disclosed and read as snapshots, not trends.

## Say what the data measures
- SOMIN reads **content made for an audience**, not the audience itself. Write "content made for Techies", never "what Techies want".
- Name every creator profile used as a panel, in an appendix or disclosure slide.
- Show a few real top-performing competitor posts as evidence (link, brand, platform, date, engagement). Say what they show and what they do not.

## Keep the story honest
- Where an insight story drifts from the strategic point (for example, a story about community financing for a factory-direct pillar), say so and say which layer carries the point.
- A pillar can be a test bet. Label it that way, with the reason ("rise unverified").

## Operational
- One study per time window; write the study registry (`strategy/studies.json`) after each call so a resumed session does not recreate studies.
- Pull large results to disk and parse them there; never read a large study response inline.
- Use studies' own numbers in the report; never add a figure that is not in a study, the guideline or the client's brief.
