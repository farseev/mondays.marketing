# Scheduling in Postly

Scheduling is real publishing: Postly posts on its own servers at the chosen time, with no one logged in. Treat every call accordingly.

## Preflight
1. `postly_list_workspaces`, then `postly_list_social_accounts(workspace_id)`. Use only accounts with `connected: true` for the platforms in the calendar. Other accounts in the workspace (other people's LinkedIn profiles, for example) are never touched.
2. Load the tools you need with `tool_search`: create, validate, upload media, list media, list scheduled posts, get post status, update, delete.
3. Compute now in the client's timezone. The first post is 3+ hours away.
4. Post 1 goes through `postly_validate_post` (a dry run) before it is created. Read its warnings.
5. The user has said "go" on the plan table. Without it, stop.

## One post
- Image: `get_screenshot` of the Figma frame returns a short-lived PNG URL; pass it as `media_file` immediately (or import with `postly_upload_media` and an `idempotency_key`, poll `postly_list_media` until completed, then pass the returned URL in `media`). Add alt text.
- `postly_create_post` with: exact caption text; `target_platforms` = the connected account ID; `one_off_schedule` = `{one_off_date, time (HH:MM), timezone}`; `platform_posts` settings for the network; `use_publishing_presets: false` (presets can append text or hashtags, and the caption must go out exactly as approved); labels with the campaign and creative key.
- Responses:
  - 200 "queued": the post exists. Record its `_id` in the ledger immediately.
  - 202 `media_processing`, `post_mutated: false`: nothing was created. Repeat the identical call after about 5 seconds. Use the wait to start the next post's image.
  - 504 or "upload outcome unknown", `post_mutated: false`: nothing was created. Wait, then repeat the same call. If unsure, list scheduled posts for that date before retrying so you never create a duplicate.
- Never create the same post twice. Never delete or edit a post without telling the user first.

## Ledger
`postly_ledger.json` maps post number to Postly ID. Write after every post. On resume, continue at the first number without an ID. Each post costs about three calls (image, first attempt, repeat), so expect to spread a 30-post run over several turns.

## Verify against Postly, not against yourself
`postly_list_scheduled_posts` with `scheduled_from`/`scheduled_until` covering the calendar, the client's timezone, `limit` 100. Check: count equals the plan, one entry per planned date and platform, local time as planned, caption identical to `schedule.json`, targets are only the intended accounts, IDs match the ledger, status `scheduled`. Report any difference.

## After the first publish time
`postly_get_post_status` shows delivery results. "Queued" or "scheduled" is not "published". Report what Postly says.

## What can still stop a post
The page connection expiring (reconnect in Postly once; later posts continue), the Postly plan lapsing or hitting its limit, a workspace approval step (check the response's approval setting). Put these in the approval PDF and the closing message.
