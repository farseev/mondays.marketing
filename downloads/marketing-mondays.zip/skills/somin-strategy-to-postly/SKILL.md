---
name: "somin-strategy-to-postly"
description: "End-to-end client workflow from SOMIN strategy to scored, on-brand creatives built in the client's own Figma file, then a calendar, Postly scheduling and customer PDFs. Starts once the prompter sends the brand manual, the posting dates and a Figma link with templates and assets."
---

# Strategy to Postly pipeline

Takes a client from analysis to scheduled, customer-approved posts. Everything the customer sees follows **this client's** brand guideline, and every image comes from **this client's** Figma file.

```
0 Intake (brand manual + posting dates + Figma link) -> 1 Figma audit -> 2 Strategy (12 months + last 90 days)
  -> 3 Build candidate creatives in Figma -> 4 Score and pick top performers (rounds until the target is met)
  -> 5 Final layouts into the SAME Figma link -> 6 Customer report PDF -> 7 Calendar + go signal
  -> 8 Schedule in Postly -> 9 Approval PDF
```
Stage 6 does not depend on scores, so draft the report while Stage 4 waits.

## Source of truth

**This SKILL.md is the only source of truth for this pipeline.** Where any file in `references/` or any script message disagrees with it, this file wins. The reference files hold supporting detail only:

- `references/figma-build.md`: Figma code patterns and API gotchas.
- `references/pdf-deliverables.md`: PDF structure, page budget, `report.json` and `approval.json` formats.
- `references/postly-scheduling.md`: Postly preflight, responses, ledger and verification.
- `references/strategy-quality.md`: strategy-stage quality rules.
- `references/lessons-learned.md`: why each rule exists.

## Default settings (apply automatically; change only when the prompter says so)

These defaults apply every time the skill runs. If the prompter states a different value ("analyse 6 months", "put finals in another file", "skip scoring", "only need 2 top performers"), use theirs, record it in `intake.json` under `overrides`, and repeat it back once.

| # | Setting | Default |
|---|---|---|
| D1 | Analysis window | **Fixed 12 months** ending on the last day of the last full month before today (strategy, personas, seasonality, prior-period trend checks), plus the **last 90 days** of that same window as the "what's working now" view for the brand and competitors. |
| D2 | Where final layouts go | **The same Figma file the prompter linked**, in a new section (see Stage 5). Never a different file unless told. |
| D3 | Scoring | **On.** Score every candidate in SOMIN and put only top performers into the final section, labelled as top performers. |
| D4 | Top-performer target | Number of finals = calendar slots (days x posts per day, per platform), unless the prompter gives a number. A creative is a **top performer** when SOMIN's above-average clickability probability is at least **0.80** (threshold from `creative-scoring`). |
| D5 | Not enough top performers | If a round gives fewer top performers than the target (for example only 1, 2 or 3), **build another set of new candidates and score again** until the target is met. Default cap: **3 rounds** (see Stage 4). |
| D6 | Scoring time | Before every round, tell the prompter how long scoring is expected to take and why; after it, report the actual time and the reason for any delay. |
| D7 | Design | Every layout follows **hierarchy** (mandatory) and is checked against balance, alignment, repetition, contrast, emphasis, white space and proportion (optional, apply where they help). Scenes highlight the layout's purpose and the product or service. |
| D8 | Product placement | Product photos must match the scene's atmosphere: not poorly cut, not poorly edited, not poorly placed. |
| D9 | Platforms | The platforms connected in Postly for this client that also have a Figma template. |
| D10 | Posting time | One consistent time per platform in the client's timezone (default 19:00 local), unless given. |
| D11 | Client data sources | Brand manual, the client's Figma file, and anything the prompter sends in this chat. **Typeform is parked** (see Stage 0). |

## The rules

Each rule comes with its reason, so you can apply it to cases not listed here.

1. **No generated imagery.** Never create, render or edit images of products, people, scenes, logos or anything that could carry someone else's copyright or likeness. Do not call image-generation tools (including SOMIN `image-generate`), and do not run the render step of `somin-creative-expressions` or `somin-brand-deck`. A "visual scene" is **composed in Figma from the client's own photos** (product shots, behind-the-scenes, installations, factory, backgrounds) that already exist in the linked file. Reason: generated products drift from the real product, and generated people and scenes create copyright and likeness risk the client never agreed to.
2. **Each network gets its own Figma template.** Build Instagram posts from the Instagram template, Facebook from the Facebook template, and so on. Read sizes from the template frames; never assume a size.
3. **If Figma lacks what the job needs, ask. Do not make it up.** Missing templates, product cutouts, scene photos, icons, logo variants: name exactly what is missing, which creatives it blocks, and wait.
4. **Scoring is time-boxed per round, never skipped by default.** Each round has a one-hour limit from its last upload. Creatives still unscored at that point cannot be called top performers; Stage 4 says what happens next (more rounds or ask, never silently continue unscored). Scores are pre-launch predictions, never measured results.
5. **Customer strategy report: PDF, at most 10 pages in total.** Technical detail (study IDs, method, definitions, caveats) goes in the Appendix, inside the 10 pages. Overflow detail goes to a separate technical file.
6. **This client's brand guideline governs everything the customer sees**: report, approval document, previews, creatives. No guideline means ask for it and stop. Do not infer a palette from a website, from earlier work, from the bundled examples, or from another client. **Build `brand.json` fresh from this client's guideline on every run**, and record in it the page or section of the guideline each colour, font and logo rule came from.
7. **After scheduling, produce the approval PDF** for the customer, built from the verified Postly queue.
8. **Never produce, export or schedule more final content than the calendar has slots for.** Candidates built for scoring are allowed to exceed the slots; finals are not.
9. **Hierarchy is mandatory on every layout** (D7), and **product placement must look native to the scene** (D8). A layout that fails either is fixed or dropped before it is scored.
10. **One client per run; no cross-client carry-over.** Use only this client's brand manual, Figma file, SOMIN workspace and Postly accounts. Ignore notes, memory files, project files, earlier chat context and finished work about any other client (for example an earlier client's palette, fonts, logo, taglines, product names or claims). No other client's name, colours, logo or wording may appear in this client's creatives, captions or PDFs. Reason: the pipeline is run for many clients, and a colour or line from one client in another's material is a brand breach.

## Working folder and the ledger

Work in `/home/claude/<client-slug>/`. Keep these files; they let a "continue" in a later turn resume exactly where you stopped:

`intake.json`, `brand.json`, `figma_inventory.json`, `strategy/` (study registry, whitespace, trends, chains), `creatives.json` (every candidate, with round and status), `scores.json` (per round: upload time, poll times, scores), `calendar.json`, `schedule.json`, `postly_ledger.json` (post number -> Postly ID, written after every post), `outputs/`.

On every "continue": read the ledger, `intake.json` and `scores.json` first, state where you are (stage, round, how many top performers so far), then do the next step. Save after each long tool call; a turn can end at any moment.

Connectors are deferred tools. Load them with `tool_search` / ToolSearch before first use (SOMIN, Figma, Postly). For Figma, call `get_figma_skill` for `figma-use` before the first `use_figma` call.

## Stage 0 - Intake (starts the skill)

The skill starts building as soon as the prompter has sent these three things:

1. **Brand manual** (file or link). Required; without it, ask and stop.
2. **Posting dates**: start and end. Posts per day defaults to 1; time defaults per D10; timezone defaults to the client's market (ask only if it cannot be told from the brand manual or the prompter).
3. **Figma link** containing the per-network templates and the assets: product photos, behind-the-scenes and scene photos, logo variants, icons.

Everything else is defaulted, not asked. **Do not ask for the analysis window or the number of creatives**:
- Client name: from the brand manual. SOMIN workspace: matched by client name in `workspaces-list` (ask only if no match or several).
- Analysis window: D1. Number of finals: D4. Platforms: D9.
- Check Postly yourself (`postly_list_workspaces`, `postly_list_social_accounts`) and record what is connected. Never assume a platform is connected because the user mentioned it.
- **Typeform is parked** until real client responses exist. Do not call any Typeform tool. The brand manual and anything the prompter sends are the only client sources for goals, voice, offers, claims and the call to action.

Then open the Figma link and confirm it actually contains templates and assets. **An empty file or page is a stop**: say so plainly and ask for the right link.

### Date arithmetic and timing

- days = end - start + 1 (inclusive). 30 Sep to 27 Oct is 28 days, not 30. State the day count back to the prompter; if they also gave a post count that disagrees, ask which one wins.
- slots per platform = days x posts per day; total slots = sum over platforms. Finals = min(target, slots), per platform.
- A platform cannot repeat a creative. A creative may be shared across platforms only if the posts are 7+ days apart.
- Compute "now" in the client's timezone (the sandbox clock is usually UTC). The first post must be at least 3 hours from now. If the start date is already in the past, ask.
- If the first post is under 48 hours away, tell the prompter the customer will not have time to review before it goes live (the approval PDF comes after scheduling) and offer to move the start.
- If the calendar overlaps posts already queued in Postly for the same account, ask whether to move the start, replace, or add.

### Confirm and write intake.json

Confirm the plan back in one short message before heavy work: client, analysis window (both ranges with dates), calendar (dates, day count, platforms, posts per day, time, timezone), number of finals, Figma file for finals, and anything defaulted. Proceed unless the prompter changes something; if they are clearly away, proceed and state the assumptions at the top of the next message.

Write `intake.json` with **the defaulted values filled in**, so the guard script does not ask for them:
- `analysis.start` / `analysis.end` = the D1 12-month window (also record the 90-day window under `analysis.recent_start` / `analysis.recent_end`),
- `creatives_requested` = total calendar slots (D4) unless the prompter gave a number,
- `calendar.platforms` = the D9 platforms, each with `connected` from Postly,
- `figma.assets_url` = the linked file, `figma.templates` = the template frame link per platform,
- plus `defaults_applied` and `overrides`.

Shape (fictional values):
```json
{
  "client": "Example Client",
  "somin_workspace": "Example Workspace",
  "brand_guideline": "Example_Brand_Manual.pdf",
  "analysis": {"start": "2025-10-01", "end": "2026-09-30", "recent_start": "2026-07-03", "recent_end": "2026-09-30"},
  "creatives_requested": 28,
  "calendar": {
    "start": "2026-11-02", "end": "2026-11-15", "timezone": "Asia/Singapore",
    "platforms": [{"name": "facebook", "posts_per_day": 1, "time": "19:00", "connected": true}]
  },
  "figma": {"assets_url": "https://www.figma.com/design/...", "templates": {"facebook": "https://www.figma.com/design/...?node-id=..."}},
  "defaults_applied": ["D1", "D4", "D9", "D10"],
  "overrides": {}
}
```

Then run `python scripts/plan_guard.py intake intake.json`. Exit code 2 means a **required** item (brand manual, posting dates, Figma link or a platform template) is genuinely missing: ask only for that. If it asks for something D1, D4 or D9 already supplies, fill it into `intake.json` and re-run instead of asking the prompter.

## Stage 1 - Figma audit

Inventory what exists in the linked file before planning content: templates per network (name, node ID, size, text layers, image slot), logo variants, product photos (and whether each is a clean cutout with transparency or a photo already in a setting), behind-the-scenes and scene photos, icons, backgrounds, fonts, existing finalized layouts. Save `figma_inventory.json`. Compare it against the connected platforms and the concepts you expect to need. Ask for anything missing now (rule 3). Code patterns: `references/figma-build.md`.

Also record the template's own colour values (fills and text colours) and check them against this client's `brand.json`. If a template uses a colour that is not in the guideline, ask before building rather than copying it into new elements.

Grade each product asset for scene use: **clean cutout** (smooth edges, no halo, no leftover background), **in-scene photo** (already lit and placed in a real setting), or **not usable for compositing** (rough edges, low resolution, heavy compression). Only the first two may be placed into scenes.

## Stage 2 - Strategy

Run the `somin-brand-deck` analysis steps (read that skill) with the D1 windows. Use the full 12 months for personas, pain points, seasonality and trend direction (prior-period comparison); use the last 90 days to say what is working now for the brand and competitors (formats, topics, hooks), and let it steer the first round of candidates. Reuse existing studies in the workspace when their windows match; create new studies only for windows not yet covered. Overrides in this pipeline:
- Do not re-ask scope items the intake or the defaults already answered.
- Skip its creative-rendering and creative-scoring steps. Stages 3 and 4 replace them.
- Skip its brand-extraction-from-web step: brand values come only from this client's brand manual (rule 6).
- The customer deliverable is the PDF report (Stage 6). Build the PPTX only if asked.
- Concepts that need a person, product or scene that is not in Figma are dropped or raised as a question, never rendered.

Quality rules (verdicts derived from the data, honest wording, creator-panel disclosure, evidence posts): `references/strategy-quality.md`.

## Stage 3 - Build candidate creatives in Figma

**Round sizing.** Round 1 builds about 2x the remaining target (at least target + 3), spread across pillars and funnel stages, so the scoring has real choice. Later rounds build about 2x whatever is still missing, and change direction based on what scored well (pillar, hook type, layout style, product shown), not copies of earlier candidates.

For each candidate write a brief in `creatives.json`: round, platform, template frame, pillar, funnel stage, **layout purpose** (one line: what this post must make the viewer understand or do), headline, supporting line, call to action, focal element, and the exact Figma asset nodes it uses.

Build each one by duplicating the platform's template frame in a **"Candidates - Round N"** section of the same linked file, filling its text layers, and composing the scene from existing image nodes. Never alter the originals. Name candidate frames `R<N>-<NNN>_<key>_<pillar>_<funnel>_<NETWORK>-<WxH>`.

### Design principles (D7)

**Hierarchy - mandatory on every layout.** Decide the reading order before placing anything, and make it unmistakable:
1. One dominant focal element: either the headline or the product, never both competing at the same size.
2. Then the supporting line, then the call to action, then the logo, in that order of visual weight (size, weight, contrast, position).
3. The focal element must carry the layout's purpose: if the purpose is "this product keeps the fridge running in a blackout", the product and that idea dominate.
4. Check: squint at the screenshot. If the eye does not land on the focal element first and the CTA last-but-findable, rebuild.

**Optional, apply where they help** (note in the brief which ones the layout uses): balance (symmetrical or deliberately asymmetrical, never lopsided by accident), alignment (every element on the template grid or a shared edge), repetition (consistent type styles, colours, icon treatment across the set), contrast (text legible against its background, using only colours defined in this client's `brand.json`), emphasis (one accent at most), white space (room around the product and the logo's clear space), proportion (product, text and logo sized relative to each other and to the frame).

**Brand colour on added elements.** Any element you add that the template does not already carry (CTA button, accent bar, highlight, shape, shadow tint, text colour change) uses only colours defined in this client's `brand.json`. Neutral black, white and grey shadows are allowed only if the guideline permits them. Never introduce a colour from another client, a bundled example or a default palette.

### Scene and product placement (D8)

The scene must highlight the layout's purpose and the product or service: a home-use post shows the product in a home setting from the client's photos; a manufacturing-quality post uses behind-the-scenes factory photos.

When placing a product photo into a scene:
- Use only assets graded **clean cutout** or **in-scene photo** in Stage 1. Never cut a product out yourself with a rough mask, never stretch or squash it, never upscale a low-resolution image.
- Match the scene: perspective and camera height, scale against the room or objects, light direction and colour temperature, and a grounded contact (a soft shadow in Figma under the product's base) so it does not float. Small Figma adjustments (exposure, contrast, warmth, a subtle shadow) are allowed; anything more is "poorly edited".
- The product must not be cropped awkwardly, overlap the logo or text, or sit on a busy area that hides its shape.
- If no scene photo fits the concept, or the needed product exists only as a poor cutout, **ask the prompter for a clean cutout or a suitable scene photo** (rule 3). Do not substitute a generated image and do not lower the bar.

### Copy rules

Every number, claim, certification, warranty, price, customer, event or testimonial must trace to a client source (brand manual, product record, client brief or material the prompter sent in this chat). Anything you cannot trace is not written; list it as "needs client confirmation". Keep the logo exactly as the template carries it and follow the guideline's logo rules. No other client's name, product or tagline appears in copy (rule 10).

### Pre-score check (every candidate)

Screenshot each frame and check: hierarchy passes, product placement passes D8, text fits, logo clear space respected, no placeholder text, fonts per the guideline, and **every colour in the frame is in this client's `brand.json`** (inspect fills and text colours programmatically, not only by eye). Fix or drop failures before scoring; record drops in `creatives.json`. Code patterns and API gotchas: `references/figma-build.md`.

## Stage 4 - Score and pick top performers

Scoring is on by default (D3). Field names and the 0.80 threshold: `creative-scoring`.

**Before uploading each round, tell the prompter (D6):**
- how many candidates are being scored,
- the expected wait: **up to 60 minutes for the round**, with results checked every 10 minutes,
- why it takes that long: SOMIN scores asynchronously. Each uploaded image and caption goes into SOMIN's processing queue, where it is first analysed (objects, composition, text, concepts) and then run through the clickability model; the result only appears once both steps finish. Queue load and the number of creatives in the round decide how long that takes, so a large round or a busy queue takes longer.

**Procedure:**
1. Finish and pass the pre-score check first; score the finished frame, not an earlier version. Export it with `get_screenshot` (`maxDimension` = the frame's longer side).
2. Upload one creative with `posts-upload` (this client's workspace; `text` = headline; `media` = exported frame URL; `labels` = campaign label, round and creative key). Read it back with `posts-search` by the returned ID and confirm it is stored as manual owned content with no external post ID, so nothing went live. Only then upload the rest of the round in batches.
3. Record in `scores.json` per round: `{"round": N, "uploaded_at": "<ISO time of the last upload>", "ids": {...}, "polls": [...], "scores": {}}`.
4. Poll no more often than every 10 minutes (`posts-search` by content ID, or `posts-aggregate` with the round label). A creative is scored when its record carries clickability data; an average of 0 across the label means none are scored yet. Use the wait to draft the Stage 6 report.
5. When the round finishes, or at 60 minutes after its last upload, **tell the prompter the actual time it took** and the reason for any delay or gap (for example "8 of 20 still unscored at 60 minutes, SOMIN's queue did not finish them in time", or "2 uploads failed and were re-sent").
6. Rank scored candidates. Every candidate with probability >= 0.80 is a **top performer**. Keep the best ones up to the target, balancing pillars and funnel stages when scores are close. Never rank unscored candidates against scored ones.

**If top performers < target (D5):** report how many were found (for example "only 3 of 30 reached top-performer level"), then go back to Stage 3 and build another round of new candidates, informed by what scored well. Repeat Stages 3 and 4 until the target is met. Do not re-upload candidates already uploaded; if their scores arrive late, include them in the ranking.

**Round cap (default 3 rounds, editable).** If the target is still not met after the cap, stop building and ask the prompter: build another round, lower the target (shorten the calendar), or fill the remaining slots with the highest-scoring non-top candidates. Fill slots with non-top candidates only with the prompter's agreement; label them "Scored below top-performer level" everywhere they appear. If the prompter is away, wait for an answer rather than filling with lower scorers.

**If a round returns no scores at all within its hour:** say so, give the time and the likely reason, and ask whether to re-run scoring or continue unscored. Never continue unscored without the prompter's answer. Unscored creatives are never labelled top performers.

Scores are pre-launch predictions from SOMIN's model, never measured results; say so wherever you show them.

## Stage 5 - Final layouts into the same Figma link

Default (D2): the finals go into **the same Figma file the prompter linked**, on the page in the link, in a new section named `FINAL - TOP PERFORMERS - <campaign> - <date range>`.

- Move or duplicate only the selected top performers there, in calendar order. Name each frame `NNN_TOP-PERFORMER_<score>_<key>_<pillar>_<funnel>_<NETWORK>-<WxH>` (score to two decimals). Any agreed non-top fillers go in a separate sub-section labelled "Scored below top-performer level" and are named `NNN_BELOW-TOP_<score>_...`.
- Add a small list frame **beside** the creatives (never on them) titled "Top performers" listing number, frame name, score and pillar. The badge must not appear on the exported image itself, because the image goes to Postly.
- Leave the candidate sections in place (or tidy them into a collapsed "Candidates" section) so the prompter can see what was tried; do not delete them unless asked.
- Verify: frame count equals the final target, every frame passes the pre-score check (including the brand-colour check), names unique. Share the Figma link to the final section and list the top performers in chat with their scores.

## Stage 6 - Customer strategy report (PDF, max 10 pages)

Build from this client's `brand.json` and a `report.json`:
```
python scripts/build_report_pdf.py report.json --brand brand.json --out outputs/<client>_strategy_report.pdf
python scripts/check_pdf.py outputs/<client>_strategy_report.pdf --max-pages 10
```
State both analysis windows (12 months and last 90 days) on the method page or in the appendix. The builder refuses more than 10 pages, flags overflowing pages and records where the appendix starts; the checker fails if technical IDs appear before the appendix. Structure, page budget and wording rules: `references/pdf-deliverables.md`. Do not copy colours from the bundled `assets/examples/brand.json`; it is a fictional placeholder.

## Stage 7 - Calendar and go signal

Build one calendar per connected platform inside the posting dates, nothing beyond them, using only the final layouts from Stage 5:
- Pillars rotate evenly. Funnel stages alternate. No creative repeats within a platform; a creative shared across platforms is at least 7 days apart. On any day, platforms carry different creatives.
- Posting times in the client's timezone, consistent per platform (D10). The first post is at least 3 hours from now; if the usual time has passed or is too close, use the next suitable slot that day, or ask.
- Captions are written per network (X: 280 characters or fewer), following the copy rules. Copy matches the calendar cadence (no "weekly" on a daily calendar).

Write `schedule.json` and run `python scripts/plan_guard.py schedule schedule.json`; fix every error. Then show the user one table: `#, date, time, platform, caption preview, image, score, issues or edits`, and say plainly what is and is not connected. **Wait for an explicit go before scheduling anything**: scheduling in Postly is real publishing.

## Stage 8 - Schedule in Postly

Follow `references/postly-scheduling.md`: preflight, one post at a time, ledger after every post, verification against Postly's own queue. Schedule only to this client's connected accounts, with publishing presets off so captions go out exactly as approved. Never describe a post as published until Postly's delivery status says so.

## Stage 9 - Approval PDF for the customer

Build from the verified queue, not from your plan:
```
python scripts/build_approval_pdf.py approval.json --brand brand.json --out outputs/<client>_content_approval.pdf
python scripts/check_pdf.py outputs/<client>_content_approval.pdf
```
It states plainly that the posts are already scheduled and will publish unless changed, how to ask for changes, what needs client confirmation, and has a sign-off page. Technical IDs sit only in the final reference table. If the first post is less than 48 hours away, tell the user the customer cannot review before it goes live, and offer to move the start.

## Brand isolation check (before Stage 7 and again before delivering PDFs)

1. Every colour in `brand.json` traces to a page or section of this client's guideline.
2. Every colour used in the final frames is in `brand.json`.
3. Search the final frame names and text, captions, `report.json`, `approval.json` and the PDFs' text for any other client's name, product names, taglines or hex codes you have seen in this session or in memory. Any hit is a defect: fix it before going on.

## Stop-and-ask list

| Situation | Action |
|---|---|
| No brand manual | Ask, stop |
| No posting dates | Ask, stop |
| Figma link missing, empty, or has no template for a connected platform | Ask for it; build nothing for that platform |
| Template uses colours not in the brand guideline | Ask before building with them |
| Concept needs a photo, scene or clean product cutout that is not in Figma | Ask, or drop the concept; never generate, never rough-cut |
| A claim cannot be traced to a client source | Leave it out; list under "needs confirmation" |
| Platform not connected in Postly | Do not schedule it; ask the user to connect it or drop it from the calendar |
| Calendar overlaps posts already queued for the same account | Ask: move, replace or add |
| Top performers below target after the round cap | Ask: another round, shorter calendar, or fill with labelled lower scorers |
| A scoring round returns nothing within its hour | Report time and reason; ask re-run or continue unscored |
| First post under 3 hours away | Move to the next suitable slot, or ask |

## Closing message to the user

Short and factual: how many top performers were found and in how many rounds, how long scoring took and why, where the finals are in Figma, what is scheduled (count, dates, platforms), what is not and why, what the customer needs to confirm, which files were produced, the result of the brand isolation check, and what you did not verify. Do not claim a post is live because it is queued.

Lessons from earlier runs of this pipeline, each tied to the rule it produced: `references/lessons-learned.md`.

## Bundled scripts

Run from the skill folder. Sample inputs for every script are in `assets/examples/` (placeholder images and a fictional client, never client material; never reuse their colours or text for a real client).

| Script | Use |
|---|---|
| `scripts/plan_guard.py intake` | Stage 0: what is still missing, calendar slots, creative cap, first-post timing (fill defaults into intake.json first) |
| `scripts/plan_guard.py schedule` | Stage 7: errors and warnings before anything goes to Postly |
| `scripts/build_report_pdf.py` | Stage 6: brand-styled report, hard page limit, overflow detection |
| `scripts/check_pdf.py` | Stages 6 and 9: page limit, technical IDs before the appendix, empty pages |
| `scripts/build_approval_pdf.py` | Stage 9: approval document from the verified queue |
| `scripts/pdfkit_brand.py` | Shared Chromium renderer; refuses to run without brand colours, logo and guideline source |

PDF scripts need Playwright with Chromium (`pip install playwright && playwright install chromium`) and pypdf.
