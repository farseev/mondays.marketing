---
name: "competitor-product-market-insights"
description: Build a multi-market competitor product, offer and marketing-insights dashboard from SOMIN data for analytics, product, market-insights and marketing teams. It covers offers, discounts, product and service launches, a launch radar, customer needs, incentive types, monthly trends, advertiser deep-dives, trending whitespace and TOFU/MOFU/BOFU "what to build" chains with SOMIN expression renders, and every insight opens the real posts behind it. Use it whenever someone wants to monitor competitors' offers, promotions or product launches across several markets or countries, asks for a competitor or product dashboard for a regional or multi-market team, wants market dive-ins split by vertical, or says /competitor-product-market-insights, even if they only say "a dashboard like the last one" or "track what competitors launch in each market".
---

# Competitor product & market insights dashboard

This skill builds one published dashboard for a regional team. It has two views, each split by vertical (e.g. mobility vs food) and by market:

- **Product & market insights**, for analytics, product and market-insights teams.
  - KPIs and computed insight cards for the recent period and for month-on-month trends.
  - The advertiser table. Each row opens an advertiser dashboard with its products, offers, incentives, needs, content types, channels, monthly trends and content.
  - Share of paid presence and of organic response.
  - Customer-need and incentive distributions.
  - Offer and product heatmaps by advertiser.
  - A weekly and monthly launch radar.
  - A first-seen table of new offers and products.
  - Monthly trend heatmaps.
  - The latest competitor moves.
- **Marketing**, for marketing teams.
  - A monthly whitespace map per market and vertical, with trending lanes.
  - Insight chains per market × vertical × paid/organic, plus one per trending whitespace lane: signal → SOMIN insight → opportunity → What to Build (TOFU / MOFU / BOFU).
  - Each stage carries a SOMIN expression render and the real posts it learns from.

The page has global filters for channels (paid and organic tick boxes), period (recent vs full window), offering type (products vs services), segment (B2C vs B2B) and incentive type. Every insight, bar, cell and row opens a content plate of the posts and ads that produced it.

## Non-negotiables (why the dashboard is trusted)
1. **Only SOMIN data.**
   - Every number is computed by the scripts.
   - Every quote is copied from a SOMIN study theme or story.
   - Every example is a real post or ad the viewer can open.
   - Chain writers work only from evidence packets, and `validate_chains.py` enforces it.
   - If something is missing (no studies in a market, no ads for a brand), the page says so. Nothing fills the gap.
2. **Every claim opens its evidence.** Keep the evidence ids on every card, lane and chain.
3. **The verdict ceiling stays.** With only brand and competitor cohorts, the strongest whitespace verdict is "POSSIBLE WHITESPACE — UNVERIFIED". Say what would confirm it.
4. **Brand-safe creative.** Expressions come only from the SOMIN expressions engine and pass its gate. The brand-lock suffix is appended after the gate. No logos are drawn, and CTAs are the brand's real ones.

## Before you start: settle these (ask once, in one AskUserQuestion round, only for what you cannot find)
- **SOMIN workspaces.** Which workspace holds the competitor pages, and which per-market workspaces hold Perspective Studies and stories. Call `mcp__SOMIN__workspaces-list` first and propose the answer.
- **Focal brand**, and its short name as it appears in page names.
- **Markets and verticals.** Derive markets from the "(MK)" suffixes in page names. Ask which verticals the team splits by and draft keyword regexes, local languages included.
- **Window.** Default: the 12 months ending today, with a recent period of 90 days.
- **Brand look.** Use an installed `<brand>-brand-guideline` skill if one exists. Otherwise infer the theme from the focal brand's own SOMIN organic feed in its home market (look at 15–25 top post thumbnails: colour field, type style, CTA shape, people and settings). Use the logo only if the user attached one, and set `provenance` in theme.json.
- **Expressions.**
  - Default: one TOFU, one MOFU and one BOFU render per chain. "None" is fine and the page adapts.
  - They need the `somin-creative-expressions` skill (a separate SOMIN add-on, if installed) and its engine key. If it is not installed, set expressions to none: the page adapts and ships without renders.
  - If the user gives a key file, pass it as `EXPRESSIONS_KEY="$(cat <file>)"` inside the same command. Never copy it into the run directory, a brief or the page.

Tell the user the run takes a few hours (mostly SOMIN harvesting), then work through it. Set up a task list with the steps below.

## Setup
This skill ships with `scripts/`, `assets/` and `references/` next to this file. If they are missing, only the instructions were installed. Ask the user to add the `competitor-product-market-insights.skill` package, because the pipeline cannot run without its scripts.
```bash
SK=<this skill's directory>            # contains scripts/, assets/, references/
RUN=<scratchpad>/cpmi_<brand>/          # one run directory per dashboard
mkdir -p $RUN/raw/inline $RUN/expr/renders && cd $RUN
cp $SK/assets/spec_example.json spec.json     # then edit: references/spec.md documents every field
cp $SK/assets/theme_example.json theme.json   # then edit tokens, fonts, brand_lock (and add logo.png if supplied)
```
Run every script from `$RUN` as `python3 $SK/scripts/<name>.py`. They all read `spec.json` via `cfg.py`.

## Workflow

**1. Resolve.**
- Call `mcp__SOMIN__profiles-list` for each source workspace.
- SOMIN tool IDs: this skill writes `mcp__SOMIN__<tool>`. Where the connector is namespaced differently (in Claude Code a plugin server's tools are `mcp__plugin_marketing-mondays_SOMIN__<tool>`), use the matching SOMIN tool of the same name, and pass that name to the sub-agent briefs.
- Write `profiles.json` as `[{id, name, workspace_id}]`, keeping SOMIN's page names.
- Fill spec.json: aliases for spelling variants, `brand_verticals` for single-vertical brands, regulators, and `profiles` overrides for pages with no "(MK)" suffix.

**2. Harvest (parallel subagents).**
- `python3 $SK/scripts/brief.py harvest` writes one brief per market to `briefs/`.
- Launch one general-purpose agent per brief in a single message, with the prompt "Read <brief path> and follow it exactly." Split very large markets into two profile groups.
- Each agent pulls monthly slices of organic posts and ads, extracts them into `raw/<MK>_<ws>.jsonl` with `extract.py`, and gates each profile against `posts-aggregate`.
- Review the gate tables. Re-brief any profile more than 2% short.

**3. Merge and check coverage.**
- `python3 $SK/scripts/merge.py` prints the organic platform × month table, the ads moved by country code, placeholder ads and the per-post vertical split of multi-vertical brands.
- A platform whose counts start mid-window goes into `like_for_like_exclude`. Add any piled-up placeholder ad date to `placeholder_dates`.
- Sanity-check the vertical split (e.g. a delivery brand coming out 40% mobility means the keywords need work), then re-run.

**4. SOMIN insight inventory (subagent, can run during step 2).**
- `python3 $SK/scripts/brief.py inventory`, then one agent writes `somin_insights.json` (studies, themes and stories per market workspace).

**5. Insights.**
- `python3 $SK/scripts/insights.py` writes `insights_recent.json` and `insights_trend.json`.
- Read a sample of cards per market. If a taxonomy is wrong for the category (offer and product families default to super-app terms), override it in spec.json and re-run.

**6. Whitespace.**
- `python3 $SK/scripts/whitespace.py` writes `whitespace.json`.
- Look at each market's trending lanes. Corporate or generic lanes that slip through are a reason to tighten `generic_lanes` or `tactic_lane_regex`. Do not hand-edit results.

**7. Packets.**
- `python3 $SK/scripts/packets.py` writes `chain_packets.json`, `ws_packets.json` and `ctas.json` (the focal brand's real CTAs per market).

**8. Chains (parallel subagents).**
- `python3 $SK/scripts/brief.py chains` (6 packets per brief) and `python3 $SK/scripts/brief.py ws`.
- Launch one agent per brief. Each writes `chains_<n>.json` or `ws_chains.json` and must finish with the validator at 0 errors.
- Then re-run `python3 $SK/scripts/validate_chains.py chains chains_*.json` and `... ws ws_chains.json` yourself.
- Read the warnings. A warned number is fine only if it is simple arithmetic on packet figures.

**9. Expressions (skip if the user chose none, or if `somin-creative-expressions` is not installed).** The engine scripts live in the `somin-creative-expressions` skill (`$EXP/scripts`), if installed.
```bash
python3 $SK/scripts/build_page.py                 # also writes expr/brand.json from theme.engine_brand
python3 $SK/scripts/concepts.py build             # expr/concepts_chains.json, concepts_ws.json + pillar maps
for s in chains ws; do
  EXPRESSIONS_KEY="$(cat <keyfile>)" python3 $EXP/scripts/unlock.py emit-prompts --concepts expr/concepts_$s.json \
     --select all --brand expr/brand.json --out expr/_prompts_$s.json
  python3 $EXP/scripts/check_prompts.py --concepts expr/concepts_$s.json --prompts expr/_prompts_$s.json \
     --write-manifest expr/manifest_$s.json          # must PASS before anything renders
  python3 $SK/scripts/concepts.py lock expr/_prompts_$s.json --batch 18
done
python3 $SK/scripts/brief.py render                 # one brief per batch
```
- Launch the render agents (`mcp__SOMIN__image-generate`, 1024x1536, medium).
- Then run `python3 $SK/scripts/concepts.py status` and `python3 $SK/scripts/contact_sheet.py`. Open every sheet and compare each image with its hook. Re-render mismatches yourself from `prompt_locked`.
- If the gate fails, fix the concepts (usually a hook over 7 words or a CTA on a non-BOFU stage) and re-emit. Never render a failing set.

**10. Thumbnails.**
- `python3 $SK/scripts/thumbs.py` picks evidence posts first and caches small JPEG data URIs. It is resumable, and the page works without them.

**11. Encode and build.**
- `python3 $SK/scripts/encode.py && python3 $SK/scripts/build_page.py` writes `site/index.html`, `site/data/*`, `site/t/*` and `site/x/*`.

**12. QA.**
- `python3 $SK/scripts/qa_render.py` serves the site locally, clicks through both views on desktop (light) and phone (dark), and fails on page errors or horizontal scroll.
- Open the screenshots in `qa/` with Read and look at them.
- Spot-check three insight cards against their plates: the number in the card should be visible in the evidence.

**13. Publish.**
- `python3 $SK/scripts/split_publish.py` writes `pub_p1.json` … (each within 60 MB and 240 files).
- Publish part 1 with the Artifact tool: `file_path=$RUN/site/index.html`, `files=<pub_p1 map>`, `root=$RUN/site`, an icon such as "chart", and a one-line description.
- Publish parts 2…n to the same URL, passing `url` and the same file_path.
- To update an existing dashboard later, pass its `url`. Use `--previous pub_manifest.json` so stale files get removed.

**14. Hand over.** Send the user the artifact card with a short summary: markets, verticals, window, item count, and the three or four strongest findings, each one a card they can click. Add one honest caveat, such as missing studies in a market or late paid tracking. Save a short run note to the project if one is attached.

## Working notes
- **Brief subagents with the files in `briefs/`.** They are self-contained, so agents never need this conversation. Run independent agents in one message so they work in parallel.
- **Keep large tool outputs out of your context.** Load saved files with python and print compact summaries.
- **Re-running is cheap after the harvest.** Every step after step 3 takes seconds to a minute. Change spec.json and re-run from the step it affects rather than patching outputs.
- **When the user asks "why does this card say X",** open the evidence plate logic in `references/method.md` and answer from the data.
- **Adapt the analysis to the user's job.** Product and analytics leads care most about offers, launches, first-seen dates, incentive types and offering or segment splits. Marketing leads care about whitespace and the chains. Lead your summary with what their role acts on.

## Reference files
- `references/spec.md`: every spec.json and theme.json field, plus the profiles.json and somin_insights.json shapes.
- `references/method.md`: metric definitions, derived fields, insight thresholds, the whitespace rubric and trend classes. Read it before explaining or changing any rule.
- `references/run-lessons.md`: the gotchas that cost time in the first build (SOMIN row caps, shared advertisers, placeholder dates, render mismatches, publish limits). Read it before step 2 and before step 13.
- `references/harvest-brief.md`, `inventory-brief.md`, `chain-brief.md`, `ws-chain-brief.md`, `render-brief.md`: subagent brief templates. Fill them with `scripts/brief.py`.
- `assets/spec_example.json`, `assets/theme_example.json`: a fictional Example Brand run (2 made-up markets, mobility and food) showing every field.
- `assets/template_body.html`, `assets/base.css`: the page. Run-specific wording comes from `meta.json → cfg`, so edit the template only to change layout or add a view.
- `assets/taxonomy_default.json`: the default offer and product families (super-app oriented). Override them in spec.json for other categories.
