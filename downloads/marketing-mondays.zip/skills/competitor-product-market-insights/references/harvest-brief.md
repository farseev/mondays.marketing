# Harvest brief: SOMIN posts and ads for {{BRAND}} · {{MARKET}}

Your job is to pull every organic post (source PAGES) and every ad (source ADS_LIBRARY) for the profiles below, then store them as compact records. Do not analyse anything.
- **Workspace:** SOMIN {{WORKSPACE_ID}}
- **Window:** {{START}} to {{END}}

**Profiles (id: name):**
{{PROFILES}}

## Tools
Load them with ToolSearch: "select:mcp__SOMIN__posts-search,mcp__SOMIN__posts-aggregate". (If that exact name is not found, the SOMIN connector is namespaced differently on this surface, e.g. `mcp__plugin_marketing-mondays_SOMIN__<tool>` in Claude Code: search ToolSearch for "SOMIN <tool>" and use what it returns.)

## Rules
1. **Always pass `profileIds` and `source`.** A workspace query without `profileIds` silently returns only a few profiles.
2. **Query in monthly slices.** For each slice, call `posts-search` with:
   - workspaceId {{WORKSPACE_ID}}, the source and your profileIds
   - startDate and endDate set to the slice
   - sortBy "date", sortDir "DESC", pageSize 50, includeHidden false

   Increment `page` until a page returns fewer than 50 items. The slices are:
{{SLICES}}

   Monthly slices keep every query under SOMIN's row cap of about 1,200 rows. If one profile still has over 1,000 items in a month, split that month in halves.
3. **Run the extractor on saved files.** The harness saves large results to a file and reports the path. Never read those files into your context. Extract them straight away:
   `python3 {{SKILL}}scripts/extract.py --out {{RUN}}raw/{{TAG}}.jsonl --src organic|paid <saved file path>`
   - Use `organic` for PAGES and `paid` for ADS_LIBRARY.
   - It dedupes by id, so re-running it on the same file is safe.
   - The tool-results folder is shared with other agents. Only extract from paths your own calls produced, and never glob that folder.
4. **Handle small inline results.** Results under about 15 items come back inline.
   - Group profiles with few items into one query (several profileIds at once), so pages fill up and get saved to files.
   - If a short tail page still comes back inline, write it with the Write tool, exactly as returned, to `{{RUN}}raw/inline/{{TAG}}_<n>.json`. Then run the extractor on it.
5. **Keep every returned row**, even rows that come back under another profile id. Shared LinkedIn pages and shared Google advertisers do this. The merge step dedupes by id and moves ads to the market in their own country code.
6. **Gate each profile and source.** Run `posts-aggregate` over the full window with that source and `profileIds:[that one id]`, then compare its count with the extractor's per-profile total.
   - The harvested count should be within 2% of the platform count.
   - If it is short (date sorting can skip about 3% of rows across pages), re-pull the affected months with sortBy "total_engagement" and extract again.
   - A gap that equals rows attributed to another profile id is fine. Report it.
   - Ads use "active in window" semantics, so the same ad can appear in several slices. The dedupe handles this.
7. **Expect thin early paid data.** Ad monitoring often starts after the window begins. Report the first month with data for each profile and source.
8. Invent nothing, strip nothing, and do not paste post content into your reply.

## Reply with only
- **A table:** profile | source | platform count | harvested count | gap % | first month with data
- **The output file path.**
- **Errors or anomalies:** tool errors, profiles with zero results, odd sourceTypes, rows under another pid.
