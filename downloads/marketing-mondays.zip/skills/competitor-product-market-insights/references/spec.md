# spec.json and theme.json reference

Both files live in the run directory. Every script reads them through `scripts/cfg.py`. `assets/spec_example.json` and `assets/theme_example.json` are a filled-in fictional run (Example Brand, two made-up markets, mobility and food) and are the fastest starting point.

## spec.json

| Field | Required | Meaning |
|---|---|---|
| `brand` | yes | Focal brand short name, exactly as it reads after `aliases` (e.g. "Example Brand"). Pages whose aliased name equals it become the focal cohort. |
| `title` | no | Page title. Default "<brand> Competitive Pulse". |
| `subtitle` | no | Line under the title. Default "Powered by SOMIN · <first month> – <last month>". |
| `source_workspaces` | yes | SOMIN workspace ids that hold the competitor pages (posts and ads). One "ALL" workspace with every market's pages is typical. |
| `markets` | yes | `[{code, name, workspace_ids}]`. `code` is the two-letter suffix SOMIN uses in page names ("Example Brand (XA)"). `name` is how sentences read ("the Philippines"). `workspace_ids` are the per-market workspaces that hold Perspective Studies and stories (the insight step). |
| `region_label` | no | How sentences name all markets together ("the region"). |
| `region_label_short` | no | Market-bar label for the all-markets view ("All markets"). |
| `verticals` | yes | `[{key, label, keywords, study_tokens}]`. `key` is one short lowercase token with no hyphen. Do not use `o` (reserved for "other"). `keywords` is a case-insensitive regex used to classify posts of multi-vertical brands, so add local-language words for every market. `study_tokens` are the words that mark a SOMIN study as belonging to this vertical (e.g. ["FOOD"] matches "SG-FOOD-ORG 90d"). |
| `default_vertical` | no | The vertical the page opens on. Default: the only vertical, or "all". |
| `vertical_tiebreak` | no | Order to try when keyword votes tie (e.g. ["f","m"]). Default: `verticals` order. |
| `window.start`, `window.end` | yes | ISO dates. Trends use full calendar months inside the window. The partial last month is left out. Twelve months gives the best trend read. Six is the minimum. |
| `recent_days` | no | Length of the recent period (insight cards, chains, launch radar). Default 90. |
| `recent_label`, `full_label` | no | Period pill labels. Default "Last 90 days" and "Last 12 months" (from the window length). |
| `aliases` | no | `{SOMIN page name: short name}` to merge spellings ("CompB/ Competitor B" → "Competitor B"). |
| `brand_verticals` | no | `{short name: vertical key | "x"}`. A single-vertical brand keeps that vertical. `"x"` means multi-vertical: each post is classified by `keywords`. Unlisted brands default to `"x"`. A brand mapped to a key outside `verticals` is treated as "other". |
| `regulators` | no | Short names of regulator or association pages. They are kept on the page but excluded from competitor shares, whitespace and chains. |
| `profiles` | no | `{pid: {name, market}}` for pages whose SOMIN name has no "(MK)" suffix. |
| `placeholder_dates` | no | Ad start dates SOMIN uses when the real date is unknown. These ads count 0 ad-days. Dates before 2024-06-01 are always placeholders. Default ["2025-01-01"]. Check `coverage.json` and add any date with a suspicious pile-up of ads. |
| `like_for_like_exclude` | no | Platforms whose SOMIN collection started mid-window (Instagram Stories is common). Month-on-month trends exclude them, and the page offers a tick box to add them back. Fill this from the coverage table that merge.py prints. |
| `whitespace_exclude_platforms` | no | Platforms left out of the whitespace read. Default ["LinkedIn"], because global corporate pages pollute every market's lanes. |
| `paid_platforms` | no | Extra platform names to treat as paid. "Meta Ads" and "Google Ads" are paid already. |
| `offer_families`, `product_families` | no | `[[name, regex], ...]` overriding `assets/taxonomy_default.json`. The default suits super-apps (ride-hailing, delivery, payments). Rewrite these for other categories: they drive the offer and product heatmaps, trends and insight cards. |
| `launch_regex`, `tactic_lane_regex`, `generic_lanes` | no | Overrides for the launch detector, the whitespace tactic filter and the generic lanes that are never whitespace. |
| `curated_rules` | no | Regex-defined pattern cards for insights.py: `[{head, body?, regex, mk?, v?, brand?, src?, since?, until?}]`. The regex is matched against text, title, perks and products. The card shows every match as evidence and appends per-market counts to the body. Write `head` and `body` only from what the matches show, and use rules sparingly: the automatic cards usually suffice. |
| `known_gaps` | no | Sentences for the scope dialog (pages with no data, pages that run no ads, skew warnings). Write only what the harvest showed. |
| `chain_min_items`, `whitespace_min_items`, `whitespace_min_lane`, `whitespace_dims` | no | Thresholds. Defaults are 40 items per chain packet, 200 items per whitespace market-vertical and 15 items per lane. The dims are Audience, Customer need, Topic and Occasion. |
| `source_text` | no | Override for the scope dialog's Source line. |

## profiles.json (written in the resolve step)
`[{"id": 1112, "name": "Example Brand (XA)", "workspace_id": 1234}, ...]`. Write one entry per page in the source workspace(s), using the SOMIN page name as returned. `brief.py harvest` groups the pages by market from the "(MK)" suffix or from `spec.profiles`.

## somin_insights.json (written by the inventory agent)
This holds the studies, themes and stories per market workspace. Its shape is in `references/inventory-brief.md`. If it is missing, chains still build, but every insight step says that no study exists.

## theme.json

| Field | Meaning |
|---|---|
| `name` | Brand name. |
| `provenance` | Where the tokens came from: `brand_guideline_skill`, `web_extracted` or `somin_content_inferred`. |
| `fonts.display`, `fonts.body` | Font family names. |
| `fonts.google` | The query string after `css2?` for Google Fonts, or omit it to use system fonts. |
| `logo` | Logo file in the run directory (PNG or SVG). Only use a logo the user supplied or that comes from a brand-guideline skill. Never draw one. |
| `logo_on_bar` | `"invert"` turns a dark or coloured logo white on the coloured bar. `"none"` keeps the original colours. |
| `light`, `dark` | Colour tokens for each mode. All of these are required: `accent`, `accent-ink` (accent-coloured text on light surfaces), `accent-soft`, `accent-soft2`, `bg`, `surface`, `ink`, `ink2`, `ink3`, `line`, `hi` (secondary highlight used for paid and offers), `hi-soft`, `alert`, `chip`, `bar` (the top bar and sheet headers), `on-bar`, `on-accent`, `on-hi` (text on those fills) and `accent-ink-on-white` (text on white pills). Check contrast: `on-bar` on `bar` and `on-accent` on `accent` need at least 4.5:1 for small text. |
| `engine_brand` | Palette passed to the expressions engine (`--brand`): name, library_title, paper, ink, accent, grey, soft, font_head, font_body. Hex values have no `#`. |
| `brand_lock` | One sentence appended to every gated prompt. It covers type style, colour field, CTA shape and people/setting, and always ends "draw no logos or wordmarks". Base it on the brand's real feed. |
