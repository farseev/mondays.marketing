# Render brief: SOMIN expressions for the {{BRAND}} dashboard

You render images that are already prompted and gated. Do not write or change prompts.

1. **Load the renderer** with ToolSearch: "select:mcp__SOMIN__image-generate". (If that exact name is not found, the SOMIN connector is namespaced differently on this surface, e.g. `mcp__plugin_marketing-mondays_SOMIN__<tool>` in Claude Code: search ToolSearch for "SOMIN <tool>" and use what it returns.)
2. **Load your batch file** (`{{BATCH}}`) with python and work through its entries in order. Each entry has `key` and `prompt_locked`.
3. **Render each entry.** Call mcp__SOMIN__image-generate with:
   - prompt = `prompt_locked`, exactly as written
   - size "1024x1536"
   - quality "medium"
   - the default model
4. **Save each image.** The call returns a `url`. Download it with curl to `{{RUN}}expr/renders/<key>.png`.
   - Skip any key whose png already exists and is over 50 KB.
   - You can run up to 4 image-generate calls in parallel in one message.
   - Use the `prompt_locked` of the entry whose key you are saving. Never mix keys.
5. **Handle failures.**
   - On a 502 or a timeout, wait about a minute and retry the same prompt, up to 3 times.
   - If the content filter rejects a prompt, report the key and its error. Do not reword it.
6. **Verify.** When finished, use python and PIL to check that every key in your batch has a png over 50 KB.

Reply only with: rendered count, skipped count, and the failed keys with their errors.
