# Brief: trending-whitespace chains for the {{BRAND}} dashboard (Marketing view)

**Input.** `{{RUN}}ws_packets.json`. It holds one packet per market × vertical. Each packet carries the top trending possible-whitespace lane from a monthly read of SOMIN data ({{MONTHS}}).

**What a packet contains:**
- **The lane:** its dimension (Audience / Customer need / Topic / Occasion) and value.
- **Monthly figures:** the category share series, item counts, and the monthly {{BRAND}} and competitor share series.
- **Recent figures ({{RECENT_MONTHS}}):** {{BRAND}} and competitor shares with their LOW/MEDIUM/HIGH labels, the two-cohort verdict and the trend class.
- **`ri`:** the organic response index, meaning the lane's median interactions divided by the market-vertical median. It measures response, not demand.
- **Context:** the leading brands, 14 evidence posts, SOMIN study themes and stories for the market, and {{BRAND}}'s real CTAs in that market (`focal_ctas`).
- **`note`:** the like-for-like exclusions.

## Method you must respect
This is the whitespace-analysis rubric in PARTIAL two-cohort mode.
- The workspaces have no audience or creator cohort, so the strongest verdict is **POSSIBLE WHITESPACE — UNVERIFIED**.
- Never call a lane confirmed whitespace or unmet demand. An absence is a content-supply gap.
- **RISING:** the last-3-month share is at least 1.5× the early share and still growing.
- **EMERGING:** the share was near zero before and is now at least 1%.

## Output
Write `{{RUN}}ws_chains.json`: a list with one object per packet.
```
{
 "key": "WS-<MK>-<v>",
 "title": "max 8 words, sentence case, names the lane",
 "signal": {"text": "1-2 sentences with packet numbers: how the lane's share moved month to month, who publishes it, the response index", "figure": "short line, e.g. 'Category share 0.4% → 2.1% · response 4.2×'", "ev": [3-6 evidence ids]},
 "insight": {"quote": "a SOMIN theme summary sentence, theme title or story title, copied EXACTLY", "theme_id": <id or null>, "study_id": <id or null>, "study_name": "...", "type": "pain_points|persona|topics|story", "n": <sampleSize or null>, "story": {"id":..,"title":..} or null, "metric_note": "why this insight fits the lane; say so if it comes from another vertical or source"},
 "opportunity": {"text": "1-2 sentences: the lane {{BRAND}} can test", "verdict": "POSSIBLE WHITESPACE — UNVERIFIED", "trend": "RISING|EMERGING (from the packet)", "verdict_note": "{{BRAND}} X% and competitors Y% of their own content (LOW/LOW), what the trend rests on, the recent sample sizes ({{BRAND}} n vs competitor n, from cohort_sizes_recent), and what would confirm it: a creator or audience cohort read over the same months"},
 "build": {
   "TOFU": {"goal": "...", "idea": "1-2 sentences", "format": "...", "channel": "...", "offer": "none or offer", "why": "cite a packet figure", "refs": [1-3 evidence ids], "sources": ["lane · series", "theme <id>", "post <id>"],
            "concept": {"subtype": "<allowed TOFU subtype>", "hook": "max 7 words, the on-image headline, may be in the market language", "tagline": "the full line"}},
   "MOFU": {... with a MOFU subtype ...},
   "BOFU": {... with a BOFU subtype, plus "cta": one of the packet's focal_ctas exactly as written, max 3 words}
 }
}
```
If the packet has no themes and no stories, use the empty insight form: quote "", ids null, type "none", and metric_note "No SOMIN study covers this market yet.".

**Allowed subtypes** (copy the label string exactly):
- **TOFU:** "1.02 Problem / tension framing", "1.04 Identity / aspiration", "1.05 Peer / community proof", "1.08 Human / empathy moment", "1.09 Vision / \"imagine\"", "1.11 Trend / \"what's changing\"", "1.12 Story / mini-narrative"
- **MOFU:** "2.01 Product capability / feature", "2.02 Solution demo / how-it-works", "2.03 Comparison / \"vs the old way\"", "2.04 Use-case / scenario", "2.06 Reliability / trust / quality", "2.08 Comfort / experience", "2.12 Objection handler / FAQ"
- **BOFU:** "3.01 Offer / booking", "3.04 Trial / starter", "3.09 Limited-time / seasonal activation", "3.10 Pricing / package", "3.11 Reassurance / risk-reversal", "3.12 Direct CTA / \"get started\""

## Rules
1. **Nothing is invented.**
   - Every number comes from the packet.
   - Every quote is exact.
   - Ref ids are evidence ids in that packet.
2. **Pick the SOMIN theme or story whose text genuinely relates to the lane.** If none fits well, use the closest one and say so in `metric_note`.
3. **Make the ideas specific** to {{BRAND}}'s products in that market and vertical, as seen in the evidence. They should be practical and repeatable.
4. **Writing style.**
   - Use short sentences in sentence case.
   - Avoid hype words such as unlock, leverage, seamless or game-changing.
   - Avoid the "X, not Y" construction and em dashes outside the verdict string.
   - Keep hooks to 7 words or fewer.
5. **Load the packets with python** and print one at a time. Do not dump the file.
6. **Validate before replying:** `cd {{RUN}} && python3 {{SKILL}}scripts/validate_chains.py ws ws_chains.json`
   - Fix every ERROR.
   - Read every WARNING.

Reply with the output path, the count, the validator's final ERROR and WARNING counts, and one line of caveats per chain.
