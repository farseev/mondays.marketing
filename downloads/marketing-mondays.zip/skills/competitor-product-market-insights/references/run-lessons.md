# Run lessons (from the first full build: a regional super-app, 6 markets, 45 pages, 110k items, 2026)

Read this before the harvest and again before publishing. Each item cost real time once.

## SOMIN harvest
- **A workspace query without `profileIds` under-counts badly.** In one run it returned 4 of 45 profiles. Always pass every profile id and `source`.
- **SOMIN caps a query at about 1,200 rows**, and date-sorted paging can skip about 3% of rows at page boundaries. Query in monthly slices. Gate every profile and source against `posts-aggregate`, and re-pull short months sorted by total_engagement.
- **posts-search calls can take up to 180 s.** Run harvest agents in parallel (one per market, or two for very large markets) and keep briefs self-contained.
- **Saved results.** Large results are saved by the harness to a shared tool-results folder, and parallel agents ingested each other's files when they globbed it. Each agent must extract only from the paths its own calls produced.
- **Inline results.** Small results come back inline. Group small profiles into one query so pages fill. Write unavoidable inline tails to raw/inline/ exactly as returned, then extract.
- **Shared advertisers come back under one page id.** Shared LinkedIn pages and shared Google advertisers do this (the focal brand's Google ads sat on one market's page but targeted three others). Keep every row, dedupe by id, and let merge.py move ads by their single country code.
- **Re-extracting saved files with one `--src` flag mislabels ads as organic.** merge.py corrects rows whose sourceType ends in `_ads`, but use the right flag.
- **Placeholder ad dates.** Google ads often carry 2020-01-01, and other dates appear in bulk (2025-01-01). These count 0 ad-days. Scan coverage.json for start-date pile-ups and add them to spec.placeholder_dates.
- **Collection starts mid-window.** Instagram Stories began in Mar 2026 in that run, and paid monitoring began Jan–Mar 2026 for most advertisers. The coverage table from merge.py shows it. Put such platforms in like_for_like_exclude and let the page note thin early paid months.
- **Allow for long runtimes.** A 12-month, 6-market harvest takes a few hours of agent time. Pull the recent 90 days first if the user needs an early draft, then backfill.

## Analysis
- **Whitespace pollution.** The first whitespace read was polluted by LinkedIn corporate posts, which are global pages repeated in every market, and by one-month spikes. Hence whitespace_exclude_platforms = LinkedIn and the presence and concentration rules. Re-check the top lanes by eye. A corporate topic such as "Company Culture" can still pass, and the chain writer may pick the next lane if it explains why.
- **Verdict ceiling.** With only focal and competitor cohorts, the honest ceiling is POSSIBLE WHITESPACE — UNVERIFIED. Say what would confirm it: a creator or audience panel read over the same months. Never call a lane unmet demand.
- **Duplicate first-seen rows.** First-seen tables listed case and punctuation variants of the same offer. The page canonicalises keys, so keep that logic when editing.
- **Skewed interaction totals.** One market can dominate them (Thai celebrity comment-to-win posts drew millions of comments). Say so in known_gaps instead of silently trimming.

## Expressions
- **The engine's master template can contradict the brand.** It described the focal brand as "all-serif". The brand_lock suffix, appended after the gate, fixes type, colour field, CTA shape and setting, and forbids logos.
- **Render agents sent the wrong prompt** for a key 3 times out of 108. Always build contact sheets (contact_sheet.py), compare every image with its hook, and re-render mismatches yourself from `prompt_locked`.
- **Hooks.** Hooks over 7 words render as garbled text blocks. BOFU CTAs must be the brand's real ad CTAs (ctas.json) and no more than 3 words.
- **The engine key** goes in the EXPRESSIONS_KEY environment variable inside the same command. Never write it to the run directory, a brief, or the page, and never print the decrypted engine.

## Page and publishing
- **Encoding.** Without `<meta charset="utf-8">`, Thai and Vietnamese text turned to mojibake. build_page.py writes it.
- **`[hidden]`** must be `display:none!important`, or the incentive dropdown never closes. This is already in base.css.
- **Phone layout.** Sticky control bars filled the whole phone screen, so under 640 px they are static. Expression images need a max width (250 px in cards).
- **Dark mode.** The coloured bar needs its own dark-mode token (`bar`) with enough contrast for `on-bar`.
- **Ad end dates.** Dates are day numbers from 1 January of the window-end year, so ads that ended the year before are negative. "No end date" is encoded as 99999. An earlier -1 sentinel counted Oct–Dec ads as live and inflated ad-days: the food KPI read 38% against a correct 51%. qa_render.py now checks that the KPI tile and the share card agree.
- **Artifact limits.** A publish holds 64 MB and 255 files, and each file must stay under 16 MB. split_publish.py groups the files. Publish part 1 (page, meta, columns) first, then the other parts to the same artifact URL. Thumbnail bundles are capped at about 14 MB per page.
- **Keep only SOMIN data on the page.** Every number must be computed, every quote must be from a SOMIN study, and every example must be a real post the viewer can open. A dashboard that invents one figure loses the room.
