# Method: what every number on the page means

Read this when you need to explain a figure to the user, change a rule, or write the scope notes.

## Contents
1. Records and windows
2. Metrics
3. Derived fields
4. Filters
5. Insight cards
6. Monthly trends
7. Whitespace
8. Chains and expressions

## 1. Records and windows
- **One record** is one organic post (SOMIN source PAGES) or one ad (ADS_LIBRARY), deduped by SOMIN id across every harvest file. When an id appears twice, the copy with the later end date wins, and missing profile fields are filled from the other copy.
- **The window** (spec.window) covers organic posts dated inside it and ads live at any point inside it. SOMIN uses "active in window" semantics for ads.
- **The recent period** is the last `recent_days` (default 90) ending on the window end. It drives the insight cards, chain packets, the weekly launch radar and the "Last 90 days" pill.
- **Trend months** are the full calendar months inside the window. RECENT is the last 3 months and EARLY is the 6 before those.
- **Market reassignment.** An ad whose SOMIN country list holds exactly one spec market, different from its page's market, is moved to the same brand's page in that market. Shared Google and LinkedIn advertisers otherwise pile onto one market.

## 2. Metrics
- **Organic interactions** = max(likes, reactions) + comments + shares + reposts.
- **Paid ad-days** = the days an ad was live inside the selected period, counting both ends. Ads with a placeholder start date (spec.placeholder_dates, or anything before 2024-06-01) count 0 ad-days and are left out of new-ad counts. They still appear as "live in period". Ad-days measure sustained presence. They are not spend.
- **Shares.** The focal share of ad-days or interactions is the focal pages' total divided by all pages in view, regulators included only in the totals.
- **Response index** = a lane's median organic interactions divided by the market-vertical median. It measures response, not demand.

## 3. Derived fields (merge.py + cfg.py)
- **Vertical.** A single-vertical brand (spec.brand_verticals) keeps its vertical. For a multi-vertical brand, each post is classified by counting `verticals[].keywords` matches in products, product types, topic, title, topic categories and the first 300 characters of text. Ties go to the vertical whose keywords appear in the product tags. A post with no match is "other", which shows only under "All".
- **Funnel stage.**
  - **BOFU:** a Discounts content type or a discount, voucher, free-shipping or cashback perk type.
  - **TOFU:** brand-awareness tactic, or community, CSR, topical, culture, PSA or pop-culture content with no product-feature, value-added, testimonial or educational content.
  - **MOFU:** everything else.
- **Offer and product families.** These are regex bitmasks over SOMIN's perk, product and product-type tags (taxonomy_default.json, or the spec override).
- **Launch flag.** A launch phrase (in several languages) appears in the text or title.
- **Offering type** comes from SOMIN goodsServices (Goods, Services, or both). **Segment** comes from SOMIN natureOfComms (B2C, B2B, or both).
- **Incentive types** are SOMIN perkType, normalised (Coupons and Vouchers become Vouchers/Coupons, and so on), keeping the top 14. **Customer needs** are SOMIN humanNeed, top 18, with "General" and "Undetermined" dropped.

## 4. Filters (all client-side)
The filters are vertical, market, channel tick boxes, period (recent vs full window), offering, segment and incentive types (any-of). Insight cards are computed before the offering, segment and incentive filters, and the page says so. Charts, tables, advertiser dashboards and content plates honour every filter.

## 5. Insight cards (insights.py)
Every card is a template filled from computed numbers. Its evidence ids are the posts or ads that produced the number, deduped by creative collation id and ranked by metric. Cards exist only when their threshold is met.

**Recent cards:**

| Card | What it shows | Threshold |
|---|---|---|
| share | The focal share of ad-days and the largest competitor advertiser | Any paid activity |
| offer-gap | An offer family on new competitor ads vs new focal ads | 30+ competitor and 15+ focal new ads; competitor share ≥12%; gap ≥8 points |
| offer-lead | An offer family the focal brand uses more than rivals | Focal share ≥15%; lead ≥10 points |
| spike | A competitor's biggest week of new ads | ≥20 ads and ≥3× that page's weekly average |
| offer | The most repeated competitor offer string in the last 30 days | ≥5 ads |
| launch | Distinct competitor launch messages in the last 60 days | Any launch message |
| organic-lead | The competitor with the highest interactions per post | 2+ brands with 15+ posts each |
| format | A content type with high median response | 25+ posts and ≥1.5× the median post |
| product | A product family competitors push more than the focal brand | 50+ competitor items; competitor share 6–60% |
| pattern | The same competitor offer string in 2+ markets, plus any spec.curated_rules | 2+ markets |

**Trend cards** (like-for-like, EARLY vs RECENT months):

| Card | What it shows | Threshold |
|---|---|---|
| product-trend, need-trend, incentive-trend | The biggest rise in competitor share | ≥4 points; 15+ recent items; recent share ≥5% |
| new-offer, new-product | Offers or products first seen after the 4th trend month | Page tracked 60+ days before; 6+ items |
| share-trend | The focal share of ad-days in months -7..-5 vs RECENT | Both windows >300 ad-days; a move of ≥5 points |
| launch-month | A competitor's biggest month of new ads | ≥40 ads and ≥3× its monthly average |

## 6. Monthly trends (page)
- **Like-for-like.** Platforms in like_for_like_exclude are dropped unless the viewer ticks them back in. Ads count in the month they started. Paid tracking starts per advertiser (coverage.json first_ad), so early paid months can be thin. The page says so when 3 or more advertisers started late.
- **First-seen table.** An offer or product (with canonicalised text) counts as new when it is first seen after the 4th trend month, on a page tracked at least 60 days before it, with at least 3 items.

## 7. Whitespace (whitespace.py): whitespace-analysis rubric, PARTIAL two-cohort mode
- **Lanes** are the values of SOMIN audience, customer-need, topic and occasion tags. Generic values are dropped, and so are tactic values (promo, sale, discount, launch, voucher and the like).
- **Excluded platforms:** whitespace_exclude_platforms plus like_for_like_exclude. **Excluded pages:** regulators.
- **Cohort coverage** is the share of a cohort's RECENT items carrying the lane: LOW < 5%, MEDIUM 5–20%, HIGH > 20%.
- **Verdicts:**
  - **POSSIBLE WHITESPACE — UNVERIFIED:** both cohorts LOW. Without an audience or creator cohort, nothing stronger is possible.
  - **COMPETITOR-LED:** focal LOW.
  - **<BRAND>-LED:** competitors LOW.
  - **BLOCKED:** competitors HIGH and focal MEDIUM.
  - **CONTESTED:** everything else.
- **Trend classes**, computed on the lane's monthly share of all items:
  - **SINGLE-SHOT:** one month holds over 50% of the lane's items.
  - **DECAYED:** early share ≥ 2% and recent < 0.5%.
  - **EMERGING:** early < 0.5% and recent ≥ 1%.
  - **RISING:** recent ≥ 1.5× early, above the previous 3 months, and ≥ 1%.
  - **FALLING:** recent ≤ 0.67× early.
  - **SUSTAINED:** everything else.
- **Trending** requires all of these:
  - the verdict is POSSIBLE WHITESPACE and the trend is RISING or EMERGING
  - the response index is at least 0.8
  - the lane has items in each of the last 3 months
  - no month holds over 40% of the lane
  - the last month is at least half the average of the two before it

  Trending lanes are ranked by trend × response index × volume.

## 8. Chains and expressions
- **Chain packets** hold the funnel-stage candidates (the top 8 per stage by metric, deduped by creative) plus the SOMIN themes and stories for the market. Themes are ranked by study-name match to the vertical (study_tokens) and the source.
- **Chain writers** may only use packet content. validate_chains.py enforces exact quotes, real refs, the verdict rubric, subtypes, hooks of 7 words or fewer, real focal CTAs and style.
- **Expressions.**
  - concepts.py turns each chain into one pillar with a TOFU, a MOFU and a BOFU concept.
  - The SOMIN expressions engine (somin-creative-expressions skill, if installed) builds every prompt from its encrypted master template, and check_prompts.py gates the result and writes the manifest.
  - The theme's brand_lock sentence is appended after the gate.
  - Renders are 1024×1536 at medium quality, checked on contact sheets, and shipped as 560 px JPGs.
