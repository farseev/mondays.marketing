# Brief: SOMIN insight inventory for the {{BRAND}} dashboard

Collect the SOMIN Perspective Studies (with their themes) and the insight stories that already exist in these workspaces: **{{WORKSPACES}}**. They become the "SOMIN insight" step of every marketing chain, so the chain writers can quote them. Do not create studies or stories, and do not summarise anything.

## Tools
Load them with ToolSearch: "select:mcp__SOMIN__studies-list,mcp__SOMIN__studies-get,mcp__SOMIN__stories-list". (If that exact name is not found, the SOMIN connector is namespaced differently on this surface, e.g. `mcp__plugin_marketing-mondays_SOMIN__<tool>` in Claude Code: search ToolSearch for "SOMIN <tool>" and use what it returns.)

## Steps
1. **For each workspace,** call `studies-list`. Then call `studies-get` for every study to fetch its themes. Fetch each theme's id, type, title, summary, sampleSize and per-profile metrics.
2. **For each workspace,** call `stories-list` and page through all stories.
3. **Handle saved results.** Large results are saved to files by the harness. Load them with python. Never read them into your context, and only use paths your own calls produced.
4. **Write `{{RUN}}somin_insights.json`** with python, in exactly this shape. Keep the field values as SOMIN returned them.
```
{"workspaces": [
  {"workspaceId": 0, "workspaceName": "...",
   "studies": [{"studyId": 0, "name": "...", "dateWindows": ..., "themes": [
       {"id": 0, "type": "pain_points|persona|topics|...", "title": "...", "summary": "...", "sampleSize": 0, "metrics": [ {...per-profile metric objects...} ]}]}],
   "stories": [{"id": 0, "title": "...", "summary": "...", "character": {"characterName": "...", "theme": "..."}, "theme": "...", "angle": "..."}]}
]}
```
5. **Report empty workspaces** (no studies, or no stories) in your reply. Do not fill them with anything.

## Reply with only
- one line per workspace: id, name, study count, theme count, story count
- the output path
- any errors
