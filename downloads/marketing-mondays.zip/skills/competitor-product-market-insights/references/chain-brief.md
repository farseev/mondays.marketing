# Brief: marketing insight chains for the {{BRAND}} dashboard (recent window)

You are writing part of the "Marketing" view of a competitive dashboard for {{BRAND}}'s marketing and insights teams.

**Input.** `{{RUN}}chain_packets.json`. Your packets are: **{{KEYS}}**. Each packet covers one market × vertical × source (organic or paid) over {{RECENT}} and holds real SOMIN data:
- counts, the {{BRAND}} metric share, and the funnel mix (TOFU / MOFU / BOFU %) for {{BRAND}} vs competitors
- competitor content types and offer types
- per funnel stage: the pool size, {{BRAND}} share, median metric and up to 8 top candidate posts. Each candidate has an id, brand, platform, content types, tone, perks, products, audiences, needs, CTA, SOMIN `humanInsight` and `proposition`, title and text.
- `somin_themes`: Perspective Study themes (pain points, personas, topics) with ids, study ids, sample sizes and per-profile metrics
- `somin_stories`: SOMIN insight stories (persona, theme, angle)
- `focal_ctas`: {{BRAND}}'s real ad CTAs in that market

**How funnel stages were assigned:**
- **BOFU:** a discount, voucher, free-shipping or cashback perk.
- **TOFU:** brand awareness, community, CSR or topical content without a discount.
- **MOFU:** everything else.

**Metrics.** Organic is measured in interactions. Paid is measured in active ad-days, a proxy for sustained presence. Ad-days are not spend.

Load the file with python and print one packet at a time in compact form. Do not dump the whole file into your context.

## Output
Write `{{RUN}}chains_{{PART}}.json`: a JSON list with one object per assigned packet.
```
{
 "key": "<packet key>",
 "title": "chain name, max 8 words, sentence case",
 "signal": {"text": "1-2 sentences on what the data shows, numbers copied from the packet", "figure": "one short figure line, e.g. '{{BRAND}} 62% BOFU vs competitors 38%'", "ev": [2-6 candidate post ids that show it]},
 "insight": {"quote": "a theme summary sentence or theme title, copied EXACTLY", "theme_id": 123, "study_id": 456, "study_name": "...", "type": "pain_points|persona|topics|...", "n": <sampleSize>, "metric_note": "one line from the theme's per-profile metrics with exact numbers, or why this theme fits", "story": {"id": 0, "title": "..."} or null},
 "opportunity": {"text": "1-2 sentences: the lane {{BRAND}} can take", "verdict": "POSSIBLE WHITESPACE — UNVERIFIED" | "OCCUPIED — <brand> leads" | "CONTESTED — <brands>" | "{{BRAND_UPPER}}-LED", "verdict_note": "what the verdict rests on and what would confirm it"},
 "build": {
   "TOFU": {"goal": "...", "idea": "1-2 sentences: a concrete post or series", "format": "e.g. 15s vertical video, carousel", "channel": "platform(s) present in the packet", "offer": "none or the offer", "why": "one sentence citing a packet figure or the reference posts", "refs": [1-3 ids from stages.TOFU.candidates], "sources": ["analysis · <packet field>", "theme <id>", "post <id>"],
            "concept": {"subtype": "<allowed TOFU subtype>", "hook": "max 7 words, the on-image headline, may be in the market language", "tagline": "the full line"}},
   "MOFU": {... the same fields; refs from stages.MOFU.candidates; a MOFU subtype},
   "BOFU": {... the same fields; refs from stages.BOFU.candidates; a BOFU subtype; plus "cta": one of the packet's focal_ctas exactly as written, max 3 words}
 }
}
```
If a packet has no `somin_themes` and no stories, set `insight` to {"quote": "", "theme_id": null, "study_id": null, "study_name": "", "type": "none", "n": null, "metric_note": "No SOMIN study covers this market yet.", "story": null}. Never write a quote that is not in the packet.

**Allowed subtypes** (copy the label string exactly):
- **TOFU:** "1.02 Problem / tension framing", "1.04 Identity / aspiration", "1.05 Peer / community proof", "1.08 Human / empathy moment", "1.09 Vision / \"imagine\"", "1.11 Trend / \"what's changing\"", "1.12 Story / mini-narrative"
- **MOFU:** "2.01 Product capability / feature", "2.02 Solution demo / how-it-works", "2.03 Comparison / \"vs the old way\"", "2.04 Use-case / scenario", "2.06 Reliability / trust / quality", "2.08 Comfort / experience", "2.12 Objection handler / FAQ"
- **BOFU:** "3.01 Offer / booking", "3.04 Trial / starter", "3.09 Limited-time / seasonal activation", "3.10 Pricing / package", "3.11 Reassurance / risk-reversal", "3.12 Direct CTA / \"get started\""

## Rules
1. **Nothing is invented.**
   - Every number comes from the packet.
   - Every quote is copied character for character from a theme summary or title, or a story title.
   - Every ref id exists in the matching stage's candidates.
2. **Pick the insight that best explains the signal.** Choose it from `somin_themes` or `somin_stories`. Prefer themes whose study name matches the vertical and the source. If the best theme comes from another vertical or source, say so in `metric_note`.
3. **Verdict rubric.** With only brand and competitor cohorts, the strongest verdict is "POSSIBLE WHITESPACE — UNVERIFIED".
   - Use it only when competitors and {{BRAND}} both under-index on the lane. {{BRAND}}'s own absence alone is never whitespace.
   - When a competitor holds the lane, write OCCUPIED or CONTESTED and name the brand.
   - `verdict_note` says what would confirm the verdict, such as an audience or creator cohort read over the same window.
4. **What to Build.** Give one TOFU, one MOFU and one BOFU idea that move the same insight down the funnel.
   - Make them practical and specific to the market's language, products and offers seen in the candidates.
   - Make each one repeatable as a format.
5. **Writing style.**
   - Use short declarative sentences in sentence case.
   - Avoid hype words such as unlock, leverage, seamless or game-changing.
   - Avoid the "X, not Y" construction and em dashes. The only em dashes allowed are inside the verdict strings above.
   - Name brands, products and formats specifically.
6. **Validate before replying:** `cd {{RUN}} && python3 {{SKILL}}scripts/validate_chains.py chains chains_{{PART}}.json`
   - Fix every ERROR.
   - Read every WARNING. A number that is simple arithmetic on packet figures is fine. Otherwise fix it.

Reply with: the output path, the number of chains written, the validator's final ERROR and WARNING counts, and any packet you skipped and why.
