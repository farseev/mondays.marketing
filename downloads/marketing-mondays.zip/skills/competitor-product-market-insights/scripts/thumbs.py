#!/usr/bin/env python3
"""Pick the posts that get a thumbnail and download them as small inline JPEGs (resumable).

Usage: python3 thumbs.py [--max 6000] [--size 220]
Selection: every evidence id the page can open first (insight cards, chain refs, whitespace lanes), plus per page
and source the top posts by metric and the latest posts, plus the top posts per page per month for the trend views.
Writes thumb_urls.json and thumbs_cache.json ({id: data-uri}). Re-running only fetches what is missing.
Image hosts must be reachable from the workspace; if every download fails, the page still works (cards show text only).
"""
import json, pickle, io, base64, os, sys, collections as C, concurrent.futures as cf, urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

MAX = int(sys.argv[sys.argv.index('--max') + 1]) if '--max' in sys.argv else 6000
SIZE = int(sys.argv[sys.argv.index('--size') + 1]) if '--size' in sys.argv else 220
recs, prof, PERKT, NEEDS = pickle.load(open(RUN + 'recs.pkl', 'rb'))
byid = {r['id']: r for r in recs}
def J(f): return json.load(open(RUN + f)) if os.path.exists(RUN + f) else []

first, rest = [], []
for f in ('insights_recent.json', 'insights_trend.json'):
    for i in J(f): first += i['ev'][:16]
for f in sorted(os.listdir(RUN)):
    if (f.startswith('chains_') or f == 'ws_chains.json') and f.endswith('.json'):
        for c in J(f):
            first += c['signal'].get('ev', [])
            for st in ('TOFU', 'MOFU', 'BOFU'): first += (c['build'].get(st) or {}).get('refs', [])
for p in J('chain_packets.json'):
    for st in p['stages'].values(): first += [x['id'] for x in st['candidates']]
ws = J('whitespace.json') or {}
for w in (ws.values() if isinstance(ws, dict) else []):
    for l in w['lanes']: first += l['ev'][:12]
byps = C.defaultdict(list)
for r in recs: byps[(r['pid'], r['src'])].append(r)
for (pid, src), rs in byps.items():
    seen = set()
    for r in sorted(rs, key=lambda r: -(r['_m'] if src == 'organic' else adays(r, R_START, W_END))):
        k = r.get('col') or r['id']
        if k in seen: continue
        seen.add(k); rest.append(r['id'])
        if len(seen) >= 22: break
    rest += [r['id'] for r in sorted(rs, key=lambda r: r['d'], reverse=True)[:10]]
bypm = C.defaultdict(list)
for r in recs:
    if r['src'] == 'organic': bypm[(r['pid'], r['d'][:7])].append(r)
for k, rs in bypm.items(): rest += [r['id'] for r in sorted(rs, key=lambda r: -r['_m'])[:3]]

U, order = {}, []
for i in first + rest:
    r = byid.get(i)
    if r and r.get('img') and str(i) not in U:
        U[str(i)] = r['img']; order.append(str(i))
    if len(U) >= MAX: break
json.dump(U, open(RUN + 'thumb_urls.json', 'w'))
print('selected', len(U), 'thumbnails (', len(set(first)), 'evidence ids first )')

from PIL import Image
out = json.load(open(RUN + 'thumbs_cache.json')) if os.path.exists(RUN + 'thumbs_cache.json') else {}
out = {k: v for k, v in out.items() if k in U}
todo = [(k, U[k]) for k in order if k not in out]
def get(ku):
    k, u = ku
    for _ in range(2):
        try:
            b = urllib.request.urlopen(u, timeout=25).read()
            im = Image.open(io.BytesIO(b)).convert('RGB'); im.thumbnail((SIZE, SIZE))
            buf = io.BytesIO(); im.save(buf, 'JPEG', quality=58, optimize=True)
            return k, 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode()
        except Exception:
            pass
    return k, None
fails = 0
with cf.ThreadPoolExecutor(48) as ex:
    for i, (k, v) in enumerate(ex.map(get, todo)):
        if v: out[k] = v
        else: fails += 1
        if i % 500 == 0:
            print(i, 'of', len(todo), 'cached', len(out), flush=True)
            json.dump(out, open(RUN + 'thumbs_cache.json', 'w'))
json.dump(out, open(RUN + 'thumbs_cache.json', 'w'))
print('thumbnails cached', len(out), 'of', len(U), 'failed', fails, 'size MB', round(sum(len(v) for v in out.values()) / 1e6, 1))
if todo and fails == len(todo): print('WARNING: every download failed: the image host is probably blocked from this workspace')
