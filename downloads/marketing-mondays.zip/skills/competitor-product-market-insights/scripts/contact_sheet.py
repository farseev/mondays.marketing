#!/usr/bin/env python3
"""Labelled contact sheet of expression renders, to check each image matches its concept before it ships.

Usage: python3 contact_sheet.py [--cols 6] [--per 36]       (run from the run directory)
Writes expr/sheet_<n>.jpg grids (key + stage + hook under each thumbnail). Open each sheet with Read and compare
every image with its hook: render agents sometimes send the wrong prompt. Re-render any mismatch from prompt_locked.
"""
import json, glob, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import RUN
from PIL import Image, ImageDraw, ImageFont

COLS = int(sys.argv[sys.argv.index('--cols') + 1]) if '--cols' in sys.argv else 6
PER = int(sys.argv[sys.argv.index('--per') + 1]) if '--per' in sys.argv else 36
EX = RUN + 'expr/'
hooks = {}
for f in ('concepts_chains.json', 'concepts_ws.json'):
    if os.path.exists(EX + f):
        for ins in json.load(open(EX + f))['insights']:
            for k, c in zip('TMB', ins['concepts']): hooks[f"P{ins['pillar_id']}-{k}-01"] = c['hook']
keys = sorted([os.path.basename(p)[:-4] for p in glob.glob(EX + 'renders/*.png')], key=lambda k: (int(k[1:].split('-')[0]), k))
if not keys: sys.exit('no renders in expr/renders/')
try: font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
except Exception: font = ImageFont.load_default()
W, H, CAP = 240, 360, 52
for s in range(0, len(keys), PER):
    chunk = keys[s:s + PER]; rows = (len(chunk) + COLS - 1) // COLS
    sheet = Image.new('RGB', (COLS * W, rows * (H + CAP)), 'white'); d = ImageDraw.Draw(sheet)
    for i, k in enumerate(chunk):
        x, y = (i % COLS) * W, (i // COLS) * (H + CAP)
        im = Image.open(EX + f'renders/{k}.png').convert('RGB'); im.thumbnail((W - 8, H - 8)); sheet.paste(im, (x + 4, y + 4))
        d.text((x + 6, y + H), k, fill='black', font=font)
        d.text((x + 6, y + H + 18), (hooks.get(k, '?'))[:30], fill=(90, 90, 90), font=font)
    out = EX + f'sheet_{s // PER}.jpg'; sheet.save(out, quality=78); print(out, len(chunk), 'renders')
