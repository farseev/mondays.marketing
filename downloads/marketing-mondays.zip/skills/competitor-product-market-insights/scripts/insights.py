#!/usr/bin/env python3
"""Insight cards with evidence ids.

Writes insights_recent.json (the recent window, default 90 days) and insights_trend.json (month-on-month,
like-for-like). Every card is {id, mk, v, kind, head, body, ev[], src}. head/body may use **bold**.
Every sentence is a template filled from computed numbers, so nothing here is free-written.
Optional spec.curated_rules add regex-defined pattern cards (see references/spec.md).
"""
import json, re, pickle, collections as C, statistics, datetime as dt, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

recs, prof, PERKT, NEEDS = pickle.load(open(RUN + 'recs.pkl', 'rb'))
OFN = [o[0] for o in OFFER]; PFN = [p[0] for p in PRODFAM]
B = lambda r: prof[r['pid']]['name']
def comp(r): return not prof[r['pid']]['focal'] and not prof[r['pid']]['regulator']
def bn(r, mk): return f"{B(r)} ({r['_mk']})" if mk == 'ALL' else B(r)
def where(mk, v): return f"{VLAB[v].lower()} in {MKN[mk]}" if mk != 'ALL' else f"{VLAB[v].lower()} across the {len(MARKETS)} markets"
def wk(d): x = dt.date.fromisoformat(d); return (x - dt.timedelta(days=x.weekday())).isoformat()
def uniq(rs, k=40, key=lambda r: -r['_mr']):
    seen, out = set(), []
    for r in sorted(rs, key=key):
        kk = r.get('col') or r['id']
        if kk in seen: continue
        seen.add(kk); out.append(r['id'])
        if len(out) >= k: break
    return out

# ---------------- recent window ----------------
REC = []
for r in recs:
    if r['src'] == 'organic' and not (R_START <= r['d'] <= W_END): continue
    if r['src'] == 'paid' and r['end'] and r['end'] < R_START: continue
    r['_mr'] = r['_m'] if r['src'] == 'organic' else adays(r, R_START, W_END)
    REC.append(r)
INS = []
def add(store, mk, v, kind, head, body, ev, src=None):
    if ev: store.append({'id': f'{"r" if store is INS else "t"}{len(store)}', 'mk': mk, 'v': v, 'kind': kind, 'head': head, 'body': body, 'ev': ev[:60], 'src': src})
def sel(rs, mk, v, src=None, focal=None):
    out = []
    for r in rs:
        if mk != 'ALL' and r['_mk'] != mk: continue
        if v != 'all' and r['_v'] != v: continue
        if src and r['src'] != src: continue
        if focal is True and not r['_g']: continue
        if focal is False and not comp(r): continue
        out.append(r)
    return out
allweeks = sorted({wk(r['d']) for r in REC if r['src'] == 'paid' and r['d'] >= R_START and not r['_ph']})
for mk in MARKETS + ['ALL']:
    for v in VKEYS + ['all']:
        W = where(mk, v); paid = sel(REC, mk, v, 'paid'); org = sel(REC, mk, v, 'organic')
        if paid:
            tot = sum(r['_mr'] for r in paid); g = sum(r['_mr'] for r in paid if r['_g'])
            byb = C.Counter()
            for r in paid:
                if comp(r): byb[bn(r, mk)] += r['_mr']
            if byb and tot:
                lead, lv = byb.most_common(1)[0]; lr = [r for r in paid if comp(r) and bn(r, mk) == lead]
                add(INS, mk, v, 'share', f"{BRAND} holds **{pct(g, tot)}%** of paid ad-days in {W}.",
                    f"{lead} is the largest competitor advertiser with {pct(lv, tot)}% of ad-days ({fmt(len(lr))} ads). Ad-days count each day an ad was live in the last {RECENT_DAYS} days.", uniq(lr), 'paid')
        np_ = [r for r in paid if r['d'] >= R_START and not r['_ph']]
        cp = [r for r in np_ if comp(r)]; gp = [r for r in np_ if r['_g']]
        if len(cp) >= 30 and len(gp) >= 15:
            def sh(rs, i): return sum(1 for r in rs if r['_o'] >> i & 1) / len(rs)
            best = max(((sh(cp, i) - sh(gp, i), i) for i in range(len(OFN)) if sh(cp, i) >= .12), default=None)
            if best and best[0] >= .08:
                i = best[1]; ev = [r for r in cp if r['_o'] >> i & 1]; lb = C.Counter(bn(r, mk) for r in ev).most_common(2)
                add(INS, mk, v, 'offer-gap', f"**{OFN[i]}** is on {round(sh(cp, i)*100)}% of new competitor ads in {W}, against {round(sh(gp, i)*100)}% of {BRAND}'s.",
                    f"Most of it comes from {', '.join(f'{b} ({n} ads)' for b, n in lb)}. Based on {fmt(len(cp))} competitor and {fmt(len(gp))} {BRAND} ads started in the period.", uniq(ev), 'paid')
            lead = max(((sh(gp, i) - sh(cp, i), i) for i in range(len(OFN)) if sh(gp, i) >= .15), default=None)
            if lead and lead[0] >= .1:
                i = lead[1]
                add(INS, mk, v, 'offer-lead', f"{BRAND} leans on **{OFN[i].lower()}** more than rivals: {round(sh(gp, i)*100)}% of its new ads vs {round(sh(cp, i)*100)}%.",
                    "Use the competitor share as the benchmark when deciding whether to keep or rotate this offer.", uniq([r for r in gp if r['_o'] >> i & 1]), 'paid')
        byb = C.defaultdict(list)
        for r in cp: byb[bn(r, mk)].append(r)
        spikes = []
        for b, rs in byb.items():
            w = C.Counter(wk(r['d']) for r in rs)
            if len(w) < 2: continue
            top, n = w.most_common(1)[0]; others = [w.get(x, 0) for x in allweeks if x != top]
            avg = round(sum(others) / max(len(others), 1), 1)
            if n >= 20 and n >= 3 * max(avg, 1):
                burst = [r for r in rs if wk(r['d']) == top]; perk = C.Counter(p for r in burst for p in r['perk']).most_common(1)
                spikes.append((n, b, top, avg, burst, perk))
        for n, b, top, avg, burst, perk in sorted(spikes, key=lambda x: -x[0])[:3 if mk == 'ALL' else 2]:
            add(INS, mk, v, 'spike', f"**{b}** started **{n} new ads** in the week of {dmy(top)}.",
                f"Across the other weeks it averaged {avg:g} new ads a week." + (f" The most repeated offer in the burst: “{perk[0][0]}”." if perk else ""), uniq(burst), 'paid')
        last30 = (dt.date.fromisoformat(W_END) - dt.timedelta(days=30)).isoformat()
        pc = C.Counter(); who = C.defaultdict(set); evs = C.defaultdict(list)
        for r in [r for r in paid if comp(r) and r['d'] >= last30]:
            for p_ in {x.lower() for x in r['perk']}:
                if len(p_) < 4 or p_ in ('undetermined', 'none'): continue
                pc[p_] += 1; who[p_].add(bn(r, mk)); evs[p_].append(r)
        if pc:
            p_, n = pc.most_common(1)[0]
            if n >= 5: add(INS, mk, v, 'offer', f"The most repeated competitor offer of the last 30 days: **“{p_}”**.", f"It appears on {n} ads from {', '.join(sorted(who[p_]))}.", uniq(evs[p_]), 'paid')
        last60 = (dt.date.fromisoformat(W_END) - dt.timedelta(days=60)).isoformat()
        seen, la = set(), []
        for r in sorted([r for r in sel(REC, mk, v, None, False) if r['_la'] and r['d'] >= last60], key=lambda r: r['d'], reverse=True):
            k = (r['pid'], (r['title'] or r['text'])[:50])
            if k in seen: continue
            seen.add(k); la.append(r)
        if la:
            lb = C.Counter(bn(r, mk) for r in la).most_common(3); ex = [r for r in la if bn(r, mk) == lb[0][0]]
            add(INS, mk, v, 'launch', f"**{fmt(len(la))}** distinct competitor messages announced a launch or new service in the last 60 days.",
                f"Most came from {', '.join(f'{b} ({n})' for b, n in lb)}. Latest from {lb[0][0]} ({dmy(ex[0]['d'])}): “{(ex[0]['title'] or ex[0]['text'])[:110].strip()}”.", [r['id'] for r in la])
        if org:
            byb = C.defaultdict(list)
            for r in org:
                if not prof[r['pid']]['regulator']: byb[bn(r, mk)].append(r)
            avg = {b: sum(r['_m'] for r in rs) / len(rs) for b, rs in byb.items() if len(rs) >= 15}
            if len(avg) >= 2:
                lead = max(avg, key=avg.get); gk = [b for b in avg if b.startswith(BRAND)]
                gt = f"{BRAND} averages {fmt(round(sum(avg[b] for b in gk)/len(gk)))}. " if gk and not lead.startswith(BRAND) else ""
                add(INS, mk, v, 'organic-lead', f"**{lead}** draws the most response per organic post in {W}: **{fmt(round(avg[lead]))}** interactions on average.",
                    f"{gt}Interactions are likes or reactions plus comments and shares, from {fmt(len(byb[lead]))} posts.", uniq(byb[lead], 30), 'organic')
            ctm = C.defaultdict(list)
            for r in org:
                for c in r['ct']: ctm[c].append(r)
            allmed = statistics.median([r['_m'] for r in org]) or 1
            cand = {c: statistics.median([r['_m'] for r in rs]) for c, rs in ctm.items() if len(rs) >= 25 and c not in ('Undetermined', 'Product Offering')}
            if cand:
                c = max(cand, key=cand.get)
                if cand[c] >= 1.5 * allmed:
                    add(INS, mk, v, 'format', f"Posts tagged **{c}** earn a median **{fmt(round(cand[c]))}** interactions, {cand[c]/allmed:.1f}× the median organic post in {W}.",
                        f"{fmt(len(ctm[c]))} posts carry this content type.", uniq(ctm[c], 30), 'organic')
        cr = sel(REC, mk, v, None, False); gr = sel(REC, mk, v, None, True)
        if len(cr) >= 50:
            best = None
            for i in range(len(PFN)):
                sc = sum(1 for r in cr if r['_pf'] >> i & 1) / len(cr); sg = sum(1 for r in gr if r['_pf'] >> i & 1) / max(len(gr), 1)
                if sc >= .06 and sc < .6 and (best is None or sc - sg > best[0]): best = (sc - sg, i, sc, sg)
            if best and best[0] > .03:
                _, i, sc, sg = best; ev = [r for r in cr if r['_pf'] >> i & 1]; lb = C.Counter(bn(r, mk) for r in ev).most_common(2)
                add(INS, mk, v, 'product', f"Competitors put **{PFN[i].lower()}** in {round(sc*100)}% of their content in {W}; {BRAND} does in {round(sg*100)}%.",
                    f"Led by {', '.join(f'{b} ({n})' for b, n in lb)}.", uniq(ev))

# automatic cross-market patterns (recent window): one competitor offer string live in 2+ markets
if len(MARKETS) > 1:
    byb = C.defaultdict(lambda: C.defaultdict(list))
    for r in REC:
        if comp(r) and r['src'] == 'paid':
            for p_ in {x.lower().strip() for x in r['perk']}:
                if len(p_) >= 6: byb[(B(r), p_)][r['_mk']].append(r)
    pats = sorted([(len(m), sum(len(x) for x in m.values()), k, m) for k, m in byb.items() if len(m) >= 2], key=lambda x: (-x[0], -x[1]))[:6]
    for nm, n, (b, p_), m in pats:
        ev = [r for x in m.values() for r in x]
        add(INS, 'ALL', 'all', 'pattern', f"**{b}** runs the same offer, **“{p_}”**, in {nm} markets.",
            "Ads per market: " + ', '.join(f'{k} {len(x)}' for k, x in sorted(m.items(), key=lambda kv: -len(kv[1]))) + ".", uniq(ev, 50, key=lambda r: r['d']), 'paid')
for rule in spec.get('curated_rules', []):
    rx = re.compile(rule['regex'], re.I)
    ev = [r for r in recs if (not rule.get('brand') or B(r) == rule['brand']) and (not rule.get('src') or r['src'] == rule['src'])
          and (rule.get('mk', 'ALL') == 'ALL' or r['_mk'] == rule['mk']) and rule.get('since', '0') <= r['d'] <= rule.get('until', '9')
          and rx.search(' '.join([r['text'], r['title']] + r['perk'] + r['prod']))]
    if ev:
        byk = C.Counter(r['_mk'] for r in ev)
        add(INS, rule.get('mk', 'ALL'), rule.get('v', 'all'), 'pattern', rule['head'], rule.get('body', '') + (' Items per market: ' + ', '.join(f'{k} {n}' for k, n in byk.most_common()) + '.'), [r['id'] for r in sorted(ev, key=lambda r: r['d'], reverse=True)][:50], rule.get('src'))
json.dump(INS, open(RUN + 'insights_recent.json', 'w'), ensure_ascii=False, indent=1)
print('recent insights', len(INS))

# ---------------- month-on-month trends (like-for-like) ----------------
TR = []
def month(r): return None if (r['src'] == 'paid' and r['_ph']) else r['d'][:7]
LFL = [r for r in recs if r['p'] not in LFL_EXCLUDE and month(r) in MONTHS]
def share_shift(rs, f, names, min_recent=15, min_share=.05):
    rec = [r for r in rs if month(r) in RECENT]; ear = [r for r in rs if month(r) in EARLY]
    if len(rec) < 40 or len(ear) < 40: return None, rec
    best = None
    for i in range(len(names)):
        a = sum(1 for r in rec if f(r, i)); b = sum(1 for r in ear if f(r, i)); sa, sb = a / len(rec), b / len(ear)
        if a >= min_recent and sa >= min_share and (best is None or sa - sb > best[0]): best = (sa - sb, i, sa, sb, a)
    return best, rec
def first_seen(rs, field, minn=6):
    first, items, pfirst = {}, C.defaultdict(list), {}
    since = MONTHS[3] + '-01' if len(MONTHS) > 6 else MONTHS[0] + '-01'
    for r in rs:
        pfirst[r['pid']] = min(pfirst.get(r['pid'], '9'), r['d'])
        for v in r[field]:
            k = (r['pid'], v.strip().lower())
            if len(k[1]) < 5 or k[1] in ('undetermined', 'none', 'general'): continue
            items[k].append(r)
            if k not in first or r['d'] < first[k]: first[k] = r['d']
    out = [(len(items[k]), k, f, items[k]) for k, f in first.items() if f >= since and len(items[k]) >= minn
           and (dt.date.fromisoformat(f) - dt.date.fromisoformat(pfirst[k[0]])).days >= 60]
    return sorted(out, key=lambda x: -x[0]), since
def top_ids(rs, k=40):
    seen, out = set(), []
    for r in sorted(rs, key=lambda r: (r['d'], r['_m']), reverse=True):
        kk = r.get('col') or r['id']
        if kk in seen: continue
        seen.add(kk); out.append(r['id'])
        if len(out) >= k: break
    return out
EL, RL = f"{mlabel(EARLY[0])[:3]}–{mlabel(EARLY[-1])[:3]}", f"{mlabel(RECENT[0])[:3]}–{mlabel(RECENT[-1])}"
for mk in MARKETS + ['ALL']:
    for v in VKEYS + ['all']:
        W = where(mk, v); rs = sel(LFL, mk, v); cr = [r for r in rs if comp(r)]
        best, rec = share_shift(cr, lambda r, i: r['_pf'] >> i & 1, PFN)
        if best and best[0] >= .04:
            _, i, sa, sb, a = best; ev = [r for r in rec if r['_pf'] >> i & 1]; lb = C.Counter(bn(r, mk) for r in ev).most_common(2)
            add(TR, mk, v, 'product-trend', f"Competitor content on **{PFN[i].lower()}** rose from {round(sb*100)}% ({EL}) to **{round(sa*100)}%** ({RL}) in {W}.",
                f"{fmt(a)} items in the last three months, led by {', '.join(f'{b} ({n})' for b, n in lb)}. Like-for-like series.", top_ids(ev))
        for field, kind, noun in [('perk', 'new-offer', 'offers'), ('prod', 'new-product', 'products or services')]:
            fs, since = first_seen(cr, field)
            if fs:
                top = fs[:3]; ev = [r for t in top for r in sorted(t[3], key=lambda r: r['d'])[:15]]
                parts = [f"“{t[1][1]}” by {prof[t[1][0]]['name']}{'' if mk != 'ALL' else ' (' + prof[t[1][0]]['mk'] + ')'} (first seen {dmy(t[2])}, {t[0]} items)" for t in top]
                add(TR, mk, v, kind, f"**{len(fs)} new competitor {noun}** appeared in {W} since {mlabel(since[:7])}.", "The biggest: " + '; '.join(parts) + ".", [r['id'] for r in ev])
        for f, names, kind, lab in [(lambda r, i: i in r['_need'], NEEDS, 'need-trend', 'customer need'), (lambda r, i: i in r['_pt'], PERKT, 'incentive-trend', 'incentive type')]:
            best, rec = share_shift(cr, f, names)
            if best and best[0] >= .04:
                _, i, sa, sb, a = best
                add(TR, mk, v, kind, f"The {lab} **{names[i].lower()}** grew in competitor content, from {round(sb*100)}% to **{round(sa*100)}%**.",
                    f"{EL} vs {RL} in {W}, from SOMIN's {lab} tags. {fmt(a)} items in the last three months.", top_ids([r for r in rec if f(r, i)]))
        paid = [r for r in recs if r['src'] == 'paid' and not r['_ph'] and (mk == 'ALL' or r['_mk'] == mk) and (v == 'all' or r['_v'] == v)]
        if len(MONTHS) >= 9:
            A = [(MONTHS[-7] + '-01', MONTHS[-5] + '-28'), (RECENT[0] + '-01', RECENT[-1] + '-28')]
            sh = []
            for a, b in A:
                t = sum(adays(r, a, b) for r in paid); g = sum(adays(r, a, b) for r in paid if r['_g']); sh.append((pct(g, t), t))
            if sh[0][1] > 300 and sh[1][1] > 300 and abs(sh[1][0] - sh[0][0]) >= 5:
                ev = [r['id'] for r in sorted([r for r in paid if r['_g'] and adays(r, *A[1]) > 0], key=lambda r: -adays(r, *A[1]))[:40]]
                add(TR, mk, v, 'share-trend', f"{BRAND}'s share of paid ad-days in {W} moved from {sh[0][0]}% ({mlabel(MONTHS[-7])[:3]}–{mlabel(MONTHS[-5])[:3]}) to **{sh[1][0]}%** ({RL}).",
                    "Ad-days count each day an ad was live. Check each advertiser's paid tracking start before reading early months.", ev, 'paid')
        byb = C.defaultdict(C.Counter); evb = C.defaultdict(list)
        for r in [r for r in cr if r['src'] == 'paid']: byb[bn(r, mk)][month(r)] += 1; evb[(bn(r, mk), month(r))].append(r)
        best = None
        for b, c in byb.items():
            vals = [c.get(m, 0) for m in MONTHS]; mm_ = max(vals); mi = vals.index(mm_); others = [x for j, x in enumerate(vals) if j != mi and x > 0]
            avg = sum(others) / len(others) if others else 0
            if mm_ >= 40 and mm_ >= 3 * max(avg, 1) and (best is None or mm_ > best[0]): best = (mm_, b, MONTHS[mi], avg)
        if best:
            mm_, b, m_, avg = best; burst = evb[(b, m_)]; perk = C.Counter(p for r in burst for p in r['perk']).most_common(1)
            add(TR, mk, v, 'launch-month', f"**{b}**'s biggest launch month was **{mlabel(m_)}**: {mm_} new ads.",
                f"In its other active months it averaged {avg:.0f} new ads." + (f" Most repeated offer: “{perk[0][0]}”." if perk else ""), top_ids(burst), 'paid')
json.dump(TR, open(RUN + 'insights_trend.json', 'w'), ensure_ascii=False, indent=1)
print('trend insights', len(TR))
