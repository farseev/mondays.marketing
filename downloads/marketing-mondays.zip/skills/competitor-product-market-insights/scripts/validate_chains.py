#!/usr/bin/env python3
"""Validate insight chains written by the chain agents against their packets. Run it before building.

Usage:
  python3 validate_chains.py chains chains_*.json         (recent-window chains vs chain_packets.json)
  python3 validate_chains.py ws ws_chains.json             (whitespace chains vs ws_packets.json)
Exit 1 on any ERROR. WARNINGS are numbers the script could not trace to the packet: read each one and fix
or justify it (a number derived by simple arithmetic from packet figures is fine; an invented one is not).

Checks: keys exist; ev/refs/sources are inside the packet; theme/story quotes are exact and metadata matches;
verdict + trend agree with the packet; subtypes come from the allowed lists; hooks <= 7 words; BOFU cta is one
of the packet's focal_ctas (<= 3 words); no em dash, no hype words; titles <= 8 words in sentence case.
"""
import json, re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import RUN, BRAND

SUB = {
    'TOFU': ["1.02 Problem / tension framing", "1.04 Identity / aspiration", "1.05 Peer / community proof",
             "1.08 Human / empathy moment", '1.09 Vision / "imagine"', '1.11 Trend / "what\'s changing"',
             "1.12 Story / mini-narrative"],
    'MOFU': ["2.01 Product capability / feature", "2.02 Solution demo / how-it-works", '2.03 Comparison / "vs the old way"',
             "2.04 Use-case / scenario", "2.06 Reliability / trust / quality", "2.08 Comfort / experience",
             "2.12 Objection handler / FAQ"],
    'BOFU': ["3.01 Offer / booking", "3.04 Trial / starter", "3.09 Limited-time / seasonal activation",
             "3.10 Pricing / package", "3.11 Reassurance / risk-reversal", '3.12 Direct CTA / "get started"'],
}
HYPE = re.compile(r'\b(unlock\w*|leverag\w*|game[- ]chang\w*|supercharg\w*|revolutioni\w*|elevat\w*|seamless\w*|unleash\w*|cutting[- ]edge|next[- ]level|synerg\w*)\b', re.I)
WS_VERDICT = "POSSIBLE WHITESPACE — UNVERIFIED"
VERDICT_RX = re.compile(r'^(POSSIBLE WHITESPACE — UNVERIFIED|OCCUPIED — .+ leads?|CONTESTED — .+|' + re.escape(BRAND.upper()) + r'-LED)$')

if len(sys.argv) < 3 or sys.argv[1] not in ('chains', 'ws'): sys.exit(__doc__)
kind = sys.argv[1]
P = {p['key']: p for p in json.load(open(RUN + ('chain_packets.json' if kind == 'chains' else 'ws_packets.json')))}
CH = []
for f in sys.argv[2:]: CH += json.load(open(f if os.path.isabs(f) else RUN + f))
errs, warns = [], []
def E(k, m): errs.append(f'{k}: {m}')
def W(k, m): warns.append(f'{k}: {m}')

def numbers_in(obj, A):
    """Every number in the packet, at 0-2 decimals, plus x100 for shares, plus numbers inside strings."""
    if isinstance(obj, bool) or obj is None: return
    if isinstance(obj, (int, float)):
        for x in ([obj, obj * 100] if isinstance(obj, float) and abs(obj) <= 1 else [obj]):
            for d in (0, 1, 2): A.add(f'{x:.{d}f}')
        A.add(str(obj))
    elif isinstance(obj, str): A.update(re.findall(r'\d+(?:\.\d+)?', obj.replace(',', '')))
    elif isinstance(obj, dict): [numbers_in(v, A) for v in obj.values()]
    elif isinstance(obj, (list, tuple)): [numbers_in(v, A) for v in obj]
def allowed(p):
    A = {'0', '1', '2', '3', '6', '7', '8', '9', '12', '30', '40', '60', '90', '0.5', '1.5', '100'}
    numbers_in(p, A)
    L = p.get('lane')
    if L:   # derived lane figures: early / previous-3 / last-3 averages, ratio, window sums, max-month share
        s, cn = L['series'], L['counts']
        early = s[:-6] or s[:1]; f6, p3, l3 = sum(early) / len(early), sum(s[-6:-3]) / 3, sum(s[-3:]) / 3
        for v in (f6 * 100, p3 * 100, l3 * 100, (l3 / f6) if f6 else 0, max(cn) / max(L['n'], 1) * 100):
            for d in (0, 1, 2): A.add(f'{v:.{d}f}')
        for i in range(len(cn)):
            for j in range(i + 1, len(cn) + 1): A.add(str(sum(cn[i:j])))
        A.add(str(sum(c for b, c in L['brands'] if b != BRAND)))
    return A
def evidence_ids(p):
    if kind == 'ws': return {e['id'] for e in p['evidence']}, {}
    st = {s: {c['id'] for c in p['stages'][s]['candidates']} for s in p['stages']}
    return set().union(*st.values()), st

for c in CH:
    k = c.get('key')
    if k not in P: E(k, 'unknown key'); continue
    p = P[k]; evids, by_stage = evidence_ids(p)
    themes = {t['id']: t for t in p['somin_themes']}; stories = {s['id']: s for s in p['somin_stories']}
    for f in ('title', 'signal', 'insight', 'opportunity', 'build'):
        if f not in c: E(k, f'missing {f}')
    if errs and errs[-1].startswith(f'{k}: missing'): continue
    if len(c['title'].split()) > 8: E(k, 'title > 8 words')
    if c['title'][:1] != c['title'][:1].upper(): E(k, 'title not sentence case')
    ev = c['signal'].get('ev', [])
    if not (2 <= len(ev) <= 6): E(k, f'signal.ev count {len(ev)} (2-6)')
    if len(set(ev)) != len(ev): E(k, 'duplicate ev ids')
    for i in ev:
        if i not in evids: E(k, f'ev {i} not in packet evidence')
    ins = c['insight']
    if ins.get('type') == 'story' or (ins.get('theme_id') is None and ins.get('story')):
        s = stories.get((ins.get('story') or {}).get('id'))
        if not s: E(k, 'story id not in packet')
        elif ins['quote'] != s['title'] and ins['quote'] not in (s.get('summary') or ''): E(k, 'story quote not exact')
    elif not themes:
        W(k, 'packet has no SOMIN themes: insight cannot be quoted (collect studies or drop the insight block)')
    else:
        t = themes.get(ins.get('theme_id'))
        if not t: E(k, 'theme id not in packet')
        else:
            if not (ins['quote'] == t['title'] or ins['quote'] in (t['summary'] or '')): E(k, 'theme quote not exact')
            if ins.get('study_id') != t['study'] or ins.get('n') != t['n'] or ins.get('type') != t['type']: E(k, 'theme metadata mismatch')
    o = c['opportunity']
    if kind == 'ws':
        L = p['lane']
        if o.get('verdict') != WS_VERDICT or L['verdict'] != WS_VERDICT: E(k, 'verdict must be the packet verdict')
        if o.get('trend') != L['trend']: E(k, 'trend mismatch')
        vn = o.get('verdict_note', '').replace(',', '')
        cs = p['cohort_sizes_recent']
        if str(cs['focal']) not in vn or str(cs['competitors']) not in vn: E(k, 'verdict_note lacks the focal vs competitor recent sample sizes')
        if f"({L['focal_label']}/{L['comp_label']})" not in o.get('verdict_note', ''): E(k, 'verdict_note lacks the (LOW/LOW) labels')
        if 'cohort' not in vn: E(k, 'verdict_note does not say what would confirm it (an audience or creator cohort)')
    elif not VERDICT_RX.match(o.get('verdict', '')): E(k, f'verdict {o.get("verdict")!r} not in the rubric')
    for stage in ('TOFU', 'MOFU', 'BOFU'):
        b = c['build'].get(stage)
        if not b: E(k, f'missing build.{stage}'); continue
        for f in ('goal', 'idea', 'format', 'channel', 'offer', 'why', 'refs', 'sources', 'concept'):
            if f not in b: E(k, f'{stage} missing {f}')
        pool = by_stage.get(stage, evids) if kind == 'chains' else evids
        if not (1 <= len(b.get('refs', [])) <= 3): E(k, f'{stage} refs count {len(b.get("refs", []))} (1-3)')
        for i in b.get('refs', []):
            if i not in pool: E(k, f'{stage} ref {i} not in {"stages." + stage + ".candidates" if kind == "chains" else "evidence"}')
        for s_ in b.get('sources', []):
            m = re.match(r'(post|theme|story) (\d+)$', s_)
            if m:
                i = int(m.group(2)); ok = {'post': evids, 'theme': themes, 'story': stories}[m.group(1)]
                if i not in ok: E(k, f'{stage} source {s_} not in packet')
            elif not (re.match(r'(analysis|lane) · \S', s_) or (kind == 'ws' and s_.startswith(p['lane']['lane'] + ' · '))): E(k,f'{stage} source {s_!r} malformed (post N | theme N | story N | analysis · field | lane · field)')
        cc = b.get('concept') or {}
        if cc.get('subtype') not in SUB[stage]: E(k, f'{stage} subtype {cc.get("subtype")!r} not allowed')
        if not cc.get('hook') or len(cc['hook'].split()) > 7: E(k, f'{stage} hook missing or > 7 words: {cc.get("hook")}')
        if stage == 'BOFU':
            cta = b.get('cta') or cc.get('cta')
            if p.get('focal_ctas') and cta not in p['focal_ctas']: E(k, f'BOFU cta {cta!r} not in focal_ctas {p["focal_ctas"]}')
            elif cta and len(cta.split()) > 3: E(k, 'BOFU cta > 3 words')
    A = allowed(p)
    texts = [c['title'], c['signal'].get('text', ''), c['signal'].get('figure', ''), ins.get('metric_note', ''), o.get('text', ''),
             o.get('verdict_note', '').replace(WS_VERDICT, '')]
    for stage in ('TOFU', 'MOFU', 'BOFU'):
        b = c['build'].get(stage) or {}
        texts += [b.get(f, '') for f in ('goal', 'idea', 'format', 'channel', 'offer', 'why')]
        texts += [(b.get('concept') or {}).get('hook', ''), (b.get('concept') or {}).get('tagline', '')]
    for t in texts:
        if not isinstance(t, str): continue
        if '—' in t: E(k, f'em dash in: {t[:60]}')
        if HYPE.search(t): E(k, f'hype word in: {t[:80]}')
        if re.search(r',\s+not\s+\w+', t): W(k, f'possible "X, not Y": {t[:80]}')
        for n in re.findall(r'\d[\d,]*(?:\.\d+)?', t):
            nn = n.replace(',', '').rstrip('.')
            if nn not in A: W(k, f'number {n} not traced to the packet: "{t[:70]}"')
missing = sorted(set(P) - {c.get('key') for c in CH})
if missing: W('coverage', f'packets with no chain: {missing}')
print('chains:', len(CH), 'packets:', len(P))
print('ERRORS:', len(errs)); [print('  ', e) for e in errs]
print('WARNINGS:', len(warns)); [print('  ', w) for w in warns]
sys.exit(1 if errs else 0)
