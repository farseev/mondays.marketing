#!/usr/bin/env python3
"""Assemble site/index.html from theme.json + assets/base.css + assets/template_body.html.

Usage: python3 build_page.py      (run from the run directory)
theme.json (see assets/theme_example.json): name, fonts {display, body, google}, logo (file in the run dir, optional),
logo_on_bar ("invert" turns a dark logo white on the bar; "none" keeps it), light {tokens}, dark {tokens},
engine_brand {...} and brand_lock "..." (used by the expressions step). Also writes expr/brand.json for the engine.
"""
import json, base64, os, sys, mimetypes
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import RUN, SKILL, spec, BRAND, W_START, W_END, mlabel

T = json.load(open(RUN + 'theme.json'))
NEED = ['accent', 'accent-ink', 'accent-soft', 'accent-soft2', 'bg', 'surface', 'ink', 'ink2', 'ink3', 'line', 'hi', 'hi-soft', 'alert',
        'chip', 'bar', 'on-bar', 'on-accent', 'on-hi', 'accent-ink-on-white']
for mode in ('light', 'dark'):
    miss = [k for k in NEED if k not in T.get(mode, {})]
    if miss: sys.exit(f'theme.json {mode} is missing tokens: {miss}')
fd, fb = T['fonts']['display'], T['fonts']['body']
def block(d): return ' '.join(f'--{k}:{v};' for k, v in d.items())
fonts = f'--display:"{fd}",ui-rounded,system-ui,sans-serif; --body:"{fb}",system-ui,sans-serif; --r:16px;'
root = (f':root{{{block(T["light"])} {fonts}}}\n'
        f'@media (prefers-color-scheme: dark){{:root:not([data-theme="light"]){{{block(T["dark"])} color-scheme:dark}}}}\n'
        f':root[data-theme="dark"]{{{block(T["dark"])} color-scheme:dark}}\n')
css = open(SKILL + 'assets/base.css').read()
if T.get('logo_on_bar', 'invert') == 'invert': css += '\n.top .logo{filter:brightness(0) invert(1)}\n'
logo = ''
if T.get('logo') and os.path.exists(RUN + T['logo']):
    mt = mimetypes.guess_type(T['logo'])[0] or 'image/png'
    logo = f'<img class="logo" alt="{BRAND}" src="data:{mt};base64,{base64.b64encode(open(RUN + T["logo"], "rb").read()).decode()}">'
body = open(SKILL + 'assets/template_body.html').read()
title = spec.get('title', f'{BRAND} Competitive Pulse')
subtitle = spec.get('subtitle') or f'Powered by SOMIN · {mlabel(W_START[:7])} – {mlabel(W_END[:7])}'
body = body.replace('__LOGO_IMG__', logo).replace('__TITLE__', (title.replace(BRAND, '').strip() or title) if logo else title).replace('__SUBTITLE__', subtitle)
g = T['fonts'].get('google')
head = ('<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n'
        f'<title>{title}</title>\n'
        + (f'<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="stylesheet" href="https://fonts.googleapis.com/css2?{g}&display=swap">\n' if g else ''))
html = head + '<style>\n' + root + css + '\n</style>\n' + body
os.makedirs(RUN + 'site', exist_ok=True)
open(RUN + 'site/index.html', 'w', encoding='utf-8').write(html)
os.makedirs(RUN + 'expr', exist_ok=True)
if T.get('engine_brand'): json.dump(T['engine_brand'], open(RUN + 'expr/brand.json', 'w'), indent=1)
print('site/index.html', round(len(html) / 1e3), 'KB; logo', 'yes' if logo else 'no', '; fonts', fd, '/', fb)
