#!/usr/bin/env python3
"""Split site/ into publish groups that fit the artifact limits, and print how to publish them.

Usage: python3 split_publish.py [--max-mb 60] [--max-files 240] [--previous pub_manifest.json]
Limits per publish: 64 MB and 255 files; 16 MB per file. Group 1 always carries meta.json and the c_*.json columns
(the page cannot render without them); later groups add text shards, thumbnail bundles and expression images.
Writes pub_p<i>.json maps ({published path: path relative to site/}) and pub_manifest.json (every published path).
With --previous, paths published last time but gone now are set to null in the last group so stale files are removed.
Publish: first call Artifact with file_path=site/index.html, files=pub_p1.json map, root=site (plus icon/description);
then the same file_path with files=pub_p2.json ... (each later publish adds to the files already there).
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import RUN

MAXB = float(sys.argv[sys.argv.index('--max-mb') + 1]) * 1e6 if '--max-mb' in sys.argv else 60e6
MAXF = int(sys.argv[sys.argv.index('--max-files') + 1]) if '--max-files' in sys.argv else 240
SITE = RUN + 'site/'
files = []
for d in ('data', 't', 'x'):
    if os.path.isdir(SITE + d):
        for f in sorted(os.listdir(SITE + d)): files.append((f'{d}/{f}', os.path.getsize(SITE + d + '/' + f)))
big = [f for f, s in files if s > 16e6]
if big: sys.exit(f'files over 16 MB (re-run thumbs/encode with smaller caps): {big}')
core = [x for x in files if x[0] == 'data/meta.json' or x[0].startswith('data/c_')]
rest = [x for x in files if x not in core]
rest.sort(key=lambda x: (0 if x[0].startswith('x/') else 1 if x[0].startswith('data/') else 2, x[0]))
groups, cur, cb = [], list(core), sum(s for _, s in core)
if cb > MAXB: sys.exit('meta + columns alone exceed one publish: shrink the window or the markets')
for f, s in rest:
    if cb + s > MAXB or len(cur) + 1 > MAXF:
        groups.append(cur); cur, cb = [], 0
    cur.append((f, s)); cb += s
if cur: groups.append(cur)
for i in range(1, 99):
    p = RUN + f'pub_p{i}.json'
    if os.path.exists(p): os.remove(p)
maps = [{f: f for f, _ in g} for g in groups]
if '--previous' in sys.argv:
    prev = set(json.load(open(RUN + sys.argv[sys.argv.index('--previous') + 1])))
    stale = prev - {f for f, _ in files}
    for f in sorted(stale): maps[-1][f] = None
    print('stale paths removed in the last group:', len(stale))
for i, m in enumerate(maps, 1):
    json.dump(m, open(RUN + f'pub_p{i}.json', 'w'), indent=0)
    print(f'pub_p{i}.json: {len(m)} files, {round(sum(s for f, s in groups[i - 1]) / 1e6, 1)} MB')
json.dump([f for f, _ in files], open(RUN + 'pub_manifest.json', 'w'))
print('total', len(files), 'files', round(sum(s for _, s in files) / 1e6, 1), 'MB in', len(maps), 'publishes; root =', SITE)
