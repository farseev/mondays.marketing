#!/usr/bin/env python3
"""Evidence packets for the marketing insight chains (one packet per chain the writer agents will author).

Usage: python3 packets.py        (run from the run directory, after merge.py and whitespace.py)
Reads recs.pkl, whitespace.json, somin_insights.json (optional; SOMIN studies + stories per workspace).
Writes:
  chain_packets.json  one per market x vertical x source (organic | paid) over the recent window
  ws_packets.json     one per market x vertical: the top trending possible-whitespace lane
  ctas.json           the focal brand's real paid CTAs per market (the only CTAs a BOFU concept may use)
Every packet carries the real post ids the writer may cite. The writers never see anything else.
"""
import json, pickle, statistics, collections as C, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

recs, prof, PERKT, NEEDS = pickle.load(open(RUN + 'recs.pkl', 'rb'))
OFN = [o[0] for o in OFFER]
B = lambda r: prof[r['pid']]['name']
def comp(r): return not prof[r['pid']]['focal'] and not prof[r['pid']]['regulator']
def bn(r): return f"{B(r)} ({r['_mk']})"
MIN_PACKET = int(spec.get('chain_min_items', 40))

# ---- SOMIN studies + stories per market (workspace -> market from spec.markets[].workspace_ids)
WS2MK = {}
for m in spec['markets']:
    for w in (m.get('workspace_ids') or ([m['workspace_id']] if m.get('workspace_id') else [])): WS2MK[int(w)] = m['code']
themes_by_mk, stories_by_mk = C.defaultdict(list), C.defaultdict(list)
SI_PATH = RUN + 'somin_insights.json'
if os.path.exists(SI_PATH):
    SI = json.load(open(SI_PATH))
    for w in SI.get('workspaces', []):
        mk = WS2MK.get(int(w['workspaceId']))
        if not mk: continue
        for s in w.get('studies', []):
            for t in s.get('themes', []):
                themes_by_mk[mk].append({'study': s['studyId'], 'studyName': s.get('name', ''), 'window': s.get('dateWindows'), 'id': t['id'],
                                         'type': t.get('type'), 'title': t.get('title'), 'summary': (t.get('summary') or '')[:600], 'n': t.get('sampleSize'),
                                         'metrics': [{k: v for k, v in m_.items() if k != 'profileId'} for m_ in (t.get('metrics') or []) if isinstance(m_, dict)][:8]})
        for st in w.get('stories', []):
            ch = st.get('character') if isinstance(st.get('character'), dict) else {}
            g = lambda x: (x.get('title') if isinstance(x, dict) else x)
            stories_by_mk[mk].append({'id': st['id'], 'title': st.get('title'), 'summary': (st.get('summary') or '')[:500],
                                      'persona': ch.get('characterName'), 'personaTheme': g(ch.get('theme')),
                                      'theme': g(st.get('theme')), 'angle': g(st.get('angle'))})
else:
    print('WARNING: somin_insights.json missing: chains will have no SOMIN theme to quote (run the inventory step)')
print('SOMIN themes per market:', {k: len(v) for k, v in themes_by_mk.items()}, 'stories:', {k: len(v) for k, v in stories_by_mk.items()})

VTOK = {v['key']: [t.upper() for t in v.get('study_tokens', [])] for v in VERTS}
ALLTOK = {t for ts in VTOK.values() for t in ts}
SRC_TOK = {'paid': ['PAID'], 'organic': ['ORG', 'WS', 'ORGANIC'], 'ws': ['ORG', 'WS', 'ORGANIC']}
def theme_pick(mk, v, src, k=14):
    def score(t):
        nm = (t['studyName'] or '').upper(); s = 0
        if any(x in nm for x in VTOK.get(v, [])): s += 4
        elif any(x in nm for x in ALLTOK): s -= 3
        if any(x in nm for x in SRC_TOK[src]): s += 2
        if t['type'] in ('pain_points', 'persona'): s += 1
        return (s, t['n'] or 0)
    return sorted(themes_by_mk[mk], key=score, reverse=True)[:k]

def card(r, mr):
    return {'id': r['id'], 'brand': bn(r), 'focal': r['_g'], 'platform': r['p'], 'date': r['d'], 'src': r['src'], 'metric': mr,
            'metric_name': 'interactions' if r['src'] == 'organic' else 'ad-days', 'contentTypes': r['ct'], 'tone': r['tone'][:3],
            'perks': r['perk'][:4], 'products': r['prod'][:3], 'audiences': r['aud'][:3], 'needs': r['need'][:3], 'video': r['vid'],
            'cta': r.get('cta') or None, 'humanInsight': r['hi'], 'proposition': r['bp'], 'title': r['title'], 'text': r['text'][:260]}

# ---- focal CTAs per market (paid first, then organic)
CTAS = {}
for mk in MARKETS:
    cc = C.Counter(r['cta'].strip() for r in recs if r['_g'] and r['_mk'] == mk and r.get('cta') and r['cta'].strip()
                   and r['cta'].strip().lower() not in ('no button', 'none'))
    CTAS[mk] = [c for c, n in cc.most_common(10) if len(c.split()) <= 3][:8]
json.dump({'ctas': CTAS}, open(RUN + 'ctas.json', 'w'), ensure_ascii=False, indent=1)
print('focal CTAs:', CTAS)

# ---- recent-window chain packets
REC = []
for r in recs:
    if prof[r['pid']]['regulator']: continue
    if r['src'] == 'organic' and R_START <= r['d'] <= W_END: REC.append((r, r['_m']))
    elif r['src'] == 'paid':
        a = adays(r, R_START, W_END)
        if a > 0: REC.append((r, a))
PACK = []
for mk in MARKETS:
    for v in VKEYS:
        for src in ['organic', 'paid']:
            rs = [(r, m) for r, m in REC if r['_mk'] == mk and r['_v'] == v and r['src'] == src]
            if len(rs) < MIN_PACKET:
                print(mk, v, src, 'skipped: only', len(rs), 'items'); continue
            g = [x for x in rs if x[0]['_g']]; c = [x for x in rs if comp(x[0])]
            fm = lambda xs: [pct(sum(1 for r, _ in xs if r['_f'] == k), len(xs)) for k in range(3)]
            stages = {}
            for k, nm in enumerate(['TOFU', 'MOFU', 'BOFU']):
                pool = sorted([x for x in rs if x[0]['_f'] == k], key=lambda x: -x[1])
                seen, picks = set(), []
                for r, m in pool:
                    kk = r.get('col') or r['text'][:60]
                    if kk in seen: continue
                    seen.add(kk); picks.append(card(r, m))
                    if len(picks) >= 8: break
                stages[nm] = {'pool': len(pool), 'focal_share': pct(sum(1 for r, _ in pool if r['_g']), len(pool)),
                              'median_metric': statistics.median([m for _, m in pool]) if pool else 0, 'candidates': picks}
            PACK.append({'key': f'{mk}-{v}-{src}', 'market': mk, 'market_name': MKN[mk], 'vertical': VLAB[v], 'source': src, 'brand': BRAND,
                         'metric': 'interactions (likes or reactions + comments + shares + reposts)' if src == 'organic'
                                   else f'active ad-days inside {dmy(R_START)} – {dmy(W_END)}',
                         'counts': {'focal': len(g), 'competitors': len(c)},
                         'metric_share_focal_pct': pct(sum(m for _, m in g), sum(m for _, m in rs)),
                         'funnel_mix_pct_TOFU_MOFU_BOFU': {'focal': fm(g), 'competitors': fm(c)},
                         'competitor_content_types': C.Counter(x for r, _ in c for x in r['ct']).most_common(8),
                         'competitor_offer_types': C.Counter(OFN[i] for r, _ in c for i in range(len(OFN)) if r['_o'] >> i & 1).most_common(6),
                         'brands': C.Counter(B(r) for r, _ in rs).most_common(10),
                         'stages': stages, 'somin_themes': theme_pick(mk, v, src), 'somin_stories': stories_by_mk[mk][:10],
                         'focal_ctas': CTAS.get(mk, [])})
json.dump(PACK, open(RUN + 'chain_packets.json', 'w'), ensure_ascii=False, indent=1)
print('chain packets', len(PACK))

# ---- whitespace packets (top trending lane per market-vertical)
WS = json.load(open(RUN + 'whitespace.json'))
byid = {r['id']: r for r in recs}
excl = sorted(WS_EXCLUDE)
note = (f"Like-for-like read excludes {', '.join(excl)}." if excl else 'All platforms included.') + \
       f" Months {mlabel(MONTHS[0])} – {mlabel(MONTHS[-1])}; recent = {', '.join(mlabel(m) for m in RECENT)}."
WSP = []
for key, w in WS.items():
    mk, v = key.split('-', 1)
    tr = [l for l in w['lanes'] if l.get('trending')]
    if not tr: print(key, 'no trending whitespace lane'); continue
    order = {t: i for i, t in enumerate(w['trending'])}
    tr.sort(key=lambda l: order.get(l['lane'] + '|' + l['dim'], 99))
    lane = tr[0]
    ev = []
    for i in lane['ev'][:14]:
        r = byid.get(i)
        if r: ev.append(card(r, r['_m'] if r['src'] == 'organic' else adays(r, W_START, W_END)))
    WSP.append({'key': f'WS-{key}', 'market': mk, 'market_name': MKN[mk], 'vertical': VLAB[v], 'brand': BRAND,
                'lane': {k: lane[k] for k in ('dim', 'lane', 'n', 'n_org', 'focal_recent', 'comp_recent', 'focal_label', 'comp_label',
                                              'verdict', 'trend', 'series', 'counts', 'focal_series', 'comp_series', 'ri', 'ri3', 'brands')},
                'months': MONTHS, 'cohort_sizes_recent': {'focal': w['n_focal_recent'], 'competitors': w['n_comp_recent']},
                'other_trending': w['trending'][1:4], 'evidence': ev,
                'somin_themes': theme_pick(mk, v, 'ws', 40), 'somin_stories': stories_by_mk[mk][:10],
                'focal_ctas': CTAS.get(mk, []), 'note': note})
json.dump(WSP, open(RUN + 'ws_packets.json', 'w'), ensure_ascii=False, indent=1)
print('whitespace packets', len(WSP), [p['key'] + ': ' + p['lane']['lane'] for p in WSP])
