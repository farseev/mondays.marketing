#!/usr/bin/env python3
"""Fill the subagent briefs in references/ with this run's values and write them to briefs/.

  python3 brief.py harvest            one brief per market from profiles.json (+ spec.profiles overrides)
  python3 brief.py inventory          one brief for the SOMIN studies/stories inventory
  python3 brief.py chains [--per 6]   recent-window chain briefs, packets split into parts of N
  python3 brief.py ws                 whitespace chain brief
  python3 brief.py render             one render brief per expr/batch_*.json file
Each subagent gets: "Read <brief path> and follow it exactly."
profiles.json (written in the resolve step) = [{"id": 123, "name": "Brand (MK)", "workspace_id": 456}, ...]
"""
import json, os, re, sys, glob, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

os.makedirs(RUN + 'briefs', exist_ok=True)
def fill(name, out, **kv):
    t = open(SKILL + f'references/{name}').read()
    base = {'BRAND': BRAND, 'BRAND_UPPER': BRAND.upper(), 'RUN': RUN, 'SKILL': SKILL, 'START': W_START, 'END': W_END,
            'MONTHS': f'{mlabel(MONTHS[0])} – {mlabel(MONTHS[-1])}', 'RECENT_MONTHS': f'{mlabel(RECENT[0])} – {mlabel(RECENT[-1])}',
            'RECENT': f'{dmy(R_START)} – {dmy(W_END)} ({RECENT_DAYS} days)'}
    base.update(kv)
    for k, v in base.items(): t = t.replace('{{' + k + '}}', str(v))
    left = re.findall(r'\{\{\w+\}\}', t)
    if left: sys.exit(f'unfilled placeholders in {name}: {left}')
    open(RUN + 'briefs/' + out, 'w').write(t); print('briefs/' + out)

def slices(a, b):
    out, s = [], dt.date.fromisoformat(a); e = dt.date.fromisoformat(b)
    while s <= e:
        nxt = (s.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
        out.append(f'{s.isoformat()}..{min(e, nxt - dt.timedelta(days=1)).isoformat()}'); s = nxt
    return out

cmd = sys.argv[1] if len(sys.argv) > 1 else ''
if cmd == 'harvest':
    P = json.load(open(RUN + 'profiles.json'))
    SP = {int(k): v for k, v in (spec.get('profiles') or {}).items()}
    by = {}
    for p in P:
        mk = SP.get(int(p['id']), {}).get('market')
        if not mk:
            m = re.match(r'.*\((\w\w)\)\s*$', p['name'])
            mk = m.group(1) if m else None
        if mk not in MARKETS: print('SKIP (no market in spec):', p); continue
        by.setdefault((mk, p.get('workspace_id') or spec.get('source_workspaces', [''])[0]), []).append(p)
    sl = '\n'.join(f'   - {x}' for x in slices(W_START, W_END))
    for (mk, ws), ps in sorted(by.items()):
        fill('harvest-brief.md', f'harvest_{mk}_{ws}.md', MARKET=f'{MKN[mk]} ({mk})', WORKSPACE_ID=ws, TAG=f'{mk}_{ws}',
             PROFILES='\n'.join(f"- {p['id']}: {p['name']}" for p in ps), SLICES=sl)
elif cmd == 'inventory':
    ws = [str(w) for m in spec['markets'] for w in (m.get('workspace_ids') or ([m['workspace_id']] if m.get('workspace_id') else []))]
    ws += [str(w) for w in spec.get('insight_workspaces', []) if str(w) not in ws]
    if not ws: sys.exit('no market workspace ids in spec.markets[].workspace_ids')
    fill('inventory-brief.md', 'inventory.md', WORKSPACES=', '.join(ws))
elif cmd == 'chains':
    per = int(sys.argv[sys.argv.index('--per') + 1]) if '--per' in sys.argv else 6
    keys = [p['key'] for p in json.load(open(RUN + 'chain_packets.json'))]
    for i in range(0, len(keys), per):
        fill('chain-brief.md', f'chains_{i // per + 1}.md', KEYS=', '.join(keys[i:i + per]), PART=str(i // per + 1))
elif cmd == 'ws':
    fill('ws-chain-brief.md', 'ws_chains.md')
elif cmd == 'render':
    for b in sorted(glob.glob(RUN + 'expr/batch_*.json')):
        fill('render-brief.md', 'render_' + os.path.basename(b).replace('.json', '.md'), BATCH=b)
else:
    sys.exit(__doc__)
