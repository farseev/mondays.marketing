#!/usr/bin/env python3
"""Render-check the built page in headless Chromium before publishing.

Usage: python3 qa_render.py [--port 8765]      (run from the run directory, after build_page.py + encode.py)
Serves site/ locally, opens the main views on desktop (1400 px, light) and phone (390 px, dark), clicks an insight
card (content plate), an advertiser row (advertiser dashboard), switches period, filters and the marketing view, and
writes screenshots to qa/. Fails (exit 1) on any page error, console error, missing core element, or horizontal scroll
on the phone. Look at the screenshots yourself: the script proves the page runs, not that it reads well.
"""
import asyncio, os, sys, subprocess, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import RUN, MARKETS, VKEYS

PORT = int(sys.argv[sys.argv.index('--port') + 1]) if '--port' in sys.argv else 8765
os.makedirs(RUN + 'qa', exist_ok=True)
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '--bind', '127.0.0.1'], cwd=RUN + 'site',
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.2)
from playwright.async_api import async_playwright
U = f'http://127.0.0.1:{PORT}/index.html'
v0 = VKEYS[0]; mk = MARKETS[0]
problems = []

async def main():
    async with async_playwright() as p:
        try: b = await p.chromium.launch()
        except Exception: b = await p.chromium.launch(executable_path='/opt/pw-browsers/chromium')
        pg = await b.new_page(viewport={'width': 1400, 'height': 1000})
        errs = []
        pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
        pg.on('console', lambda m: errs.append('console: ' + m.text) if m.type == 'error' else None)
        t = time.time()
        await pg.goto(f'{U}#analytics-{v0}-ALL-90')
        try: await pg.wait_for_selector('.kpis', timeout=90000)
        except Exception: problems.append('analytics view never rendered (.kpis missing)')
        print('first render s', round(time.time() - t, 1))
        await pg.wait_for_timeout(1200); await pg.screenshot(path=RUN + 'qa/01_analytics_regional.png', full_page=False)
        n_cards = await pg.locator('.icard').count(); print('insight cards in view', n_cards)
        # the focal-share KPI tile and the share insight card are computed separately (page vs insights.py): they must agree
        kpi = await pg.locator('.kpi.g .v').first.text_content()
        share_card = pg.locator('.icard .hd', has_text='of paid ad-days')
        if await share_card.count():
            import re as _re
            ct = await share_card.first.text_content(); m1 = _re.search(r'(\d+)%', kpi or ''); m2 = _re.search(r'(\d+)%', ct or '')
            if m1 and m2 and abs(int(m1.group(1)) - int(m2.group(1))) > 1:
                problems.append(f'KPI tile says {m1.group(1)}% but the share card says {m2.group(1)}%: the page and insights.py disagree on ad-days')
        if n_cards:
            await pg.locator('.icard').first.click(); await pg.wait_for_timeout(2500)
            if not await pg.locator('.sheet .pc').count(): problems.append('insight card opened no content plate')
            await pg.screenshot(path=RUN + 'qa/02_plate.png'); await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
        if await pg.locator('tr[data-adv]').count():
            await pg.locator('tr[data-adv]').first.click(); await pg.wait_for_timeout(2500)
            await pg.screenshot(path=RUN + 'qa/03_advertiser.png'); await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
        else: problems.append('no advertiser rows')
        await pg.goto(f'{U}#analytics-{v0}-{mk}-12'); await pg.reload(); await pg.wait_for_selector('.kpis', timeout=90000); await pg.wait_for_timeout(1500)
        await pg.screenshot(path=RUN + 'qa/04_market_full_period.png', full_page=True)
        if not await pg.locator('table.heat').count(): problems.append('no monthly heatmaps in the full-period view')
        await pg.click('#fOff button[data-v="services"]'); await pg.wait_for_timeout(800)
        await pg.click('#fSeg button[data-v="b2c"]'); await pg.wait_for_timeout(800)
        await pg.click('#fOff button[data-v="all"]'); await pg.click('#fSeg button[data-v="all"]'); await pg.wait_for_timeout(500)
        await pg.click('#viewSeg button[data-v="marketing"]'); await pg.wait_for_timeout(2000)
        await pg.screenshot(path=RUN + 'qa/05_marketing_market.png', full_page=True)
        await pg.click('#mkBar button[data-m="ALL"]'); await pg.wait_for_timeout(1500)
        await pg.screenshot(path=RUN + 'qa/06_marketing_regional.png', full_page=False)
        await pg.click('#srcBtn'); await pg.wait_for_timeout(400); await pg.screenshot(path=RUN + 'qa/07_scope.png')
        broken = await pg.evaluate("[...document.images].filter(i=>i.complete&&i.naturalWidth===0&&i.src&&!i.src.startsWith('data:')).map(i=>i.src).slice(0,5)")
        if broken: problems.append(f'broken images: {broken}')
        ph = await b.new_page(viewport={'width': 390, 'height': 860}, color_scheme='dark')
        ph.on('pageerror', lambda e: errs.append('phone pageerror: ' + str(e)))
        await ph.goto(f'{U}#analytics-{v0}-{mk}-90'); await ph.wait_for_selector('.kpis', timeout=90000); await ph.wait_for_timeout(1500)
        await ph.screenshot(path=RUN + 'qa/08_phone_dark.png')
        sw = await ph.evaluate('document.documentElement.scrollWidth')
        if sw > 392: problems.append(f'phone horizontal scroll: page is {sw}px wide at 390px')
        await ph.goto(f'{U}#marketing-{v0}-{mk}-90'); await ph.reload(); await ph.wait_for_timeout(2500)
        await ph.screenshot(path=RUN + 'qa/09_phone_marketing.png')
        sw = await ph.evaluate('document.documentElement.scrollWidth')
        if sw > 392: problems.append(f'phone horizontal scroll (marketing): {sw}px')
        problems.extend(errs[:10])
        await b.close()
try: asyncio.run(main())
finally: srv.terminate()
print('screenshots in qa/:', sorted(os.listdir(RUN + 'qa')))
if problems:
    print('PROBLEMS:'); [print('  ', x) for x in problems]; sys.exit(1)
print('QA PASS (now look at the screenshots)')
