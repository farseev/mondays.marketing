#!/usr/bin/env python3
"""Turn validated chains into a creative-concepts JSON for the SOMIN expressions engine, then brand-lock and batch the prompts.

  python3 concepts.py build
      reads chains_*.json (recent-window chains) and ws_chains.json, writes
      expr/concepts_chains.json + expr/pillar_map_chains.json   (pillar ids 1..N)
      expr/concepts_ws.json     + expr/pillar_map_ws.json       (pillar ids 101..)
      One pillar per chain, one TOFU / MOFU / BOFU concept per pillar: keys P<pillar>-T-01, -M-01, -B-01.

  (then run the expressions engine: unlock.py emit-prompts + check_prompts.py, see SKILL.md step 9)

  python3 concepts.py lock expr/_prompts_chains.json [--batch 18]
      appends theme.json "brand_lock" to every gated prompt (after the gate, so the gate stays valid),
      writes <file>_locked.json and expr/batch_<set>_<i>.json files for render agents.

  python3 concepts.py status
      lists keys with no render in expr/renders/ (png > 50 KB).
"""
import json, glob, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import RUN

EX = RUN + 'expr/'
os.makedirs(EX + 'renders', exist_ok=True)

def chains_files():
    return sorted(f for f in glob.glob(RUN + 'chains_*.json'))

def to_concepts(chains, start):
    out, pm = [], {}
    for i, c in enumerate(sorted(chains, key=lambda c: c['key'])):
        pid = start + i; pm[c['key']] = pid
        ins = c['insight']; quote = ins.get('quote') or c['title']
        cs = []
        for st in ('TOFU', 'MOFU', 'BOFU'):
            b = c['build'][st]; cc = b['concept']
            x = {'type': st, 'subtype': cc['subtype'], 'hook': cc['hook'], 'tagline': cc.get('tagline') or b.get('idea')}
            if st == 'BOFU' and (b.get('cta') or cc.get('cta')): x['cta'] = b.get('cta') or cc.get('cta')
            cs.append(x)
        out.append({'pillar_id': pid, 'pillar': c['title'], 'chain_key': c['key'],
                    'persona': {'name': quote[:60], 'theme_id': ins.get('theme_id')}, 'concepts': cs})
    return {'insights': out}, pm

cmd = sys.argv[1] if len(sys.argv) > 1 else ''
if cmd == 'build':
    CH = [c for f in chains_files() for c in json.load(open(f))]
    if CH:
        cj, pm = to_concepts(CH, 1)
        json.dump(cj, open(EX + 'concepts_chains.json', 'w'), ensure_ascii=False, indent=1); json.dump(pm, open(EX + 'pillar_map_chains.json', 'w'), indent=1)
        print('concepts_chains:', len(cj['insights']), 'pillars,', 3 * len(cj['insights']), 'concepts')
    if os.path.exists(RUN + 'ws_chains.json'):
        cj, pm = to_concepts(json.load(open(RUN + 'ws_chains.json')), 101)
        json.dump(cj, open(EX + 'concepts_ws.json', 'w'), ensure_ascii=False, indent=1); json.dump(pm, open(EX + 'pillar_map_ws.json', 'w'), indent=1)
        print('concepts_ws:', len(cj['insights']), 'pillars,', 3 * len(cj['insights']), 'concepts')
elif cmd == 'lock':
    src = sys.argv[2]; src = src if os.path.isabs(src) else RUN + src
    n = int(sys.argv[sys.argv.index('--batch') + 1]) if '--batch' in sys.argv else 18
    theme = json.load(open(RUN + 'theme.json'))
    suffix = theme.get('brand_lock') or ''
    if not suffix: print('WARNING: theme.json has no brand_lock: prompts go out with the engine palette only')
    P = json.load(open(src))
    for p in P: p['prompt_locked'] = p['prompt'] + (' ' + suffix.strip() if suffix else '')
    out = src.replace('.json', '_locked.json'); json.dump(P, open(out, 'w'), ensure_ascii=False, indent=1)
    tag = os.path.basename(src).replace('_prompts_', '').replace('.json', '')
    for f in glob.glob(EX + f'batch_{tag}_*.json'): os.remove(f)
    for i in range(0, len(P), n):
        json.dump(P[i:i + n], open(EX + f'batch_{tag}_{i // n}.json', 'w'), ensure_ascii=False, indent=1)
    print('locked', len(P), 'prompts ->', out, '; batches', (len(P) + n - 1) // n, f'(expr/batch_{tag}_*.json)')
elif cmd == 'status':
    keys = []
    for f in glob.glob(EX + '_prompts_*_locked.json'): keys += [p['key'] for p in json.load(open(f))]
    miss = [k for k in keys if not (os.path.exists(EX + f'renders/{k}.png') and os.path.getsize(EX + f'renders/{k}.png') > 50_000)]
    print('prompts', len(keys), 'rendered', len(keys) - len(miss), 'missing', len(miss), miss[:40])
else:
    sys.exit(__doc__)
