"""Run configuration: loads spec.json from the run directory and exposes shared helpers.

The run directory is the current working directory, or CPMI_RUN if set. Every script imports this.
spec.json fields are documented in references/spec.md (assets/spec_example.json is a filled-in run).
"""
import json, os, re, datetime as dt, calendar

RUN = os.path.abspath(os.environ.get('CPMI_RUN', os.getcwd())) + '/'
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/'
spec = json.load(open(RUN + 'spec.json'))

BRAND = spec['brand']                                   # focal brand short name, as it appears after aliasing
MARKETS = [m['code'] for m in spec['markets']]
MKN = {m['code']: m['name'] for m in spec['markets']}
MKN['ALL'] = spec.get('region_label', 'the region')
VERTS = spec['verticals']                               # [{key, label, keywords, study_tokens?}]
VKEYS = [v['key'] for v in VERTS]
VLAB = {v['key']: v['label'] for v in VERTS}
VLAB['all'] = 'all verticals'
OTHER = 'o'

W_START, W_END = spec['window']['start'], spec['window']['end']
RECENT_DAYS = int(spec.get('recent_days', 90))
EPOCH = dt.date(dt.date.fromisoformat(W_END).year, 1, 1)
def day(s): return (dt.date.fromisoformat(s) - EPOCH).days if s else None
R_START = (dt.date.fromisoformat(W_END) - dt.timedelta(days=RECENT_DAYS - 1)).isoformat()

def months_between(a, b):
    """Full calendar months that start on/after the window-start month and end before the window-end month."""
    y, m = int(a[:4]), int(a[5:7]); out = []
    ey, em = int(b[:4]), int(b[5:7])
    while (y, m) < (ey, em):
        out.append(f'{y:04d}-{m:02d}'); m += 1
        if m == 13: y, m = y + 1, 1
    return out
MONTHS = months_between(W_START, W_END)                 # trend months (the partial last month is excluded)
RECENT = MONTHS[-3:]
EARLY = MONTHS[-9:-3] if len(MONTHS) >= 9 else MONTHS[:-3]
def mlabel(m): return dt.date.fromisoformat(m + '-01').strftime('%b %Y')
def dmy(d): x = dt.date.fromisoformat(d); return f"{x.day} {x.strftime('%b')}"

# ---------- taxonomies (spec overrides, else the shipped super-app defaults) ----------
TAX = json.load(open(SKILL + 'assets/taxonomy_default.json'))
OFFER = spec.get('offer_families') or TAX['offer_families']
PRODFAM = spec.get('product_families') or TAX['product_families']
OFFER_RX = [(n, re.compile(x, re.I)) for n, x in OFFER]
PF_RX = [(n, re.compile(x, re.I)) for n, x in PRODFAM]
LAUNCH = re.compile(spec.get('launch_regex') or TAX['launch_regex'], re.I)
TACTIC = re.compile(spec.get('tactic_lane_regex') or TAX['tactic_lane_regex'], re.I)
GENERIC = set(x.lower() for x in (spec.get('generic_lanes') or TAX['generic_lanes']))
VRX = {v['key']: re.compile(v['keywords'], re.I) for v in VERTS}
TIE = spec.get('vertical_tiebreak') or VKEYS                      # order used when keyword votes tie
LFL_EXCLUDE = set(spec.get('like_for_like_exclude', []))          # platforms whose collection started mid-window
WS_EXCLUDE = set(spec.get('whitespace_exclude_platforms', ['LinkedIn'])) | LFL_EXCLUDE
PLATS = ['Facebook', 'Instagram', 'Instagram Stories', 'TikTok', 'LinkedIn', 'Telegram', 'YouTube', 'Meta Ads', 'Google Ads']

def offers(r):
    s = ' | '.join(r['perk']); out = 0
    for i, (n, rx) in enumerate(OFFER_RX):
        if rx.search(s): out |= 1 << i
    return out
def prodfam(r):
    s = ' | '.join(r['prod'] + r['pt']); out = 0
    for i, (n, rx) in enumerate(PF_RX):
        if rx.search(s): out |= 1 << i
    return out
def vertical(r, p):
    """Single-vertical brands keep their vertical; multi-vertical brands ('x') are classified per post by keyword votes."""
    if p['vd'] in VKEYS: return p['vd']
    if p['vd'] not in ('x', None, ''): return OTHER                     # a single-vertical brand outside this run's verticals
    strong = ' '.join(r['prod'] + r['pt'])
    blob = ' '.join(r['prod'] + r['pt'] + [r['tp'], r['title']] + r['tc']) + ' ' + r['text'][:300]
    votes = {k: len(rx.findall(blob)) for k, rx in VRX.items()}
    best = max(votes.values())
    if best == 0: return OTHER
    top = [k for k in TIE if votes.get(k) == best]
    if len(top) == 1: return top[0]
    for k in top:
        if VRX[k].search(strong): return k
    return OTHER
def funnel(r):
    disc = {'Discounts', 'Vouchers/Coupons', 'Free Shipping', 'Cashback or Rebates'}
    if 'Discounts' in r['ct'] or disc & set(r['perkT']): return 2     # BOFU
    if r['tb'] == 'Brand Awareness' or (set(r['ct']) & {'Brand Offering', 'Community Engagement', 'CSR', 'Topical', 'Company Culture', 'PSA', 'Pop Culture'}
                                        and not set(r['ct']) & {'Product Features', 'Value Added Services', 'Testimonial & Reviews', 'Educational'}): return 0
    return 1
def eng(r): return max(r['l'], r['rx']) + r['c'] + r['s'] + r['rp']
def is_placeholder(d): return (not d) or d < '2024-06-01' or d in set(spec.get('placeholder_dates', ['2025-01-01']))
def adays(r, a, b):
    """Active ad-days inside [a, b] (ISO dates). Placeholder-dated ads count 0."""
    if r['src'] != 'paid' or r.get('_ph'): return 0
    s = max(r['d'], a); e = min(r['end'] or b, b)
    return max(0, (dt.date.fromisoformat(e) - dt.date.fromisoformat(s)).days + 1) if s <= e else 0
def mon0(a):
    x = dt.date.fromisoformat(a); return day((x + dt.timedelta(days=(7 - x.weekday()) % 7)).isoformat())
def pct(a, b): return 0 if not b else round(100 * a / b)
def fmt(n): return f"{n:,}"
