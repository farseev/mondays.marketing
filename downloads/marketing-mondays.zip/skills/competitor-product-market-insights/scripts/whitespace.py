#!/usr/bin/env python3
"""Monthly whitespace per market x vertical (two-cohort PARTIAL mode: focal brand vs competitors).

Usage: python3 whitespace.py           (run from the run directory, after merge.py)
Writes whitespace.json keyed "MK-v": {n_items, n_focal_recent, n_comp_recent, median_org, lanes[], trending[]}.

A lane is one value of a SOMIN tag dimension (audience, customer need, topic, occasion).
Coverage per cohort = share of that cohort's items in the RECENT months that carry the lane.
  LOW < 5%, MEDIUM 5-20%, HIGH > 20%.
Verdicts: both LOW -> POSSIBLE WHITESPACE - UNVERIFIED (no audience cohort, so never "confirmed");
  focal LOW -> COMPETITOR-LED; competitors LOW -> FOCAL-LED; comp HIGH + focal MEDIUM -> BLOCKED; else CONTESTED.
Trend over the monthly share series: SINGLE-SHOT, DECAYED, EMERGING, RISING, FALLING, SUSTAINED.
Trending whitespace = POSSIBLE + RISING/EMERGING + response index >= 0.8 + items in each of the last 3 months
  + no month above 40% of the lane + last month >= half the average of the two before it.
Response index = lane median organic interactions / market-vertical median. It measures response, not demand.
"""
import json, re, pickle, statistics, collections as C, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

recs, prof, PERKT, NEEDS = pickle.load(open(RUN + 'recs.pkl', 'rb'))
N = len(MONTHS)
if N < 6: sys.exit(f'whitespace needs at least 6 full months in the window, found {N}')
if N < 9: print(f'WARNING: only {N} full months; the early baseline is short, so trend labels are weak')
MI = {m: i for i, m in enumerate(MONTHS)}
R0 = N - 3                                                    # index of the first RECENT month
DIMS = spec.get('whitespace_dims') or {'Audience': 'aud', 'Customer need': 'need', 'Topic': 'tc', 'Occasion': 'occ'}
MIN_ITEMS = int(spec.get('whitespace_min_items', 200))        # skip market-verticals thinner than this
MIN_LANE = int(spec.get('whitespace_min_lane', 15))
FOCAL_LED = f'{BRAND.upper()}-LED'

B = lambda r: prof[r['pid']]['name']
def comp(r): return not prof[r['pid']]['focal'] and not prof[r['pid']]['regulator']
def month(r): return None if (r['src'] == 'paid' and r['_ph']) else r['d'][:7]
def lab(s): return 'HIGH' if s > .20 else ('MEDIUM' if s >= .05 else 'LOW')
def verdict(g, c):
    lg, lc = lab(g), lab(c)
    if lg == 'LOW' and lc == 'LOW': return 'POSSIBLE WHITESPACE — UNVERIFIED'
    if lg == 'LOW': return 'COMPETITOR-LED'
    if lc == 'LOW': return FOCAL_LED
    if lc == 'HIGH' and lg == 'MEDIUM': return 'BLOCKED'
    return 'CONTESTED'
def trend(series, counts):
    tot = sum(counts)
    if tot and max(counts) / tot > .5: return 'SINGLE-SHOT'
    early = series[:-6] or series[:1]
    f6 = sum(early) / len(early); p3 = sum(series[-6:-3]) / 3; l3 = sum(series[-3:]) / 3
    if f6 >= .02 and l3 < .005: return 'DECAYED'
    if f6 < .005 and l3 >= .01: return 'EMERGING'
    if l3 >= 1.5 * f6 and l3 > p3 and l3 >= .01: return 'RISING'
    if f6 > 0 and l3 <= .67 * f6: return 'FALLING'
    return 'SUSTAINED'
def score(l):
    t = {'EMERGING': 3, 'RISING': 2.5, 'SUSTAINED': 1}.get(l['trend'], 0)
    return t * min(3, (l['ri3'] or l['ri'] or 1)) * (1 + min(l['n'], 200) / 200)
def is_trending(l):
    c = l['counts']
    return (l['verdict'].startswith('POSSIBLE') and l['trend'] in ('RISING', 'EMERGING') and (l['ri'] or 0) >= 0.8
            and all(x > 0 for x in c[-3:]) and max(c) <= 0.4 * l['n'] and c[-1] >= 0.5 * (sum(c[-3:-1]) / 2))

base = [r for r in recs if r['p'] not in WS_EXCLUDE and month(r) in MI and not prof[r['pid']]['regulator']]
WS = {}
for mk in MARKETS:
    for v in VKEYS:
        rs = [r for r in base if r['_mk'] == mk and r['_v'] == v]
        if len(rs) < MIN_ITEMS:
            print(mk, v, 'skipped: only', len(rs), 'items'); continue
        org = [r for r in rs if r['src'] == 'organic']
        med_all = statistics.median([r['_m'] for r in org]) if org else 1
        tot_m, g_m, c_m = [0] * N, [0] * N, [0] * N
        acc, disp = {}, {}
        for r in rs:
            j = MI[month(r)]; isg = r['_g']; isc = comp(r)
            tot_m[j] += 1; g_m[j] += isg; c_m[j] += isc
            for dname, f in DIMS.items():
                for raw in {x.strip() for x in (r.get(f) or []) if x and x.strip()}:
                    if raw.lower() in GENERIC or TACTIC.search(raw): continue
                    val = re.sub(r's$', '', raw.lower()).strip()
                    disp.setdefault((dname, val), C.Counter())[raw] += 1
                    a_ = acc.get((dname, val))
                    if a_ is None:
                        a_ = acc[(dname, val)] = {'cnt': [0] * N, 'g': [0] * N, 'c': [0] * N, 'org': [], 'org3': [], 'rs': []}
                    a_['cnt'][j] += 1; a_['g'][j] += isg; a_['c'][j] += isc
                    if r['src'] == 'organic':
                        a_['org'].append(r['_m'])
                        if j >= R0: a_['org3'].append(r['_m'])
                    a_['rs'].append(r)
        gR, cR = sum(g_m[R0:]), sum(c_m[R0:])
        lanes = []
        for (dname, val), a_ in acc.items():
            n = sum(a_['cnt'])
            if n < MIN_LANE: continue
            counts = a_['cnt']
            series = [counts[j] / tot_m[j] if tot_m[j] else 0 for j in range(N)]
            gs = sum(a_['g'][R0:]) / max(gR, 1); cs = sum(a_['c'][R0:]) / max(cR, 1)
            ri = statistics.median(a_['org']) / med_all if len(a_['org']) >= 15 and med_all else None
            ri3 = statistics.median(a_['org3']) / med_all if len(a_['org3']) >= 8 and med_all else None
            ev = [r['id'] for r in sorted(a_['rs'], key=lambda r: (MI[month(r)] >= R0, r['_m']), reverse=True)[:40]]
            lanes.append({'dim': dname, 'lane': disp[(dname, val)].most_common(1)[0][0], 'n': n, 'n_org': len(a_['org']),
                          'focal_recent': round(gs, 4), 'comp_recent': round(cs, 4), 'focal_label': lab(gs), 'comp_label': lab(cs),
                          'verdict': verdict(gs, cs), 'trend': trend(series, counts),
                          'series': [round(x, 4) for x in series], 'counts': counts,
                          'focal_series': [round(a_['g'][j] / g_m[j], 4) if g_m[j] else 0 for j in range(N)],
                          'comp_series': [round(a_['c'][j] / c_m[j], 4) if c_m[j] else 0 for j in range(N)],
                          'ri': round(ri, 2) if ri else None, 'ri3': round(ri3, 2) if ri3 else None, 'ev': ev,
                          'brands': C.Counter(B(r) for r in a_['rs']).most_common(4)})
        ws = sorted([l for l in lanes if is_trending(l)], key=score, reverse=True)
        for l in ws: l['trending'] = True
        keep = sorted(lanes, key=lambda l: -l['n'])[:45]
        ids = {id(l) for l in keep}
        keep += [l for l in ws if id(l) not in ids]
        WS[f'{mk}-{v}'] = {'n_items': len(rs), 'n_focal_recent': gR, 'n_comp_recent': cR, 'median_org': med_all,
                           'lanes': keep, 'trending': [l['lane'] + '|' + l['dim'] for l in ws[:6]]}
        print(mk, v, 'lanes', len(lanes), 'trending', [(l['dim'][:3], l['lane'], l['trend'], l['ri']) for l in ws[:5]])
json.dump(WS, open(RUN + 'whitespace.json', 'w'), ensure_ascii=False)
print('wrote whitespace.json for', len(WS), 'market-verticals; months', MONTHS[0], '..', MONTHS[-1], '; recent', RECENT)
