#!/usr/bin/env python3
"""Extract compact records from SOMIN posts-search results (harness-saved files or saved JSON).

Usage: python3 extract.py --out OUT.jsonl --src organic|paid FILE [FILE ...]
Appends to OUT.jsonl, deduping by id against what is already in it.
Prints: new records added, total in file, per-profile totals.
"""
import argparse, json, re, sys, os
from pathlib import Path

def iter_posts(obj):
    if isinstance(obj, dict):
        if isinstance(obj.get("items"), list):
            yield from obj["items"]
        elif "id" in obj and ("metrics" in obj or "creatives" in obj):
            yield obj
        else:
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    yield from iter_posts(v)
    elif isinstance(obj, list):
        for x in obj:
            yield from iter_posts(x)

def load_any(path):
    txt = Path(path).read_text(encoding="utf-8", errors="replace")
    try:
        return [json.loads(txt)]
    except json.JSONDecodeError:
        pass
    out, dec, i = [], json.JSONDecoder(), 0
    while True:
        m = re.search(r"[\[{]", txt[i:])
        if not m:
            break
        try:
            obj, end = dec.raw_decode(txt[i + m.start():])
            out.append(obj); i += m.start() + end
        except json.JSONDecodeError:
            i += m.start() + 1
    return out

def walk(cr, fn):
    if not cr: return None
    r = fn(cr)
    if r: return r
    for ch in cr.get("children") or []:
        r = walk(ch, fn)
        if r: return r
    return None

def img(cr):
    for im in cr.get("images") or []:
        if im.get("url"): return im["url"]
def txt(cr):
    for t in cr.get("texts") or []:
        if t.get("content"): return t["content"]
def data_field(k):
    def f(cr):
        d = cr.get("data") or {}
        return d.get(k)
    return f
def click(cr):
    cs = (cr.get("data") or {}).get("clickability_score") or {}
    for v in cs.values():
        if isinstance(v, dict) and "ABOVE_AVERAGE" in v: return round(v["ABOVE_AVERAGE"], 3)
def has_video(cr):
    return bool(cr.get("videos")) or None

def clean(s, n):
    s = re.sub(r"\s+", " ", (s or "")).replace("�", "").strip()
    return s[:n]

def platform(p):
    st = (p.get("sourceType") or "").lower()
    pl = " ".join((p.get("rawData") or {}).get("placement") or []).upper()
    if st.endswith("_ads") or p.get("type") == "AD":
        return "Google Ads" if "google" in st else "Meta Ads"
    if "STORIES" in pl or p.get("type") == "STORY": return "Instagram Stories"
    for k, lab in [("linkedin","LinkedIn"),("instagram","Instagram"),("facebook","Facebook"),("tiktok","TikTok"),("telegram","Telegram"),("youtube","YouTube")]:
        if k in st: return lab
    return st or "Other"

def L(v):
    if v is None: return []
    if isinstance(v, list): return [clean(str(x), 80) for x in v if x][:8]
    return [clean(str(v), 80)]

def compact(p, src):
    m = p.get("metrics") or {}
    rd = p.get("rawData") or {}
    f = p.get("feature") or {}
    crs = p.get("creatives") or []
    cr = crs[0] if crs else {}
    text = walk(cr, txt) or ""
    title = walk(cr, data_field("title")) or ""
    return {
        "id": p.get("id"), "pid": (p.get("profile") or {}).get("id"), "b": (p.get("profile") or {}).get("name"),
        "src": src, "st": p.get("sourceType"), "type": p.get("type"), "p": platform(p),
        "d": (p.get("postDate") or "")[:10], "end": (p.get("endDate") or "")[:10] or None,
        "act": rd.get("is_active"), "atime": rd.get("total_active_time"), "col": rd.get("collationId"),
        "pl": rd.get("publisher_platforms") or rd.get("placement"), "cc": p.get("countries"),
        "l": m.get("likesCount") or 0, "c": m.get("commentsCount") or 0, "s": m.get("sharesCount") or 0,
        "rx": m.get("reactionsCount") or 0, "rp": m.get("repostsCount") or 0,
        "v": m.get("viewsCount") or m.get("playCount") or rd.get("play_count") or rd.get("view_count"),
        "er": m.get("engagementRate"),
        "img": walk(cr, img), "vid": bool(walk(cr, has_video)), "ncr": len(cr.get("children") or []),
        "text": clean(text, 700), "title": clean(title, 160),
        "cta": clean(walk(cr, data_field("cta")) or "", 40), "link": clean(walk(cr, data_field("link_url")) or "", 200),
        "click": walk(cr, click),
        "code": rd.get("code"),
        "x": f.get("extractStatus"),
        "tp": clean(f.get("topic"), 160), "tc": L(f.get("topicCategory")), "ct": L(f.get("contentTypes")),
        "tb": clean(f.get("tacticalBrand"), 40), "tone": L(f.get("toneOfVoice")), "arch": L(f.get("archetypes")),
        "aud": L(f.get("audiences")), "need": L(f.get("humanNeed")), "hi": clean(f.get("humanInsight"), 300),
        "sp": clean(f.get("socialProblem"), 200), "bp": clean(f.get("brandProposition"), 300),
        "prod": L(f.get("mainProduct")), "gs": L(f.get("goodsServices")), "pt": L(f.get("productType")),
        "perk": L(f.get("perkIncentive")), "perkT": L(f.get("perkType")), "occ": L(f.get("occasion")),
        "emo": L(f.get("emotions")), "appeal": L(f.get("appealCategory")),
        "vcat": L(f.get("videoCategory")), "icat": L(f.get("imageCategory")), "age": L(f.get("ageGroup")), "nc": L(f.get("natureOfComms")), "pp": L(f.get("purchasingPower") or f.get("globalPurchasingPower")),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True); ap.add_argument("--src", required=True, choices=["organic","paid"])
    ap.add_argument("files", nargs="+")
    a = ap.parse_args()
    seen = set()
    if os.path.exists(a.out):
        for line in open(a.out, encoding="utf-8"):
            try: seen.add(json.loads(line)["id"])
            except Exception: pass
    added = 0
    with open(a.out, "a", encoding="utf-8") as fo:
        for fp in a.files:
            for obj in load_any(fp):
                for p in iter_posts(obj):
                    if p.get("id") in seen: continue
                    if not isinstance(p, dict) or not isinstance(p.get("feature") or {}, dict) or not p.get("profile"): continue
                    try: rec = compact(p, a.src)
                    except Exception as e: continue
                    seen.add(p.get("id")); added += 1
                    fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
    by = {}
    for line in open(a.out, encoding="utf-8"):
        r = json.loads(line); k = (r["b"], r["src"]); by[k] = by.get(k, 0) + 1
    print(f"added {added}; total {len(seen)}")
    for k, v in sorted(by.items(), key=lambda kv: (str(kv[0][0]), str(kv[0][1]))): print(f"  {k[0]} [{k[1]}]: {v}")

if __name__ == "__main__":
    main()
