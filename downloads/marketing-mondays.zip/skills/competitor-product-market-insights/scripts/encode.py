#!/usr/bin/env python3
"""Encode everything the page needs into site/ (columnar data, text shards, thumbnail bundles, expression JPGs, meta).

Usage: python3 encode.py        (run from the run directory, after insights/whitespace/chains/thumbs)
Writes site/data/meta.json (run config + insights + chains + whitespace), site/data/c_<MK>.json (one column array per
field), site/data/x_<MK>_<shard>.json (caption text by month, loaded on demand), site/t/t_<pid>.json (thumbnails per
page, loaded on demand) and site/x/<key>.jpg (expression renders). Chains and expressions are optional: the page hides
what is missing. Nothing here invents content: every string shown on the page comes from these files.
"""
import json, pickle, collections as C, os, sys, glob, shutil, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

recs, prof, PERKT, NEEDS = pickle.load(open(RUN + 'recs.pkl', 'rb'))
def J(f, d=None): return json.load(open(RUN + f)) if os.path.exists(RUN + f) else d
cov = J('coverage.json', {})
IR, IT = J('insights_recent.json', []), J('insights_trend.json', [])
WS, WSC = J('whitespace.json', {}), J('ws_chains.json', [])
CH = [c for f in sorted(glob.glob(RUN + 'chains_*.json')) for c in json.load(open(f))]
PK = {p['key']: p for p in J('chain_packets.json', [])}
for c in CH:
    p = PK.get(c['key'])
    if p: c['stats'] = {'counts': p['counts'], 'share': p['metric_share_focal_pct'], 'funnel': p['funnel_mix_pct_TOFU_MOFU_BOFU'], 'metric': p['metric']}
pm_c, pm_w = J('expr/pillar_map_chains.json', {}), J('expr/pillar_map_ws.json', {})
for i, c in enumerate(sorted(CH, key=lambda c: c['key'])): c['pillar'] = pm_c.get(c['key'], 1 + i)
for i, c in enumerate(sorted(WSC, key=lambda c: c['key'])): c['pillar'] = pm_w.get(c['key'], 101 + i)

# ---- expressions: concept metadata + renders (png -> jpg 560 px wide)
from PIL import Image
SITE = RUN + 'site/'
for d in ('data', 't', 'x'):
    os.makedirs(SITE + d, exist_ok=True)
    for f in os.listdir(SITE + d): os.remove(SITE + d + '/' + f)
EXPR = {}
for f in ('expr/concepts_chains.json', 'expr/concepts_ws.json'):
    for ins in (J(f, {}) or {}).get('insights', []):
        for k, ch in zip(['T', 'M', 'B'], ins['concepts']):
            key = f"P{ins['pillar_id']}-{k}-01"
            EXPR[key] = {'hook': ch['hook'], 'subtype': ch['subtype'], 'cta': ch.get('cta'), 'img': False}
nimg = 0
for key in EXPR:
    src = RUN + f'expr/renders/{key}.png'
    if os.path.exists(src) and os.path.getsize(src) > 50_000:
        im = Image.open(src).convert('RGB'); im.thumbnail((560, 840))
        im.save(SITE + f'x/{key}.jpg', 'JPEG', quality=80, optimize=True); EXPR[key]['img'] = True; nimg += 1
print('expressions', len(EXPR), 'with renders', nimg)

# ---- dictionaries (frequency-thresholded so the columns stay small)
cnt = {k: C.Counter() for k in ['perk', 'prod', 'aud', 'occ', 'tone', 'ct']}
for r in recs:
    for k in cnt: cnt[k].update(set(r[k]))
keep = {'perk': {v for v, n in cnt['perk'].items() if n >= 2}, 'prod': {v for v, n in cnt['prod'].items() if n >= 2},
        'aud': {v for v, n in cnt['aud'].items() if n >= 3}, 'occ': {v for v, n in cnt['occ'].items() if n >= 3},
        'tone': {v for v, n in cnt['tone'].most_common(80)}, 'ct': {v for v, n in cnt['ct'].items() if n >= 2}}
lists = {k: sorted(v, key=lambda x: -cnt[k][x]) for k, v in keep.items()}
idx = {k: {v: i for i, v in enumerate(l)} for k, l in lists.items()}
ctas = [v for v, n in C.Counter(r.get('cta') or '' for r in recs).most_common()]; cidx = {v: i for i, v in enumerate(ctas)}
present = {r['p'] for r in recs}
plats = [p for p in PLATS if p in present] + sorted(present - set(PLATS))
PAID_P = [p for p in plats if p.endswith(' Ads') or p in spec.get('paid_platforms', [])]
ORG_P = [p for p in plats if p not in PAID_P]
VI = {k: i for i, k in enumerate(VKEYS)}; VI[OTHER] = len(VKEYS)
TH = J('thumbs_cache.json', {})
def L(k, vals, n): return [idx[k][v] for v in vals if v in idx[k]][:n]
def shard(r):
    if r['src'] == 'paid' and r['_ph']: return 'ph'
    d = r['d'][:7]
    return 'pre' if d < MONTHS[0] else d

# thumbnails: keep each page bundle under ~14 MB (priority = thumb_urls.json order)
order = list(J('thumb_urls.json', {}).keys()) or list(TH.keys())
pid_of = {str(r['id']): r['pid'] for r in recs}
bp, size = C.defaultdict(dict), C.Counter(); dropped = 0
for k in order:
    v = TH.get(k)
    if not v or k not in pid_of: continue
    pid = pid_of[k]
    if size[pid] + len(v) > 14_000_000: dropped += 1; continue
    bp[pid][k] = [v]; size[pid] += len(v)
has_th = {k for d_ in bp.values() for k in d_}
for pid, d_ in bp.items(): json.dump(d_, open(SITE + f't/t_{pid}.json', 'w'), separators=(',', ':'))
print('thumb bundles', len(bp), 'thumbs', len(has_th), 'dropped (bundle cap)', dropped, 'MB', round(sum(size.values()) / 1e6, 1))

cols, texts, colmap = {}, C.defaultdict(dict), {}
FIELDS = ['id', 'pid', 'src', 'plat', 'd', 'end', 'ph', 'm', 'v', 'fu', 'of', 'pf', 'gs', 'nc', 'pt', 'need', 'perk', 'prod', 'ct', 'tone', 'aud', 'occ',
          'la', 'cta', 'code', 'th', 'vid', 'l', 'c', 's', 'col', 'sh']
for mk in MARKETS: cols[mk] = {f: [] for f in FIELDS}
for r in recs:
    if r['_mk'] not in cols: continue
    o = cols[r['_mk']]; ck = r.get('col') or ''
    ci = colmap.setdefault(r['_mk'], {}).setdefault(ck, len(colmap[r['_mk']])) if ck else -1
    sh = shard(r)
    vals = [r['id'], r['pid'], 0 if r['src'] == 'organic' else 1, plats.index(r['p']), day(r['d']) if r['d'] else -9999,
            day(r['end']) if r['end'] else 99999, int(r['_ph']), r['_m'], VI.get(r['_v'], VI[OTHER]), r['_f'], r['_o'], r['_pf'], r['_gs'], r['_nc'], r['_pt'], r['_need'],
            L('perk', r['perk'], 3), L('prod', r['prod'], 3), L('ct', r['ct'], 3), L('tone', r['tone'], 2), L('aud', r['aud'], 3), L('occ', r['occ'], 2),
            int(r['_la']), cidx[r.get('cta') or ''], r.get('code') or '', int(str(r['id']) in has_th), int(bool(r['vid'])), r['l'] or r['rx'], r['c'], r['s'], ci, sh]
    for f, v in zip(FIELDS, vals): o[f].append(v)
    texts[(r['_mk'], sh)][r['id']] = [(r['text'] or '')[:260], (r['title'] or '')[:110], (r['hi'] or '')[:220]]
for mk, o in cols.items():
    json.dump(o, open(SITE + f'data/c_{mk}.json', 'w'), ensure_ascii=False, separators=(',', ':'))
for (mk, sh), t in texts.items():
    json.dump(t, open(SITE + f'data/x_{mk}_{sh}.json', 'w'), ensure_ascii=False, separators=(',', ':'))
firstAd = {}
for r in recs:
    if r['src'] == 'paid' and not r['_ph']: firstAd[r['pid']] = min(firstAd.get(r['pid'], '9'), r['d'])

# ---- run config for the page (all wording that depends on the run lives here)
def dlong(d): x = dt.date.fromisoformat(d); return f"{x.day} {x.strftime('%b %Y')}"
end_next = dt.date.fromisoformat(MONTHS[-1] + '-01'); end_next = (end_next.replace(day=28) + dt.timedelta(days=4)).replace(day=1).isoformat()[:7]
full_days = (dt.date.fromisoformat(W_END) - dt.date.fromisoformat(W_START)).days + 1
full_label = spec.get('full_label') or (f'Last {round(full_days / 30.4)} months' if full_days > 62 else f'Last {full_days} days')
recent_label = spec.get('recent_label') or f'Last {RECENT_DAYS} days'
m0 = mon0(R_START)
new_since = MONTHS[3] + '-01' if len(MONTHS) > 6 else MONTHS[0] + '-01'
fa_months = sorted(v[:7] for k, v in cov.get('first_ad', {}).items() if v[:7] > MONTHS[0])
paid_note = (f"Paid tracking for {len(fa_months)} advertisers began after {mlabel(MONTHS[0])} (mostly {mlabel(C.Counter(fa_months).most_common(1)[0][0])}), so early paid months are thin."
             if len(fa_months) >= 3 else '')
lfl = sorted(LFL_EXCLUDE)
lfl_note = f"Month-on-month comparisons are like-for-like: {', '.join(lfl)} {'is' if len(lfl) == 1 else 'are'} excluded because SOMIN collection started mid-window." if lfl else ''
wsx = sorted(WS_EXCLUDE)
mk_ws = ', '.join(str(w) for m in spec['markets'] for w in (m.get('workspace_ids') or ([m['workspace_id']] if m.get('workspace_id') else [])))
src_ws = [str(w) for w in (spec.get('source_workspaces') or [])]
src_txt = spec.get('source_text') or (f"SOMIN workspace{'s' if len(src_ws) != 1 else ''} {', '.join(src_ws) if src_ws else '(see spec)'}, {len(prof)} pages labelled by market."
                                       + (f" Insights and stories for the Marketing view come from the market workspaces ({mk_ws})." if mk_ws else ''))
nexpr = nimg
scope = [
    ['Source', src_txt],
    ['Window', f"Organic posts dated {dlong(W_START)} – {dlong(W_END)}, and ads live at any point in that window. The recent period is {dlong(R_START)} – {dlong(W_END)}."],
    ['Volume', "{N} items: {O} organic posts and {A} ads. Each profile was checked against SOMIN's own count during collection. "
               "Shared pages and shared advertisers come back under one page, so ads are moved to the market in their own country code."],
    ['Metrics', "Organic: interactions, meaning likes or reactions plus comments, shares and reposts. Paid: active ad-days inside the selected period. "
                "{PH} ads carry a placeholder start date and are not counted in ad-days or new-ad counts."],
    ['Coverage changes', (lfl_note + ' ' if lfl_note else '') + (paid_note or 'Paid tracking dates are shown on each advertiser dashboard.')],
    ['Filters', "Offering type uses SOMIN's goods or services tag, and a post can be both. Segment uses SOMIN's nature-of-communication tag (B2C or B2B). "
                "Incentive type uses SOMIN's incentive-type tags, top {PT}. Customer needs use SOMIN's human-need tags, top {NEED}."],
    ['Verticals', f"{', '.join(VLAB[k] for k in VKEYS)}. Single-vertical brands keep their vertical. For multi-vertical brands each post is assigned from SOMIN's product tags and its text; posts that match no vertical appear under “All” only."],
    ['First seen', f"An offer or product counts as new when SOMIN first tags it after {dlong(new_since)}, on a page tracked for at least 60 days before, with at least 3 items."],
    ['Whitespace', f"Run monthly per market and vertical with the whitespace-analysis rubric in two-cohort mode ({BRAND} vs competitors). With no creator or audience cohort, the strongest verdict is POSSIBLE WHITESPACE — UNVERIFIED. "
                   f"Trend labels: RISING, EMERGING, SUSTAINED, FALLING, DECAYED, SINGLE-SHOT. A trending lane has items in each of the last three months, no month over 40% of its volume, and a response index of at least 0.8×."
                   + (f" {', '.join(wsx)} {'is' if len(wsx) == 1 else 'are'} excluded." if wsx else '')],
]
if CH or WSC:
    scope.append(['Insight chains', f"{len(CH)} recent-window chains and {len(WSC)} whitespace chains, written only from evidence packets and checked by a validator: quotes are exact, every reference is a real post, and numbers are checked against the packet figures."])
if nexpr:
    scope.append(['Expressions', f"{nexpr} images (TOFU, MOFU and BOFU per chain). Each prompt was built by the SOMIN expressions engine and passed the provenance gate (manifest kept). A {BRAND} brand-lock suffix was appended after the gate. Hooks are 7 words or fewer, and CTAs come from {BRAND}'s real ad CTAs in each market."])
if spec.get('known_gaps'): scope.append(['Known gaps', ' '.join(spec['known_gaps'])])

CFG = {'brand': BRAND, 'title': spec.get('title', f'{BRAND} Competitive Pulse'), 'markets': spec['markets'], 'region_label': spec.get('region_label_short', 'All markets'),
       'verticals': [{'key': v['key'], 'label': v['label']} for v in VERTS], 'default_vertical': spec.get('default_vertical'),
       'months': MONTHS, 'month_end': end_next, 'epoch_y': EPOCH.year,
       'w_recent': [day(R_START), day(W_END)], 'w_full': [day(W_START), day(W_END)], 'mon0': m0, 'weeks': (day(W_END) - m0) // 7 + 1,
       'recent_label': recent_label, 'full_label': full_label,
       'recent_text': f"{recent_label.lower()} ({dmy(R_START)} – {dlong(W_END)})", 'full_text': f"{full_label.lower()} ({dlong(W_START)} – {dlong(W_END)})",
       'months_text': f"{mlabel(MONTHS[0])} – {mlabel(MONTHS[-1])}", 'recent_months_text': f"{mlabel(RECENT[0])} – {mlabel(RECENT[-1])}",
       'new_since': new_since, 'new_since_text': dlong(new_since),
       'organic': ORG_P, 'paid': PAID_P, 'lfl_exclude': lfl, 'lfl_note': lfl_note,
       'lfl_toggle': f"Include {', '.join(lfl)} (collection started mid-window)" if lfl else '',
       'ws_exclude_text': f"Like-for-like: {', '.join(wsx)} {'is' if len(wsx) == 1 else 'are'} excluded." if wsx else '',
       'paid_note': paid_note, 'footer': f"Source: SOMIN. {dlong(W_START)} – {dlong(W_END)}.", 'scope': scope}
meta = {'cfg': CFG, 'prof': prof, 'lists': {**lists, 'cta': ctas, 'plat': plats, 'need': NEEDS, 'pt': PERKT},
        'offers': [o[0] for o in OFFER], 'pf': [p[0] for p in PRODFAM], 'ins90': IR, 'ins12': IT, 'chains': CH, 'ws': WS, 'wsChains': WSC,
        'expr': EXPR, 'nexpr': nexpr, 'firstAd': firstAd, 'n': len(recs)}
json.dump(meta, open(SITE + 'data/meta.json', 'w'), ensure_ascii=False, separators=(',', ':'))
tot = 0
for f in sorted(os.listdir(SITE + 'data')):
    s = os.path.getsize(SITE + 'data/' + f); tot += s
    if not f.startswith('x_'): print(' ', f, round(s / 1e6, 2), 'MB')
    if s > 15_500_000: print('WARNING: file over the 16 MB publish limit:', f)
print('data MB', round(tot / 1e6, 1), 'files', len(os.listdir(SITE + 'data')), 'markets', list(cols), 'platforms organic', ORG_P, 'paid', PAID_P)
