#!/usr/bin/env python3
"""Merge every harvest file (raw/*.jsonl) into one record set with derived fields.

Usage: python3 merge.py            (run from the run directory)
Writes recs.pkl and coverage.json (platform x month counts, first ad date per page, placeholder ads).
Read coverage.json before trusting trends: a platform whose counts start mid-window goes into
spec.like_for_like_exclude; a page whose first ad is late is printed on its dashboard.
"""
import json, glob, re, pickle, collections as C, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import *

rows = {}
files = sorted(glob.glob(RUN + 'raw/*.jsonl'))
if not files: sys.exit('no raw/*.jsonl files: run the harvest first')
for f in files:
    for line in open(f, encoding='utf-8'):
        r = json.loads(line)
        if r.get('id') is None: continue
        o = rows.get(r['id'])
        if o is None or (r.get('end') or '') >= (o.get('end') or ''):     # keep the most recently scraped copy
            if o is not None:
                for k in ('pid', 'b', 'img', 'cc'):
                    if not r.get(k) and o.get(k): r[k] = o[k]                   # a re-extract can miss the profile block
            rows[r['id']] = r
nopid = [i for i, r in rows.items() if r.get('pid') is None]
for i in nopid: del rows[i]
fixed = 0
for r in rows.values():
    r.setdefault('nc', []); r.setdefault('pp', [])
    if r['src'] == 'organic' and ((r.get('st') or '').endswith('_ads') or r['p'] in ('Meta Ads', 'Google Ads')):
        r['src'] = 'paid'; fixed += 1                                           # extracted with the wrong --src flag
if fixed: print('WARNING: corrected', fixed, 'ad rows that were extracted as organic')
print('merged unique', len(rows), 'from', len(files), 'files', f'(dropped {len(nopid)} rows with no profile id)' if nopid else '')

# ---- profiles: spec.profiles override, else "Name (MK)" suffix
SPECP = {int(k): v for k, v in (spec.get('profiles') or {}).items()}
ALIAS = spec.get('aliases', {}); REG = set(spec.get('regulators', [])); BV = spec.get('brand_verticals', {})
prof, bykey = {}, {}
for r in rows.values():
    pid = r['pid']
    if pid in prof: continue
    if pid in SPECP: full, mk = SPECP[pid]['name'], SPECP[pid]['market']
    else:
        m = re.match(r'(.*?)\s*\((\w\w)\)\s*$', r['b'] or '')
        if not m: sys.exit(f'profile {pid} "{r["b"]}" has no market: add it to spec.profiles')
        full, mk = m.group(1).strip(), m.group(2)
    short = ALIAS.get(full, full)
    prof[pid] = {'pid': pid, 'name': short, 'mk': mk, 'focal': short == BRAND, 'vd': BV.get(short, 'x'), 'regulator': short in REG}
for p in prof.values(): bykey[(p['name'], p['mk'])] = p['pid']
unknown_mk = {p['mk'] for p in prof.values()} - set(MARKETS)
if unknown_mk: print('WARNING: profile markets not in spec.markets:', unknown_mk)

# ---- ads move to the market in their own single country code (shared advertisers sit on one page)
moved = C.Counter()
for r in rows.values():
    r['opid'] = r['pid']
    if r['src'] == 'paid':
        cc = [c for c in (r.get('cc') or []) if c in MARKETS]
        if len(cc) == 1 and cc[0] != prof[r['pid']]['mk']:
            t = bykey.get((prof[r['pid']]['name'], cc[0]))
            if t: moved[(prof[r['pid']]['name'], prof[r['pid']]['mk'], cc[0])] += 1; r['pid'] = t
print('ads moved by country code:', moved.most_common(12))

# ---- SOMIN tag taxonomies kept as filters
PERKT_MAP = {'Exclusive Access': 'Early Access or Exclusive Access', 'Free Delivery': 'Free Shipping', 'Coupons': 'Vouchers/Coupons',
             'Vouchers': 'Vouchers/Coupons', 'Rewards': 'Loyalty/Reward Programs', 'Cashback': 'Cashback or Rebates'}
ptc = C.Counter(PERKT_MAP.get(v, v) for r in rows.values() for v in r['perkT'])
PERKT = [v for v, n in ptc.most_common(18) if v != 'Undetermined'][:14]
needc = C.Counter(v for r in rows.values() for v in r['need'])
NEEDS = [v for v, n in needc.most_common(24) if v not in ('Undetermined', 'General')][:18]

recs = []
for r in rows.values():
    p = prof[r['pid']]
    if p['mk'] not in MARKETS: continue                                       # pages outside the markets in spec
    if r['src'] == 'organic' and not (W_START <= r['d'] <= W_END): continue
    if r['src'] == 'paid' and r['end'] and r['end'] < W_START: continue
    r['_mk'] = p['mk']; r['_g'] = p['focal']
    r['_v'] = vertical(r, p); r['_o'] = offers(r); r['_pf'] = prodfam(r); r['_f'] = funnel(r)
    r['_m'] = eng(r) if r['src'] == 'organic' else 0
    r['_ph'] = r['src'] == 'paid' and is_placeholder(r['d'])
    r['_la'] = bool(LAUNCH.search((r['text'] or '') + ' ' + (r['title'] or '')))
    gs = set(r['gs']); r['_gs'] = (1 if 'Goods' in gs else 0) | (2 if 'Services' in gs else 0)
    nc = set(r['nc']); r['_nc'] = (1 if 'Business to Consumer' in nc else 0) | (2 if 'Business to Business' in nc else 0)
    r['_pt'] = sorted({PERKT.index(PERKT_MAP.get(v, v)) for v in r['perkT'] if PERKT_MAP.get(v, v) in PERKT})
    r['_need'] = [NEEDS.index(v) for v in r['need'] if v in NEEDS][:3]
    recs.append(r)

cov = {'platform_by_month': {}, 'market_by_month': {}, 'first_ad': {}, 'placeholder_ads': sum(r['_ph'] for r in recs),
       'vertical_by_brand': {}, 'records': len(recs)}
pm = C.Counter((r['p'], r['d'][:7]) for r in recs if r['src'] == 'organic')
for (p_, m), n in pm.items(): cov['platform_by_month'].setdefault(p_, {})[m] = n
mm = C.Counter((r['_mk'], r['d'][:7]) for r in recs if r['src'] == 'organic')
for (k, m), n in mm.items(): cov['market_by_month'].setdefault(k, {})[m] = n
for r in recs:
    if r['src'] == 'paid' and not r['_ph']:
        k = str(r['pid']); cov['first_ad'][k] = min(cov['first_ad'].get(k, '9'), r['d'])
for b in {p['name'] for p in prof.values() if p['vd'] == 'x'}:
    cov['vertical_by_brand'][b] = dict(C.Counter(r['_v'] for r in recs if prof[r['pid']]['name'] == b))
json.dump(cov, open(RUN + 'coverage.json', 'w'), indent=1)
pickle.dump((recs, prof, PERKT, NEEDS), open(RUN + 'recs.pkl', 'wb'))
print('records', len(recs), dict(C.Counter(r['src'] for r in recs)), 'placeholder ads', cov['placeholder_ads'])
print('organic by platform and month (check where collection starts):')
ms = sorted({m for d_ in cov['platform_by_month'].values() for m in d_})
for p_, d_ in sorted(cov['platform_by_month'].items()):
    print(f'  {p_:18}', ' '.join(f'{d_.get(m, 0):5}' for m in ms))
print('mixed-brand vertical split:', cov['vertical_by_brand'])
