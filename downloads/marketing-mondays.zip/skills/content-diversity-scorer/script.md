# Content Diversity Scorer — Execution Script

**You must have read spec.md fully before opening this file. If you have not, close this file and read spec.md first.**

**Process campaigns one at a time. Complete the full checklist for one campaign before moving to the next.**

---

## Before starting: confirm prerequisites

```
[ ] meta-ads-analyzer (separate SOMIN skill, if installed) script.md gate is OPEN
[ ] D1 (ad aggregate) data available for all Phase 3 campaigns
[ ] meta-creative-fatigue (separate SOMIN skill, if installed) complete for the campaign being processed
    (similarity cluster data from F7 required for Dimension 4)
[ ] E1 (creative asset pull) status known — available or not run
    If available: body, title, image_url, video_id accessible from ads_get_creatives
    If not run: format and theme inference falls back to D1 + ad name parsing
```

---

## Campaign processing order

Process campaigns in the same order as meta-creative-fatigue (separate SOMIN skill, if installed) — which is the same sort order as meta-report-architect:
1. CRITICAL by spend descending
2. SLIPPING by spend descending

---

## Per-campaign checklist — run for EVERY Phase 3 campaign

**Campaign being processed: [name] — [verdict] — $[spend]**

---

### STEP 1 — Confirm campaign context

Before any diversity analysis, confirm the context that every observation must connect back to.

- [ ] Campaign verdict: [CRITICAL / SLIPPING / HEALTHY]
- [ ] Root cause from meta-ads-analyzer (separate SOMIN skill, if installed): [CREATIVE / AUDIENCE / COMPOUND / POST-CLICK]
- [ ] Three-way audience health verdict: [AUDIENCE SATURATION / CREATIVE FATIGUE LIKELY / EXTERNAL AUCTION PRESSURE / HEALTHY DELIVERY]
- [ ] Similarity clusters from meta-creative-fatigue (separate SOMIN skill, if installed) F7: [N clusters — describe]
- [ ] E1 data available: [YES — body, title, image_url, video_id accessible / NO — inference from D1 + ad names only]

```
Context [campaign name]: [verdict] · root cause [X] · three-way [X] · clusters [N] ✓
```

---

### STEP 2 — Dimension 1: Format Diversity

→ **Re-read spec.md Section 2, Dimension 1 (format inference method) before this step.**

**2a — Identify relevant formats for this campaign's funnel type:**

| Objective | Relevant formats |
|---|---|
| OUTCOME_SALES / LINK_CLICKS | Video, Static image, Carousel, Collection, Dynamic product ad |
| APP_INSTALLS | Video, Static image |
| OUTCOME_ENGAGEMENT / OUTCOME_AWARENESS | Video, Static image, Instant Experience, Collection |
| Messaging | Messenger ad, WhatsApp ad |

Relevant formats for this campaign: [list]

**2b — Infer format per ad from available data:**

For each active ad in D1, apply inference signals in order:

**If E1 is available:**
- [ ] Check `video_id` → VIDEO if present
- [ ] Check `image_hash` without `video_id` → STATIC IMAGE
- [ ] Check `child_attachments` with multiple items → CAROUSEL
- [ ] Check `object_type: SHARE` with `product_set_id` → DYNAMIC PRODUCT AD

**If E1 not available, use D1 video fields:**
- [ ] `video_thruplay_watched_actions` or `video_p25_watched_actions` non-null and non-zero → VIDEO
- [ ] All video fields null or zero → STATIC / UNKNOWN

**Fallback — ad name parsing:**
- [ ] Check ad names for format-encoding segments (`_video_`, `_static_`, `_carousel_`, `_ugc_`)

**2c — Count distinct formats and apply threshold:**

Formats identified: [list with ad count per format]
Distinct format count: [N]
Verdict: [HIGH ≥4 / MODERATE = 3 / LOW = 2 / SINGLE-FORMAT RISK = 1]
Data source used: [E1 creative data / D1 video fields / ad name parsing / assumed from absence]

```
Dim 1 [campaign name]: [N] formats [HIGH/MOD/LOW/RISK] · absent: [list] ✓
```

---

### STEP 3 — Dimension 2: Thematic Diversity

→ **Re-read spec.md Section 2, Dimension 2 (theme inference method) before this step.**

**3a — Infer theme per ad from available data in order:**

**Signal 1 — E1 body and title (most reliable, if E1 available):**
- [ ] Read `body` (primary text) for each ad creative
- [ ] Read `title` (headline) for each ad creative
- [ ] Classify each ad against the nine themes: Seasonal / Product feature / Social proof / Promotional-Sale / Behind-the-scenes / Course-Educational / Event / Direct Response / Evergreen-Brand

**Signal 2 — Ad name parsing:**
- [ ] Check ad names for theme-encoding segments (FACES convention: `_ev-bau_` = Evergreen, `_ev-promo_` = Promotional, `_ev-ss_` = Seasonal/Sale, `_ev-event_` = Event)
- [ ] Apply pattern: if ad name contains recognisable theme encoding, classify accordingly

**Signal 3 — Campaign name:**
- [ ] Check campaign name for theme-encoding (e.g. "PromoSale", "BAU", "Seasonal")

**Signal 4 — image_url visual inspection (if E1 available):**
- [ ] If body/title and ad name are inconclusive, inspect image_url for visual theme signals

**3b — Count distinct themes and apply threshold:**

Themes identified per ad: [list]
Distinct theme count: [N]
Verdict: [HIGH ≥4 / MODERATE = 3 / LOW = 2 / SINGLE-THEME RISK = 1]
Data source used: [E1 body/title / ad name / campaign name / image_url / UNKNOWN]

If theme cannot be determined for any ad: mark "theme unknown — [reason: E1 not available and ad name does not encode theme]"

```
Dim 2 [campaign name]: [N] themes [HIGH/MOD/LOW/RISK] · absent: [list] ✓
```

---

### STEP 4 — Dimension 3: Creative Ratio

→ **Re-read spec.md Section 2, Dimension 3 (formula clarification) before this step.**

From D1 for this campaign:
- [ ] Count unique `creative_id` values across all active ads: [N unique]
- [ ] Count total active ads: [N total]
- [ ] Compute: [N unique] ÷ [N total] = [ratio]
- [ ] Apply threshold: >0.7 = HIGH / 0.4–0.7 = MODERATE / <0.4 = LOW

Note: Active ads = ads with `effective_status` ACTIVE or with spend in the date range from D1.

```
Dim 3 [campaign name]: ratio [X] [HIGH/MOD/LOW] ✓
```

---

### STEP 5 — Dimension 4: Andromeda clustering impact

→ **Re-read spec.md Section 2, Dimension 4 (corrected multi-cluster formula) before this step.**

Data source: meta-creative-fatigue (separate SOMIN skill, if installed) F7 output for this campaign.

- [ ] Similarity clusters confirmed from meta-creative-fatigue (separate SOMIN skill, if installed): [N clusters]

**If no clusters:**
Effective unique count = total active ads from D1 = [N]
Statement: "No Andromeda clusters detected — all [N] ads have unique creative IDs."

**If one or more clusters:**
- [ ] List each cluster: creative_id [X] — [N] ads — ad sets [list]
- [ ] Compute redundant ads per cluster: (cluster_size − 1) for each
- [ ] Sum all redundant ads: Σ(cluster_size − 1) = [M]
- [ ] Effective unique count: [total_ads] − [M] = [effective_unique_count]

Show the formula visibly:
"[total_ads] total ads − [M] redundant (cluster A: [size]−1=[redundant], cluster B: [size]−1=[redundant]) = [effective_unique_count] effective unique creatives."

```
Dim 4 [campaign name]: [N] effective unique ([N] total − [M] redundant) ✓
```

---

### STEP 6 — Dimension 5: Format and theme gap

From Dimensions 1 and 2:
- [ ] Formats in use: [list]
- [ ] Relevant formats for this objective: [list from Dimension 1 table]
- [ ] Format gaps: [relevant formats not in use]
- [ ] Themes in use: [list]
- [ ] Theme gaps: [absent themes from the nine that would introduce differentiation]

**Prioritise gaps that connect to the root cause:**
- CREATIVE root cause → which gaps would introduce formats/themes that Andromeda treats as genuinely distinct?
- AUDIENCE root cause → which gaps would give recycled accounts something new to respond to?
- HEALTHY → note gaps as opportunities, not urgencies

```
Dim 5 [campaign name]: format gaps [list] · theme gaps [list] ✓
```

---

### STEP 7 — Root cause connection

→ **Re-read spec.md Section 3 (root cause connection templates) before this step.**

Select the correct template for this campaign's root cause and populate it with actual values:

**If CREATIVE root cause:**
Use the CREATIVE template. Fill in: Creative Ratio, cluster count, effective_unique_count, the specific primary metric gradient (e.g. ROAS decline).

**If AUDIENCE root cause:**
Use the AUDIENCE template. Fill in: Creative Ratio, format count, frequency gradient from C2.

**If COMPOUND root cause:**
Use the COMPOUND template. Fill in: Creative Ratio, effective_unique_count, what happens if audience is expanded without creative refresh.

**If HEALTHY:**
Use the HEALTHY template. Fill in: format count, theme count, cluster severity.

- [ ] Correct template selected: [CREATIVE / AUDIENCE / COMPOUND / HEALTHY]
- [ ] Template populated with actual metric values from this campaign
- [ ] No generic statements — every sentence references this specific campaign's data

```
Root cause [campaign name]: template [X] ✓
```

---

### STEP 8 — Assemble Tab 3 item 8 output

→ **Re-read spec.md Section 5 (output format) before assembling.**

Write as narrative prose — not a bullet list. The bullets below are structure guides; the output is connected paragraphs.

- [ ] Framework disclaimer: "The following diversity observations use a constructed analytical framework for consistent comparison — not official Meta metrics or published industry standards."
- [ ] Format Diversity paragraph: formats in use, count, verdict, data source stated
- [ ] Thematic Diversity paragraph: themes in use, count, verdict, data source stated
- [ ] Creative Ratio paragraph: formula shown, result, verdict
- [ ] Andromeda clustering impact paragraph: formula shown, effective unique count, plain language statement
- [ ] Format and theme gaps paragraph: specific absent formats/themes, connection to objective
- [ ] Root cause connection paragraph: using correct template with actual values

```
Tab 3 item 8 complete — [campaign name] ✓
```

---

### Write stageAnalysis.stage4 to report_data.json — MANDATORY before moving to next campaign

```bash
python3 << 'PYEOF'
import json

with open('/mnt/user-data/outputs/report_data.json') as f:
    d = json.load(f)

campaign_id = '[campaign_id]'

# Write Stage 4 output into stageAnalysis.stage4
# Read by meta-report-architect (separate SOMIN skill, if installed) in Stage 5:
#   diversityObservations → Tab 3 item 8 (the full diversity paragraph)

d['campaignData'][campaign_id]['stageAnalysis']['stage4'] = {
    'diversityObservations': '[Full narrative prose paragraph — framework disclaimer, format diversity, thematic diversity, Creative Ratio, Andromeda effective count, format/theme gaps, root cause connection using correct template]'
}

with open('/mnt/user-data/outputs/report_data.json', 'w') as f:
    json.dump(d, f, indent=2)

# Verify
with open('/mnt/user-data/outputs/report_data.json') as f:
    check = json.load(f)
s4 = check['campaignData'][campaign_id].get('stageAnalysis', {}).get('stage4', {})
assert s4.get('diversityObservations'), f"FAIL: stage4.diversityObservations empty for {campaign_id}"
print(f'stage4 written and verified for {campaign_id[:30]}')
PYEOF
```

---

### Campaign complete confirmation

```
CONTENT DIVERSITY COMPLETE ✓ — [campaign name] — [verdict] — Tab 3 item 8 ready ✓
```

---

## Final confirmation — all campaigns processed

```
CONTENT DIVERSITY SCORER COMPLETE — [N] campaigns · Tab 3 item 8 ready for all ✓
```

---

## Channel concentration — add once to report Limitations section

After processing all campaigns, add this observation to the report Limitations section (not to any campaign tab):

"100% of paid spend is concentrated on Meta. This is a business risk independent of campaign performance — any Meta algorithm shift, CPM spike, or account restriction affects the entire paid acquisition strategy. Acting on this requires a separate platform audit, creative production planning, and budget discussion."

- [ ] Added to Limitations section ✓
