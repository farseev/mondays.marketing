# Content Diversity Scorer — Spec

**Read this file fully before opening script.md. This is not a checklist. It is the knowledge base you need to apply each dimension correctly and connect observations to campaign findings.**

---

## SECTION 1 — What this skill produces and why

For each Phase 3 campaign, this skill produces observations across five dimensions that together describe the structural diversity of a campaign's creative mix. These observations are embedded in Tab 3 item 8 of the campaign's HTML section — they do not stand alone.

**Why creative diversity matters:**
When Meta's delivery system recycles the same accounts due to audience saturation, a campaign with high creative diversity gives those recycled accounts something genuinely new to respond to. A campaign with low creative diversity compounds the fatigue problem — the same account sees the same ad type with the same message at increasing frequency. Diversity is not a goal in itself; it is a lever that affects how quickly fatigue accumulates and how effectively spend distributes across a varied creative set.

**The thresholds in this framework are constructed — not official Meta metrics.** They exist to produce consistent, comparable observations across campaigns within the same report. State this when presenting scores: "The following diversity observations use a constructed analytical framework for consistent comparison — not official Meta metrics or published industry standards."

---

## SECTION 2 — The five dimensions

### Dimension 1 — Format Diversity

**What it measures:** How many distinct creative formats does this campaign use?

**Thresholds:**
- 4+ formats = HIGH diversity
- 3 formats = MODERATE
- 2 formats = LOW
- 1 format = SINGLE-FORMAT RISK

**Relevant formats by funnel type:**
The applicable formats depend on the campaign's objective and destination. State which formats are relevant before assessing diversity.

| Funnel type | Relevant formats |
|---|---|
| Website conversion (OUTCOME_SALES, LINK_CLICKS) | Video, Static image, Carousel, Collection, Dynamic product ad |
| App install (APP_INSTALLS) | Video, Static image (optimised for app install) |
| On-Facebook (OUTCOME_ENGAGEMENT, awareness) | Video, Static image, Instant Experience / Canvas, Collection |
| Messaging | Messenger ad, WhatsApp ad |

**How to infer format from available API data — no `format` field exists:**

Apply these signals in order. Stop at the first signal that confirms the format.

**Signal 1 — E1 creative asset data (if E1 was pulled):**
- `video_id` present in the creative → VIDEO
- `image_hash` present, no `video_id` → STATIC IMAGE
- `child_attachments` present with multiple items → CAROUSEL
- `object_type: SHARE` with `product_set_id` → DYNAMIC PRODUCT AD

**Signal 2 — D1 video fields (always available):**
- `video_thruplay_watched_actions` non-null AND non-zero for this ad → VIDEO
- `video_p25_watched_actions` non-null AND non-zero → VIDEO
- All video fields null or zero → likely STATIC IMAGE or CAROUSEL (cannot distinguish from D1 alone)

**Signal 3 — Ad name parsing:**
If the campaign naming convention encodes format (e.g. `_video_`, `_static_`, `_carousel_`, `_ugc_`) — extract from the name.

**Signal 4 — Default when all signals are inconclusive:**
If E1 was not pulled and all video fields are null, mark format as "STATIC/UNKNOWN — format unconfirmed from available data."

**State data source used:** "Format inferred from [E1 creative data / D1 video fields / ad name parsing / assumed from video field absence]."

---

### Dimension 2 — Thematic Diversity

**What it measures:** How many distinct messaging themes or content pillars does this campaign use?

**Thresholds:**
- 4+ themes = HIGH diversity
- 3 themes = MODERATE
- 2 themes = LOW
- 1 theme = SINGLE-THEME RISK

**Available themes:**
Seasonal, Product feature/benefit, Social proof / Influencer, Promotional / Sale / Offer, Behind-the-scenes, Course / Educational, Event, Direct Response / CTA-led, Evergreen / Brand.

**How to infer theme from available API data — no `theme` field exists:**

Apply these signals in order, combining where multiple are available.

**Signal 1 — E1 ad copy (body and title fields, if E1 was pulled):**
This is the most reliable signal. The `body` (primary text) and `title` (headline) from `ads_get_creatives` directly state the messaging angle.
- "Save 30% this weekend only" → Promotional / Sale
- "Trusted by 50,000 customers" → Social proof
- "Introducing the new Example Brand collection" → Product feature
- "Limited time — shop now" → Direct Response

**Signal 2 — Ad names:**
If the campaign naming convention encodes the creative angle (FACES campaigns encode this: `_ev-bau_` = BAU/Evergreen, `_ev-promo_` = Promotional, `_ev-ss_` = Season/Sale, `_br-hugo-boss_` = Brand).
Extract the theme-relevant segment from the name.

**Signal 3 — Campaign name:**
Campaign names sometimes encode the brief type (e.g. "FACES_Conversion_HugoBoss_PromoSale_Jun26").

**Signal 4 — image_url from E1:**
If image_url is available, visual inspection of the creative can confirm the theme.

**Signal 5 — Default when all signals are inconclusive:**
"Theme could not be determined from available data — E1 creative body/title not available and ad name does not encode theme." Mark as "UNKNOWN — theme unconfirmed."

**State data source used:** "Themes inferred from [E1 body/title / ad name parsing / campaign name / image_url visual inspection]."

---

### Dimension 3 — Creative Ratio

**What it measures:** What proportion of ads in this campaign are genuinely distinct creatives?

**Formula:**
```
Creative Ratio = unique creative_id count ÷ total active ad count

Numerator:   count of unique creative_id values from D1 for active ads in this campaign
Denominator: total count of active ads returned in D1 for this campaign
```

Both numerator and denominator come from D1 for this campaign only. Active ads = ads with `effective_status` = ACTIVE or with spend in the date range.

**Thresholds:**
- Above 0.7 = HIGH — most ads are genuinely different creatives
- 0.4–0.7 = MODERATE — some creative repetition
- Below 0.4 = LOW — most spend runs on repeated creative variations

**What this ratio reveals:**
A Creative Ratio below 0.4 means most ads share creative IDs. This does not automatically mean Andromeda clusters them — cosmetic variations may share a creative_id without being the same creative in Andromeda's view. But a low ratio is a signal that the campaign is not testing genuinely different creatives. The Andromeda clustering impact (Dimension 4) provides the more precise view.

**Example:**
Campaign has 12 active ads. D1 returns 5 unique creative_ids across those 12 ads.
Creative Ratio = 5 ÷ 12 = 0.42 → MODERATE.

---

### Dimension 4 — Andromeda clustering impact

**What it measures:** After accounting for Andromeda clustering, how many genuinely distinct creatives does this campaign actually have?

**Data source:** meta-creative-fatigue (separate SOMIN skill, if installed) similarity cluster output (F7). This dimension cannot be computed without that data.

**Formula — for multiple clusters:**
```
effective_unique_count = total_ads - Σ(cluster_size - 1) for each cluster
```

Where `(cluster_size - 1)` = number of redundant ads per cluster (each cluster of M ads counts as 1 effective creative, so M-1 are redundant).

**Example with two clusters:**
10 total ads. Cluster A has 3 ads. Cluster B has 2 ads.
Redundant ads = (3-1) + (2-1) = 2 + 1 = 3
Effective unique count = 10 - 3 = 7

**Example with one cluster:**
10 total ads. One cluster of 4 ads.
Redundant ads = (4-1) = 3
Effective unique count = 10 - 3 = 7

**Example with no clusters:**
10 total ads. No clusters.
Effective unique count = 10 (same as total).

**Plain language statement required:**
"Although this campaign has [N] ads, [M] of them are grouped into [X] Andromeda cluster(s) — meaning the effective unique creative count is [effective_unique_count], not [N]. Meta treats [effective_unique_count] of these ads as distinct creatives for auction, delivery, and fatigue accumulation purposes."

If no clusters: "No Andromeda clusters detected — all [N] ads have unique creative IDs. The effective unique creative count equals the total ad count."

---

### Dimension 5 — Format and theme gap

**What it measures:** What formats and themes are absent from this campaign that could introduce genuine differentiation?

**How to identify gaps:**
1. List the formats currently in use (from Dimension 1)
2. List the formats relevant for this campaign's funnel type (from Section 2, Dimension 1 table)
3. Gap = relevant formats not currently in use
4. Apply the same logic to themes (Dimension 2) — which of the nine themes are absent?

**Prioritise gaps that would address the root cause:**
- CREATIVE root cause → prioritise format gaps that introduce genuinely different visual compositions and theme gaps that introduce different messaging angles
- AUDIENCE root cause → prioritise format diversity that gives recycled accounts something new to respond to
- HEALTHY → note gaps as opportunities, not urgencies

State gaps in plain language: "This campaign does not currently use [format/theme]. Adding [specific format or theme] would introduce genuinely differentiated creative that Andromeda would treat as a distinct creative, reducing shared fatigue accumulation."

---

## SECTION 3 — Root cause connection templates

Every diversity observation must connect to the root cause finding from meta-ads-analyzer (separate SOMIN skill, if installed). Use the correct template for the campaign's root cause. Preserve the logic of these templates — do not genericise them.

**When root cause is CREATIVE (fatigue or poor quality):**
"The low Creative Ratio of [X] — combined with the [N] Andromeda cluster(s) identified — means [Y]% of this campaign's impressions run on what Meta's system treats as [effective_unique_count] creative(s). This directly compounds the [fatigue / poor quality] problem: the effective unique creative count is [Z], not [N]. [Connect to specific metric: 'With ROAS declining from 13.77x to 0.91x, the absence of genuinely differentiated creative means there is no alternative delivery pathway for Meta to optimise toward.']"

**When root cause is AUDIENCE (saturation):**
"With the audience pool exhausting, creative diversity becomes more important — not less. When Meta can only reach the same Accounts Center accounts repeatedly, more varied creatives give those accounts something genuinely new to respond to. Current Creative Ratio of [X] and [N] formats means the recycled audience is seeing the same ads on repeat, compounding the saturation effect. [Connect to specific metric: 'Frequency has risen from [start] to [end] — those accounts need a genuinely different creative to re-engage, not a variation of the same one.']"

**When root cause is COMPOUND (audience saturation causing creative fatigue):**
"The audience saturation is driving frequency recycling — the same Accounts Center accounts see these ads repeatedly. With a Creative Ratio of [X] and only [effective_unique_count] effective unique creatives (after Andromeda clustering), those recycled accounts have no new creative to respond to. Expanding the audience and introducing genuine creative diversity must happen simultaneously. Adding new audience segments without refreshing the creative library will deliver the same fatigued creatives to the new accounts — they will fatigue at the same rate."

**When campaign is HEALTHY:**
"This campaign uses [N] formats and [M] themes — [HIGH/MODERATE] diversity. [No Andromeda clusters detected / N clusters with low severity]. This structural diversity is a contributing factor to the campaign's healthy performance — Meta's delivery system has genuinely differentiated creatives to test and optimise against, reducing the rate of fatigue accumulation."

---

## SECTION 4 — Channel concentration

The observation that 100% of paid spend is on Meta is a valid business risk observation. However it:
- Requires business context beyond Meta API data to act on
- Is not a per-campaign finding
- Is not immediately actionable from campaign-level data

State this observation once in the report Limitations section as a strategic observation — not as a campaign finding, not as a Tab 3 item.

Format: "100% of paid spend is concentrated on Meta. This is a business risk independent of campaign performance — any Meta algorithm shift, CPM spike, or account restriction affects the entire paid acquisition strategy. Acting on this requires a separate platform audit, creative production planning, and budget discussion."

---

## SECTION 5 — Output format

Diversity observations are embedded in Tab 3 item 8 of the campaign's HTML section. The output is narrative prose — not a bullet list. The bullet structure below is the spec template; the actual output is written as connected paragraphs.

**Content required:**
1. Framework disclaimer (one sentence)
2. Format Diversity observation — formats in use, count, threshold verdict, data source stated
3. Thematic Diversity observation — themes in use, count, threshold verdict, data source stated
4. Creative Ratio — formula result, threshold verdict
5. Andromeda clustering impact — effective unique count, formula shown
6. Format and theme gaps — specific absent formats/themes relevant for this objective
7. Root cause connection — using the correct template from Section 3, with actual metric values

**What NOT to do:**
- Do not produce a standalone diversity section
- Do not aggregate diversity observations across campaigns
- Do not present the observations without the root cause connection
- Do not invent format or theme data — if a dimension cannot be determined, state "data not available" and explain why

---

## SECTION 6 — Rules

1. Never produce a standalone diversity section
2. Never aggregate diversity observations across campaigns into one score
3. Never present diversity observations without connecting them to the campaign's root cause finding
4. If data for a dimension is genuinely unavailable, mark "data not available — [specific reason]". Never invent figures.
5. Always state that the framework is constructed, not official Meta metrics
6. Always state the data source used for format and theme inference
7. Always use the correct root cause connection template from Section 3 — do not genericise it

---

**You have now finished reading spec.md. Before opening script.md, confirm:**
- [ ] You know how to infer format from D1 video fields and E1 data — and what to do when neither is available
- [ ] You know how to infer theme from E1 body/title, ad names, and campaign names
- [ ] You know the Creative Ratio formula: unique creative_id count ÷ total active ad count from D1
- [ ] You know the corrected Andromeda formula for multiple clusters: total_ads − Σ(cluster_size − 1)
- [ ] You know all four root cause connection templates and which to apply when
- [ ] You know this output is narrative prose embedded in Tab 3 item 8 — not a standalone bullet list

**If any of these is unclear, re-read the relevant section before opening script.md.**

---

## OUTPUT FORMAT — SIGNAL-BULLETS (supersedes any "narrative prose" instruction above)

`diversityObservations` is rendered by `meta-report-architect` (separate SOMIN skill, if installed) and audited by
`meta-report-qa` (separate SOMIN skill, if installed) Check 9.1, which requires `<ul class="signal-bullets">`. Narrative
paragraphs are a HARD-GATE failure. Where an earlier section of this spec says the output is
prose rather than a bullet list, **this section wins**.

Target shape — nine bullets, each with a bolded lead-in, each ≤30 words:

```html
<ul class="signal-bullets">
<li><b>Framework:</b> constructed for consistent comparison, not official Meta metrics or published standards.</li>
<li><b>Format:</b> one, video. SINGLE-FORMAT RISK. Confirmed by the creative record and the ad-level video metrics.</li>
<li><b>Format gap:</b> four of the five formats relevant to this objective are absent. …</li>
<li><b>Theme:</b> one, evergreen brand. SINGLE-THEME RISK. Read from the creative body copy.</li>
<li><b>Theme gap:</b> eight of nine absent. No offer, no social proof, no product claim, no urgency device.</li>
<li><b>Creative Ratio:</b> 1.00, which lands in the HIGH band but is misleading. …</li>
<li><b>Andromeda:</b> 0 clusters. Effective unique creatives 1 of 1, so Meta treats this campaign as a single creative.</li>
<li><b>Root cause fit:</b> …</li>
<li class="signal-conclusion">&there4; … (≤40 words)</li>
</ul>
```

**State the data source, not every figure from it.** Video IDs, ThruPlay counts and quartile
view numbers already appear in the Ads Analysis tab; repeating them here is duplication.
"Confirmed by the creative record and the ad-level video metrics" is sufficient.

**Never write internal pipeline codes** (`D1`, `D2`, `C2`, `B1`, `POST_CLICK`) into this
field — Check 8.1 fails on them. Write "the ad-level video metrics" and "post-click".

### Degenerate single-creative campaigns

- **Creative Ratio 1.00 must be flagged as misleading, not reported as HIGH.** The ratio is
  at its arithmetic maximum because there is nothing to repeat. Reported bare it renders as
  a strength badge on a campaign with no creative variation at all.
- Note the inverse of the cluster finding: 0 clusters with 1 ad means no creative variation
  and no internal comparison, not healthy differentiation.

### ROOT CAUSE CONNECTION TEMPLATE — POST_CLICK

The four templates above cover CREATIVE, AUDIENCE, COMPOUND and HEALTHY. Use this one when
the root cause is POST_CLICK. Do not force-fit the CREATIVE template: that asserts diversity
compounds a creative problem, when the creative is functional and the break is downstream.

> Creative diversity is not the lever for this failure. The creative already earns clicks at
> [LINK CTR]% against a [BENCH]% account average, and [N] of [M] link clicks reached the
> site. The break is [P] purchases from those [N] landing page views, or [RATE]%. More
> formats and themes would buy more traffic into a funnel converting at [RATE]%.
> The diversity finding still matters narrowly: with one creative there is no internal
> comparison, so a second execution is a test to run after the funnel is instrumented,
> not a fix to deploy now.

If a future root cause has no template here, write to the LOGIC of the existing templates
and record that no template existed. Never silently reuse a mismatched one.
