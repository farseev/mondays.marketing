---
name: "content-diversity-scorer"
description: "Scores creative variety as Meta Diversity (0-100, higher is more diverse) for one Meta Ads campaign, or for a brand vs competitors as the standard competitor slide in somin-brand-deck."
---

# Content Diversity Scorer — v3 · Meta Diversity

**Two modes.** Pick one before computing anything.

- **Single-campaign mode** — invoked from the Meta Ads report flow (a separate SOMIN skill set, if installed;
  without it, score the one campaign standalone and report the number, band and drivers in chat). Scores one campaign; output
  goes into Tab 3 item 8 (see *Output*).
- **Cohort mode** — invoked by `somin-brand-deck` Step 12A, or whenever the user asks how a
  brand's creative variety compares with its competitors. Scores the brand and every
  competitor on the same basis; output is a deck slide plus an appendix worked calculation
  (see *Cohort mode* below). Everything under *Stage 0*, *Computing it*, *Computation rules*,
  *Gates*, *The image-only control* and *Bands* applies to both modes.

**SINGLE-CAMPAIGN MODE (canonical definition in meta-ads-report-orchestrator, if installed):** in the Meta
Ads flow this pipeline analyses exactly ONE user-named target campaign. Wherever this skill's files say "Phase 3
campaigns", "all campaigns in scope", "each campaign", or "per campaign", they resolve to that
single target campaign; loops execute exactly once; "next campaign" gates are trivially satisfied.

**This file supersedes `spec.md` and `script.md` in this skill folder.** Those describe the
retired five-dimension framework (Format Diversity, Thematic Diversity, Creative Ratio,
Andromeda clustering impact, Format/theme gap). Do not read or follow them. Everything needed
to compute and report the score is below; their root-cause templates survive, restated here.

## THE SCORE: Meta Diversity, 0–100, HIGHER IS BETTER

```
META DIVERSITY = (1 − mean pairwise similarity) × 100        round to a whole number

100 = every creative is its own idea
  0 = every creative is identical
```

**The direction is the most common source of error. State it every time you report the number.**
The underlying quantity is *similarity* (low = good); Meta Diversity inverts it so the score
reads the way a score should. Never report a raw similarity figure to a client without saying
which direction it runs; prefer reporting Meta Diversity alone.

### Why it is named this way

Meta officially names and defines **creative similarity** — in *About account insights in Meta
Ads Reporting* ([help/1784925068944145](https://www.facebook.com/business/help/1784925068944145)):

> "creative similarity occurs when the images or videos in your ads appear too visually
> identical. this can lead to creative fatigue and increase your cost per result."
> "creative similarity insights are based on static ads active in the last 28 days."

Meta publishes **no diversity score**. Its Help Center uses "diverse creative assets" and
"materially different" only as advice. So Meta Diversity is SOMIN's metric, built by inverting
the one concept Meta does define, and extended to video (Meta's own insight covers static ads
only). Claim that lineage — do not claim Meta computes this score, and do not assert that
Andromeda collapses ads by similarity: Meta's Andromeda engineering post describes a
hierarchical index and never mentions similarity matching. That link is a practitioner
inference.

## STAGE 0 — Concept unification (run before any comparison)

**Two labels that mean the same thing must become one concept before a single pair is scored.**
The extractor is generative: it writes `Wellness` on one creative and `Well-being` on the next,
`Healthcare` and `Medical Care`, `Joy` and `Happiness`, `Presenting` and `Presenting
information`. Set overlap counts every one of those as a miss, so two creatives saying the same
thing score as different and the set looks more varied than it is. Skipping this stage does not
merely add noise — it biases every score in one direction.

1. **Surface-form collapse, every axis.** Casefold; `&` to `and`; strip possessives, punctuation
   and duplicate whitespace. This alone merges `Graphic Design` / `graphic design`,
   `Medical Consultation` / `Medical consultation`, `Life milestones` / `Life's milestones`.
2. **Semantic merge, open-vocabulary axes only.** Embed each surviving label and average-link
   cluster it **within its own axis** (a word means different things on different axes).
   Canonical form = the most frequent member of each cluster. Rewrite every creative's labels to
   canonical form, then score.
3. **Never semantically merge a controlled taxonomy.** These axes are designed value lists where
   every entry is deliberately distinct, and merging them destroys real signal:
   `natureOfComms`, `tacticalBrand`, `archetypes`, `contentTypes`, `productType`, `humourType`,
   `videoCategory`, `appealCategory`, `visualRepresentation`, `imageCategory`, `perkType`.
   Surface-form collapse only. **Verified failure:** an unrestricted pass merged `Business to
   Consumer` with `Business to Business` — opposites — and collapsed `Brand Offering`,
   `Product Offering` and `Brand Awareness` into one value.
4. **Calibrate the threshold against a labelled battery, never by eye.** Assemble ~10 pairs that
   must merge and ~10 that must not, drawn from the actual vocabulary, and pick a cut between
   them. Reference calibration: all-mpnet-base-v2, cosine **0.62** — closest must-merge pair
   0.68 (`Presenting` / `Presenting information`), furthest must-not 0.51 (`Families` / `New
   Parents`). A smaller model failed this test: all-MiniLM-L6-v2 scored `Wellness` /
   `Well-being` at 0.44, below pairs that must stay apart, so no threshold separates them.
   If no threshold separates your battery, the model is too weak — change the model, not the
   battery.
5. **Keep the map and report the collapse rate.** The mapping is the audit trail for every score
   built on it, and the rate tells the reader how much wording variance the extractor carries.

**Measured effect** (338 organic posts, 7 entities, Sep 2026): 2,243 of 5,050 distinct labels
collapsed — **44.4%**. Headline scores moved only 1–2 points, inside the ±2 noise floor, because
the added overlap is spread thinly across thousands of pairs. **Effective entity counts fell by
roughly a fifth** (59→48, 57→50, 27→21), because unification pushes borderline pairs across the
clustering threshold. So: unification barely moves the headline and materially changes EEC and
EEC₂. **Never report EEC or EEC₂ from a non-unified run.**

## Computing it

```
For every pair of creatives i,j in the set (labels already unified by Stage 0):

  S_ij = Σ_g w_g · mean over axes in g of  |F_i ∩ F_j| / |F_i ∪ F_j|

  w:  structural 0.55 · message 0.30 · interpretive 0.15

similarity  = mean S_ij over all i<j
META DIVERSITY = round((1 − similarity) × 100)

clustering  = average-linkage agglomerative on S, cut at τ = 0.60
EEC         = surviving cluster count      ← explains the score, never the headline
EEC₂        = 1 / Σ (m_k/N)²               ← inverse Simpson, exposes one dominant cluster
```

Weights lean structural because visual sameness is what Meta's own definition names. An ad set
mixing statics, video, UGC and carousels can still score low if the assets share a template.

### Axis groups (SOMIN `feature` fields)

- **Structural 0.55** — `compositionStyle`, `videoComposition`, `imageObjects`, `videoObject`,
  `videoLocation`, `visualRepresentation`, `imageCategory`, `videoCategory`,
  `activityRecognition`, `videoActivity`, `videoSubject`, `videoMotionPacing`, media type
- **Message 0.30** — `contentTypes`, `topicCategory`, `perkIncentive`, `perkType`,
  `tacticalBrand`, `appealCategory`, `natureOfComms`, `humourType`, `mainProduct`,
  `productType`, `occasion`
- **Interpretive 0.15** — `toneOfVoice`, `archetypes`, `brandTraits`, `emotions`,
  `lyricalDevices`, `audiences`, `interests`, `aspirations`, `humanNeed`, `videoMood`,
  `videoThemes`, `videoSymbolism`, `videoSoundDesign`

Creatives of different modality share no structural axes, so that group's Jaccard is 0. That is
correct when the creatives genuinely differ — and **wrong when they are the same asset
cross-posted**. Read *Cross-posting, modality and the noise floor* below before reporting a
score for any set that spans formats.

## Computation rules — all nine are load-bearing

1. **Hash pre-pass.** Compare `images[].hash` and `videos[].hash` first; force `S=1` for a
   byte-identical pair regardless of labels. Catches re-uploads for free. **It does not catch
   cross-posts**: platforms re-encode on upload, so the same frame carries a different hash on
   each channel. Rule 8 covers those.
2. **Multi-label mass normalisation.** A creative tagged with five tones and one tagged with two
   contribute the same total weight of 1.0 per axis. Without this, verbose extractions look more
   diverse than they are.
3. **Drop placeholders.** Remove `Undetermined`, `General`, `Unknown`, `N/A`, `None` before
   counting. Then drop any axis where over 80% of **scorable** creatives carry a placeholder or
   nothing. Creatives whose feature extraction failed are excluded from this denominator
   entirely — they are evidence of an extraction failure, not evidence that an axis is useless.
4. **Carousels nest.** Images and `clickability_score` live under `creatives[*].children[*]`,
   not `creatives[*].images`. A top-level-only read silently emits empty hashes and null quality
   for every carousel. Recurse.
5. **Refuse below n=8.** Do not emit a score for fewer than eight scorable creatives. Report the
   count instead.
6. **Unify concepts before scoring.** Stage 0 above — mandatory, and not a post-hoc cleanup.
7. **An unmeasured axis group is skipped, never scored.** When NO real axis in a group carries a
   value on either side, drop that group from the pair and renormalise the weights over the
   groups that were measured. In particular, do not let the media-type axis stand in for the
   structural group: two creatives with no visual labels at all both read as media `none`, that
   axis returns 1.0, and the pair collects a perfect structural score — 55% of the weight — on
   no visual evidence. **Verified:** all 36 pairs among one brand's nine no-creative posts
   scored structural 1.00 this way and formed a nine-post cluster that was reported as a
   concentration finding; renormalising broke it into three and left every headline score
   unchanged. Absence of evidence is not evidence of sameness.
8. **Detect cross-posts before scoring.** Treat a pair as one creative when the captions match
   after normalisation (casefold, strip URLs, link shorteners, hashtags, emoji and
   punctuation) at a similarity of **≥0.95** (character-level ratio, so a trailing emoji or one
   changed word still matches) **and** the posts are within **48 hours**, or when a perceptual
   hash of the assets matches. Keep the record with the most populated structural axes. A cross-post scored as two independent
   creatives inflates diversity — see below.
9. **Compute structural coverage excluding the media-type axis.** It is always populated, so
   including it reports 1.00 for a set carrying no visual labels at all — exactly the case the
   gate exists to catch.

## Gates — check before reporting any number

- **Concept unification ran.** Report the collapse rate. A score computed on raw labels
  overstates diversity, and its EEC is not comparable with a unified run.
- **Structural coverage.** Share of creatives with at least one *real* structural axis populated
  (rule 9). Below **0.60** the 0.55 structural weight reads nothing and the score silently
  renormalises onto message and interpretive axes — a different measurement wearing the same
  name. Google Ads routinely score 0.25 here. Label any such score "message-only".
- **Feature-extraction failures.** Creatives with an empty `feature` object (upstream
  extractStatus `error`) are excluded from scoring. Report effective n against total n whenever
  they differ.
- **Profile purity.** SOMIN's `profileIds` filter leaks — it can return other profiles' posts or
  a workspace-wide aggregate. Verify `profile.id` on every item and discard mismatches.
- **Cross-post inflation.** When a set spans image and video, report the image-only control
  beside the headline. If the two diverge by more than about 5 points, media mix is carrying the
  headline and the control is the figure to compare across entities.

## The image-only control

Re-run the identical calculation over image creatives only, and report it beside the headline
whenever a set contains both images and video. It removes the structural bonus an entity earns
simply for publishing in more than one format, which is not evidence that its ideas vary.

Measured on the seven-entity organic cohort above (unified): headline spread 16 points (61–78),
image-only spread **7 points (59–68)**. The entity with the most video fell 18 points; the
image-only publisher did not move at all. Most of the apparent ranking was media mix. Do not
rank entities on the headline alone when their video shares differ.

Needs at least 8 image creatives per entity; below that, report the headline and say the control
could not be computed.

## Cross-posting, modality and the noise floor

The measure compares labels, never pixels, so it cannot tell that two records describe the same
creative. Two failure modes follow, and both push scores **upward** — more diverse than reality.

**Modality forfeit.** When one asset is posted as video on one channel and image on another,
every structural axis is populated on one side and empty on the other. All twelve score 0, the
full 0.55 weight is forfeited, and the pair cannot exceed 0.45 however identical it is. Concept
unification does **not** fix this — measured, it moved two such pairs by only 0.01 and 0.02.

**Label wobble.** Even on axes both records populate, the extractor returns different words for
one concept. This is what Stage 0 fixes.

A cross-post is one creative scored twice, which is exactly the known-duplicate pair needed to
estimate the noise floor. Two measured in the cohort above, after unification:

| Known-duplicate pair | Structural axes empty one side | Agreement on comparable axes | Scored S |
|---|---|---|---|
| TikTok / Facebook, identical copy and frame | 12 of 12 | 0.78 | 0.32 |
| Instagram / Facebook, identical copy | 12 of 12 | 0.59 | 0.23 |

Comparing only the axes both records populate, two copies of one creative agree 0.78 and 0.59 —
not 1.00, even with concepts unified. **That residual shortfall is measurement noise, and it is
larger than the ±2-point reproducibility figure implies**, because reproducibility was measured
by re-scoring one record rather than two records of one creative.

When a reported set contains cross-posts, say so, and prefer the image-only control.

## Cohort mode — brand vs competitors (the standard deck slide)

Used by `somin-brand-deck` Step 12A, where it is a **standard main-section slide** (slide 2,
right after the hero) in every briefing deck. It answers: is the brand's creative more or less
varied than each competitor's, and is any gap real or just media mix?

**Set per entity.**
- **Channel: organic by default** (SOMIN `PAGES`), window `LAST_90_DAYS`, the **28 most recent**
  posts per entity (a fixed count keeps entities comparable; a time window alone lets a
  high-volume poster dominate). Pull each entity with an explicit single `profileIds` value and
  run the profile-purity check — the filter leaks other profiles' posts, and omitting
  `profileIds` under-reports. Split any mixed result by true `profile.id`.
- **Paid (optional, on request):** Ads Library, most recent 28 per entity over the last year.
  Record each entity's date span: a paid set bunched into a few days of one burst reads less
  diverse than a set spread over the year for reasons that have nothing to do with ideas, so
  report the span beside the score and flag spans under 30 days. Google text ads carry no
  visual axes — score them message-only and never rank them against image/video ads. Never
  compare a paid score with an organic one.
- **In-pillar (optional, on request):** restrict each entity's posts to the chosen pillar with
  the deck's pillar classifier (pillar term in `topic`, subject-based disqualifiers), organic
  and paid separately. Entities under n=8 in-pillar get a count, not a score.

**Required on the slide.**
1. The direction, every time: "Meta Diversity, 0–100, higher is more diverse".
2. Every entity in scope — the brand and every competitor — with n. Below n=8: show the count
   and "below the 8 needed for a score", never a number.
3. The image-only control beside the headline for every entity that publishes images and video.
   When controls and headlines rank the entities differently, the headline sentence follows the
   control.
4. Structural coverage per entity; any entity under 0.60 is labelled "message-only".
5. A one-line reading of what the gap means for the brand, stated as a content-supply fact.

**Required in the appendix** — a worked calculation: the formula, the three weights, the Stage 0
collapse rate, one worked pair from the brand's own set (both creatives' shared and unshared
labels per group, the group Jaccards, the weighted S), and the cross-posts collapsed per entity.

**Deck-side rules.** Never write a pipeline status on the slide ("could not be computed",
"pending", "rate-limited") — report that in the chat reply. The slide shows measured facts only.

**Output file** `content_diversity.json`: `stage0` (distinct labels, collapsed, rate),
`dropped_axes`, `tau`, `channel`, `window`, `sample_per_entity`, and per entity `n`,
`meta_diversity`, `mean_similarity`, `EEC`, `EEC2`, `largest_cluster`, `structural_coverage`,
`media_mix`, `crossposts_collapsed`, `image_only_control`, `image_only_n` (paid adds `span`,
`span_days`, `platform_mix`). The deck reads every printed number from this file.

**Worked reference** (a maternity-care cohort, organic, 2026, 7 entities, unified, 37%
collapse; names anonymised), headline / image-only: Hospital A 74 / 59 (11 of 20 video); Hospital B 72 / 66;
Hospital C 72 / 66; Hospital D 72 / 57 (11 of 24 video); Hospital E 71 / 62 (9 of 21 video); Hospital F
66 / 59; Hospital G 61 / 61 (image only). The headline put Hospital A first; the image-only
control put Hospital B and Hospital C first and Hospital A and Hospital D near the bottom — their lead was
video share, not variety. Hospital E (0.57) and Hospital D (0.58) sat under the 0.60 coverage gate on the
headline, so their headline scores count as message-only under the gate and their image-only
controls are the comparable figures. That is why the control sits beside every headline.

## Bands and reporting

| Meta Diversity | Band | Reading |
|---|---|---|
| **above 60** | Healthy | reads as distinct creatives |
| **40 – 60** | Watch | drifting toward collapse |
| **below 40** | Suppression risk | likely folding into fewer auction entities than the ad count suggests |

**Publish it as a whole number.** The measured reproducibility floor is **±2 points**, so
decimals are invented precision and band edges need about 5 points of clearance.

**Thresholds are calibration targets** derived from practitioner reporting on the similarity
side (the widely cited 40%/60% similarity figures, inverted), **not published Meta values**, and
τ = 0.60 is inherited rather than fitted. State this. Rank order is stable across τ 0.35–0.70;
absolute counts are not.

**Benchmark within channel.** Paid creative is structurally more self-similar than organic —
measured medians **76 organic against 65 paid** across 64 entities. One universal threshold
flags every competent paid account as failing. Never compare a paid score to an organic
baseline. Those medians come from non-unified runs on count-sampled sets of 20–25 creatives, so
re-baseline them once unification is standard; until then compare within a cohort scored the
same way rather than against the published median.

## Second axis — diversity yield

Meta Diversity answers "are these distinguishable?", not "are they any good?". Where SOMIN
`clickability_score` is present, also report:

```
q_i = P(ABOVE_AVERAGE);  Q = { i : q_i ≥ 0.50 }
Diversity Yield = EEC(Q) / EEC(all)
```

It is close to independent of Meta Diversity, and carries the diagnosis the headline cannot: a
set can be genuinely varied and still be varied weak creative. The clickability model is keyed
to the image — the thumbnail even for video — so it proxies first-frame appeal, not full-video
quality. For carousels, average across children.

Yield carries a reproducibility CV of 0.089, so it is a diagnostic and not a ranking. Gaps
smaller than roughly 0.10 between entities sit inside the noise — do not order entities on them.
Because it is a ratio of two EECs, it also requires a unified run.

## Output

Embedded in Tab 3 item 8 of the campaign's HTML section, rendered by `meta-report-architect` (separate SOMIN skill, if installed).
Must be `<ul class="signal-bullets">` — narrative paragraphs are a HARD-GATE failure in
`meta-report-qa` (separate SOMIN skill, if installed) Check 9.1. Never write internal pipeline codes (`D1`, `E1`, `F7`, `C2`,
`POST_CLICK`) into the field; Check 8.1 fails on them. Write "the creative record", "the
ad-level video metrics", "post-click".

Six bullets, bolded lead-in, each ≤30 words. The first bullet always carries the direction:

```html
<ul class="signal-bullets">
<li><b>Meta Diversity:</b> 42 of 100, where higher is more diverse — Watch band.</li>
<li><b>Framework:</b> SOMIN metric inverting creative similarity, Meta's own term; Meta publishes no diversity score.</li>
<li><b>Effective entities:</b> 5 of 28, with 22 in a single cluster. EEC₂ 1.59.</li>
<li><b>Coverage gate:</b> structural coverage 0.86 — visual axes present, so this is a full-fingerprint score.</li>
<li><b>Diversity yield:</b> 0.20 — one in five distinct entities is also predicted above average.</li>
<li class="signal-conclusion">∴ … (≤40 words, connected to the campaign's root cause)</li>
</ul>
```

When the set spans formats, spend one of the six bullets on the image-only control rather than
adding a seventh.

### Degenerate sets

A single-creative campaign has no pairs, so **no Meta Diversity score exists**. Say that plainly
— never report 100, which would read as perfect variety, and never 0. State that with one
creative there is no internal comparison, and that a second execution is a test to run, not a
fix to deploy. Likewise 0 clusters with 1 ad means no variation at all, not healthy
differentiation.

### Root cause connection — required on every score

Use the template matching the root cause from meta-ads-analyzer (separate SOMIN skill, if installed). Preserve the logic; do not
genericise, and cite the campaign's actual metric values.

- **CREATIVE** — a low score compounds the fatigue: with N effective entities there is no
  alternative delivery pathway for Meta to optimise toward.
- **AUDIENCE** — as the pool exhausts, diversity matters more, not less. Recycled accounts need
  a genuinely different creative to re-engage, not a variation of the same one. Cite frequency.
- **COMPOUND** — expanding audience without refreshing creative delivers the same fatigued set to
  new accounts, which fatigue at the same rate. Both must happen together.
- **POST_CLICK** — diversity is not the lever. The creative already earns clicks; the break is
  downstream. More formats buy more traffic into a funnel that is not converting. The finding
  still matters narrowly: with one creative there is no internal comparison.
- **HEALTHY** — a high score is a contributing factor in the campaign's performance; note gaps as
  opportunities, not urgencies.

If a future root cause has no template, write to the logic of these and record that none existed.
Never silently reuse a mismatched one.

## What this skill does NOT do

- In single-campaign mode, does not produce standalone sections — output is embedded in Tab 3
  item 8. (Cohort mode produces the deck slide and appendix calculation described above.)
- Does not produce an archetype view or a dashboard; the only chart is the cohort-mode deck slide. `archetypes` is one of
  thirteen interpretive axes at 0.15 weight — an input to the score, never an output surface
- Does not aggregate unrelated campaigns into an account-level score — per-campaign, or per
  entity in cohort mode
- In single-campaign mode, does not re-pull MCP data — reads from data already collected. In
  cohort mode it pulls each entity's posts itself, one `profileIds` value per call
- Does not duplicate meta-creative-fatigue (separate SOMIN skill, if installed) — that skill handles fatigue and overexposure; this
  one handles similarity and effective entity structure. Meta treats them as distinct: fatigue
  is overexposure of one asset to one audience, similarity is how alike different ads look.

## Channel-concentration observation

That 100% of paid spend sits on Meta is a valid business risk but not a campaign finding. State
it once in the report's Limitations section, never as a Tab 3 item.