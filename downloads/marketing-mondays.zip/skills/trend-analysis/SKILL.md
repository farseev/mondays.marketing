---
name: trend-analysis
description: Track how tensions move across time by comparing multiple SOMIN tension studies for the same cohort across sequential windows. Use whenever the user asks "how is this tension changing", "what's trending up", "when does X peak", "is Y seasonal", "month-on-month trend", "12-month evolution", "is this growing or fading", "did the Nov spike repeat", or any time-series question about tension data. Depends on persona-tension-discovery — assumes at least 3 tension studies on the same cohort across different time windows already exist. Aligns themes semantically across windows (theme IDs differ between studies), builds a time-series matrix, computes peaks and troughs, and classifies each tension as RISING, FALLING, SUSTAINED, SEASONAL, SINGLE-SHOT, EMERGING, or DECAYED with confidence ratings. Strictly time-series — does not produce competitive landscape (use whitespace-analysis), creative output (insight-creation), or formatted deliverables.
---

# Trend Analysis

Time-series tension tracking. Takes N tension studies from the same cohort across sequential windows; outputs a classification per tension with confidence.

## When to use

- "How is this tension changing?"
- "When does X peak?"
- "Is Y seasonal?"
- "Month-on-month / 12-month evolution"
- "Is this growing or fading?"
- "Did the Nov spike repeat?"

## When NOT to use

- Only 1 study window — no trend with one data point. Run **persona-tension-discovery** to commission more windows.
- Snapshot competitive comparison → use **whitespace-analysis**
- Turn trend into creative → produce trend data first, then **insight-creation**
- Charts / slides / visuals → packaging concern outside this skill

## Inputs

**Same cohort, multiple time windows.** Typical configurations:

| Pattern | Studies | Window | totalSize |
|---|---|---|---|
| Monthly cuts on influencer panel | 5–6 | ~30 days | 40–100 |
| Quarterly cuts on brand profile | 4 | ~90 days | 100–200 |
| Weekly cuts during campaign | 4–12 | ~7 days | 20–50 |
| Year-on-year same-month | 2–3 | Same month, different years | varies |

**Minimum viable:** 3 studies. **Maximum useful:** ~12.

**Critical:** the cohort must be identical across windows — same workspace, profile IDs, filters. If a creator was added mid-year, note cohort discontinuities in the output.

## Dual-cohort pattern (recommended for full strategy decks)

When the engagement has BOTH a primary workspace (brand + competitors) AND an audience-proxy workspace (e.g. influencer panel), run this skill TWICE — once per cohort — and compare:

- **Primary (brand+comp) trend** = what advertisers are saying month-on-month
- **Audience-proxy trend** = what audiences are actually engaging with month-on-month

The two trends are NOT redundant. Brand+comp lags audience demand by 2–4 months typically. Tensions RISING in audience cohort but LOW/FALLING in brand cohort = EMERGING WHITESPACE (claim before category catches up). See `references/dual-cohort-trends.md` for the 4-cell verdict matrix.

## The 5-step workflow

### 1 — Retrieve all studies in one batch
```
SOMIN:studies-get({studyIds: [...all_ids], reportTypes: ["tensions"]})
```
For each study capture: `id`, window (start, end, label), `totalSize`, plus each theme's `id`, `name`, `summary`, `sampleSize`.

### 2 — Align themes semantically across windows
Theme IDs differ between studies. Alignment is **semantic** — read summaries, not titles. Titles drift; summaries are stable.

See `references/alignment-rules.md` for the alignment heuristics (when to merge, when to split, how to handle "near matches", how to detect a tension that has actually split into two sub-tensions over time).

### 3 — Build the share-of-voice matrix
For each aligned tension × each window, compute `sampleSize / totalSize`. Convert to a percentage. Empty cells (tension didn't appear in that window) are 0%.

### 4 — Classify each tension
Apply the 7-status rubric. See `references/status-rubric.md` for the full rubric with examples and confidence-rating rules.

Short form:
- **RISING** — monotonic upward trend, latest value highest
- **FALLING** — monotonic downward, latest lowest
- **SUSTAINED** — average ≥20% AND coefficient of variation <30%
- **SEASONAL** — peak in same month/quarter across years OR detectable cyclic pattern
- **SINGLE-SHOT** — appears once with high share, then disappears (event-driven, not a true tension)
- **EMERGING** — absent for first half of window range, present and growing in latter half
- **DECAYED** — was sustained, has dropped to <5% in latest 2+ windows

### 5 — Produce the output table
See `references/output-template.md` for the canonical output format consumed by whitespace-analysis and somin-brand-deck (and somin-agency-deck, if installed).

## Confidence ratings

Each classification gets HIGH / MEDIUM / LOW based on:
- Number of windows where tension is present (more = higher confidence)
- Consistency of the pattern (lower coefficient of variation = higher confidence)
- Sample size in each window (>30 = high; <10 = low)

Don't claim HIGH confidence on <5 windows.

## Seasonality verification — the prior-year pass (run before presenting any RISING / FALLING)

A single year of windows is **one cycle**, and one cycle cannot tell a true trend from a seasonal slope. The downslope of an annual cycle looks identical to a genuine decline; the back half of a seasonal build looks identical to a genuine rise. Before any directional verdict is presented as a finding:

- **A FALLING (or DECAYED) verdict drawn from ≤12 months of windows is UNVERIFIED.** Label it "FALLING — UNVERIFIED (single cycle; may be a seasonal downslope)" until checked. The same applies to RISING that could be a seasonal build. Do not let a builder render an unverified direction as a confident decline/growth claim.
- **Run the prior-year pass to verify.** Commission (or retrieve) the *same windows one year earlier* for the same cohort and compare. If the prior year shows the same shape at the same time of year, the pattern is SEASONAL, not a trend — the "decline" is the recurring downslope and must be reported as seasonality, not decay. If the prior year does **not** repeat the shape, the direction is a genuine trend and can be presented as RISING/FALLING with raised confidence.
- **SEASONAL requires ≥2 years to confirm.** "Peak in the same month across years" cannot be asserted from a single year. With one year you may only *hypothesise* seasonality ("possible seasonal peak in Nov — unverified"); confirmation needs the prior-year pass.

This is a verification step, not optional colour: a decline shown to a client that is really the annual downslope is a factual error. When the prior-year data cannot be obtained, ship the directional verdict with its UNVERIFIED flag intact and say so in the output.

## Common failure modes

| Failure | Cause | Fix |
|---|---|---|
| "Trend" with only 2 studies | Insufficient input | Need 3+ |
| Same tension classified differently across runs | Alignment drift | Document alignment decisions in output |
| Cohort changed mid-window | Profile added/removed | Flag in output, don't silently include |
| Tension absent from every window | Wasn't in original concept search | Not a trend signal; drop |
| "Falling" reported from one year of data | Single-cycle downslope mistaken for decline | Run the prior-year pass; until then label FALLING — UNVERIFIED (see Seasonality verification) |
| "Seasonal" asserted from a single year | One peak ≠ a recurring season | Needs ≥2 years; with one year say "possible seasonal — unverified" |

## Token discipline

- Don't paste full `studies-get` outputs into context. Extract theme summaries into a working table on disk, then analyse the table.
- The classification scripts in scripts/ can take the matrix as a JSON and emit verdicts deterministically.
