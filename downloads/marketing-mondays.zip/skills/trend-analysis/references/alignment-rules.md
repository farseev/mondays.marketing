# Semantic Alignment of Themes Across Windows

Theme IDs differ between SOMIN studies even when the underlying tension is the same. Aligning them is the core analytical work in trend analysis. Done wrong, the trend reflects clustering noise instead of real evolution.

## Core rules

### 1. Read every theme summary in every window before aligning.
Titles drift across windows; summaries are stable. A theme titled "Maintenance Anxiety" in Jul and "Care for Your Engine" in Aug may be the same underlying tension — only the summary tells you.

### 2. Don't align on title alone.
Theme titles are generative. Two studies can produce different titles for the same cluster. Trust the summary's tone and content scope.

### 3. Track unique-tension count over time.
If the number of distinct tensions grows from 4 to 6 across windows, something split — either the cluster fragmented or new content entered the corpus. Note this; it's often a signal worth surfacing.

## Alignment decisions

### Same tension → use the same alignment key

If summary in window N and window N+1 describe the same friction (same audience, same problem, same emotional register), they align. Use a stable internal key like `EXCITEMENT_MOTORSPORT` or `MAINTENANCE_ANXIETY`.

### Tension that has split → create two aligned keys

If "Heritage / Analogue Driving" in earlier windows shows up as two distinct themes in later windows ("Heritage Cars" and "Manual Transmission Devotion"), that's a split. Track them separately going forward, AND keep a parent key to maintain the aggregate trend if useful.

### Tension that has merged → flag the merge

If two earlier themes ("Performance Literacy" and "Track-Day Culture") later appear as one ("Performance Enthusiast Culture"), note the merge. The aggregate is comparable; the individual lines aren't.

### Near match — when to merge cautiously

Two themes from different windows where summaries overlap by ~60–70%:
- If they share the same persona target AND the same friction type → merge
- If they share friction but different audiences → don't merge; they're different signals
- If they share audience but different friction → don't merge

### Outlier — single appearance

A tension that shows up in exactly one window with high share is a **SINGLE-SHOT** classification, not a trend. Common when a campaign or news event dominated a corpus briefly.

## Worked example — Example Lubricants Q3 2026

| Underlying tension | Jul 25 | Aug 25 | Sep 25 | Nov 25 | Feb 26 | May 26 live |
|---|---|---|---|---|---|---|
| Excitement / Motorsport thrill | — | 10036 (10/53) | 10038 (7/55) | 10042 (53/66) | 10043 (19/48) | 10032 (18/40) |
| Luxury Access / Personal Expression | — | 10037 (20/53) | 10041 (20/55) | — | 10044 (24/48) | 10031 (11/40) |
| Heritage / Analogue | — | 10035 (14/53) | 10040 (17/55) | — | — | — |
| Performance literacy | 10014 (9/17) | — | — | — | — | 10033 (4/40) |
| EV / Urban mobility | — | — | 10039 (5/55) | — | — | 10034 (2/40) |

Classifications:
- **Excitement / Motorsport** — RISING (M07 → M11) then SUSTAINED. F1 season pattern detected.
- **Luxury Access** — SUSTAINED at ~20–25% across most windows
- **Heritage / Analogue** — DECAYED (present Aug/Sep, gone after)
- **Performance literacy** — SINGLE-SHOT (Jul only) + late re-emergence (May) → tentatively EMERGING but LOW confidence
- **EV / Urban mobility** — EMERGING (first appears Sep, persists in May with growth) → MEDIUM confidence

## Alignment audit trail

Every alignment decision should be recorded in the output:
```
TENSION: Excitement / Motorsport
  ALIGNED THEMES:
    - 10036 (Aug 25): "Motorsport excitement and community engagement..."
    - 10038 (Sep 25): "Thrill and shared passion in racing culture..."
    - 10042 (Nov 25): "F1 finale energy and tribalism..."
    - 10043 (Feb 26): "Track culture as identity marker..."
    - 10032 (May 26): "Live motorsport consumption..."
  ALIGNMENT BASIS: Shared persona (Performance Enthusiast), shared friction (belonging via competition)
```

This trail makes the analysis reproducible. Without it, two analysts will get different trends on the same data.
