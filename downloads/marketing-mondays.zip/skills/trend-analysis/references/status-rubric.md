# 7-Status Rubric — Tension Classification

Each aligned tension gets exactly one classification. Definitions, examples, and confidence rules.

## RISING

Monotonic upward trend across at least 3 of the last 4 windows, AND latest value is the highest.

```
Window:  M07  M08  M09  M10  M11  M12
Share %:  2    5    8    12   15   18   ← RISING
```

Confidence: HIGH if monotonic across 5+ windows. MEDIUM if monotonic across 3.

## FALLING

Mirror of RISING. Monotonic downward, latest is lowest.

```
Share %:  25   20   15   10   8    5   ← FALLING
```

Often signals a fading conversation; can be combined with another tension that's rising in its place.

## SUSTAINED

Average share ≥20% across all windows AND coefficient of variation <30% (the tension stays in a relatively narrow band).

```
Share %:  22   24   21   23   25   22   ← SUSTAINED
```

These are the "always there" tensions. Defensive territories — usually BLOCKED in whitespace terms because every player runs them.

## SEASONAL

Peak occurs in the same calendar period across multiple years OR a clearly cyclic pattern within a year.

```
Share %:  12   8    5    3    25   15   ← SEASONAL (M11 peak — F1 finale)
                            ↑ peak
```

Confidence requires 2+ peaks at consistent intervals. Otherwise classify as SINGLE-SHOT or EMERGING.

## SINGLE-SHOT

Appears once with significant share (>15%), then drops to 0 or near-0 in subsequent windows. Event-driven, not a true tension.

```
Share %:  0    0    35   2    0    0   ← SINGLE-SHOT
                  ↑ event
```

Common causes: a viral post, a product launch, a news event. Useful as a signal of what spikes engagement; not actionable as ongoing creative territory.

## EMERGING

Absent (0%) for the first half of the window range, present and increasing in the latter half.

```
Share %:  0    0    0    3    7    12   ← EMERGING
```

These are the most interesting whitespace candidates — new audience demand that competitors haven't met yet. Confidence depends on persistence: 3+ recent windows with growth = MEDIUM/HIGH; 1 window = LOW.

## DECAYED

Was SUSTAINED (≥20%) in earlier windows, has dropped to <5% in latest 2+ windows.

```
Share %:  28   25   22   18   4    2   ← DECAYED
```

Often signals a conversation that has commodified or that audience taste has moved past. Don't re-enter; pick something fresh.

## Edge cases

### Inconsistent / noisy pattern
If the tension shows no clear pattern (e.g. 5%, 15%, 8%, 20%, 7%, 18%) → classify as UNCLASSIFIED with LOW confidence and a note that more windows are needed.

### Missing data in middle windows
If a tension appears in M07 and M11 but not M08–M10, treat as SINGLE-SHOT × 2 unless there's clear evidence the cohort changed.

### Tension with only LOW confidence everywhere
If sample size in every window is <10, the trend is unreliable. Document the limitation rather than guess.

## Confidence-rating decision rules

| Confidence | Requires |
|---|---|
| HIGH | ≥5 windows with consistent pattern AND sample sizes >20 each |
| MEDIUM | 3–4 windows with mostly consistent pattern, OR ≥5 with one anomaly |
| LOW | 2 windows, OR very small samples (<10), OR inconsistent pattern |

## Outputs

A classified tension entry looks like:
```
TENSION: Excitement / Motorsport
STATUS: SUSTAINED (was RISING M07→M11, plateau since)
CONFIDENCE: HIGH
SHARE OVER TIME: 0%, 19%, 13%, 80%, 40%, 45%
PEAK: M11 (F1 finale alignment)
TROUGH: M07 (off-season)
```
