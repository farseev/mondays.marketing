# Output Template — Trend Analysis

Canonical output consumed by whitespace-analysis (for the verdict computation) and somin-brand-deck (for slides 10–11).

## Top-level structure

```
COHORT: <name>
WINDOWS: <count> studies — <range>
ALIGNMENT: <how themes were aligned across windows — brief>

TENSION 01: <name>
  STATUS: <one of: RISING / FALLING / SUSTAINED / SEASONAL / SINGLE-SHOT / EMERGING / DECAYED>
  CONFIDENCE: <HIGH / MEDIUM / LOW>
  SHARE OVER TIME: <comma-separated %, one per window in order>
  PEAK: <window label and %>
  TROUGH: <window label and %>
  ALIGNED THEMES: <study_id/theme_id pairs across windows>
  COMMENTARY: <1–2 lines on what drives the pattern>

TENSION 02: ...
```

## Filled example — Example Lubricants Q3 2026

```
COHORT: Influencer Panel (workspace 1235, 14 creators)
WINDOWS: 6 studies — Jul 2025 to May 2026 (rolling 30D)
ALIGNMENT: Semantic, summary-based. 1 split detected (Heritage / Manual into 2 sub-themes Nov onward).

TENSION 01: Excitement / Motorsport
  STATUS: RISING then SUSTAINED
  CONFIDENCE: HIGH
  SHARE OVER TIME: 0%, 19%, 13%, 80%, 40%, 45%
  PEAK: Nov 2025 (80% — F1 finale dominance)
  TROUGH: Jul 2025 (0% — off-season)
  ALIGNED THEMES: 10036 (Aug), 10038 (Sep), 10042 (Nov), 10043 (Feb), 10032 (May live)
  COMMENTARY: F1 calendar drives the cycle; Creator X cluster carries the late-season spike.

TENSION 02: Luxury Access / Personal Expression
  STATUS: SUSTAINED
  CONFIDENCE: HIGH
  SHARE OVER TIME: 0%, 38%, 36%, 0%, 50%, 28%
  PEAK: Feb 2026 (50%)
  TROUGH: Nov 2025 (0% — displaced by F1)
  ALIGNED THEMES: 10037 (Aug), 10041 (Sep), 10044 (Feb), 10031 (May live)
  COMMENTARY: Lifestyle/luxury thread sustained at ~30% baseline; recedes during motorsport peaks.

TENSION 03: Heritage / Analogue
  STATUS: DECAYED
  CONFIDENCE: MEDIUM
  SHARE OVER TIME: 0%, 26%, 31%, 0%, 0%, 0%
  PEAK: Sep 2025 (31%)
  TROUGH: post-Sep (zeroed out)
  ALIGNED THEMES: 10035 (Aug), 10040 (Sep)
  COMMENTARY: Heritage moment passed; tension absent in last 3 windows. Don't re-enter.

TENSION 04: EV / Urban Mobility
  STATUS: EMERGING
  CONFIDENCE: MEDIUM
  SHARE OVER TIME: 0%, 0%, 9%, 0%, 0%, 5%
  PEAK: May 2026 live (5% — current)
  TROUGH: most windows (0%)
  ALIGNED THEMES: 10039 (Sep), 10034 (May live)
  COMMENTARY: Whisper signal. Worth a small test bet; not a primary pillar yet.
```

## Why this format

- **STATUS** = single-word verdict feeds directly into whitespace-analysis's verdict computation
- **SHARE OVER TIME** = the values for the line chart in slide 11 of the deck
- **PEAK / TROUGH** = anchors for the deck's "ride the wave" narrative
- **ALIGNED THEMES** = the audit chain back to study + theme IDs
- **COMMENTARY** = one human-readable line that explains the pattern without rerunning analysis

This format must stay stable; downstream skills parse it.
