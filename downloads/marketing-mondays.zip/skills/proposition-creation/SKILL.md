---
name: proposition-creation
description: Generate product propositions on the SOMIN platform by ensuring a product exists for the brand and calling propositions-create with chosen story IDs and focus dimensions. Use whenever the user asks "create propositions", "generate value propositions", "what should we say about [product]", "turn this insight into a proposition", "what's the offer story for [product]", or any product-positioning request AFTER insight stories exist. Orchestrates SOMIN tools — products-list, product-create (only if missing), propositions-create, propositions-list. Does NOT generate insights — consumes existing story IDs from insight-creation. Each combination of story × focus item generates one proposition. The four focus dimensions are product_features, rtb, usp, and promotion (singular — the API rejects plural "promotions"). Returns structured proposition objects with audit trail back to product, stories, and focus.
---

# Proposition Creation

Story × Product × Focus → Proposition. Call after insight-creation has produced 1+ story IDs.

## When to use

- "Create propositions for [product]"
- "Turn this insight into a value proposition"
- "What's the offer story for [product]?"
- "Generate the messaging for [product]"
- After insight-creation has produced story IDs that need to be translated into product-level positioning

## When NOT to use

- No story IDs yet → run **insight-creation** first
- Need to generate creative or ad copy → propositions are messaging seeds, not finished copy
- Need timing triggers → use **moment-generation** instead

## Required inputs

| Input | Source | Notes |
|---|---|---|
| Story IDs | From insight-creation output | One or more |
| Product ID | From `products-list` or freshly created | Brand's product in the workspace |
| Focus dimensions | See below | `product_features` / `rtb` / `usp` / `promotion` |

## Critical schema gotcha

**The `focus` parameter key for promotions is SINGULAR `promotion`, not plural `promotions`.**

The API rejects `promotions` with `Invalid focus type: promotions`. Always use:
```json
{
  "focus": {
    "product_features": [...],
    "rtb": [...],
    "usp": [...],
    "promotion": [...]    ← singular, even though it lists multiple promotion items
  }
}
```

This is a known discrepancy between the documented schema and the actual API. Don't try to "fix" it by pluralising.

## The workflow

### 1 — Check for existing product
```
SOMIN:products-list({workspaceId: <id>})
```
If a product already exists for the brand's profile, capture its ID and skip to step 3.

### 2 — Create the product (only if missing)
```
SOMIN:product-create({
  profileId: <brand_profile_id>,
  name: "<Product Name>",
  category: "<Category>",
  description: "<Long-form description pulled from brand.offerings>",
  marketSegment: "b2c" | "b2b",
  details: {
    product_features: ["..."],
    promotions: ["..."],        ← here it IS plural — only propositions-create wants singular
    rtb: ["..."],
    usp: ["..."]
  }
})
```

The product is the brand's authoritative offering. Pull features/RTBs/USPs from `brand.json` (produced by brand-extraction-from-web) if available.

### 3 — Generate propositions
```
SOMIN:propositions-create({
  productId: <id>,
  insightIds: [<story_id_1>, <story_id_2>, ...],
  focus: {
    product_features: ["Feature A", "Feature B"],
    rtb: ["RTB 1", "RTB 2"],
    usp: ["USP 1"],
    promotion: ["Promo 1"]      ← SINGULAR KEY
  }
})
```

Each combination of `(story × focus_item)` generates one proposition. For 3 stories × 5 focus items = 15 propositions per product.

Returns an array of proposition objects, each with: `id`, `name`, `focusType`, `focus`, `product`. **The proposition is the `name` field** — a full statement templated as `[focus] ([product]) - [story summary]`. The `focus` field is just the seed input you supplied — useful for filtering but it is NOT the proposition. Downstream consumers (decks, briefs) must render `name`, not `focus`.

### 4 — Audit
```
SOMIN:propositions-list({workspaceId: <id>, productId: <id>})
```
Confirm count and IDs.

## Sizing

For a 3-pillar SOMIN deck with 2 products: 3 stories × (3 features + 2 RTBs + 1 USP + 1 promotion = 7 focuses) × 2 products = 42 propositions. The actual generation depends on how many items you pass per focus.

See `references/focus-dimensions.md` for guidance on what to put in each focus list.

## Output

See `references/output-template.md` for the canonical output format. Brief form:
```
PRODUCT: id <N> · <Name> · profile <N>
PROPOSITIONS (count <N>):
  <id> · <focus_type> · "<name>"
  <id> · <focus_type> · "<name>"
  ...
```

## Common failure modes

| Failure | Cause | Fix |
|---|---|---|
| `Invalid focus type: promotions` | Used plural | Singular `promotion` |
| Empty propositions array | No items in focus dimensions | Pass at least 1 item per focus you want propositions for |
| Duplicate propositions | Re-running with same inputs | Check `propositions-list` first |
| Proposition names look generic | Story summaries are too short | Re-run insight-creation; ensure story summary is the "gold" insight statement |

## Token discipline

- Don't paste the full propositions-create response — extract IDs and focus types into the summary format.
- For multi-product engagements, write each product's propositions to separate files: `propositions_music.json`, `propositions_dance.json`.
