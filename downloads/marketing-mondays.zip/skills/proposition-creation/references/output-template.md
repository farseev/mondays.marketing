# Output Template — Propositions

## Structure

```
PRODUCT: id <N> · <Name> · profile <N>
  Category: <category>
  Market: <b2b|b2c>
  Source: <existing|created_this_run>

INPUTS:
  Stories: <id_1>, <id_2>, ...
  Focus dimensions: <count> items

PROPOSITIONS (<count>):
  <id> · <focusType> · "<name>"
  <id> · <focusType> · "<name>"
  ...

AUDIT:
  Workspace: <id>
  Profile: <id>
  Story IDs: <list>
  Product ID: <id>
```

## Filled example — Example Academy Music

```
PRODUCT: id 91 · Example Academy Music Programme · profile 1111
  Category: Music Education
  Market: b2c
  Source: created_this_run

INPUTS:
  Stories: 601, 602, 603
  Focus dimensions: 5 items (2 features, 2 rtbs, 1 usp)

PROPOSITIONS (15):
  1301 · product_features · "Piano + Violin + Conducting (Example Academy Music Programme) - Holistic growth flourishes where heart and art interlace."
  1302 · product_features · "Music + Ballet under one loyalty card - Holistic growth flourishes where heart and art interlace."
  1307 · rtb · "12-year track record since 2014 - Holistic growth flourishes where heart and art interlace."
  1327 · rtb · "Example Academy Loyalty Programme Silver Gold Platinum - Holistic growth flourishes where heart and art interlace."
  1329 · usp · "Only academy in the city with Conducting - Holistic growth flourishes where heart and art interlace."
  1312 · product_features · "Piano + Violin + Conducting - Effort shapes artistry more than innate talent."
  1313 · product_features · "Music + Ballet under one loyalty card - Effort shapes artistry more than innate talent."
  ... (etc, 5 focuses × 3 stories = 15 total)

AUDIT:
  Workspace: 1236
  Profile: 1111
  Story IDs: 601 (Aina's Journey), 602 (The Silent Struggle), 603 (The Dance of Shadows)
  Product ID: 91
```

## Multi-product orchestration

For a strategy with 2 products (Music + Dance), output two PRODUCT blocks stacked. Each gets its own audit chain.

## What proposition names tell you

The auto-generated name follows the format:
```
[Focus item] ([Product name]) - [Story summary]
```

If the story summary in the name reads like "Effort shapes artistry more than innate talent" — that's the gold. If it reads like "Holistic growth flourishes where heart and art interlace" — also gold. If it reads like a generic phrase ("The journey of discovery") — the underlying story is weak and the proposition will read flat. Re-run insight-creation with a sharper angle in that case.
