# Focus Dimensions — Guidance for `propositions-create`

The four focus dimensions are the lenses through which an insight gets translated into product-level positioning. Each generates a distinct proposition.

## product_features

**What goes here:** literal product/service attributes — what the offering does, has, or contains.

**Source:** `brand.offerings` (each offering becomes a feature line) OR the product's `product_features` array.

**Examples:**
- "Piano + Violin + Conducting"
- "Music + Ballet under one loyalty card"
- "Group Lessons stream"
- "RAD UK + Vaganova Russian methods"

**Resulting proposition framing:** "Because we offer [feature], the [insight] becomes deliverable."

## rtb (Reasons To Believe)

**What goes here:** structural proofs that the offering can deliver on its promise — certifications, track record, methodology, governance, transparent process.

**Source:** `brand.offerings` augmented with the brand's about/heritage pages.

**Examples:**
- "12-year track record since 2014"
- "Example Academy Loyalty Programme Silver/Gold/Platinum tier structure"
- "Master teachers with 22+ years of teaching experience"
- "RAD UK certification"

**Resulting proposition framing:** "You can trust us because [proof], which means [insight] is grounded not promised."

## usp (Unique Selling Propositions)

**What goes here:** what only this brand can credibly say in the category — structural monopolies, exclusive partnerships, formats no competitor runs.

**Source:** the brand's actual competitive position, often surfaced by whitespace-analysis.

**Examples:**
- "Only academy in the city that runs Conducting"
- "Only academy with both RAD UK + Vaganova Russian methods"
- "Holistic Music + Dance under one roof"
- "Crossroad where music and dance meet"

**Resulting proposition framing:** "Only we can claim [USP] — and that's why [insight] lives here, not elsewhere."

## promotion (SINGULAR KEY)

**What goes here:** the offer / mechanic that activates the value — referral programmes, trial offers, term structures, loyalty tier benefits.

**Source:** `brand.offerings` plus the brand's actual real promotions (must be verifiable on the website).

**Examples:**
- "Free trial via DM"
- "$88 referral credit per friend"
- "Silver tier after 2 terms — 3% off + 1 makeup class"
- "Long-Term Loyalty Bonus: 8% off 9th term after 8 terms"

**Resulting proposition framing:** "[Insight] is unlocked by [mechanic] — here's how to start."

## How to balance the four

A healthy proposition set has roughly:
- 30–40% product_features (the substantive offer)
- 20–30% rtb (the proof)
- 20% usp (the differentiator)
- 10–20% promotion (the activation)

Skewing too heavy on `promotion` makes the brand sound discount-driven. Skewing too heavy on `rtb` makes it sound bureaucratic. Skewing too heavy on `usp` makes it sound boastful. Balance.

## Item count per focus

Each item in a focus list multiplies the proposition count: `stories × focus_items_per_dimension`. For 3 stories and 3 features + 2 rtbs + 1 usp + 1 promotion = 21 propositions.

For a typical SOMIN deck, aim for **5–7 total focus items across all dimensions** (15–21 propositions per product). Beyond that, the propositions blur — too many micro-variants on the same insight.

## Worked example — Example Academy Music Programme

```
focus: {
  product_features: [
    "Piano + Violin + Conducting",
    "Music + Ballet under one loyalty card"
  ],
  rtb: [
    "12-year track record since 2014",
    "Example Academy Loyalty Programme Silver/Gold/Platinum"
  ],
  usp: [
    "Only academy in the city that runs Conducting"
  ],
  promotion: [
    "$88 referral credit per friend"
  ]
}
```

→ 6 focus items × 3 stories = 18 propositions.
