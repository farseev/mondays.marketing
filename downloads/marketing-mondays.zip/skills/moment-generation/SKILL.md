---
name: moment-generation
description: Generate calendar-anchored marketing moments from existing SOMIN persona and tension themes via the moments-create tool. A moment pairs (persona × tension) for one of seven moment types — life, seasonal, purchase, micro, search, emotional, vulnerable — surfacing specific timing triggers when a brand can credibly enter the conversation. Use whenever the user asks "generate moments", "what are the triggers for this audience", "when should we reach them", "build the timing brief", "what life events / seasonal triggers / purchase moments matter", "find the cultural anchors", or any timing-of-creative question. Depends on persona-tension-discovery (needs persona and tension theme IDs that exist). One call yields ~5 trigger items per (persona × tension) for one moment type. To produce enough triggers for a content calendar, call multiple times across different moment types.
---

# Moment Generation

Persona × Tension → Timing Triggers. The supply side of a content calendar — each call produces ~5 specific moments when a brand can enter a conversation.

## Two modes of use

This skill is called in two ways:

1. **Directly by a user** asking "what triggers should we plan around?" — the user picks `momentType` themselves from the seven options below.
2. **By a deck orchestrator** (`somin-brand-deck`, or `somin-agency-deck` if installed) after analysis has run — in this case the orchestrator does not pick types from a default mix. Instead it reads `scope.moments.types` from `scope.json`: if the value is an explicit array, use it; if the value is the sentinel `"derive_from_analysis"`, the orchestrator runs the *Moment-type derivation* table (defined in `scope-elicitation`'s SKILL.md) once per pillar, matching tension shape (lifecycle / calendar-cyclic / decision / search-intent / emotional / vulnerability) to 2–3 of the seven moment types. Each pillar typically gets 2–3 types — never just 1 (underfeeds the calendar), never more than 4 (dilutes pillar weighting).

In both modes the actual SOMIN call is identical — the only difference is who picks the types.

## When to use

- "What triggers / moments should we plan around?"
- "When should we reach them?"
- "What life events matter to this audience?"
- "Build the timing brief"
- "Find the cultural anchors for [pillar]"

## When NOT to use

- Persona/tension themes don't exist → run **persona-tension-discovery** first
- Need creative seed (character, angle, story) → use **insight-creation**
- Need product propositions → use **proposition-creation**
- Want a dated calendar (not just triggers) → run this skill first to produce triggers, then **content-calendar-build** to map them to dates

## The 7 moment types

| Type | What it surfaces | When to choose |
|---|---|---|
| **life** | Life-stage milestones (starting school, becoming a parent, retiring) | Use for any audience where life-stage drives need |
| **seasonal** | Cultural / calendar moments (Lunar New Year, Christmas, Back-to-School) | Use for B2C campaigns across a quarter or year |
| **purchase** | Buying decision moments (researching, comparing, deciding, post-purchase) | Use for product-purchase or service-enrolment journeys |
| **micro** | Micro-moment intents (I-want-to-know, I-want-to-go, I-want-to-do, I-want-to-buy) | Use when audience is in search / discovery mode |
| **search** | Search-intent triggers (specific queries audiences run) | Use for SEO-adjacent content or paid search strategy |
| **emotional** | Emotional-state moments (Triumph, Frustration, Hope, Longing, Belonging, Regret) | Use for community / brand-love content; reels and stories |
| **vulnerable** | Vulnerability moments (transitions, doubts, isolation) | Use carefully for empathy-led content; avoid exploitative framings |

See `references/moment-types.md` for full descriptions and triggering examples.

## Required inputs

| Input | Source | Notes |
|---|---|---|
| `workspaceId` | SOMIN context | |
| `personaIds` | From persona-tension-discovery | One or more persona theme IDs |
| `themeIds` | From persona-tension-discovery or trend-analysis | One or more tension theme IDs |
| `momentType` | Pick from the 7 above | One per call |

## The call

```
SOMIN:moments-create({
  workspaceId: <id>,
  personaIds: [<persona_theme_id>],
  themeIds: [<tension_theme_id>],
  momentType: "life" | "seasonal" | "purchase" | "micro" | "search" | "emotional" | "vulnerable"
})
```

Returns a moment object with:
- `id` — moment ID
- `name` — auto-generated (persona name + timestamp)
- `person` — persona details
- `tension` — tension details
- `items[]` — **~5 trigger items**, each with: `id`, `name`, `type` (sub-type), `description`, `motivation`, `generationType` (matches the moment type)

## Supply math — how many calls do I need?

The supply equation:
```
required_triggers = posts_per_week × weeks
supply = personas × tensions × moment_types_called × 5
```

For 39 posts (3/week × 13 weeks) across 3 (persona, tension) chains:
- 1 moment type → 3 × 5 = 15 triggers (NOT ENOUGH)
- 2 moment types → 30 triggers (TIGHT)
- 3 moment types → 45 triggers ✓
- 4 moment types → 60 triggers (comfortable margin)

Default mix for a quarterly calendar: **life + seasonal + emotional** (3 types).

See `references/supply-math.md` for sizing tables.

## Recommended workflow for a 3-pillar SOMIN deck

```
For each of the 3 pillars (i.e. each (persona, tension) pair):
  Call moments-create 3 times with different momentTypes
    Pillar 1 (life, seasonal, emotional)
    Pillar 2 (micro, emotional, life)        ← micro for "Quiet Work" type tensions
    Pillar 3 (emotional, seasonal, life)     ← emotional first for "Mothers" / empathy tensions

→ 9 moment calls, ~45 trigger items, fits a 39-post calendar with comfortable margin
```

The moment-type choice per pillar depends on the tension's emotional register — see `references/moment-types.md`.

## Output

See `references/output-template.md`. Brief form:
```
PILLAR <N> · (persona <id>, tension <id>):
  Moment <id> · type=<type>:
    Trigger <id> · <subtype> · "<name>"
    Trigger <id> · <subtype> · "<name>"
    ...
```

## Seasonal trigger discipline — don't invent a calendar for a year-round behaviour

Seasonal moments are the easiest type to hallucinate, because the model will happily attach a festival to any tension whether or not the timing is real. Two rules:

1. **Match the moment type to the tension's actual rhythm.** A tension whose confidence is **year-round** — e.g. home cooking, everyday meals, daily routines, ongoing discipline — does not have a season. Forcing it into Oct/Nov (or any window) invents timing that isn't in the data. For year-round tensions use `life`, `emotional`, or `micro` moments, which carry no false date claim. Reserve `seasonal` for tensions that genuinely crest on the calendar (gifting, back-to-school, summer travel, a specific festival's food).
2. **Seasonal triggers must be specific and tied to the tension — never a generic festival list.** "Diwali, particularly its sweets" tied to a dessert/baking tension is a real trigger. "Diwali / Christmas / Lunar New Year" pasted onto every pillar is filler: the same list across multiple pillars is a tell that the timing was generated, not observed. Each seasonal trigger must (a) name a real date/window in the locale, and (b) state the concrete connection to *this* tension. If you can't state the connection in one specific sentence, drop the trigger rather than ship a generic one.

Verification: before a seasonal trigger reaches a calendar, confirm the cultural date is real for the target market and that the tension actually concentrates around it. A seasonal trigger that survives only because "a festival exists" is a hallucination — cut it.

## Common failure modes

| Failure | Cause | Fix |
|---|---|---|
| Trigger labels generic | Tension theme is too broad | Re-run with a sharper tension theme |
| Triggers all "Lunar New Year" / "Christmas" | Only ran `seasonal` type | Diversify — add life + emotional |
| Same festival list pasted across pillars | `seasonal` forced onto every pillar regardless of fit | One festival list reused across pillars is a hallucination tell — make each trigger specific to its tension or drop it (see Seasonal trigger discipline) |
| Seasonal window on a year-round tension (e.g. Oct/Nov "home cooking") | `seasonal` chosen for a tension with no real season | Switch that pillar to `life`/`emotional`/`micro`; year-round behaviours carry no date claim |
| Not enough triggers for the calendar | Insufficient moment-type calls | Add more types, OR reduce calendar cadence |
| Triggers don't anchor to specific dates | Working with `life` or `emotional` (these have no dates) | Use `seasonal` + `cultural_anchors` parameter in content-calendar-build to add dates |
| `vulnerable` triggers feel exploitative | Brand voice doesn't match | Drop `vulnerable`; the type is correct for some categories but not others |

## Token discipline

- Don't paste full moment objects (each has ~5 trigger items + descriptions = large). Write to a single `moments.json` and pass the path to content-calendar-build.
- The 7-type description table belongs in references/moment-types.md, not SKILL.md.
