# Supply Math — How Many Moments to Generate

Each `moments-create` call yields ~5 trigger items for each (persona × tension) combination. Calculate how many calls you need before running.

## Core equation

```
required_triggers ≥ posts_per_week × weeks

supply = personas × tensions × moment_types × 5
```

To cover the calendar:
```
moment_types_needed ≥ ceil(required_triggers ÷ (personas × tensions × 5))
```

## Sizing table — typical configurations

| Cadence × weeks | Triggers needed | If 1 (persona, tension) pair | If 3 (persona, tension) pairs |
|---|---|---|---|
| 1/week × 4 weeks | 4 | 1 call (5 triggers) | 1 call across pairs |
| 2/week × 4 weeks | 8 | 2 calls (10 triggers) | 1 call per pair × 1 type |
| 3/week × 4 weeks | 12 | 3 calls | 1 call per pair × 1 type |
| 3/week × 13 weeks (quarter) | 39 | 8 calls (need many types!) | 3 calls per pair × 3 types = 9 calls, 45 triggers |
| 5/week × 13 weeks | 65 | unfeasible from 1 pair | 5 calls per pair × 3 types = 15 calls, 75 triggers |
| 5/week × 26 weeks (half-year) | 130 | unfeasible | 5+ types per pair across 3 pairs, 75+ triggers — consider 2 pairs running side-by-side |

## Recommended default — quarterly 3-pillar deck

```
3 pillars × 3 moment types = 9 moments-create calls
Each call yields 5 triggers → 45 trigger items total
Covers 39 calendar slots with 6 trigger items of margin
```

Choice of 3 moment types per pillar depends on the tension's flavour:

| Pillar tension | Recommended 3 types |
|---|---|
| Music / arts enrichment | life + seasonal + emotional |
| Quiet work / discipline | micro + emotional + life |
| Mothers / caregivers | emotional + seasonal + life |
| Heritage / cultural | seasonal + sociological-emotional + life |
| Performance / mastery | micro + emotional + life |
| Practical / functional | micro + search + purchase |

## Parallelisation

The 9 calls for a quarterly deck can be fired in parallel — each call is independent. SOMIN processes them concurrently. Save IDs into one moments.json then pass to content-calendar-build.

## When supply is short

If `supply < required_triggers`:
- Option 1 — Add more moment types per pair (cheapest)
- Option 2 — Add more (persona, tension) pairs (requires more insight-creation work upstream)
- Option 3 — Reduce calendar cadence (e.g. 3/week → 2/week)
- Option 4 — Accept that some calendar slots will reuse triggers (mark them in the calendar as `repeat` slots)

## When supply is excessive

If `supply >> required_triggers` (e.g. 80 triggers for 30 slots):
- Pick the best triggers per pillar; don't try to use all of them
- The unused triggers become a "next quarter" reservoir — store them as backlog
- Don't generate more types than needed; SOMIN compute is finite
