# 7 Moment Types — Full Descriptions

Each moment type surfaces a different kind of audience entry point. Pick types based on the tension's emotional register and the campaign's goal.

## life

**Surfaces:** life-stage milestones — moments where the audience is undergoing a structural change in their life.

**Example triggers:**
- Starting a family
- Enrolling children in arts programmes
- Transitioning to primary education
- Achieving a personal best in technique
- Pursuing a professional dance career
- Establishing a self-care routine
- Retiring
- Buying a first home

**Best for:** B2C brands serving audiences with clear life-stage transitions. The triggers don't have specific dates — they're stage-anchored.

## seasonal

**Surfaces:** cultural and calendar moments — anchored to specific dates or windows in the year.

**Example triggers:**
- Lunar New Year (date-specific, varies by year)
- Children's Day (October in Singapore, June elsewhere)
- Mid-Autumn Festival
- Back-to-School season
- Christmas / Hanukkah / Diwali
- National holidays
- Black Friday
- Summer / Winter breaks

**Best for:** consumer brands across a quarter or year. Always pair with `cultural_anchors` in content-calendar-build to actually pin to dates.

## purchase

**Surfaces:** buying decision moments — the journey from "thinking about it" to "bought it" to "post-purchase".

**Example triggers:**
- Researching options
- Comparing products / services
- Reading reviews
- Trial / sample
- Decision moment ("ready to buy")
- Post-purchase ("did I make the right choice?")
- Re-purchase / renewal

**Best for:** considered-purchase categories — education, financial services, home improvement, automotive. Less useful for impulse categories.

## micro

**Surfaces:** Google's "micro-moments" framework — I-want-to-know / I-want-to-go / I-want-to-do / I-want-to-buy.

**Example triggers:**
- "Seeking ballet training resources" (I-want-to-know)
- "Finding local dance classes" (I-want-to-go)
- "Watching ballet performance videos" (I-want-to-do)
- "Comparing ballet gear and attire" (I-want-to-buy)

**Best for:** audiences in active discovery / search mode. Pair with `search` type for SEO-driven plans. Best content format for micro triggers: CAROUSEL, STORY, or short REEL.

## search

**Surfaces:** specific search queries the audience runs — the literal SEO landscape around the tension.

**Example triggers:**
- "best [product] for [need]"
- "how to [problem]"
- "[brand] vs [competitor]"
- "why does [behaviour] happen"

**Best for:** SEO content, paid search, FAQ pages. Tends to produce more functional triggers than the other types.

## emotional

**Surfaces:** emotional-state moments. SOMIN classifies these into named emotional registers.

**Example triggers (sub-types):**
- **Triumph** — moments of accomplishment / breakthrough
- **Frustration** — moments of friction / obstacle / unmet need
- **Longing** — moments of yearning / nostalgia / unfulfilled wish
- **Hope** — moments of forward-looking optimism
- **Belonging** — moments of connection / community / inclusion
- **Regret** — moments of self-criticism / second-guessing

**Best for:** brand-love content, reels, stories, community posts. The Mothers pillar in particular benefits from emotional triggers because the underlying tension IS emotional.

Best content format for emotional triggers: REEL with audio.

## vulnerable

**Surfaces:** vulnerability moments — transitions, doubts, isolation, fear of inadequacy.

**Example triggers:**
- Feeling left out
- Imposter syndrome moments
- Transition uncertainty
- Loss / grief
- Body / appearance vulnerability
- Financial worry

**Best for:** empathy-led content, mental health-adjacent brands, support-focused product positioning.

**Caution:** vulnerable triggers can read as exploitative if the brand voice isn't naturally empathetic. Use with deliberate care, and probably not for every brand. Check the brand's voice with `voice-patterns.md` (in content-brief-from-moment) before using vulnerable triggers.

## Mapping tension types → recommended moment types

| Tension flavour | First-choice moment types |
|---|---|
| Recognition / validation | emotional, life |
| Heritage / craft | seasonal, sociological-life |
| Practical knowledge gap | micro, search |
| Premium access | purchase, seasonal |
| Quiet work / discipline | micro, emotional, life |
| Mothers / unsung labour | emotional, life, seasonal |
| Cultural belonging | seasonal, emotional |
| Decision fatigue | purchase, micro |
