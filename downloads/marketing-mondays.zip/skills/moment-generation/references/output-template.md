# Output Template — Moment Generation

## Structure

```
WORKSPACE: <id>

MOMENT <id> · type=<momentType> · persona <id> × tension <id>:
  Persona: <name>
  Tension: <name>
  Triggers (5):
    <id> · <subtype> · "<name>"
      Description: <short paraphrase>
      Motivation: <if present>
    <id> · <subtype> · "<name>"
    ...
```

## Filled example — Example Academy August (Music pillar)

```
WORKSPACE: 1236

MOMENT 701 · type=life · persona 10051 × tension 10052:
  Persona: The Melodic Pathfinder
  Tension: Bridging the Gap in Early Childhood Arts
  Triggers (5):
    801 · Family & Relationships · "Starting a family"
      Description: Transformative milestone shifting priorities toward nurturing and educating children.
      Motivation: I want to provide my child with the best opportunities.
    802 · Education & Career Transitions · "Enrolling children in arts programs"
    803 · Personal Growth & Life Changes · "Participating in community arts events"
    804 · Education & Career Transitions · "Transitioning to primary education"
    805 · Family & Relationships · "Encouraging self-expression through music"

MOMENT 702 · type=seasonal · persona 10051 × tension 10052:
  Persona: The Melodic Pathfinder
  Tension: Bridging the Gap in Early Childhood Arts
  Triggers (5):
    806 · Cultural & Religious Festivals · "Lunar New Year Celebrations"
    807 · National Holidays & Observances · "Children's Day Activities"
    808 · Cultural & Religious Festivals · "Mid-Autumn Festival"
    809 · Commercial & Shopping Events · "Arts in the Park Festival"
    810 · Seasonal Shifts & Lifestyle Changes · "Back to School Season"

MOMENT 703 · type=emotional · persona 10051 × tension 10052:
  Persona: The Melodic Pathfinder
  Tension: Bridging the Gap in Early Childhood Arts
  Triggers (5):
    811 · Triumph · "The Joy of Discovery"
    812 · Frustration · "Frustration in Finding Quality Programs"
    813 · Longing · "Nostalgia for Childhood Creativity"
    814 · Hope · "Hope for Holistic Development"
    815 · Belonging · "Connection Through Creative Expression"
```

## Multi-pillar output

For a 3-pillar deck, output 9 MOMENT blocks (3 pillars × 3 types). Group them by pillar:

```
=== PILLAR 1 · MUSIC · persona 10051 × tension 10052 ===
MOMENT 701 · life
MOMENT 702 · seasonal
MOMENT 703 · emotional

=== PILLAR 2 · QUIET WORK · persona 10054 × tension 10053 ===
MOMENT 704 · micro
MOMENT 705 · emotional
MOMENT 706 · life

=== PILLAR 3 · MOTHERS · persona 10055 × tension 10056 ===
MOMENT 707 · emotional
MOMENT 708 · seasonal
MOMENT 709 · life
```

This is exactly the input shape that content-calendar-build consumes.

## What downstream skills need

- **content-calendar-build** consumes: moment_id, pillar, trigger_id, trigger_label, trigger_type
- **content-brief-from-moment** consumes: trigger_label, trigger_description, story_id (from insight chain)
- **somin-brand-deck** audit trail consumes: just the moment IDs and a summary count

The full triggers JSON is large — store on disk, pass paths between skills.
