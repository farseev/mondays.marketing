# Output Template — Persona + Tension Summary

After completing all 5 steps, return this structured summary. Downstream skills (whitespace-analysis, trend-analysis, insight-creation, proposition-creation) consume this format.

## Template

```
WORKSPACE: <name> (id: <NNNN>)
PROFILES: <count> — <comma-separated names>
FILTER: <concept>=<values>  WINDOW: <start_date> to <end_date>

PERSONA STUDY <NNNN>: totalSize <N>
  Theme <NNNNN> — <Name> — sampleSize <N>/<TOTAL> (<X>%) — <one-line summary>
  Theme <NNNNN> — <Name> — sampleSize <N>/<TOTAL> (<X>%) — <one-line summary>
  ...

TENSIONS STUDY <NNNN>: totalSize <N>
  Theme <NNNNN> — <Name> — sampleSize <N>/<TOTAL> (<X>%) — <one-line summary>
  Theme <NNNNN> — <Name> — sampleSize <N>/<TOTAL> (<X>%) — <one-line summary>
  ...
```

## Filled example (fictional brand and IDs)

```
WORKSPACE: Example Lubricants + Competitors (id: 1234)
PROFILES: 9 — Example Lubricants, Competitor A, Competitor B, Competitor C, Competitor D, Competitor E, Competitor F, Competitor G, Competitor H
FILTER: AUDIENCES=Car Lovers  WINDOW: 2025-02-15 to 2025-05-15

PERSONA STUDY 2001: totalSize 56
  Theme 10001 — Resourceful Gear Guardian — sampleSize 26/56 (46%) — Drivers who maintain their own vehicles; value functional knowledge over status
  Theme 10002 — Performance Enthusiast — sampleSize 18/56 (32%) — Track-day participants; engagement with motorsport content
  Theme 10003 — Heritage Collector — sampleSize 12/56 (21%) — Classic car ownership; pride in restoration

TENSIONS STUDY 2002: totalSize 150
  Theme 10011 — Maintenance — sampleSize 44/150 (29%) — Practical care advice tension; finding trusted information
  Theme 10012 — Motorsport Excitement — sampleSize 35/150 (23%) — Belonging through competitive driving culture
  Theme 10013 — Personal Expression in Design — sampleSize 6/150 (4%) — Aesthetics of car ownership as identity marker
```

## Why this exact format

- **Workspace ID + profile list** = the audit chain
- **Study ID** = retrievable via `SOMIN:studies-get` for any reader
- **Theme ID** = passable to `insight-creation`, `moments-create`, `propositions-create`
- **sampleSize/totalSize ratio** = the auditable evidence number for client decks
- **One-line summary** = enough context for a downstream skill to decide whether to use the theme

The format must stay copy-pasteable into briefs and downstream skill inputs without modification.
