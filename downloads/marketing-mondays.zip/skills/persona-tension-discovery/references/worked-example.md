# Worked Example — Example Lubricants Q3 2026 Discovery (fictional)

A complete trace of persona-tension-discovery applied to a strategy build. Brand, competitor and creator names and all IDs are fictional. Read this when designing a multi-cohort study setup or when in doubt about which sequence to follow.

## Goal

Discover what audiences and tensions the lubricants market expresses, what Example Lubricants currently says, and what competitors run.

## Steps

### 1. Resolve workspace and profiles
```
workspaces-list → workspace 1234 "Example Lubricants + Competitors", 1235 "Influencer Panel"
profiles-list(1234) → Example Lubricants + 8 competitors (Competitor A–H)
profiles-list(1235) → 14 automotive creators
```

### 2. Audit concepts (in workspace 1235 specifically — influencer panel)
```
concepts-search({concept: "AUDIENCES", workspaceId: 1235, datePreset: "LAST_90_DAYS"})
→ "Car Lovers" (high count) — confirmed as dominant segment
```

### 3. Spot-check
```
posts-search({
  workspaceId: 1235,
  filters: [{key: "AUDIENCES", values: ["Car Lovers"]}],
  sortBy: "total_engagement",
  pageSize: 10
})
→ top posts dominated by Creator X (single profile, 5–6% engagement rates)
  Captured: meta.code values like ABC123xyz + likes/views/ER
```

### 4. Commission 6 studies in parallel
| Study | Workspace | Profiles | Filters | Window | Reports | maxContentItems |
|---|---|---|---|---|---|---|
| 2001 | 1234 | Example Lubricants only | none | 90D | persona | 100 |
| 2002 | 1234 | Example Lubricants only | none | 90D | tensions | 200 |
| 2003 | 1234 | 8 competitors | none | 90D | tensions | 200 |
| 2004 | 1235 | all 14 creators | AUDIENCES=Car Lovers | 30D | tensions | 40 |
| (5 more for trend analysis — see trend-analysis skill) |

All 6 `studies-create` calls fired within 6 seconds.

### 5. Retrieved after ~90 seconds
```
studies-get({studyIds: [2001, 2002, 2003, 2004], reportTypes: ["persona", "tensions"]})
```

Results:
- **Example Lubricants persona 2001**: theme 10001 "Resourceful Gear Guardian", 26/56 (46%)
- **Example Lubricants tensions 2002**: theme 10011 "Maintenance" (44/150 = 29%), 10012 "Motorsport Excitement" (35/150 = 23%), 10013 "Personal Expression in Design" (6/150 = 4%)
- **Competitor tensions 2003**: theme 10022 "Excitement / Community Engagement" (111/200 = 55.5%), 10021 "Performance & Reliability" (53/200 = 26.5%), 10023 "Maintenance" (30/200 = 15%)
- **Influencer live 2004**: 6 themes; Excitement and Luxury dominant

## Downstream

These study + theme IDs became the audit trail for a 33-slide Q3 2026 strategy deck. Every claim in the deck ("Example Lubricants at 23% adjacent in motorsport", "competitors at 56% on excitement", "Riley Gearhart is 46% of Example Lubricants' voice") traced directly to one of these theme IDs.

## Lessons from this engagement

1. **Run brand-only AND competitor-only AND influencer studies in parallel.** Each one answers a different question (what we say / what they say / what the audience consumes). Doing them sequentially wastes wall-clock.
2. **The influencer-live 30D study is the freshness signal.** It catches cultural moments competitor brand corpora don't reach.
3. **Capture the top engaged posts in Step 3 BEFORE running the study.** Those are your downstream proof-post citations for the deck.
4. **Note single-profile dominance.** Creator X carrying the Car Lovers cohort means the resulting persona is partly "Creator X's audience" — flag this in the deck commentary.
