# Filter Selection — Which Concept to Use When

The most-used concept filters in SOMIN Perspective Studies, ranked by frequency.

## AUDIENCES — the workhorse filter

Defines who the corpus is actually reaching. Use this first, almost always.

Examples that have appeared in real workspaces:
- `Car Lovers` — automotive content discovery
- `Sustainable Living Enthusiasts` — green / ESG segmentation
- `Luxury Goods` — premium-tier audiences
- `Sports Enthusiasts` — sports / motorsport
- `Tech Innovators` — early-adopter content
- `Parents` / `Families` — family/parenting category

**Always run `concepts-search({concept: "AUDIENCES"})` first** to see which labels are actually present. They vary by client workspace.

## BRAND_LIST — for cross-brand cohort studies

Use when studying how a **category** talks, not just one brand. List all competitor profile IDs as `profileIds`, AND add `BRAND_LIST` filter to surface posts that mention category brands more broadly.

Example: a lubricant-category study where you want both the rivals' posts AND broader brand mentions.

## TOPIC_CATEGORY — secondary thematic cut

Use when AUDIENCES isn't specific enough. Examples: "Motorsports", "Sustainability", "Wellness".

## LANG — for multi-language workspaces

If a workspace has mixed languages, filter on `LANG: ["en"]` (or target code) to prevent the study from clustering across languages, which creates noise.

Skip if monolingual.

## TONES — use sparingly

`Inspirational`, `Educational`, `Humorous`. Filtering by tone over-constrains. Use only when the user specifically wants "what does inspirational content look like in this category".

## Demographics — PROFESSION / AGE_GROUP / GENDER

Use only when the user explicitly asks for a demographic cut. These filters reduce corpus aggressively.

## INTERESTS / ASPIRATIONS / ARCHETYPES

Psychographic filters. Useful for refined persona work but tend to be noisy on smaller corpora. Use as secondary filters only.

## Decision flowchart

```
Does the user mention a segment / audience by name?
  YES → start with AUDIENCES filter
  NO  → check what concepts exist in workspace first

Are you studying multiple brands?
  YES → ProfileIds is your main "filter"; consider BRAND_LIST for broader mentions
  NO  → profileIds: [one_brand] is sufficient

Does the workspace span languages?
  YES → add LANG filter
  NO  → skip

Is the user asking about a specific topic vertical (motorsport, wellness)?
  YES → TOPIC_CATEGORY in addition to AUDIENCES
  NO  → skip TOPIC_CATEGORY
```

## Filter-count rule

- 1 filter: works on any corpus
- 2 filters: works if corpus is decent (>300 posts in window)
- 3+ filters: requires very large corpus AND user explicitly asks for the narrow cut

If a study returns `totalSize < 30`, drop the most restrictive filter and re-run.
