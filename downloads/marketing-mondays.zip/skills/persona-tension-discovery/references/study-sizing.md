# Study Sizing — `maxContentItems` and `minClusters`

## `maxContentItems`

| Use case | Recommended | Rationale |
|---|---|---|
| Single brand, last 90 days | 100–200 | Brand corpora are small; cap prevents over-sampling old content |
| Brand + competitor cohort (5–10 brands), last 90 days | 200 | One representative slice per brand on average |
| Influencer panel (10–20 creators), 1-month window | 100 | Monthly cuts; the smaller window gives the trend signal |
| Influencer panel, 30-day rolling live | 40 | Captures what's live right now; small but current |
| Monthly cuts for 12-month trend analysis | 50–60 per month | Enough for stable themes per window without exploding study count |

## `minClusters`

| Value | Use case |
|---|---|
| 2 | Almost never — output too coarse |
| **3** | **Default for both persona and tensions** |
| 4 | Larger corpora (totalSize >150) where you want finer segmentation |
| 5+ | Only if corpus is very large (>300) AND the user wants high resolution |

Anything below 3 produces output too coarse to act on. Anything above 4–5 over-fragments small corpora.

## Volume math

```
SOMIN can return up to maxContentItems posts
The study clusters them into ≥minClusters themes
Healthy theme has sampleSize ≥ 10
So: maxContentItems ÷ minClusters should be ≥ 30
```

For `minClusters: 3`, set `maxContentItems ≥ 90`. For `minClusters: 4`, set `≥ 120`.

## Window selection

| Window | Use case |
|---|---|
| LAST_7_DAYS | What's live right now (campaign monitoring) |
| LAST_30_DAYS | Current state |
| LAST_90_DAYS | **Whitespace + persona snapshot — default** |
| Explicit month (e.g. 2025-08-01 to 2025-08-31) | Monthly cuts for trend analysis |
| 12-month range | Don't run as single study — split into monthly cuts |

## Report types — when to request which

| Report | Use when | Output |
|---|---|---|
| `persona` | Need to know who the audience is | Demographic + psychographic clusters |
| `tensions` | Need to know what problem/friction is expressed | Tension theme clusters |
| `topics` | Coarse thematic map | Less actionable than tensions |
| `relevance` | What audience cares about that connects to brand | Audience-to-brand bridges |
| `propositions` | Extract value-prop language already in market | Proposition clusters |
| `brand_personalities` | How a brand presents itself | Archetypes |
| `product_incentives` | What offers / incentives running | Incentive clusters |

For audience discovery, request `persona` + `tensions` together. They are the two halves of "who is the audience and what are they expressing".

## Multi-study batching

When running multiple studies (e.g. monthly cuts for trend analysis):

1. Fire all `studies-create` calls first — each returns in ~1 second with a study ID
2. Save all IDs to a working file
3. Do other prep work for ~90 seconds
4. Call `studies-get` once with ALL IDs in `studyIds: [...]`

A 12-month trend setup runs in ~2 minutes wall-clock this way, vs ~18 minutes serial.
