---
name: persona-tension-discovery
description: Run end-to-end persona and tension discovery on the SOMIN platform — the foundational research step that produces inputs for whitespace analysis, trend analysis, insight creation, and proposition creation. Use whenever the user wants to understand an audience, find tensions, build a persona, audit what a brand is currently communicating, or map a competitor cohort. Trigger phrases include "find me the audience", "what are people talking about", "who is X's audience", "what tensions surface in Y", "build a persona", "what's the conversation in this market", "compare what audiences ask for vs what brands publish". Orchestrates SOMIN MCP tools (workspaces-list, profiles-list, concepts-search, posts-search, studies-create, studies-get) in a 5-step workflow. Always run the platform — never answer persona or tension questions from memory or training data.
---

# Persona and Tension Discovery (SOMIN)

Foundational research workflow. Output: validated personas + tension themes, each backed by a study ID and a measurable sample size. Feeds whitespace-analysis, trend-analysis, insight-creation, proposition-creation.

## When to use

- "Who is the audience for X?" / "What's our audience saying?"
- "What tensions surface in [category / brand / influencer panel]?"
- "Build me a persona from [these profiles]"
- "What is [Brand X] currently communicating?"
- "Compare what audiences ask for vs what brands publish"

## When NOT to use

- Study IDs already exist — call `SOMIN:studies-get` directly
- Generating creative concepts → **insight-creation** consumes this skill's output
- Time-series tracking across windows → **trend-analysis** loops this skill
- Comparing covered-vs-open territory → **whitespace-analysis** consumes this skill's output

## The 5 steps

### 1 — Resolve workspace and profiles
```
SOMIN:workspaces-list      → workspaceId by name
SOMIN:profiles-list({workspaceId})  → profileIds by brand/creator name
```
Workspaces typically contain either (a) brand + competitors or (b) audience proxy panel (influencers). Confirm which type before continuing — analytical framing differs.

### 2 — Audit available filter concepts
Before commissioning a study, check what filter values actually exist. Prevents zero-result studies.

```
SOMIN:concepts-search({workspaceId, source: "PAGES", concept: "AUDIENCES", datePreset: "LAST_90_DAYS", limit: 50})
```

Priority concept types: AUDIENCES > TOPIC_CATEGORY > BRAND_LIST > TONES > INTERESTS > demographic (PROFESSION/AGE_GROUP/GENDER, use sparingly).

**Rule:** apply at most 2 concept filters per study unless user explicitly wants a narrower cut. If a candidate concept value has <30 items, don't use it as a filter.

See `references/filter-selection.md` for which concepts to pick when.

### 3 — Spot-check the filtered corpus
Pull top 5–10 posts by engagement BEFORE the slow study generation:
```
SOMIN:posts-search({workspaceId, filters: [...], sortBy: "total_engagement", pageSize: 10})
```
Check: profile coverage, caption sanity, engagement range (capture top `meta.code` values for downstream citation), volume (need >30 posts in window).

### 4 — Commission the Perspective Study
```
SOMIN:studies-create({
  workspaceId,
  name: "<COHORT>_<CONCEPT>_<WINDOW>",   // e.g. "COMPETITOR_TENSIONS_90D"
  source: "PAGES",
  startDate, endDate (or datePreset),
  profileIds: [...],
  filters: [...],            // same as Step 3
  maxContentItems: 100-200,
  generationOptions: [
    {reportType: "persona", minClusters: 3},
    {reportType: "tensions", minClusters: 3}
  ]
})
```

Sizing rules and `maxContentItems` guidance: see `references/study-sizing.md`.

**Async pattern:** if running multiple studies (e.g. for trend-analysis), fire all `studies-create` calls in one batch — each returns immediately with an ID. Then call `studies-get` on the full list once they've had ~90 seconds.

### 5 — Retrieve and interpret
```
SOMIN:studies-get({studyIds: [...], reportTypes: ["persona", "tensions"]})
```

For each theme capture: `id`, `name`, `summary` (READ THIS — title alone is misleading), `sampleSize`, `totalSize`. Cite `sampleSize/totalSize` ratio, never absolute count alone.

Sanity checks:
- 3–6 themes per report = healthy. Only 1–2 = corpus too narrow, re-run.
- One theme >80% of corpus = "single voice" study — note it as a signal.
- Title-summary mismatch is common — always cite the summary's framing.

## Output shape

See `references/output-template.md` for the structured summary downstream skills consume.

## Validation discipline — the audit rule

Every number reaching a client deck must trace to a study ID + theme ID. Capture them in working notes the moment you retrieve them. Cite `sampleSize/totalSize`, never standalone "9 posts". If a number can't be traced, drop it — even if it strengthens the argument.

## Common failure modes

| Failure | Cause | Fix |
|---|---|---|
| Study returns 1 theme | Corpus too narrow | Widen window or drop a filter |
| Themes feel generic | Filters too broad | Add an AUDIENCES filter |
| Single-profile dominance | One creator carries the corpus | Note explicitly; consider weighting |
| `studies-get` returns empty | Async not done | Wait 90s, retry |
| Concept value not found | Filter doesn't exist in workspace | Re-run `concepts-search` |
| `totalSize` < `maxContentItems` | Filters reduced corpus | OK — cite actual totalSize, not cap |

## Worked example

A full worked trace with a fictional brand (Example Lubricants, Q3 2026: 6 parallel studies, 6 theme IDs, the audit chain into a 33-slide deck) is in `references/worked-example.md`. Read it when designing a multi-cohort study setup.

## Token discipline

- Don't paste raw `studies-get` output into the conversation — it's verbose JSON. Extract the theme IDs + names + sample ratios into the summary format and pass that.
- The detailed examples and the filter reference live in references/; read them only when planning a new study type.
