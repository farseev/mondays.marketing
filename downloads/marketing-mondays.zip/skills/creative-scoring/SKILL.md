---
name: creative-scoring
description: "Score rendered marketing creatives for predicted clickability on SOMIN and flag the strong ones in a deck. The shared scoring step for the SOMIN deck orchestrators (somin-brand-deck, plus somin-agency-deck and somin-influencer-deck if installed), also usable on its own. Uploads each creative (image plus caption) with posts-upload, polls posts-search over a long horizon until the asynchronous per-asset scoring lands, reads the three-way clickability class, and flags a creative Top performer potential only when it is BOTH predicted ABOVE_AVERAGE and at or above 0.80 confidence. Two placement modes - GRID badges Creative-Library appendix tiles and adds an explanation slide plus a leaderboard via scripts/score_annotate.py; INLINE emits per-render scores for a builder to badge composited renders. Skips the summary slide and all badges when nothing qualifies. A pre-launch prediction, not measured results."
---

# Creative Scoring — SOMIN clickability

Predict the clickability of a set of rendered creatives, flag the strong ones, and surface them in the deck. This is the **shared scoring step** for the deck orchestrators (`somin-brand-deck`, plus `somin-agency-deck` and `somin-influencer-deck` if installed); it can also be run on its own against any set of rendered creatives.

## The selection criterion — both halves, always

A creative is **"Top performer potential"** only when **both** are true:

1. its **predicted class is `ABOVE_AVERAGE`** (the argmax of the three-way clickability distribution), **and**
2. its **`ABOVE_AVERAGE` probability is `≥ 0.80`**.

Never report a ranking on the probability alone, and never report one on the class alone. A creative whose class is `AVERAGE` does not qualify no matter how its numbers are phrased. Keep `0.80` unless the caller overrides it. When asked for "the top N", return only those that clear **both** halves — if fewer than N qualify, return fewer and say how many cleared. Do not pad the list with near-misses.

**Skip rule:** if **no** creative clears both halves, **add no summary slide and no badges**. Record `top_performers: 0` in the scope passed to QA.

**When to run — MANDATORY after any generation:** whenever rendered creatives exist (a Creative-Library appendix was assembled, or in-style renders were generated), this step is **required** — `deck-qa-*` fails a deck that has rendered creatives but no predicted-performance pass (`scoring_ran` must be true). The **only** exemption is a genuinely text-only deck with **zero** rendered creatives.

`SOMIN:posts-upload` and `SOMIN:posts-search` are deferred tools — load them with `tool_search` first (`tool_search(query="posts upload")`, `tool_search(query="posts search owned clickability")`). Never treat their absence from the visible tool list as "unavailable".

---

## Inputs

- The rendered creatives as a `key → {image_url, hook}` map. **`image_url`** = a durable URL for the rendered image (the `SOMIN:image-generate` return URL persists on SOMIN storage; keep the map when you render). **`hook`** = the caption the creative was built around, so image and copy are scored together.
- `workspaceId`, the campaign `platform` (e.g. `INSTAGRAM` / `TIKTOK`), and the `audience` label (for the explanation copy).
- `threshold` (default `0.80`).
- `placement`: **GRID** (Creative-Library appendix grids) or **INLINE** (composited by a bespoke builder).

## Step A — Upload every creative

`SOMIN:posts-upload({ workspaceId, posts:[ {text, platforms:[…], media:[url]} … ] })` — one post per creative, `text` = its hook, `media` = its image URL, `platforms` = the campaign channel. Send them in one call; the returned **post IDs come back in order** — persist a `key → postId` map (`id_map.json`) immediately, before anything else. That map is the only link back from a score to a creative, and the polling below may span hours or a separate session.

This is the supported ingest path: uploaded owned posts are queued for asset scoring and the scores surface later in `posts-search` under `source: "OWNED"`. Base64 upload of dozens of multi-MB PNGs is not viable in tool calls — use URLs.

## Step B — Poll until scoring lands (asynchronous, long horizon)

Per-asset image scoring is a **queue, not a request**. Budget **hours, not minutes**: 108 images were observed still queued at **4.8 hours** after ingest, with the pipeline entirely healthy. Treat a multi-hour wait as the expected case.

- Poll `SOMIN:posts-search({ workspaceId, source:"OWNED", postIds:[…], pageSize:50 })`. `pageSize` caps at 50 — page the IDs in batches of ≤50.
- **Read the queued state correctly.** A still-processing creative comes back as a **fully populated post whose `creatives[].data` is `null`** — the post is returned, not omitted, and the list is not empty. Do not read "post returned" as "scored".
- **Confirm health rather than assuming failure.** On a normal queued post: `feature.extractStatus == "success"`, `errorMessage == null`, `extractedAt` populated, `updatedAt` unchanged since ingest. That combination means *queued and fine*. It is **not** evidence that the image stage never runs, that the upload failed, or that the pathway is broken.
- **Never abort on a stall, and never re-upload.** There is no time after which "still null" means failure. Do not delete and re-post, do not re-fire the upload, do not switch to the fallback merely because the wait is long. Duplicated posts pollute the workspace and do not jump the queue.
- **Poll patiently and cheaply.** A few in-session retries (~110 s apart; bash `sleep` is capped) are fine, but do not burn a session looping. Once it is clear the queue is long, **schedule a re-check** (`send_later` / a scheduled task) hours out and hand back to the user with the elapsed time — then re-sweep every uploaded postId on each wake. A re-check instruction must carry: the `id_map.json` path, the `workspaceId`, the field path in Step C, and the both-halves criterion, since it may fire in a fresh session.
- Large results **auto-store to disk** (`/mnt/user-data/tool_results/…json`) — parse with Python (the payload is wrapped as `[{type,text}]`; the real array is `json.loads(wrap[0]["text"])`).
- **Do not enumerate candidates with the `clickability:"High"` filter.** That filter is a separate High/Normal/Low *search* vocabulary, not the score. It caps at 50 and can omit genuine `≥0.80` creatives (observed: two 85–89% creatives missing from a `High`-filtered page). Always retrieve **every** uploaded postId and threshold yourself.

## Step C — Parse and flag

The per-asset score lives at:

```
post["creatives"][i]["data"]["clickability_score"]["<asset_key>"]
  → {"ABOVE_AVERAGE": p, "AVERAGE": p, "BELOW_AVERAGE": p}   # sums to ~1
```

`<asset_key>` is per-asset (e.g. `image_<id>`) — iterate the keys rather than assuming one. A post-level `clickability` object, where present, mirrors `High`/`Normal`/`Low` onto the same three classes; the `creatives[].data` path above is authoritative.

For each returned post:
- map `postId → key` via `id_map.json`;
- take `above_avg = ABOVE_AVERAGE`, and `predicted_class = argmax` of the three;
- **flag a top performer iff `predicted_class == "ABOVE_AVERAGE"` **and** `above_avg ≥ threshold`.**

Write `scores_all.json` — one row per creative `{key, predicted_class, above_avg, average, below_average, hook}` (add `creator` for INLINE) — and `top_performers.json` (the qualifying subset, sorted by `above_avg` desc).

When reporting to a user, give the count that cleared both halves, the ranked qualifiers with their probabilities and their frame/render keys, and — if the count is short of what was asked for — say so rather than substituting weaker creatives.

## Step C-fallback — corpus-lift proxy (only when per-asset scoring is genuinely unavailable)

Use this **only** when the upload → poll path cannot be run at all (no `posts-upload` access, or no owned-content workspace) — **not** as an impatience escape from a long queue. Pull each creative attribute at `clickability:High` and `clickability:Low` from the brand's own paid (`ADS_LIBRARY`) corpus, normalise each to share-of-set, rank by **High-minus-Low lift (pp)**, and grade every rendered concept against the winning patterns. Label it a **corpus-pattern proxy**, never a per-asset measurement. Record `scoring_method` (`per_asset` | `corpus_lift`).

**Ceiling check — mandatory before reporting any count.** The proxy maps evidence to a pseudo-probability (e.g. logistic `p = 1/(1+exp(-(a0 + b·E)))`). Compute the **maximum attainable `p`** under the observed lift range before thresholding. If that ceiling is **below** the threshold, then "0 creatives cleared 0.80" is **arithmetic about the mapping, not a finding about the creatives** — say exactly that, report the proxy ranking on its own scale instead, and do not tell the user their creatives are weak. (Observed once: ceiling 0.502 against a 0.80 threshold — a +13.9pp lift would have been needed against a +5.76pp maximum observed.) Either recalibrate the mapping against a corpus with known outcomes or present rank-order only.

## Step D — Annotate

### GRID placement (Creative-Library appendix → brand / agency decks)

```
python3 <creative-scoring>/scripts/score_annotate.py \
  --deck <assembled-deck-with-library.pptx> \
  --scores scores_all.json \
  --renders-dir <dir of key.png renders> \
  --brand brand_tokens.json \
  --out <deck>_scored.pptx \
  --threshold 0.80 --platform Instagram --audience "<audience>"
```

It badges every qualifying tile (highlight frame + `★ NN%` badge, caption recoloured) and inserts, **right after the Creative-Library cover**, a **"Predicted performance"** explanation slide (what the score measures, the three classes, the both-halves 0.80 rule, the *prediction not measurement* caveat) and a **"Top performer potential"** leaderboard (ranked thumbnails + scores + the headline pattern). It renumbers body footers and mirrors the wordmark/footer from a reference body slide. **Skip rule is built in:** with zero qualifiers it makes no changes and exits. Pass `brand_tokens.json` (`paper`/`ink`/`accent`/`grey`/`soft` + `font_head`/`font_body` + `name`), hex **without** `#`.

### INLINE placement (composited renders → creator / influencer decks)

No grid to badge — `score_annotate.py` does **not** apply. Emit `creative_scores.json` (`{key, creator, predicted_class, above_avg, hook, top_performer}`) for the deck **builder**, which then:
- overlays a `★ NN%` badge (single accent) on each qualifying render where it composites it;
- **if ≥1 render qualifies**, adds one **"Predicted creative performance"** summary slide — ranked list (creator · hook · score thumbnail), a one-line legend, and the caveat;
- **omits that slide and all badges when nothing qualifies**.

## Step E — Record scope for QA

Add to the scope object passed to the QA skill: `scoring_ran: true`, `scoring_method: per_asset | corpus_lift`, `creatives_scored: <N>`, `top_performers: <M>`. When `M = 0`, note whether that is a real result or a `corpus_lift` ceiling artefact (Step C-fallback). If scoring is still queued at hand-off, record `scoring_ran: pending` with the elapsed time and the scheduled re-check — do not record a fabricated zero.

---

## Method caveat (state it on the explanation / summary slide)

Scores reflect each creative **as rendered** paired with its **hook as caption**, scored for the **named audience on the chosen platform**. Change the platform or audience and the predictions shift. It is a model estimate of above-average click-through likelihood versus benchmark content — a pre-launch prioritisation signal, **not** a report of measured live performance.