#!/usr/bin/env python3
"""
score_annotate.py — badge top-performing creatives in a SOMIN deck's Creative-Library
appendix and insert a "Predicted performance" explanation + "Top performer potential"
leaderboard, right after the Creative-Library cover.

Threshold default 0.80 on above-average (clickability High) probability.
SKIP RULE: if no creative reaches the threshold, the deck is left unchanged (no slides,
no badges) — the summary slide is omitted by design.

Usage:
  python3 score_annotate.py --deck IN.pptx --scores scores_all.json \
      --renders-dir renders --brand brand_tokens.json --out OUT.pptx [--threshold 0.80]

scores_all.json: [{"key":"P1-T-03","above_avg":0.91,"hook":"…"} , …]   (one row per creative)
brand_tokens.json: {"name","accent","ink","grey","soft","paper","font_head","font_body"}  (hex WITHOUT '#')
"""
import argparse, json, re, copy, shutil, sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_SHAPE_TYPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

def hx(s, default):
    s=(s or default).lstrip('#')
    return RGBColor(int(s[0:2],16),int(s[2:4],16),int(s[4:6],16))

GOLD=RGBColor(0xB0,0x78,0x12); GOLDF=RGBColor(0xC8,0x88,0x1C); WHITE=RGBColor(0xFF,0xFF,0xFF)
HAIR=RGBColor(0xE2,0xE2,0xE2)
KEYRE=re.compile(r'^(P\d+-[TMB]-\d{2})')
PNUM=re.compile(r'^\d{1,2} / \d{1,3}$')
STAGE={"T":"TOFU","M":"MOFU","B":"BOFU"}; STAGEW={"T":"awareness","M":"consideration","B":"conversion"}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--deck',required=True); ap.add_argument('--scores',required=True)
    ap.add_argument('--renders-dir',required=True); ap.add_argument('--brand',required=True)
    ap.add_argument('--out',required=True); ap.add_argument('--threshold',type=float,default=0.80)
    ap.add_argument('--platform',default='Instagram'); ap.add_argument('--audience',default='the target audience')
    # No default: per SOMIN's own schema-gotchas ("no creative ingest, no per-asset scoring
    # via MCP for generated/unpublished creatives"), `per_asset` is realistically almost never
    # the true method for a rendered Creative Library. A silent default let a caller who forgot
    # this flag ship a deck that claims live per-image AI scoring when it was actually graded
    # by content-subtype pattern against the paid-ad corpus — an accuracy defect, not a style
    # choice. Forcing the caller to state which one happened keeps the explanation slide honest.
    ap.add_argument('--method',choices=['per_asset','corpus_lift'],required=True,
                     help='per_asset: creative was uploaded to SOMIN and scored directly (rare for '
                          'generated/unpublished creatives — verify this actually happened before using it). '
                          'corpus_lift: no per-asset scoring path exists for this run; graded against '
                          "the brand's own High-vs-Low clickability corpus patterns instead (a proxy, not a measurement).")
    a=ap.parse_args()

    bt=json.load(open(a.brand))
    ACCENT=hx(bt.get('accent'),'2DBF9C'); INK=hx(bt.get('ink'),'1A1A1A'); GREY=hx(bt.get('grey'),'6B6B6B')
    BODY=RGBColor(0x33,0x33,0x33); LIGHT=hx(bt.get('soft') or bt.get('paper'),'F4F6F5')
    FH=bt.get('font_head','Arial'); FB=bt.get('font_body','Arial')
    # brand.json's convention is a top-level "brand" key (see somin-brand-deck's BRAND const);
    # "name" was this script's own (undocumented) expectation. Falling back silently produced
    # "graded against 's own High-vs-Low..." on the explanation slide -- a missing-brand-name
    # typo baked straight into client-facing copy. Accept either key, and fail loudly if truly absent.
    NAME=bt.get('name') or bt.get('brand') or ''
    if not NAME:
        sys.exit("score_annotate: brand.json has neither 'name' nor 'brand' -- the explanation slide "
                 "needs a brand name to read correctly. Add one of these keys and re-run.")

    rows=json.load(open(a.scores))
    scored=[r for r in rows if r.get('above_avg') is not None]
    top=sorted([r for r in scored if r['above_avg']>=a.threshold], key=lambda r:-r['above_avg'])
    print(f"scored={len(scored)}  threshold={a.threshold}  top_performers={len(top)}")

    # ---- SKIP RULE ----
    if not top:
        shutil.copyfile(a.deck,a.out)
        print(f"0 creatives >= {a.threshold:.0%} above-average — predicted-performance section skipped. "
              f"Deck copied unchanged to {a.out}")
        return

    prs=Presentation(a.deck); SW=prs.slide_width; SH=prs.slide_height
    slides=list(prs.slides)

    # locate grid slides + the Creative-Library cover (slide just before the first grid)
    def is_grid(s):
        pics=sum(1 for sh in s.shapes if sh.shape_type==MSO_SHAPE_TYPE.PICTURE)
        labels=sum(1 for sh in s.shapes if sh.has_text_frame and KEYRE.match(sh.text_frame.text.strip()))
        return pics>=6 and labels>=6
    grid_idx=[i for i,s in enumerate(slides) if is_grid(s)]
    if not grid_idx:
        shutil.copyfile(a.deck,a.out); print("No Creative-Library grids found; nothing to annotate."); return
    cover_idx=max(0,grid_idx[0]-1)
    ref_idx=cover_idx-1 if cover_idx>0 else 0   # a body slide whose chrome we mirror

    # ---------- helpers ----------
    def add_text(s,x,y,w,h,runs,size,bold=False,color=INK,align=None,anchor=None,font=None,ls=None,sa=None):
        tb=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h)); tf=tb.text_frame; tf.word_wrap=True
        tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0
        if anchor: tf.vertical_anchor=anchor
        paras=runs if (isinstance(runs,list) and runs and isinstance(runs[0],list)) else [runs]
        for pi,pr in enumerate(paras):
            p=tf.paragraphs[0] if pi==0 else tf.add_paragraph()
            if align:p.alignment=align
            if ls:p.line_spacing=ls
            if sa is not None:p.space_after=Pt(sa)
            items=pr if isinstance(pr,list) else [(pr,color,bold)]
            for txt,col,bd in items:
                r=p.add_run();r.text=txt;f=r.font;f.size=Pt(size);f.bold=bd;f.name=font or FB;f.color.rgb=col
        return tb
    def rect(s,x,y,w,h,fill=None,line=None,lw=None,shape=MSO_SHAPE.RECTANGLE):
        sp=s.shapes.add_shape(shape,Inches(x),Inches(y),Inches(w),Inches(h))
        if fill is None: sp.fill.background()
        else: sp.fill.solid(); sp.fill.fore_color.rgb=fill
        if line is None: sp.line.fill.background()
        else: sp.line.color.rgb=line; sp.line.width=Pt(lw or 1)
        sp.shadow.inherit=False; return sp
    def new_slide():
        layout=prs.slide_layouts[6] if len(prs.slide_layouts)>6 else prs.slide_layouts[-1]
        s=prs.slides.add_slide(layout)
        for ph in list(s.placeholders): ph._element.getparent().remove(ph._element)
        bg=rect(s,0,0,SW/914400,SH/914400,fill=WHITE)
        el=bg._element; el.getparent().remove(el); s.shapes._spTree.insert(2,el)
        # mirror wordmark + footer chrome from the reference body slide (text/line shapes only,
        # skipping the page-number run and any full-bleed background)
        ref=slides[ref_idx]
        for sh in ref.shapes:
            try:
                if sh.shape_type==MSO_SHAPE_TYPE.PICTURE: continue
                if sh.shape_type not in (MSO_SHAPE_TYPE.AUTO_SHAPE,MSO_SHAPE_TYPE.TEXT_BOX): continue
                top=(sh.top or 0)/914400; w=(sh.width or 0)/914400; h=(sh.height or 0)/914400
                if w>12 and h>7: continue                     # full-bleed bg
                if not (top<1.12 or top>6.85): continue       # only wordmark / footer zones
                if sh.has_text_frame and PNUM.match(sh.text_frame.text.strip()): continue  # skip page number
                clone=copy.deepcopy(sh._element)
                # Strip hlinkClick elements: their r:id is only meaningful inside the
                # reference slide's own relationships, so a literal copy dangles / can
                # collide with an unrelated relationship id in the new slide's part
                # (e.g. "somin.ai"'s footer link resolving to some other image rId).
                # Leave the text as plain runs; link_somin.py's final pass re-attaches
                # the real hyperlink by matching the visible text.
                for hlink in clone.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/main}hlinkClick'):
                    hlink.getparent().remove(hlink)
                s.shapes._spTree.append(clone)
            except Exception: pass
        # fresh page-number placeholder (renumbered at the end)
        add_text(s,11.78,7.02,1.0,0.3,"0 / 0",9,False,GREY,align=PP_ALIGN.RIGHT)
        return s
    def header(s,label,title):
        add_text(s,0.62,1.12,12.09,0.3,label,10.5,True,ACCENT,font=FH)
        add_text(s,0.62,1.52,12.09,0.8,title,22,True,INK,font=FH)

    # ---------- SLIDE A: explanation ----------
    sA=new_slide(); header(sA,"PREDICTED PERFORMANCE","How these creatives were scored.")
    if a.method=='corpus_lift':
        para=[
         [("There is no per-asset upload/scoring path for unpublished, AI-rendered creatives \u2014 so each of the 36 canonical funnel subtypes was graded instead against ",BODY,False),(f"{NAME}\u2019s own",INK,True),(" High-vs-Low clickability corpus (tones, emotions and content-type share-of-set lift from its own paid ad library).",BODY,False)],
         [("Every creative sharing a subtype gets that subtype\u2019s ",BODY,False),("corpus-lift score",INK,True),(" \u2014 the modelled probability it lands ",BODY,False),("above-average",INK,True),(" versus the benchmark, based on how that subtype\u2019s tone/emotion/content register performed historically.",BODY,False)],
         [("A creative is flagged ",BODY,False),("\u201cTop performer potential\u201d",GOLD,True),(" when its subtype\u2019s above-average probability is ",BODY,False),(f"{a.threshold:.0%} or higher",GOLD,True),(".",BODY,False)],
         [("This is a corpus-pattern proxy for prioritisation \u2014 not a per-asset measurement, and not a report of measured live results.",GREY,False)],
        ]
        fsz=12; lsp=1.1; spa=8
    else:
        para=[
         [("Every creative \u2014 the image and its caption together \u2014 was uploaded to the SOMIN content library and scored by SOMIN\u2019s clickability model.",BODY,False)],
         [("For each one the model returns the probability that it will earn ",BODY,False),("above-average",INK,True),(", ",BODY,False),("average",INK,True),(" or ",BODY,False),("below-average",INK,True),(f" click-through versus benchmark {a.platform} content for {a.audience}.",BODY,False)],
         [("A creative is flagged ",BODY,False),("\u201cTop performer potential\u201d",GOLD,True),(" when its above-average probability is ",BODY,False),(f"{a.threshold:.0%} or higher",GOLD,True),(" \u2014 i.e. the model is at least "+f"{a.threshold:.0%}"+" confident it will beat the benchmark.",BODY,False)],
         [("It is a pre-launch prediction used to prioritise which creatives to produce and back with spend \u2014 not a report of measured live results.",GREY,False)],
        ]
        fsz=13; lsp=1.18; spa=11
    tb=sA.shapes.add_textbox(Inches(0.62),Inches(2.45),Inches(7.2),Inches(3.6)); tf=tb.text_frame; tf.word_wrap=True
    tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0
    for i,pr in enumerate(para):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.line_spacing=lsp; p.space_after=Pt(spa)
        for txt,col,bd in pr:
            r=p.add_run();r.text=txt;r.font.size=Pt(fsz);r.font.bold=bd;r.font.name=FB;r.font.color.rgb=col
    cx,cw=8.2,4.5; rect(sA,cx,2.45,cw,3.62,fill=LIGHT)
    add_text(sA,cx+0.3,2.7,cw-0.6,0.3,"THE CLICKABILITY SCORE",9.5,True,ACCENT,font=FH)
    leg=[("\u25CF","Above-average",GOLDF,"likely to beat benchmark CTR"),
         ("\u25CF","Average",GREY,"in line with the benchmark"),
         ("\u25CF","Below-average",RGBColor(0xC9,0xCE,0xD2),"likely under the benchmark")]
    ly=3.12
    for dot,nm,dc,desc in leg:
        add_text(sA,cx+0.3,ly,0.3,0.3,dot,11,False,dc); add_text(sA,cx+0.62,ly-0.02,cw-0.9,0.28,nm,11,True,INK)
        add_text(sA,cx+0.62,ly+0.22,cw-0.9,0.28,desc,9,False,GREY); ly+=0.62
    rect(sA,cx+0.3,ly+0.02,cw-0.6,0.012,fill=HAIR); ly+=0.16
    add_text(sA,cx+0.3,ly,cw-0.6,0.6,[[("\u2605  ",GOLDF,True),("Top performer potential",GOLD,True)],[(f"above-average probability \u2265 {a.threshold:.0%}",GREY,False)]],10,True,GOLD)
    mean=sum(r['above_avg'] for r in scored)/max(1,len(scored))
    stats=[(str(len(scored)),"creatives scored"),(str(len(top)),f"top performers (\u2265{a.threshold:.0%})"),(f"{mean*100:.0f}%","mean above-average prob."),(a.platform[:9],a.audience[:18])]
    sx,sw=0.62,12.09/4
    for i,(big,lab) in enumerate(stats):
        add_text(sA,sx+i*sw,6.18,sw-0.2,0.4,big,19,True,(GOLD if i==1 else INK),font=FH)
        add_text(sA,sx+i*sw,6.6,sw-0.2,0.3,lab,8.5,False,GREY)

    # ---------- SLIDE B: leaderboard ----------
    sB=new_slide(); header(sB,"TOP PERFORMER POTENTIAL",f"{len(top)} creative{'s' if len(top)!=1 else ''} the model backs to beat the benchmark.")
    # headline pattern: dominant funnel stage among winners
    from collections import Counter
    st_ct=Counter(r['key'].split('-')[1] for r in top); dom,domn=st_ct.most_common(1)[0]
    sub=[("Above-average click-through probability \u2265 "+f"{a.threshold:.0%}.  ",GREY,False)]
    if domn>=max(2,len(top)//2):
        sub+=[(f"{domn} of the {len(top)} are {STAGEW[dom]}-stage ({STAGE[dom]}) creatives",INK,True),(" \u2014 the content the model rates highest.",GREY,False)]
    add_text(sB,0.62,2.32,12.0,0.5,[sub],10.5,False,GREY)
    PN={"P1":"Pillar 1","P2":"Pillar 2","P3":"Pillar 3","P4":"Pillar 4","P5":"Pillar 5"}
    import os
    os.makedirs('._thumbs',exist_ok=True)
    try:
        from PIL import Image
        HAVE_PIL=True
    except Exception: HAVE_PIL=False
    def thumb(key):
        src=os.path.join(a.renders_dir,key+'.png')
        if not os.path.exists(src): return None
        if not HAVE_PIL: return src
        dst=os.path.join('._thumbs',key+'.png')
        im=Image.open(src).convert('RGB'); w=240; h=int(im.height*w/im.width); im.resize((w,h)).save(dst); return dst
    def row(s,x,y,w,rank,rec):
        key=rec['key']; pct=rec['above_avg']; hook=rec.get('hook','')
        pil,st=key.split('-')[0],key.split('-')[1]
        t=thumb(key)
        if t: s.shapes.add_picture(t,Inches(x),Inches(y),Inches(0.40),Inches(0.48))
        add_text(s,x+0.54,y-0.01,w-1.4,0.22,[[(f"{rank}  ",GOLDF,True),(key,INK,True),(f"    {PN.get(pil,pil)} \u00b7 {STAGE[st]}",GREY,False)]],8.5,True,INK)
        add_text(s,x+0.54,y+0.235,w-1.4,0.22,hook,9,False,BODY)
        add_text(s,x+w-1.05,y+0.02,1.0,0.42,f"{pct*100:.0f}%",15,True,GOLD,align=PP_ALIGN.RIGHT,anchor=MSO_ANCHOR.MIDDLE)
    colw=5.95; per=8; y0=2.80; rh=0.50
    for i,rec in enumerate(top[:16]):
        col=0 if i<per else 1; r=i if i<per else i-per
        x=0.62 if col==0 else 6.95
        row(sB,x,y0+r*rh,colw,i+1,rec)

    # ---------- reorder: move the 2 new slides to right after the Creative-Library cover ----------
    sldIdLst=prs.slides._sldIdLst; ids=list(sldIdLst); nA,nB=ids[-2],ids[-1]
    sldIdLst.remove(nA); sldIdLst.remove(nB)
    sldIdLst.insert(cover_idx+1,nA); sldIdLst.insert(cover_idx+2,nB)

    # ---------- badge qualifying tiles in the grids ----------
    topkeys={r['key']:r['above_avg'] for r in top}; badged=0
    for s in prs.slides:
        shp=list(s.shapes)
        for j,sh in enumerate(shp):
            if not sh.has_text_frame: continue
            m=KEYRE.match(sh.text_frame.text.strip())
            if not m or m.group(1) not in topkeys: continue
            key=m.group(1); pic=shp[j-1]
            if pic.shape_type!=MSO_SHAPE_TYPE.PICTURE:
                cand=[sp for sp in shp if sp.shape_type==MSO_SHAPE_TYPE.PICTURE]
                if not cand: continue
                pic=min(cand,key=lambda sp:abs((sp.left or 0)-(sh.left or 0))+abs((sp.top or 0)-(sh.top or 0)))
            px=pic.left/914400; py=pic.top/914400; pw=pic.width/914400; ph=pic.height/914400
            rect(s,px-0.035,py-0.035,pw+0.07,ph+0.07,fill=None,line=GOLDF,lw=3.0)
            pill=rect(s,px-0.02,py-0.06,0.78,0.26,fill=GOLDF,shape=MSO_SHAPE.ROUNDED_RECTANGLE)
            tf=pill.text_frame; tf.word_wrap=False; tf.margin_left=Pt(2);tf.margin_right=Pt(2);tf.margin_top=0;tf.margin_bottom=0
            p=tf.paragraphs[0]; p.alignment=PP_ALIGN.CENTER
            r=p.add_run(); r.text=f"\u2605 {topkeys[key]*100:.0f}%"; r.font.size=Pt(8.5); r.font.bold=True; r.font.name=FB; r.font.color.rgb=WHITE
            for rr in sh.text_frame.paragraphs[0].runs: rr.font.color.rgb=GOLD; rr.font.bold=True
            badged+=1

    # ---------- renumber every page-number footer to its final position / new total ----------
    total=len(prs.slides._sldIdLst); renum=0
    for i,s in enumerate(prs.slides,1):
        for sh in s.shapes:
            if not sh.has_text_frame: continue
            for pp in sh.text_frame.paragraphs:
                for r in pp.runs:
                    if PNUM.match(r.text.strip()):
                        r.text=f"{i:02d} / {total}"; renum+=1
    prs.save(a.out)
    print(f"badged {badged} tiles · inserted 2 slides after cover (idx {cover_idx}) · renumbered {renum} footers · total {total} slides -> {a.out}")

if __name__=='__main__':
    main()
