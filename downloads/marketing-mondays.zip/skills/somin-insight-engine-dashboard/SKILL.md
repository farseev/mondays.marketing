---
name: somin-insight-engine-dashboard
description: "Build an interactive 'Insight Engine' HTML dashboard artifact for a brand study on SOMIN: persona-tension-angle-story chains per pillar, real validation data, and honest TOFU/MOFU/BOFU content examples ranked by confident SOMIN scores only."
---

# SOMIN Insight Engine Dashboard

Produces a published HTML Artifact that summarizes a brand's strategic insight chains (one tab per pillar) with real evidence, for a workspace on the SOMIN MCP connector (earlier SOMIN connector versions expose identical tool shapes; use whichever is connected).

## When to use

Use this when the user asks for an "insight engine", "insights dashboard", or similar interactive summary of a brand's persona/tension/angle/story chains — either from an existing study, or by asking you to run the study first ("run a study on X and give me the dashboard").

## Step 0 — Ask how many examples per funnel stage

Before sourcing content, ask the user (via AskUserQuestion if available, otherwise in plain text) how many content examples they want per funnel stage (TOFU / MOFU / BOFU) in each pillar tab — e.g. 1, 2, 3, or "as many confidently-scored ones as exist." Default to 1 per stage if the user has no preference or you're running unattended. This count applies per stage per pillar (so "2" means up to 2 TOFU + up to 2 MOFU + up to 2 BOFU examples per pillar tab).

## Step 1 — Get or build the study

If a study already exists (check `studies-list` / `studies-get` for the workspace), use it. Otherwise run one:

1. `workspaces-list` / `profiles-list` to confirm the workspace and brand profile.
2. `studies-create` (or the existing pillar/insight structure the workspace already has) to establish 2-4 pillars, each backed by a persona (`persona-create_characters`), a tension, a strategic angle (`theme-generate_angles`), and a story (`story-create`). If the workspace already has insights, pull them via whatever listing tool exists (e.g. `stories-list`, `propositions-list`) rather than re-generating.
3. Also pull `propositions-list` (or generate via `propositions-create`) for 2-3 USP/RTB/feature propositions per pillar.

Do not skip straight to dashboard-building without this chain — the whole point of the artifact is persona → tension → angle → story, per pillar.

## Step 2 — Pull real validation evidence per pillar

For each pillar, gather with `posts-search` (and `concepts-search` for context):

- **Engagement totals**: sum engagement across posts matching the pillar's theme/cluster ID. Try `clusterIds:[themeId]` first; if that returns empty (common — cluster filtering is unreliable when combined with `profileIds`), fall back to an unfiltered `profileIds`-only search across both `PAGES` (organic) and `ADS_LIBRARY` (paid), sorted by `total_engagement` DESC, and manually match items to the pillar using `feature.topic` / `feature.humanInsight` / ad copy.
- **Share of voice**: proportion of the brand's own content vs. the category's own content that falls in this pillar's territory (not raw counts — normalize by each cohort's total content volume).
- **Trend**: a 12-month (or quarterly) series of content volume in this territory, if obtainable; if no clean per-pillar time series exists, say so honestly in the dashboard ("no individual trend series maps to this pain point") rather than fabricating one.

## Step 3 — Source content examples per pillar × funnel stage, ranked by confident score only

Every pillar tab needs, for each of TOFU / MOFU / BOFU, up to N examples (N = the count the user gave in Step 0).

### 3a. Collect candidates

For each pillar × stage, search the brand's own real content (`posts-search`, both `PAGES` and `ADS_LIBRARY` sources, `profileIds` scoped to the brand) and classify by funnel stage using the content itself, not guesswork: no CTA / pure lifestyle-brand feel → TOFU; feature explanation, comparison, or third-party/sponsorship credibility-building with no direct CTA → MOFU; explicit discount code, "start now", price, or conversion CTA → BOFU. Collect every real candidate you can find for that pillar × stage before picking which to show.

### 3b. Compute score and confidence, and gate on confidence

SOMIN's `creatives[].data.clickability_score` field (when present) is a 3-way probability distribution over `BELOW_AVERAGE` / `AVERAGE` / `ABOVE_AVERAGE`. For each candidate with this field:

- **confidence** = the highest of the three probabilities (how sure the model is, regardless of which bucket it landed on).
- **score** = that same highest-probability value, labeled with its bucket (e.g. "87.3% ABOVE-AVERAGE").

**Only treat a score as usable when confidence > 80%** (the same 0.80 bar the `creative-scoring` skill uses for "top performer potential" — stay consistent with it). If confidence is ≤ 80% (a close or muddled 3-way split), or the `clickability_score` field is absent entirely, that candidate has **no usable score** — do not display any percentage for it, and do not describe it as "low-scoring" or invent your own qualitative rank ("weak", "strong", etc.) in its place. It is simply unranked. This applies per-candidate, not per-pillar: within one stage some candidates may be confidently scored and others not. If literally none of a pillar's candidates anywhere clear 80% confidence, that's a fine and expected outcome — the whole dashboard just shows no scores, and that is not an error to work around.

### 3c. Sort and select

Within each pillar × stage:

1. Sort candidates that have a usable score (per 3b) highest-to-lowest by that score, and take up to N of them first.
2. If fewer than N confidently-scored candidates exist, fill the remaining slots with unranked real candidates (any order, no fabricated score), then — only if still short of N — fall back to the brand's own generated creative-library concept(s) for that pillar × stage, if any exist, clearly labeled as concept renders, not real posts.
3. Never leave a stage empty by inventing content, and never force a score onto something the model wasn't confident about.

### 3d. Never fabricate

Never fabricate copy, metrics, or scores. Where you can, verify on-image text by actually opening the downloaded image with the Read tool rather than trusting a paraphrase from memory. A concept-render example is always labeled as such (e.g. "Example concept creative", "not yet run") and never presented as a scored real post.

## Step 4 — Embed images

SOMIN image URLs (`cdn.cloud.somin.ai`, etc.) are not on the Artifact CSP allowlist and will be silently blocked if referenced directly. For every real or concept image used:

1. `curl` the image down to disk (verify HTTP 200; if a top-ranked image 404s, fall back to the next-best image from the same post/ad rather than giving up).
2. Compress with PIL: resize to max ~900px on the long edge, save as JPEG quality ~82.
3. Base64-encode and embed as an inline `data:image/jpeg;base64,...` URI. Do this via a script (not by pasting base64 through an editing tool) — the file gets large and base64 blobs waste context if handled by hand. When later editing the HTML (e.g. to add more examples), use Python string/brace-matching on disk rather than reading the whole (multi-hundred-KB) file back into context.

## Step 5 — Build the dashboard

Single self-contained HTML file, one tab per pillar. Load the `artifact-design` skill first for the page contract (theme tokens, CDN allowlist, etc.). Structure per pillar panel:

- Verdict pill (whitespace / contested / emerging / etc.) + headline story line + territory description.
- Persona → tension → angle → story vertical stepper (with real theme/persona/angle/story IDs shown for traceability).
- Propositions list (USP/RTB/feature).
- Validation KPIs (engagement, evidence-post count).
- Share-of-voice bar comparison (brand vs. category).
- Trend chart (custom inline SVG line/area) or an honest "no trend series" note.
- **Examples by funnel stage** card: a TOFU / MOFU / BOFU sub-section, each listing its (up to N) examples sorted highest-score-first, showing the image, source tag (organic/paid/concept), post ID, a score tag only when 3b's confidence gate was passed (otherwise no score tag at all — not even a placeholder), the real caption/ad copy or concept description, any real metrics available, and one honest sentence of interpretation.

Fonts: Archivo Black (display), Inter (body), JetBrains Mono (labels/data) via Google Fonts. Theme tokens in `:root`, redefined for dark mode per the artifact-design skill's contract. Verify responsive down to ~400px.

## Step 6 — Verify then publish

Take one local Playwright screenshot pass (dark mode desktop + mobile width, each tab) before publishing — the "look once" rule. Check specifically that: every example's score tag matches whether it actually passed the 80% confidence gate (never a fabricated or low-confidence number), examples within each stage are sorted highest-score-first, images actually loaded, and text is legible against its background. Then publish with the `Artifact` tool. If updating an existing dashboard, republish to the same `url` so the link stays stable.