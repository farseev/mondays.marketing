---
name: competitor-audience-content-analysis
description: Analyze a SOMIN workspace's social content across a primary brand and competitors — hashtags and captions (kept separate), share of voice, shares by platform/content type, content volume by platform, target audiences, pain points, content style/aesthetics, product focus, and best-performing content strategies, finishing with whitespace recommendations. Use whenever the user says "using SOMIN Monitor/SOMIN MCP, look at [workspace]", asks to "highlight keywords", "examine competitor content", "identify target audiences", "evaluate product focus", "share of voice", "content volume by platform", "shares", or "what content strategies are performing best" for any SOMIN workspace. Always confirm brand/competitor split, product scope, and time range first. Brand-agnostic. Depends on whitespace-analysis for closing recommendations and somin-keyword-explorer-widget for its interactive rendering.
---

# Competitor Audience & Content-Strategy Analysis (SOMIN)

> SOMIN was previously branded Defy. Tool names and shapes are identical, so any older note that says `Defy:<tool>` maps one-to-one to `SOMIN:<tool>` / `mcp__SOMIN__<tool>`.

Recurring workflow, brand-agnostic, for any SOMIN workspace. Two halves:

**(A) Keywords** — hashtags and captions, kept as separate, clearly-defined
datasets but rendered in **one combined interactive widget** (see
`somin-keyword-explorer-widget`) with three mandatory button rows (category,
metric, brand), and exportable. Scope (window, product, brand set) is
resolved to literal values in Step 0 and reused unchanged for
reproducibility.

**(B) Audience & content strategy** — content audit (incl. main products
per brand) → audience segments → performance ranking → forward-looking
whitespace recommendations.

This file is the orchestrator. Full step-by-step detail for each part
lives in `references/` — read the relevant reference file before running
that part, don't try to reconstruct the detail from memory.

## When to use

- "Using SOMIN Monitor/SOMIN MCP, looking at [workspace] — highlight keywords"
- "Examine competitor content to identify target audiences"
- "Evaluate product focus" / "what are competitors pushing?"
- "Which keywords/content strategies are performing best?"

## When NOT to use

- User already has a study ID and just wants it re-read → `SOMIN:studies-get` directly
- User wants a full three-cohort whitespace map with an external audience-proxy workspace → run **whitespace-analysis** directly instead of this skill
- User wants time-series tracking across multiple windows → **trend-analysis**
- User wants this turned into creative concepts/propositions → hand off to whatever insight-creation skill is available in this environment, or state it's out of scope if none is

## Dependencies

- **`somin-keyword-explorer-widget`** — the interactive rendering component
  for Part A (and reusable for B3/B4's hover-popover needs). Read that
  skill's SKILL.md before A5.
- **`whitespace-analysis`** — for B5's verdict rubric (two-cohort PARTIAL
  mode only; see `references/part-b-audience-content.md`).
- A self-contained card-grid widget for B4's persona/topic/pain-point cards
  (built inline; see `references/part-b-audience-content.md` B4).

## Step discipline — nothing is optional by default

Every numbered step in this skill — Step 0, A1 through A6, B0.5 through
B5 — runs in full, every time, in the order given. None may be skipped,
merged, condensed, answered from memory/history, or replaced with a
plausible-sounding shortcut (e.g. offering a generic guessed product
bucket instead of actually running the `MAIN_PRODUCT` `concepts-search`
pull first) unless the user has **explicitly** said to skip or shorten
that specific step in this conversation. "Explicit" means a direct
instruction naming what to skip — not an inference from tone, urgency,
prior familiarity with the workspace, or an assumption that a step is
"probably unnecessary this time."

This applies in particular to the elicitation steps, which are the
easiest to shortcut because a hand-written question can look complete
without the underlying data pull actually having happened: the
product-scope question in Step 0 must never be asked with options that
weren't built from a real `concepts-search({concept: "MAIN_PRODUCT"})`
pull that already ran; the format question in A5 must be asked fresh
every run, not assumed from a prior run in the same conversation; the
time-range question in Step 0 must be asked fresh every run.

**The only standing exception**, stated explicitly here and nowhere
else: once brand/competitor split, time window, and product scope have
all been resolved and confirmed for a given workspace earlier in *this*
conversation, a follow-up question about that same workspace doesn't
require re-asking those three things or re-running the
`profiles-list`/`MAIN_PRODUCT` pulls that resolved them — per the
"First-run confirmation" rule in `references/step0-scope-resolution.md`.
Every other step, and every other data pull, still runs fresh. If
skipping something on the user's explicit instruction, say so out loud
before proceeding (e.g. "Skipping B4's card grids since you only asked
for the keyword explorer this run") so the gap is visible in the output
rather than silently absent.

## Run order

1. **`references/step0-scope-resolution.md`** — resolve workspace,
   brand/competitor split, literal time window, and product scope before
   any deliverable. Nothing downstream may fire before this is confirmed.
2. **`references/part-a-keywords.md`** — hashtags (A1), caption keywords
   (A2), volume/performance/engagement (A3), cross-competitor pattern
   read (A4), visualize via `somin-keyword-explorer-widget` (A5),
   reproducibility rules (A6).
3. **`references/part-b-audience-content.md`** — share of voice & platform
   volume (B0.5), content audit incl. main products & aesthetic style
   (B1), Perspective Study for personas/topics/pain points (B2),
   performance ranking (B3), card-grid visualization (B4), recommended
   strategies (B4.5), whitespace verdicts (B5).
4. **`references/reference-run.md`** — the locked canonical deliverable
   sequence and shape for a full run. Treat this as the contract for what
   "done" looks like; deviating from it (skipping a deliverable,
   collapsing two into one, reordering) is a regression unless the user
   explicitly asked for a shorter run.

Order matters within Part B too: share of voice/platform volume first
(the "how much and where" baseline), then content audit, then audience,
then performance ranking, then forward-looking recommendations.

## Extraction script

`scripts/extract_posts.py` implements A2's mandatory per-post field
extraction and caption-keyword cleaning (stopwords, CTA/giveaway words,
`@handle` mention filtering against raw caption text, all-caps acronym
filter, casing tie-break) as a single reusable pass — run it (or its
logic) once per profile's `posts-search` result rather than
reconstructing the filter lists from memory each run. See the script's
docstring and `references/part-a-keywords.md` A2 for the full rules this
encodes.

## Troubleshooting

See `references/failure-modes.md` for the full table of confirmed
failure modes and fixes — check it before treating an unexpected result
as a data problem rather than a process gap.

## Token discipline

Don't paste raw `studies-get`, `posts-search`, or `concepts-search` JSON
into the conversation. Extract IDs, titles, sample sizes, and per-profile
metrics into a compact working summary before writing the response or
building any widget.
