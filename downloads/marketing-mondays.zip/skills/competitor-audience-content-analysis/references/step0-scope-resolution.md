# Step 0 — Resolve scope before doing anything else

```
SOMIN:workspaces-list                    → workspaceId by name
SOMIN:profiles-list({workspaceId})       → all profiles in the workspace
```

**Brand/competitor split:** assume the profile matching the workspace's
own name is the primary brand and every other profile is a competitor
(e.g. an "Example Brand UK" workspace → Example Brand UK is primary, the rest are
competitors). If the workspace name doesn't clearly match one profile, or
there's more than one plausible primary brand, **stop and ask** via
`ask_user_input_v0` rather than guessing.

**Time range — always ask, every run, via `ask_user_input_v0`:**
> "What time range should I analyze?" — options: `Last 30 days`,
> `Last 3 months`, `Last 6 months`, `Last 12 months`

**Resolve to explicit absolute dates immediately — never pass a rolling
`datePreset` into any tool call in this skill.** Compute today's date
once, at the moment the user answers, and convert the choice to a fixed
literal pair:

| Option | Resolved window |
|---|---|
| Last 30 days | `startDate` = today − 30 days, `endDate` = today |
| Last 3 months | `startDate` = today − 90 days, `endDate` = today |
| Last 6 months | `startDate` = today − 182 days, `endDate` = today |
| Last 12 months | `startDate` = today − 365 days, `endDate` = today |

Store these two literal dates as `WINDOW_START` / `WINDOW_END` and pass
them as explicit `startDate`/`endDate` on **every** `concepts-search`,
`posts-search`, and `studies-create` call for the rest of this run — in
Part A and Part B alike. Never re-derive "today" partway through, and
never fall back to `datePreset` for convenience. This one substitution is
the fix for the single biggest source of run-to-run inconsistency in this
skill: a `datePreset` is re-evaluated relative to the clock at the moment
each individual tool call fires, so a multi-step run spanning real
wall-clock time (or the same skill re-run hours or days later) silently
shifts which posts are in scope — producing different hashtag/keyword
rankings from a run that never actually changed inputs on purpose.
Literal dates make the window identical no matter when each call fires or
when the skill is re-run with the same stated window.

**Platform scope:** default to all platforms. Only restrict to a specific
platform (`platforms: [...]` on `posts-search`/`concepts-search`/
`studies-create`) if the user explicitly names one.

**Product scope — always ask, never assume, and be explicit about what's
actually in the data.** Don't infer the product category from the
workspace name (e.g. don't silently assume "Example Brand UK" means coffee
machines just because that's the obvious guess) — a workspace can cover
multiple product lines. Pull `MAIN_PRODUCT` concepts-search **per
profile first** (not workspace-wide — per-profile keeps the real product
names attributable) to see what's actually in the corpus, then ask via
`ask_user_input_v0` with the **real product/model names you found**
spelled out in the question text itself (not generic buckets) — e.g.
"Which product(s) should I focus on? Found in the data: Espresso Pro, Bean-to-
Cup One, Milk Master (Example Brand); Ice-Cream Maker X, Air Fryer Y, Slush
Maker Z (Competitor A); Barista Machine Plus (Competitor B); coffee machines
and capsules (Competitor C)." Build the 3-4 answer options from that same real
list — group into sensible product lines only where genuinely equivalent
(e.g. "Espresso/coffee machines across all brands"), never a vague
catch-all category the user has to guess the contents of. Always include
"All products" as one option, and an explicit "Let me specify" option so
the user can name something not in the top list.

**This question must never be batched into the same elicitation call as
the brand-split confirmation or the time-range question, and never asked
with placeholder/guessed option labels before the `MAIN_PRODUCT` pull has
actually run.** The product-scope options have to be built from real
returned data, which means the `concepts-search` calls come first, in
their own step, and only then does the `ask_user_input_v0` call fire with
those real names as options. Asking a plausible-sounding generic bucket
like "Coffee machines" up front — even if it happens to be correct —
skips the verification this rule exists for (a workspace can have product
lines the requester doesn't expect, and a generic label can silently
paper over a mismatch between what the user meant and what's actually
tagged in the corpus) and defeats the entire purpose of this step. If the
user answers a bucket-style question before this pull happened, don't
lock it in as scope — go back, pull the real `MAIN_PRODUCT` values, and
get explicit confirmation that the bucket the user picked maps onto
specific real values found in the data.

If the user picks a specific product line, add a `MAIN_PRODUCT` (or
`PRODUCT_TYPE`) filter to every subsequent `concepts-search`/
`posts-search`/`studies-create` call in Parts A and B. If they pick "All
products," proceed unfiltered but still surface the main-products
breakdown per brand (see Part B, B1) so the user can see what's actually
being compared.

**First-run confirmation:** state the resolved brand/competitor split,
the **literal resolved window** (`WINDOW_START`–`WINDOW_END`, not the
relative label), and product scope in one line before spending any
study-generation cost (e.g. "Treating Example Brand UK as the primary brand,
Competitor A / Competitor B / Competitor C as competitors, over 2026-06-04 to
2026-09-02, across all products.") so the user can correct it and so a
repeat run can be pointed at exactly the same window on purpose. Don't
re-ask on follow-ups within the same conversation for the same workspace
— this is the one standing exception described in the main SKILL.md's
Step discipline section.
