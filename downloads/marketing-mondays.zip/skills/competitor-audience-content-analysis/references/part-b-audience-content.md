# Part B — Audience & content strategy

Order matters — share of voice/platform volume first (the "how much and
where" baseline), then content audit, then audience, then performance
ranking, then forward-looking recommendations.

## B0.5. Share of voice and content volume by platform

Two related, always-included deliverables that establish the baseline
before diving into what's *in* the content.

**Share of voice.** For the chosen window and scope, pull each profile's
total post count and total engagement (reuse the A2/B1 `posts-search`
pulls — no new calls needed if already fetched at `pageSize` high enough
to cover the full corpus, otherwise re-pull with `pageSize: 50` and page
through if the workspace has genuinely more posts than that in the
window).

**Check for the page cap before reporting any volume number as if it were
exact.** `posts-search` returns at most `pageSize` (max 50) items with no
total-count field anywhere in the response — if a brand's result set
comes back at exactly 50, that's the cap, not necessarily the true total,
and treating it as one silently produces a false "everyone has equal
volume" read (three capped brands will all show `pageSize`-worth of posts
regardless of how different their real volumes are). When a brand's page
1 comes back at exactly `pageSize`, pull `page: 2`, `page: 3` (cap
yourself at ~3-4 pages total per brand — this is expensive and not worth
exhausting) to get a better floor; if still capped after that, report the
number as "**150+ posts (floor — hit the page cap, true total is
higher)**" rather than a bare number, and do not compute a volume-share
percentage across brands where some are floors and others are exact —
that comparison is misleading on its face. Engagement-share percentages
computed from a `sortBy: total_engagement DESC` sample are more
trustworthy even when volume is capped, since the sample captures the
brand's *highest-performing* posts first — still label it "share of the
sampled engagement," not "true total share," when any brand hit the cap.

Compute, per brand: `volume_share = brand_posts ÷ total_posts_all_brands`
and `engagement_share = brand_engagement ÷ total_engagement_all_brands`,
both as percentages — but only present `volume_share` when no brand in
the comparison hit the cap; otherwise present the floor volumes as plain
numbers per brand (not as a %-of-total chart) alongside the
engagement-share chart, which can still be shown. Render as its own
titled visualization — e.g. "**Share of voice — engagement share, [brand]
vs [competitors], last 6 months**" — a small-multiples or grouped bar
chart (never a single shared donut per metric if the group has more than
~3 brands; stacked/grouped horizontal bars per the existing
scale-disparity rules read more clearly). State explicitly in prose
whenever volume and engagement share diverge for a brand (e.g. "high post
volume but low engagement share" is a real, reportable finding, not
noise).

**Content volume by platform.** Break down each profile's post count by
platform for the window: Instagram feed/grid posts, Instagram Stories,
TikTok posts, TikTok Stories, Facebook, etc. — whichever platforms are
actually present. `posts-search`'s `platforms` filter and each post's own
`sourceType`/`placement` fields are what to use; don't assume every
profile posts to every platform — some brands may be Instagram-only.
Render as a grouped bar chart, one color per brand, platforms on the
axis, titled explicitly — e.g. "**Content volume by platform, [brand] vs
[competitors], last 3 months**". This is the deliverable that supports
"are we posting enough relative to competitors" and "which platform is
under-invested" conversations — flag it plainly if the primary brand's
total volume is meaningfully behind competitors, since that's often the
actual point of asking for this.

**Shares — check field coverage before building anything, then split
into two deliverables.** `metrics.sharesCount` exists in SOMIN's data
model, but coverage is platform-dependent, not universal — check every
profile's posts before assuming it's populated. In practice it is
consistently present for Facebook and TikTok posts and consistently
absent (always `null`, never `0`) for Instagram posts, across every
content type (feed, carousel, and Reels/clips all show the same gap) —
this reads as a SOMIN-side collection gap specific to Instagram's public
API limitations, not a per-post or per-brand setting
(`share_count_disabled` is `false` on the same posts). Confirm this
pattern on the current workspace's actual data rather than assuming it
always holds exactly this way, but expect it.

Once confirmed, build two things, both filtered to only the posts where
`sharesCount` is not `null`:

1. **Shares by brand and platform, as one interactive chart with a
   platform toggle** (All platforms combined / Facebook only / TikTok
   only) rather than three separate static charts — same interaction
   pattern as the word clouds' metric toggle. State plainly in the
   chart's note text (functional, not narrative, so it's fine inside the
   widget) that Instagram is excluded from every view because the field
   doesn't exist for it — never let a bar read as "zero shares" without
   that caveat, since it could otherwise be misread as "nobody shares
   this brand's content" rather than "this platform's shares aren't
   measurable here." A brand whose entire sampled presence is Instagram
   will show as having no shares-eligible posts at all — say this
   explicitly per brand rather than silently omitting it from the chart.
2. **Average shares by content type, per brand**, using
   `feature.contentTypes` cross-referenced against the same
   shares-eligible subset — small multiples per brand, sample size in
   each bar's label (`n=`), since per-content-type post counts within the
   shares-eligible subset are often small (single digits). This is what
   answers "what kind of content actually gets shared," distinct from the
   platform breakdown answering "on which platform." Exclude any brand
   with zero shares-eligible posts from this chart entirely (don't render
   an empty chart for them) and say so in prose.

## B1. Content audit (what they post, style, consistency, main products, and aesthetic style)

Pull `CONTENT_TYPES`, `TONES`, and `MAIN_PRODUCT` concepts per profile
(including the primary brand) over the chosen window (apply the
product-scope filter from Step 0 if the user picked a specific product
line):

```
SOMIN:concepts-search({workspaceId, profileIds: [one profile], concept: "CONTENT_TYPES"/"TONES"/"MAIN_PRODUCT", datePreset/startDate+endDate, source: "PAGES", limit: 30})
```

Also pull top 20-30 posts per profile by engagement (reuse the Step A2
pull if already done) and look at `feature.contentTypes`,
`feature.toneOfVoice`, `feature.mainProduct` per post to sanity-check the
aggregated concepts against actual top performers. Note **consistency**:
does one or two content types dominate (a repeatable format) or is the
mix scattered (no clear content identity)?

**Aesthetic style — pull it explicitly, don't assume it's covered by
content type.** "What does the content look like" is a different
question from "what kind of content is it." Pull `COMPOSITION_STYLE`,
`IMAGE_CATEGORY`, and `VISUAL_REPRESENTATION` concepts per profile the
same way as above, and cross-check against each top post's
`feature.compositionStyle`/`feature.imageCategory`/
`feature.visualRepresentation`/`feature.imageAppeal` fields (already
present in the same post objects pulled for A2/B1 — no extra fetch needed
for the sanity-check layer). Report this as its own short paragraph per
brand (e.g. "close-up, flat-lay product photography" vs "lifestyle/
in-context shots" vs "video-led demonstrations") — don't fold it silently
into the content-type read, since a reader asking specifically about
aesthetic style needs it named as its own finding.

**Main products — always call out explicitly, per brand, as its own
labeled deliverable.** Don't let this get buried inside general
content-audit prose. Build a per-brand top-products table or
small-multiples bar chart (same disparity rule as A5/somin-keyword-
explorer-widget — check scale before choosing shared vs per-brand axes)
titled explicitly, e.g. "**Main products mentioned per brand, last 30
days**", showing each brand's top 3-5 `MAIN_PRODUCT` values with mention
count. This is what lets the user see at a glance whether the primary
brand's product focus overlaps with competitors' or sits in a different
lane entirely.

## B2. Target audiences, pain points, and content strategies

**Non-determinism — tell the user up front, don't let it look like a bug
later.** `studies-create` regenerates its clustering fresh every call —
persona names, summaries, cluster boundaries, and even the number of
themes returned (subject to `minClusters` as a floor, not a fixed count)
can differ between two runs on identical `profileIds`, window, and
`filters`. The underlying corpus can also shift slightly between calls
since SOMIN crawls continuously, so "the same 30-day window" pulled an
hour apart isn't guaranteed to be pixel-identical either. Neither of
these is a defect in this skill's process — it's how the Perspective
Study engine works. Practical implications: (1) don't imply to the user
that re-running this skill on the same scope will reproduce the same
personas verbatim; (2) if the conversation needs to reference the same
personas again later (e.g. building B4.5 recommendations, or a follow-up
question), reuse the `studyId` already returned via `SOMIN:studies-get`,
don't call `studies-create` again — a second `studies-create` call is a
new, independently-clustered study, not a refresh of the first one; (3)
if the user explicitly asks why their personas changed from a previous
run, this paragraph is the honest answer — point them here rather than
guessing at a data or filter discrepancy first.

Commission a Perspective Study across **all profiles including the
primary brand** (not competitors-only — the brand needs its own audience
read too). Add `pain_points` alongside `persona` and `topics` — pain
points are a distinct, frequently-requested dimension (what problem/
frustration the content is addressing) and SOMIN supports it as a
first-class report type, so don't skip it by default:

```
SOMIN:studies-create({
  workspaceId, name: "<BRAND>_AUDIENCE_CONTENT_<WINDOW>", source: "PAGES",
  datePreset/startDate+endDate, profileIds: [primary + all competitors],
  maxContentItems: 150-300,
  filters: [{key: "MAIN_PRODUCT", values: [...]}],  // REQUIRED whenever Step 0 resolved a specific product scope — see below
  generationOptions: [{reportType: "persona", minClusters: 3}, {reportType: "topics", minClusters: 4}, {reportType: "pain_points", minClusters: 3}]
})
```

**Mandatory: this call's product scope must match Step 0's exactly — no
exceptions, checked before the call fires.** If the user picked a
specific product line in Step 0 (not "All products"), `studies-create`
gets the *same* `MAIN_PRODUCT` filter as every `posts-search`/
`concepts-search` call in Parts A and B1, applied at study-creation time.
This is not optional and not a "nice to have" — a study built on an
unfiltered corpus silently mixes in whatever else the workspace's
profiles post (a different product line, a different market), and every
downstream persona/topic/pain-point theme, share number, and whitespace
verdict built from it inherits that contamination. The failure is
invisible until a theme title reads suspiciously off-scope (e.g. a
"coffee machines only" run producing a theme about slushies) — by then
the study cost and the wrong numbers are already in the response.

`studies-create`'s `filters` parameter applies **one shared list across
every profile in the call** — it does not accept a different filter per
profile. When brands use different product-name vocabularies for the same
in-scope category (e.g. "Espresso Pro coffee machine" for one brand,
"Auto Barista" for another), build **one combined list that unions
every brand's in-scope `MAIN_PRODUCT` values** (pulled per-profile in
Step 0) and pass that single list. Do not narrow the filter to only the
primary brand's product names — that would silently zero out
competitors' in-scope content instead of just excluding their out-of-scope
lines.

Before sending the `studies-create` call, state the check explicitly in
your working notes: "Product scope = [X]; filter values = [the combined
list]; applies to profiles [...]." If Step 0 resolved "All products,"
state that explicitly instead and proceed unfiltered — that's a
deliberate scope, not a gap.

If a study is ever produced from this step without following this check,
and a later look at the results discloses off-scope themes, treat it as
this skill's central failure mode (see `failure-modes.md`) — the fix is
to rebuild the study with the filter, restate the corrected scope to the
user, and rebuild everything downstream that depended on the contaminated
study.

Wait ~75-90s, then:

```
SOMIN:studies-get({studyIds: [...], reportTypes: ["persona", "topics", "pain_points"]})
```

`persona` themes = target audiences (per-profile `metrics` shows who owns
which audience). `topics` themes = content strategies/product-focus
clusters — this is also where **repeated narratives** live (a `topics`
theme's `summary` describes the recurring story/angle, so when the user
specifically asks about "narratives," pull the read from here rather than
treating it as a separate study). `pain_points` themes = the problems/
frustrations content addresses per brand. Capture `id`, `title`,
`summary`, `sampleSize`, and per-profile `total`/`total_engagement` for
each theme across all three report types; compute engagement-per-post
yourself.

**Shared audiences — state it as its own number, not just implied by the
persona cards.** For each persona theme, if the primary brand and at
least one competitor both have MEDIUM/HIGH share, that persona is a
genuinely *shared* audience — call this out explicitly in prose (e.g.
"Brand X and Competitor Y both meaningfully serve the [persona name]
audience") rather than leaving the reader to infer overlap from two
side-by-side percentage bars.

## B3. Performance ranking — this is the point, not an afterthought

Listing the themes that exist isn't the deliverable — which ones actually
**perform** is. For every `topics` theme, compute both:

- **theme-level engagement-per-post** = theme's combined `total_engagement`
  ÷ combined `total` posts across all brands (says how strong the theme
  is overall)
- **per-brand engagement-per-post within that theme** (says who's winning
  inside it — already captured in B2's per-profile metrics)

Rank themes by theme-level engagement-per-post and render this as its own
explicitly-titled visualization (e.g. "**Content theme performance —
engagement per post, last 30 days**") — a horizontal bar chart, one bar
per theme, sorted descending, with the dominant brand named directly in
the label or a data callout (not left for the reader to cross-reference
against the card grid). Check the scale-disparity rule (5x threshold →
small multiples) before choosing shared-axis vs small multiples. Make
each bar hoverable to a real example-post popover per
`somin-keyword-explorer-widget`'s hover-popover standards (pull the
theme's top post via `clusterIds`-filtered `posts-search`, or a specific
brand's top post within the theme when that's the story). This chart is
mandatory alongside the persona/topic card grids in B4, not a replacement
for them — the cards show composition (who's present), the chart shows
performance (what's winning).

Cross-reference against B1's content-type/tone read and the main-products
breakdown: does the top-performing theme match a content type and product
the brand already produces, or is it something only a competitor does?

## B4. Visualize — embedded card widget (self-contained)

Render personas as **persona cards**, topics as **signal cards**, and
pain points as a third **signal card grid** (same visual pattern as
topics — a problem/frustration is a signal, not a persona), using the
same normalized-JSON approach as the keyword widget. This skill is
self-sufficient for that rendering — build one card-grid widget inline
(card per theme: title, one-line summary, per-brand share bars, an
expandable detail body) with the same escaping, colour and popover rules
as `somin-keyword-explorer-widget`. If a card-grid template skill happens
to be installed, you may reuse its CSS/JS instead.
Normalize per-profile `metrics` into 0-100 percentage bars with `count`,
populate `refs` with the theme/study IDs, and add a real example-post
link inside each card's detail/accordion body per the hover-popover
standards in `somin-keyword-explorer-widget`.

**Every card grid gets its own explicit title line, same as A5's
charts/clouds — no exceptions.** Card grids are just as easy to mistake
for one another as two untitled charts, and "here are the personas"
followed later by "here are the topics" with no bolded header in between
is exactly the ambiguity the mandatory-titling rule was written to
prevent — it applies here too, not just to charts and clouds. Before the
personas `visualize:show_widget` call, write a title stating the category
and window, e.g. "**Target audience personas — [brand] vs [competitors],
last 3 months**"; before the topics call, "**Content strategy themes —
[brand] vs [competitors], last 3 months**"; before the pain-points call,
"**Pain points addressed — [brand] vs [competitors], last 3 months**".
Call `visualize:show_widget` per grid (personas, then topics, then pain
points), with the title + a line of prose in between each, never two card
grids back to back with no title separating them.

## B4.5. Recommended strategies — explicit deliverable, not folded into B5's verdict table

Don't let "recommended actions" live only as one terse cell per row
inside the B5 whitespace table — that's too easy to skim past. Once the
verdicts are set, write a short, separate **Recommended strategies**
section (plain prose, a few bullets) that turns the CONTESTED/BLOCKED/
stronghold pattern into concrete next moves the user could actually act
on: which lane to defend and how, which competitor-owned lane to avoid
entering without a real differentiator, and — if a genuine gap surfaced —
what a first test post in it might look like. Ground every recommendation
in the specific themes/personas and numbers already established; don't
introduce generic marketing advice that isn't traceable back to this
run's data. If the user wants this expanded further (a content calendar,
specific creative concepts, timing/moment recommendations), that's
downstream of this skill — point to whichever of **content-calendar-
build**, **moment-generation**, or an insight-creation skill is available
in this environment, rather than trying to build it here.

## B5. Forward-looking recommendations — scoped whitespace read

This step assumes the user already has the **whitespace-analysis** skill
(don't re-derive its rubric here — call into it) but only apply the
**audience whitespace** and **content whitespace** portions of that
rubric, not a full three-cohort external-audience-proxy build:

- Treat the primary brand's persona/topic share (from Step B2's study,
  per-profile `metrics`) as the **brand** cohort and the combined
  competitor shares as the **competitor** cohort. There is no separate
  audience-proxy cohort in this skill's default flow, so this is
  whitespace-analysis's **two-cohort PARTIAL mode**: you may **not** emit
  a WHITESPACE verdict (that requires a verified audience-directed-content
  signal). The strongest available verdict is **POSSIBLE WHITESPACE —
  UNVERIFIED** where brand and all competitors are LOW on a theme that
  still has real audience engagement behind it (per the study's
  `total_engagement`).
- For themes where brand is LOW and competitors are MEDIUM/HIGH, apply
  CONTESTED/BLOCKED per the rubric — never mislabel a competitor-owned
  theme as open ground.
- Output: a short verdict per persona/topic theme (using
  whitespace-analysis's verdict vocabulary) plus one concrete recommended
  action per verdict, all traceable back to the theme IDs and study ID
  from Step B2.
- If the user wants a *true* WHITESPACE-verified read (full three-cohort
  with a real audience-proxy panel), tell them that requires running
  whitespace-analysis directly with an additional audience-proxy
  workspace, rather than trying to fake it here.
