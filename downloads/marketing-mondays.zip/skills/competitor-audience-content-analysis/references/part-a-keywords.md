# Part A — Keywords

Two **separate** categories — hashtags and caption keywords. Never merge
them into one list or one visualization; they answer different questions
(what's tagged vs what's actually said). SOMIN MCP has no comment-text
endpoint (only a comment *count*), so there is no comment-keyword category
by default — see A3 for how to handle this if the user specifically asks
about comments. The visualization-format question (A5) **must** be
prompted before A1 begins.

## A1. Hashtags

```
SOMIN:concepts-search({workspaceId, profileIds: [one profile at a time], concept: "HASH_TAGS", startDate: WINDOW_START, endDate: WINDOW_END, platforms, source: "PAGES", limit: 50})
```

Run once per profile (including the primary brand) so each hashtag can be
attributed to a brand for coloring. This gives usage-count volume per
hashtag — a tagging-behavior signal, not a performance signal by itself.
**`limit` is fixed at 50, every run, every profile — never a range.** A
range like "30-50" leaves the exact cutoff to whichever number the model
happens to pick that run, which alone can change which hashtags clear the
per-brand floor; pinning it to one number removes that as a variable.

## A2. Caption keywords

SOMIN doesn't expose a "caption keyword" concept endpoint directly, but
each post returned by `posts-search` carries a platform-extracted
salient-terms field at `creatives[].texts[].textAttention` (alongside the
full caption in `.content`). Pull top posts per profile:

```
SOMIN:posts-search({workspaceId, profileIds: [one profile], startDate: WINDOW_START, endDate: WINDOW_END, platforms, source: "PAGES", sortBy: "total_engagement", pageSize: 30})
```

`sortBy`, `pageSize`, `source`, and the literal window are fixed values,
every run — never vary them run to run, since any change to which posts
get pulled changes the keyword set downstream. Then always extract, per
post: `id`, `postDate`, `sourceType`, `rawData.code` (Instagram permalink
slug — see below), `metrics.likesCount + metrics.commentsCount`
(engagement), `metrics.engagementRate`, and every string in
`textAttention`. Results are often too large for context — use
`scripts/extract_posts.py` (or equivalent logic) rather than pasting raw
JSON.

**Capturing `rawData.code` here is mandatory and non-negotiable, not an
optional extra to add later if the popover needs it.** This is a
confirmed, previously-shipped failure mode: an earlier run of this skill
extracted engagement and `textAttention` in A2 but never pulled `id`,
`sourceType`, or `rawData.code` alongside them, so every downstream
keyword/hashtag "best post" record had no way to construct a real
permalink — the word-cloud popover rendered a "Best:" line with no link
at all. The fix is structural, not a reminder to "remember the link
later": the extraction pass must pull these four identity fields for
every post, every run, in the same pass as the engagement fields — never
as a separate follow-up step, and never only when a popover bug is
reported. When building each keyword/hashtag's `best` record (A3), attach
`link` at the same time as `engagement`/`date`/`brand` — construct it as
`https://www.instagram.com/p/{rawData.code}/` when `sourceType` is
`instagram` and `rawData.code` exists, and set `link: null` (rendered as
"No link available", never a fabricated URL) for every other `sourceType`
or a missing code. Do this once in the shared extraction pass, not
per-widget — A5's word cloud, B3's theme-performance chart, and B4's card
grids all consume the same `best` records and all inherit the same link
(or its honest absence) from this single source.

**Clean before counting — apply this exact, fixed list every run, don't
improvise additions or omissions.** Reproducibility depends on the filter
being the same set of words every time, not a judgment call remade from
scratch each run. `scripts/extract_posts.py` implements this list; the
rules it encodes:

- **Stopwords:** the, a, an, and, or, but, to, of, with, for, in, on, at,
  by, from, is, are, was, were, be, been, this, that, these, those, it,
  its, your, you, we, our, us, i, my, so, as, if, than, then, just, more,
  most, all, out, up, new, get, got, now, please
- **Giveaway/CTA mechanic words** (engagement-bait boilerplate, not
  content signal): like, tag, follow, share, win, giveaway, comment,
  enter, rules, congrats, congratulations, winner, luck, glow, click,
  link, bio, swipe, dm, repost, rt
- **`@handle` mentions** — drop any token appearing as `@word` in the
  lowercased caption. **This cannot be done by checking `textAttention`
  tokens for a literal `@` prefix — the platform strips the `@` before
  populating `textAttention`, so a handle like `@examplebranduk` surfaces as
  the bare token `examplebranduk`, indistinguishable at a glance from a real
  keyword, and a naive per-token check silently lets it through.** This is
  a confirmed, previously-shipped failure mode: an early run of this
  skill let `examplebranduk`, `competitorc`, `creatorhandle`, and four other
  handles into the caption-keyword tables, and `examplebranduk` came out as
  the primary brand's own #1 term by average engagement purely because it's the
  brand's own self-tag, not organic vocabulary. The fix is mandatory and
  must run every time, on the full caption text, not on `textAttention`:
  1. For every post, regex-extract every `@word` from the **raw,
     unstripped** `creatives[].texts[].content` (not `textAttention`):
     `re.findall(r'@(\w+)', caption.lower())`.
  2. Normalize each extracted handle by stripping leading/trailing
     underscores (`re.sub(r'^_+|_+$', '', handle)`) — Instagram handles
     starting with `_` (e.g. `@_creatorhandle`) get shortened by the
     platform's own extraction, so `textAttention` may surface it as
     `creatorhandle` without the underscore; comparing raw strings misses
     this.
  3. Build one normalized mention set across **all posts, all brands, in
     the whole corpus** (not per-post, not per-brand) before touching
     `textAttention` — a handle only needs to appear as `@word` once
     anywhere in the pulled data to be excluded everywhere.
  4. When building the caption-keyword table, drop any `textAttention`
     token whose normalized form (same underscore-strip) is in that
     mention set, in addition to the stopword/CTA/all-caps filters above.

  This step is not optional and not "check if it looks like a handle" —
  it is a required, scripted cross-reference against the real caption
  text, every run, before any keyword table is built or rendered.
- **All-caps acronym noise ≤4 characters** (e.g. NINE, WIN, TAG) — drop
  tokens ≤4 chars that appear in all-caps in the original
  (pre-lowercasing) caption text

Group case-insensitively (Iced/iced/ICED → one entry). **Casing tie-break
(fixed, deterministic):** display the casing used in the
highest-engagement post containing the word; if engagement ties, use the
casing from the chronologically earliest post among the tied set. Only
report words appearing in ≥2 posts as a "repeated" signal — a single
viral post's one-off phrasing isn't a strategy.

If the user specifically asks about comments or comment keywords (not
part of the default flow): explain that SOMIN MCP has no comment-text
field (only `metrics.commentsCount`), so the category can't be produced
from this data, and offer `commentsCount` as an engagement/discussion-
volume proxy instead. If they have a separate social-listening or
comment-export connector, ask whether they want to route this through
that instead.

## A3. Volume, performance, and engagement per keyword

For every keyword (hashtag or caption keyword) surviving the A1/A2
filters, compute per brand:

- **volume** = count of posts containing it
- **engagement** = total `likesCount + commentsCount` across those posts
- **performance** = engagement ÷ volume (avg per post) — this is what
  separates "used often" from "actually works"

Rank by performance, not volume, when answering "what's performing best"
— a word used once on a viral post will always show a bigger total than a
word used ten times at moderate engagement, but the average is the more
honest comparison.

## A4. Cross-competitor pattern read

With the per-brand keyword tables assembled, write the actual analytical
read — grounded only in what's in the data, never invented:

- Which brand's keyword strategy is product-name-led vs occasion/
  lifestyle-led vs flavour/seasonal-led
- Where the primary brand's keyword presence is thin relative to
  competitors (e.g. near-zero hashtag volume while a competitor has 50+)
  — state this as an observed gap, not as a prescriptive "you should,"
  since that's Part B/whitespace's job
- Where the same word appears across multiple brands (shared vocabulary —
  the category's default language) vs where it's exclusive to one (a
  brand's actual point of difference)

## A5. Visualize — ask the format, then render ONE combined interactive widget

Ask via `ask_user_input_v0`, every run: "How should I visualize the
keywords?" — options: `Word cloud`, `Bar chart`, `Table`. Never assume a
format from a prior run in this conversation — ask fresh each time, since
a smoke-test or re-run may deliberately want a different format on the
same data.

**Hashtags and caption keywords render inside ONE combined interactive
widget, not two.** This is exactly the shape the `somin-keyword-explorer-
widget` skill exists for — read its SKILL.md and use its canonical
templates. That skill covers:

- the three-button-row contract (category / metric / brand)
- the per-brand floor guarantee
- brand color coding (including checking for a brand-guideline skill)
- the canonical word-cloud/bar-chart/table implementations
- hover-popover standards

**Hashtags need one extra step to unlock the same three metrics.**
`concepts-search` with `HASH_TAGS` only returns usage counts, not
per-hashtag engagement — so don't leave the hashtag side of the widget
stuck on volume-only while the caption-keyword side gets all three.
Derive hashtag-level engagement by cross-referencing: for each post
already pulled in A2 (which has the full caption text), extract every
`#word` occurring in the caption (`re.findall(r'#(\w+)', caption.lower())`),
intersect against the real hashtag list from `concepts-search`, and
attribute that post's engagement to each hashtag it contains — this gives
the same volume/total_engagement/avg_engagement/example-post shape as
caption keywords, so both sides of the widget can share the identical
interactive template. This surfaces real signal a volume-only view hides
— e.g. a hashtag used only twice but driving one viral post will jump to
the top under "Total engagement" even though it looks negligible under
"Volume."

Build the `DATA` object the widget skill expects as
`{category: {brand: [{term, volume, engagement, avg_engagement, best:
{brand, date, engagement, link, sourceType}}]}}`, using the `best` records
built in A2/A3, and hand off to `somin-keyword-explorer-widget` for
rendering.

## A6. Reproducibility — what must be identical across independent runs, and what's allowed to differ

Two independent runs of Part A over the **same literal
`WINDOW_START`/`WINDOW_END`, same product scope, same brand set** should
produce the **same** hashtag list, the same caption-keyword list, and the
same volume/total-engagement/avg-engagement numbers for each — because
every input to Part A (window, limit, pageSize, sortBy, the fixed
stopword/CTA lists, the casing tie-break rule) is now pinned to a fixed
value rather than a range or a judgment call. If two such runs disagree,
it's a real bug in how the skill was followed, not expected variance, and
should be traced to one of these before concluding the data itself
changed:

- A rolling `datePreset` used somewhere instead of the literal
  `WINDOW_START`/`WINDOW_END` (check every `concepts-search`/
  `posts-search` call in the run)
- The A1 hashtag `limit` wasn't pinned at exactly 50
- The A2 `pageSize`/`sortBy`/`source` weren't exactly `30`/
  `"total_engagement"`/`"PAGES"`
- The stopword/CTA/acronym filters in A2 weren't applied as the fixed
  list verbatim (an ad-hoc addition or omission)
- The casing tie-break wasn't applied deterministically
- The per-brand floor rule (top ~5 brand-exclusive words) was computed
  against a different metric than the one actually reported

**What's legitimately allowed to differ between two runs, and should be
stated as such rather than treated as a bug:** the underlying SOMIN corpus
itself changing between runs (new posts published, edits/deletions on the
platform) if any wall-clock time passed between them, or the user
genuinely changing the window/product/brand inputs. When reporting a
repeat run, say explicitly whether inputs were held identical to a prior
run, and if so, whether the output matched — that's the reproducibility
statement itself, not something to leave implicit.

**The most common false-positive "bug" report: two runs both called
"last 30 days" but not actually the same window.** Because Step 0
re-resolves the relative label to literal dates fresh at the moment each
run's user answers the time-range question, two runs of "last 30 days"
separated by any wall-clock gap — even a few hours, even one day —
resolve to two different `WINDOW_START`/`WINDOW_END` pairs by
construction. This is **not** a rolling-`datePreset` bug (Step 0's
literal-date rule was followed correctly in both runs) and it is **not**
unexplained variance — it's two genuinely different inputs that happen to
share the same relative label. Don't diagnose divergent keyword lists
from two such runs as a reproducibility failure; instead, name the actual
literal windows each run used and show that they differ. Check this
first, since it's the cheapest explanation to rule in or out (just
compare the two logged `WINDOW_START`/`WINDOW_END` lines from each run's
first-run confirmation) before assuming something deeper broke.

**Paired reproducibility test protocol — run this explicitly whenever the
user wants to verify determinism (not just when something looks wrong):**

1. Fix one literal `WINDOW_START`/`WINDOW_END` pair up front — don't let
   either run independently resolve "last 30 days"; state the literal
   dates to the user before either run starts and pass them identically
   into both.
2. Run Part A (A1–A5) twice back to back, same brand set, same product
   scope, same literal window, same visualization format.
3. Diff the two runs' raw keyword tables (word, volume, total_engagement,
   avg_engagement per brand) — not just the rendered widget — since two
   visually similar clouds can still hide a numeric mismatch.
4. Report the result explicitly as a pass/fail statement: "Two runs over
   the identical literal window `WINDOW_START`–`WINDOW_END` produced
   [identical / different] keyword tables." If different, trace it
   against the bullet list above (datePreset leakage, unpinned
   `limit`/`pageSize`/`sortBy`, filter-list drift, casing tie-break,
   floor-rule metric mismatch) rather than concluding "the data changed"
   — the corpus itself does not change results in a true same-window,
   back-to-back test unless posts were actually published/edited/deleted
   on the platform in the seconds between the two calls, which is rare
   enough to flag as its own anomaly if it's the actual cause.
