# Reference run — locked expected output structure

A full run on a home-appliance brand's UK workspace (coffee/espresso machines only,
last 6 months, three competitors; names withheld)
produced the structure below. **Treat this as the canonical shape for
every future run of this skill** — same deliverable sequence, same
visualization types, same level of prose between them — substituting only
the real brand names, numbers, and findings for the current run.
Deviating from this shape (skipping a deliverable, collapsing two into
one, or reordering) is a regression unless the user explicitly asked for
a shorter run.

## Elicitation sequence (before any deliverable)

1. Resolve workspace/profiles, state the brand/competitor split in one
   line.
2. Pull `MAIN_PRODUCT` per profile, then ask product scope via
   `ask_user_input_v0` with real product names as options (per Step 0) —
   wait for the answer before proceeding.
3. Confirm resolved scope in one line (brand split + literal window +
   product scope).
4. Ask the Part A visualization-format question via `ask_user_input_v0` —
   offer word cloud / bar chart / table, and honor an "all three, each as
   if requested individually" answer by building all three at full
   quality (not a condensed hybrid) — per A5.

## Part A deliverables, in this order

1. One combined interactive word-cloud widget (`visualize:show_widget`) —
   category/metric/brand button rows, hover-popover with linked example
   post, brand-floor guarantee — per `somin-keyword-explorer-widget`'s
   canonical reference implementation. One line of prose immediately
   before it naming what it compares.
2. One interactive bar-chart widget — per-brand small multiples (one mini
   horizontal bar chart per brand in a grid), category toggle
   (hashtags/captions), ranked by avg engagement per post, sample size
   `(n=N)` in every bar label. One line of prose before it.
3. Two markdown tables in the response text (not widgets) — one for
   hashtags, one for caption keywords — columns `Brand | Keyword | Volume
   | Total eng. | Avg eng./post`, top 3-5 rows per brand. These satisfy
   the "table" format request; don't substitute a third widget for them.

## Part B deliverables, in this order, each with its own one-line title/intro and its own chart — never combined into a single mega-widget

1. Share-of-voice engagement chart (`chart_display_v0`, bar) — one bar
   per brand, % of sampled engagement. Immediately follow with a one-line
   caveat if any brand hit the `posts-search` page cap (state which
   brands, and that their true volume is a floor, not exact).
2. Content-volume-by-platform chart (`chart_display_v0`, grouped bar) —
   platforms on x-axis, one series per brand.
3. Shares summary — markdown table (`Brand | Facebook shares (n) | TikTok
   shares (n)`) plus one line noting Instagram's `sharesCount` is always
   null and is excluded.
4. Content audit — short prose paragraph per brand covering dominant
   content types, tone of voice, composition style (from the already-
   pulled `feature` fields, no extra tool calls needed beyond A2/B0.5's
   pulls).
5. Persona card widget (`visualize:show_widget`, inline card-grid
   persona template) — one card per persona theme, per-brand share bars.
   One line of prose before it calling out the sharpest gap or overlap.
6. Topic/content-strategy card widget (same template, signal variant) —
   one card per topic theme.
7. Topic performance bar chart (`chart_display_v0`) — engagement-per-post
   per theme, labeled with the dominant brand per theme in the axis
   labels. Immediately follow with a caveat if any bar is driven by a
   thin sample (state the post count and flag it as not yet a proven
   pattern).
8. Pain-point card widget (same template, signal variant).
9. Whitespace verdict table (markdown: `Theme | Brand share | Verdict |
   Read`) using the rubric appropriate to however many cohorts were
   actually run (two-cohort brand-vs-combined-competitor CONTESTED/absent
   read if no separate audience-proxy cohort exists this run — never
   claim WHITESPACE from two-cohort data, per `failure-modes.md`).
10. A short "Recommended strategies" bullet list (4-6 bullets) grounded
    in the specific numbers already surfaced above — never generic
    marketing advice untethered from this run's data.

## Tone and pacing rules demonstrated in the reference run

- Every widget gets one short sentence of framing immediately before the
  tool call, in-conversation — never a paragraph, never restating what
  the widget already shows once it renders.
- Numbers cited in prose must match numbers visible in the widget/table
  right above or below them — don't introduce a stat that only lives in
  prose.
- Caveats (page-cap floors, thin-sample warnings, Instagram shares-null)
  are stated once, plainly, right next to the number they qualify — not
  collected into a separate "limitations" section at the end.
- The final message ends with the recommended-strategies bullets and,
  optionally, a one-line offer to extend into a calendar/deck/deeper
  dive — no restating of the whole analysis.
