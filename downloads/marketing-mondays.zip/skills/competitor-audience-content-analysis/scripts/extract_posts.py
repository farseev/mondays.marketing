#!/usr/bin/env python3
"""
extract_posts.py — A2 post extraction and caption-keyword cleaning.

Implements the fixed, reproducible rules from
references/part-a-keywords.md, section A2, so they don't get
reconstructed from memory (and drift) on every run:

  - Extracts the mandatory identity fields per post (id, postDate,
    sourceType, rawData.code, engagement, engagementRate, textAttention)
    so every downstream "best example post" record can build a real
    permalink instead of a broken/missing link.
  - Applies the fixed stopword / CTA-mechanic / all-caps-acronym filters.
  - Cross-references the RAW caption text (not textAttention) for
    @handle mentions, normalizes underscore-stripped handles, and drops
    any textAttention token that matches a mention anywhere in the whole
    pulled corpus — this is the hardened fix for the "brand's own handle
    shows up as a top keyword" failure mode.
  - Applies the deterministic casing tie-break (highest-engagement post's
    casing wins; ties go to the chronologically earliest post).
  - Only reports terms appearing in >= 2 posts as "repeated" signal.

Usage:
    Feed this the raw JSON list of post objects returned by
    SOMIN:posts-search for ONE profile (already the shape documented in
    A2 — do not pre-filter or pre-flatten it).

    from extract_posts import extract_and_clean
    keywords = extract_and_clean(posts_json, brand="Example Brand UK")

Do not paste raw posts-search JSON into the conversation — call this
(or equivalent logic) on it first and work from the compact output.
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "to", "of", "with", "for", "in",
    "on", "at", "by", "from", "is", "are", "was", "were", "be", "been",
    "this", "that", "these", "those", "it", "its", "your", "you", "we",
    "our", "us", "i", "my", "so", "as", "if", "than", "then", "just",
    "more", "most", "all", "out", "up", "new", "get", "got", "now",
    "please",
}

CTA_WORDS = {
    "like", "tag", "follow", "share", "win", "giveaway", "comment",
    "enter", "rules", "congrats", "congratulations", "winner", "luck",
    "glow", "click", "link", "bio", "swipe", "dm", "repost", "rt",
}

MENTION_RE = re.compile(r"@(\w+)")
HASHTAG_RE = re.compile(r"#(\w+)")
UNDERSCORE_TRIM_RE = re.compile(r"^_+|_+$")


def _strip_underscores(handle: str) -> str:
    return UNDERSCORE_TRIM_RE.sub("", handle)


def build_mention_set(posts: list[dict[str, Any]]) -> set[str]:
    """Build one normalized @handle mention set across the WHOLE corpus,
    from the raw unstripped caption text — not textAttention, which has
    the '@' already stripped by the platform. Call this once across all
    posts, all brands, before filtering any single profile's keywords."""
    mentions: set[str] = set()
    for post in posts:
        for text_obj in _iter_texts(post):
            caption = (text_obj.get("content") or "").lower()
            for handle in MENTION_RE.findall(caption):
                mentions.add(_strip_underscores(handle))
    return mentions


def _iter_texts(post: dict[str, Any]):
    for creative in post.get("creatives") or []:
        for text_obj in creative.get("texts") or []:
            yield text_obj


def _post_identity(post: dict[str, Any]) -> dict[str, Any]:
    """The four mandatory identity fields, pulled in the same pass as
    engagement — never as a separate follow-up step."""
    metrics = post.get("metrics") or {}
    raw_data = post.get("rawData") or {}
    likes = metrics.get("likesCount") or 0
    comments = metrics.get("commentsCount") or 0
    return {
        "id": post.get("id"),
        "postDate": post.get("postDate"),
        "sourceType": post.get("sourceType"),
        "code": raw_data.get("code"),
        "engagement": likes + comments,
        "engagementRate": metrics.get("engagementRate"),
    }


def build_permalink(identity: dict[str, Any]) -> str | None:
    """Construct a real permalink only when the platform supports it
    directly from data already in hand. Never fabricate a URL."""
    if identity.get("sourceType") == "instagram" and identity.get("code"):
        return f"https://www.instagram.com/p/{identity['code']}/"
    return None


def _is_allcaps_short_acronym(raw_caption: str, token: str) -> bool:
    """Drop tokens <=4 chars that appear in ALL CAPS in the ORIGINAL
    (pre-lowercasing) caption text."""
    if len(token) > 4:
        return False
    return re.search(r"\b" + re.escape(token.upper()) + r"\b", raw_caption) is not None


def extract_and_clean(
    posts: list[dict[str, Any]],
    brand: str,
    mention_set: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Extract and clean caption keywords for ONE profile's posts.

    `mention_set` should be built once via build_mention_set() across the
    FULL multi-brand corpus and passed in here — a handle only needs to
    appear as @word once anywhere in the whole pulled dataset to be
    excluded everywhere, not just within this one profile's posts.

    Returns a list of term records:
        {term, volume, engagement, avg_engagement, best: {brand, date, engagement, link, sourceType}}
    ready to feed into the DATA object somin-keyword-explorer-widget expects.
    """
    if mention_set is None:
        mention_set = build_mention_set(posts)

    # term -> list of (post_identity, casing_seen)
    occurrences: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for post in posts:
        identity = _post_identity(post)
        link = build_permalink(identity)
        raw_captions = [t.get("content") or "" for t in _iter_texts(post)]
        raw_caption_joined = " ".join(raw_captions)

        seen_terms_this_post = set()
        for text_obj in _iter_texts(post):
            for token in text_obj.get("textAttention") or []:
                lowered = token.lower()
                if lowered in STOPWORDS or lowered in CTA_WORDS:
                    continue
                normalized_handle = _strip_underscores(lowered)
                if normalized_handle in mention_set:
                    continue
                if _is_allcaps_short_acronym(raw_caption_joined, lowered):
                    continue
                if lowered in seen_terms_this_post:
                    continue  # count each post once per term
                seen_terms_this_post.add(lowered)
                occurrences[lowered].append(
                    {
                        "display": token,
                        "engagement": identity["engagement"],
                        "date": identity["postDate"],
                        "link": link,
                        "sourceType": identity["sourceType"],
                        "brand": brand,
                    }
                )

    results = []
    for term, occs in occurrences.items():
        if len(occs) < 2:
            continue  # only repeated (>=2 posts) signal counts
        volume = len(occs)
        total_engagement = sum(o["engagement"] for o in occs)
        avg_engagement = total_engagement / volume

        # Casing tie-break: highest-engagement post wins; ties -> earliest date.
        best_casing_occ = sorted(
            occs, key=lambda o: (-o["engagement"], o["date"] or "")
        )[0]

        # Best example post for the popover = highest engagement occurrence.
        best_occ = max(occs, key=lambda o: o["engagement"])

        results.append(
            {
                "term": best_casing_occ["display"],
                "volume": volume,
                "engagement": total_engagement,
                "avg_engagement": avg_engagement,
                "best": {
                    "brand": best_occ["brand"],
                    "date": best_occ["date"],
                    "engagement": best_occ["engagement"],
                    "link": best_occ["link"],
                    "sourceType": best_occ["sourceType"],
                },
            }
        )

    return results


def extract_hashtag_engagement(
    posts: list[dict[str, Any]],
    hashtag_volume_list: list[dict[str, Any]],
    brand: str,
) -> list[dict[str, Any]]:
    """Derive per-hashtag engagement/avg_engagement/best by cross-
    referencing #word occurrences in already-pulled post captions against
    the real hashtag list from concepts-search(HASH_TAGS). This is the
    'extra step' A5 requires so hashtags get the same three metrics
    (volume/total/avg) as caption keywords instead of staying volume-only.
    """
    known_hashtags = {h["term"].lower(): h for h in hashtag_volume_list}
    per_hashtag: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for post in posts:
        identity = _post_identity(post)
        link = build_permalink(identity)
        for text_obj in _iter_texts(post):
            caption = (text_obj.get("content") or "").lower()
            for tag in set(HASHTAG_RE.findall(caption)):
                if tag not in known_hashtags:
                    continue
                per_hashtag[tag].append(
                    {
                        "engagement": identity["engagement"],
                        "date": identity["postDate"],
                        "link": link,
                        "sourceType": identity["sourceType"],
                        "brand": brand,
                    }
                )

    results = []
    for tag, occs in per_hashtag.items():
        volume = known_hashtags[tag].get("volume", len(occs))
        total_engagement = sum(o["engagement"] for o in occs)
        avg_engagement = total_engagement / len(occs) if occs else 0
        best_occ = max(occs, key=lambda o: o["engagement"]) if occs else None
        results.append(
            {
                "term": known_hashtags[tag].get("term", tag),
                "volume": volume,
                "engagement": total_engagement,
                "avg_engagement": avg_engagement,
                "best": (
                    {
                        "brand": best_occ["brand"],
                        "date": best_occ["date"],
                        "engagement": best_occ["engagement"],
                        "link": best_occ["link"],
                        "sourceType": best_occ["sourceType"],
                    }
                    if best_occ
                    else None
                ),
            }
        )
    return results


if __name__ == "__main__":
    import json
    import sys

    if len(sys.argv) != 3:
        print("Usage: extract_posts.py <posts.json> <brand name>", file=sys.stderr)
        sys.exit(1)

    with open(sys.argv[1], encoding="utf-8") as f:
        posts_data = json.load(f)

    cleaned = extract_and_clean(posts_data, brand=sys.argv[2])
    cleaned.sort(key=lambda r: r["avg_engagement"], reverse=True)
    print(json.dumps(cleaned, indent=2, ensure_ascii=False))
