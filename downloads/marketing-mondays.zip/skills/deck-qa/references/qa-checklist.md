# QA Checklist — Core (8 families) + Conditional Sections

Run the **core** section on every deck. Run each **conditional** section whose trigger is met. Tick every item against the rendered deck, the deck's source data, and the brand spec.

---

## CORE — runs for every deck

### C1 · Summary-vs-detail consistency
Summary, one-page-read, headline and "key numbers" slides repeat figures shown in full on a detail slide. They must agree.
- [ ] Identify every slide printing a headline statistic (one-page reads, "three numbers", footprint stats, hero figures).
- [ ] For each figure, find the detail slide that derives it (chart, verdict map, cross-check table).
- [ ] Confirm the numbers match exactly. A mismatch = a stale literal on the summary slide.
- [ ] Confirm the caption/label on the summary slide describes the same thing the detail slide shows.

### C2 · Every figure, count, name traces to source
- [ ] Every printed count — studies/analyses, posts, weeks, items, propositions, competitors — matches the source registry/data.
- [ ] Persona/audience names match the source persona theme titles exactly.
- [ ] Character names, story titles, angle names, product names match the source records.
- [ ] Competitor/brand names are the correct set for THIS deck.
- [ ] No figure is carried from a template or a sibling deck.

### C3 · No foreign-market / foreign-client leftovers
- [ ] No competitor, brand, ambassador, person, place, city or country on any slide belongs to a different market or client.
- [ ] No phrasing names the wrong market's theme/territory (watch closing slides especially).
- [ ] Source/citation lines cite THIS deck's IDs, not another deck's.
- [ ] Internal slide-numbering / section labels were updated, not left from a source deck.

### C4 · Chart integrity — label matches the data
The label, the colour and the line/bar must all agree. A trend status is a *claim about the data* and must be true of the line it sits on.
- [ ] For every trend/line chart: each series' status label (Rising / Falling / Sustained / etc.) actually matches the direction of that line. A "Rising" label on a visibly falling line is a defect.
- [ ] **Recompute every trend status from the series values, don't trust the printed word.** When the chart shows per-point values, derive the status against the rubric: SUSTAINED = mean ≥20% AND coefficient of variation <30%; RISING = monotonic up, latest highest; FALLING = monotonic/net down, latest lowest; SEASONAL = cyclic peaks-and-troughs or CV ≥30% with no monotonic trend; SINGLE-SHOT = one high window then ~0; EMERGING = absent early, present and growing late; DECAYED = was sustained, <5% in the latest 2+ windows. A high-average but volatile series (deep troughs, CV well above 30%) labelled SUSTAINED is a defect.
- [ ] **The same tension carries the same status on every slide.** A tension shown on a trend-chart slide, a movement-table slide and a divergence/narrative slide must read identically on all of them. One tension SUSTAINED on slide 9 and FALLING or SEASONAL on slide 11 is a cross-slide contradiction — reconcile all occurrences to the value-derived status.
- [ ] Every data label value matches the underlying data point.
- [ ] Legend entry colours match the series they name; the colour chip beside a status row matches that series' line on the chart.
- [ ] Axis maximum accommodates the largest value in the data plus headroom; no bar or line clips, flattens, or touches the chart ceiling. Axis minimum appropriate (usually 0 for share charts).
- [ ] The axis maximum is computed from the data (largest series value + ~15% headroom), NOT a hardcoded literal. A fixed axis max typed into the builder is a defect class in itself: it fits the deck it was written for and silently clips the next deck whose data runs higher. If the builder hardcodes the axis max, flag it even when the current data happens to fit.
- [ ] **The chart is readable on its own.** A first-time reader must be able to read a value off every chart without external context. Either the axis is visible and labelled, or each data point carries a value label. A line/bar chart with no axis AND no data labels — just shapes the reader cannot quantify — is a defect, even if the lines are technically accurate. This applies especially to small-multiple panels: if four mini-charts share a hidden axis, every panel needs point labels so levels can be read and compared across panels.
- [ ] Every delta or "X → Y" arrow notation shows the series' real start and end. A second value that is a mid-series peak, not the endpoint, is a misrepresentation — it must be relabelled "X → end · peak Y".

### C5 · References and links
The brief required every SOMIN/source insight to be referenced by its URL, and post references to resolve to the specific post.
- [ ] Every slide that cites an insight/study/story/post carries the required reference.
- [ ] Each reference is an actually-clickable hyperlink in the PPTX — not plain text that looks like a URL. Verify in the raw file (the `.pptx` is a zip — check `ppt/slides/_rels/slideN.xml.rels` for `Target="https://..."` relationships); teal underlined styling alone is NOT proof of a link.
- [ ] **The audit-trail / sources slide has every ID clickable.** If a slide says "every claim traces to a SOMIN ID", each workspace, study, whitespace, story, **proposition AND product** ID on it must be an individual hyperlink to its SOMIN record — not styled-but-dead text. Watch the easily-missed classes: proposition-range and product IDs are often left as plain text while workspaces/studies/stories are linked. If even one ID class is unlinked, either link it or scope the slide caption to what is actually clickable — a blanket "every ID is a live link" caption above any plain-text ID is a defect. SOMIN URL patterns: workspace `cloud.somin.ai/app/a/{wsId}`, study `cloud.somin.ai/app/a/{wsId}/studies/{studyId}`, story `cloud.somin.ai/app/inspire/insights/story/{storyId}`; propositions and products have no per-object URL — link them to their owning workspace.
- [ ] **The footer wordmark/URL is a live link on every slide.** If the page footer shows "somin.ai" (or the platform URL), it must be a clickable hyperlink to the platform, not decorative text — on every slide, not just the cover.
- [ ] Every link resolves to THIS deck's correct workspace/study/story/post resource — no foreign-market IDs.
- [ ] Where a post is referenced, the link points at that specific post (and its visual is shown where layout allows).
- [ ] The audit-trail / sources slide lists IDs matching the data actually used.

### C6 · Brand identity
- [ ] The logo / wordmark is rendered in the correct colours per the brand spec. For the SOMIN "S O MIN" wordmark: "S O" in teal #2DBF9C, "MIN" in #16201F on light surfaces / #FFFFFF on dark — never one flat colour.
- [ ] The wordmark spacing is correct: letters are visibly tracked/airy (not tight), AND there is a distinct gap between the "S O" and "MIN" tonal groups. A wordmark set tight, jammed together, or rendered as "SOMIN" without spaces is a defect even if the colours are right. Check on a light slide AND a dark slide.
- [ ] Logo placement and clear space follow the brand spec.
- [ ] The palette on every slide is the brand palette; no off-spec colours.
- [ ] Colour-coding is consistent: every recurring category (e.g. each whitespace verdict, each pillar) uses ONE colour and ONE label everywhere it appears across the deck. The same category never changes colour between slides; two categories never share a colour.
- [ ] Category labels are unambiguous — the label states what the category is, and the legend defines it.

### C7 · Layout and rendering
- [ ] No text overflows its box, overlaps another element, or runs past the slide edge.
- [ ] No headline or label is truncated.
- [ ] Nothing collides with the reserved footer band — the footer text and page-number strip at the slide bottom. Captions, footnotes, chart axis labels and the last row of any card grid must clear it.
- [ ] No slide is empty or padded with filler; where two thin slides cover one idea, they are combined (per brief intent).
- [ ] Slide count is as expected; no blank or duplicated slides.

### C8 · Data-object fidelity
When the deck presents a structured platform object (a SOMIN proposition, study, moment, persona), it must show that object's REAL content.
- [ ] Each presented object's fields are the actual fields from the platform record (e.g. a proposition's own defining fields), retrieved from the API — not invented, not paraphrased into something the object does not say.
- [ ] A proposition is shown with its real **name (the focus line)** and **insight tagline** — not as a bare "Proposition {id}" reference. The ID is supporting metadata; it never stands in for the proposition's content.
- [ ] The deck does not silently drop an object's defining fields. If only a subset is shown, the subset still represents the object faithfully and the choice is deliberate.
- [ ] No slide presents made-up content in place of a real object the platform can return.

### C9 · Tone
- [ ] Language is the register a professional marketing manager at an MNC would be comfortable with — no empty buzzwords, no hype filler.
- [ ] **Headlines state the finding, not a consultant-register placeholder.** Every slide headline should say what the slide actually shows, in plain words. Flag headlines that lean on borrowed strategy-framework jargon ("where to play / how to play", "win the right to play", "unlock / unpack / double-down", "north star", "the X imperative") — these sound strategic but carry no specific finding. The test: could this headline sit on any deck about anything? If yes, rewrite it to the concrete point of THIS slide. A punchy line is fine when it states a real finding ("Brand X is loud — in the wrong room"); it fails when cleverness substitutes for substance ("Where to play, how to play — everywhere").
- [ ] On-slide labels (card eyebrows, section tags) are plain language, not framework-speak — "THE TERRITORY", not "WHERE TO PLAY"; "WHAT WE MEASURE", not "THE MEASUREMENT IMPERATIVE".

### C10 · Claim integrity — content vs audience
SOMIN detects concepts **from content** — it classifies what posts are about and what audience they were *created for*. It does NOT observe the audience. The deck's language must not claim more than was measured.
- [ ] No slide says "audience demand", "what [audience] wants", "what the audience is asking for", "what [audience] talk about", "demand-side", "consumers want", or any phrasing that asserts a measured audience desire. These are factual overclaims — FAIL.
- [ ] Content/creator/influencer cohorts are described as **content made for** an audience ("[audience]-directed content", "what creators publish toward [audience]"), never as the audience itself or its demand.
- [ ] A whitespace "gap" is framed as a **content-supply gap** (creators publish toward a theme, the brand/category does not), not as unmet audience demand. The strategic conclusion may stand; the claim must be scoped to content.
- [ ] The word "audience" paired with a verb of wanting/saying/talking is only acceptable when the slide is citing a **views or engagement** figure — and even then only as reaction volume, never attributed to a specific audience.
- [ ] Chart titles, eyebrows, captions and persona slides all pass the same test — a persona is a content persona, not a measured person who "wants" things.

### C11 · Comparison-slide integrity — the columns must differ
Any slide whose job is to compare entities (markets, pillars, segments, periods) side by side must make the compared dimension genuinely vary. A comparison slide where every column says the same thing has failed at its one job.
- [ ] The hero stat / headline number is NOT identical across all columns. If three of four tiles show the same "1 of 6", that is a defect — the reader sees a layout error, not a finding. The varying dimension should be the hero number.
- [ ] All columns use the **same metric and the same unit**. A row that shows a ratio in three columns and a raw count in the fourth ("1 of 6", "1 of 6", "1 of 6", "15") is not comparable — FAIL.
- [ ] Each column's hero number traces to that entity's own source data — no invented or back-filled values to force variety.
- [ ] If a statistic genuinely IS uniform across all entities, the slide states that uniformity once as the finding (in prose or a single callout) rather than repeating N identical tiles. Uniformity stated once is insight; uniformity repeated N times is a defect.
- [ ] Captions and the headline describe what actually varies on the slide — a slide titled "where markets differ" must show difference, not three identical cards.

### C13 · Deliverable completeness
The deck contains every layer and every object its agreed scope requires.
- [ ] Every object the analysis generated appears in the deck — all N propositions (on dedicated plate slides), every insight chain, the moments, the calendar entries. A 3-of-9 proposition subset, or a pillar with no chain, is a dropped-object defect.
- [ ] The deck's section coverage matches the scope recorded in the configuration. A deck presented as the full strategy deck carries the full blueprint (~32 slides: trend, whitespace, insight chains, proposition plates, calendar, wireframes).
- [ ] A reduced-scope deck (e.g. snapshot only, ~14 slides) is acceptable ONLY when the configuration records that reduced scope was explicitly agreed with the user. A full-scope deck missing layers — or a reduced-scope deck presented as complete — is a FAIL.
- [ ] Object counts on the audit-trail slide match what the analysis actually produced.

---

## CONDITIONAL A — deck was ADAPTED from another deck
Trigger: this deck was produced by copying/patching a previous deck (different market, client, or period). **Highest-risk configuration.**
- [ ] Diff every numeric literal in the deck against the new deck's source data — not just the obviously data-driven slides.
- [ ] Verify the slides that historically leak, one by one: summary / one-page-read slide; "in-context" / category / brand-position slide (brand bullets, competitor list, ambassadors, citation IDs); headline-persona slide; chart-caption slides; method/coverage slide (hardcoded counts); closing slides (theme phrasing).
- [ ] Confirm logo, palette and category colour-coding were not left in a prior client's brand.
- [ ] Confirm slide-comment numbering / internal labels were updated.

## CONDITIONAL B — multi-deck / multi-market run
Trigger: more than one deck in the engagement.
- [ ] Each deck QA'd independently against ITS OWN source data (full core checklist per deck).
- [ ] No two decks print the same headline figure unless their data genuinely coincides — investigate every coincidental match.
- [ ] Cross-deck spot-check: named entities, counts, persona names, IDs and reference URLs differ between decks wherever the markets/clients differ.
- [ ] The same slide index across decks does not carry identical captions unless genuinely identical.

## CONDITIONAL C — creator / influencer content cohort present
Trigger: the deck used a separate creator/influencer cohort (content made for the target audience).
- [ ] The creator-content slides exist; their captions and numbers describe the CREATOR-CONTENT cohort, not the brand cohort — and describe it as content made for the audience, never as audience demand (see C10).
- [ ] Dual/triple-cohort comparison charts use independent proportional axes; no shared % axis across widely different sample sizes.
- [ ] Any topicality / live-cohort slide draws on the live study, and its ID is on the audit trail.

## CONDITIONAL D — extra category / context workspaces
Trigger: additional workspaces beyond the primary brand+competitor set.
- [ ] Context/category slides are attributed to the correct workspace.
- [ ] Those workspace and study IDs appear on the audit-trail slide.
- [ ] Context-cohort numbers are not conflated with primary-cohort numbers.

## CONDITIONAL E — small-sample or honest-limitation slides
Trigger: any small-sample cohort, or any slide flagged as an adaptation/approximation.
- [ ] Small-sample slides state the sample size honestly and do not over-claim.
- [ ] Any slide that is an honest substitute (a chart standing in for an un-run analysis) is labelled as such, not presented as something it is not.
