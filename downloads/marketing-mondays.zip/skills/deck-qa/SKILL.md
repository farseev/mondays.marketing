---
name: deck-qa
description: >-
  Configuration-aware quality-assurance pass for a generated presentation deck
  (PPTX/PDF) before delivery. Verifies that summary slides agree with detail
  slides, every figure/name/count traces to source data, no content is stale
  from a prior market or template, chart labels and trend statuses match the
  data and agree across slides, reference URLs are present and clickable, the
  logo/wordmark and category colour-coding are on-brand, no text overflows, and
  platform objects (e.g. SOMIN propositions) show their real fields. Use
  whenever a deck has just been built or edited and is about to be delivered,
  or the user asks to "QA the deck", "check the deck", "audit the slides", "is
  the deck consistent", or after adapting one deck into another. Works for
  single and multi-deck/multi-market runs, with or without an influencer cohort
  — a core checklist plus conditional sections per configuration. Not a builder
  or brand-styler — it inspects a finished deck and returns a PASS/FAIL verdict.
---

# Deck QA — Pre-Delivery Quality Assurance

A deck builder produces a polished-looking file even when it is wrong — wrong numbers, dead links, a mis-coloured logo, a chart label that contradicts its own line. Nothing crashes. This skill is the verification gate that catches those errors before a deck reaches a client.

It is a **separate, reusable skill**: any deck-building workflow invokes it as its final step. It owns exactly one responsibility — *verifying a finished deck against its own source data and brand spec* — and does not build, style, or restyle anything.

## When to use

- A deck (PPTX/PDF) has just been built or edited and is about to be delivered.
- The user asks to "QA the deck", "check the deck", "audit the slides", "is this consistent".
- A deck was produced by adapting another deck (new market, client, quarter) — the highest-risk case.
- One deck in a multi-deck set changed and the set must stay mutually consistent.

## When NOT to use

- The deck has not been built yet — build first, QA after.
- The request is to *create* or *restyle* slides — that is the builder / brand skill. QA only inspects and reports.
- The user wants a content critique ("is the strategy any good") — QA checks correctness, consistency, references, brand and layout, not strategic merit.

## Core principle

A slide is correct only when **everything printed on it traces to a verifiable source**: a number to the deck's own data, a name to the source record, a URL to a real resource, a colour to the brand spec, a data-object field to the actual object returned by the platform. Anything that cannot be traced is a defect. QA is a **gate, not advice** — a deck that fails is rebuilt and re-QA'd; it is never delivered with known defects.

## Required inputs

| Input | Purpose |
|---|---|
| The built deck | PPTX and PDF to inspect |
| The deck's source data | The JSON/registry/data files the deck was built from — ground truth for figures, names, counts, IDs |
| The brand spec | The brand-guideline skill or brand.json — ground truth for logo/wordmark, palette, category colour-coding |
| The reference list | Which SOMIN/source URLs each slide is required to cite, so QA can confirm presence AND clickability |
| Deck configuration | single vs multi-deck; influencer/audience cohort?; extra workspaces?; adapted-from another deck? — selects conditional checks |
| The builder source (if available) | Lets QA separate data-driven slides (safe) from hardcoded literals (must verify) |

If any input is unavailable, QA still runs the checks it can and **states in the verdict which checks were skipped** — a deck cannot be certified clean with checks skipped.

## The workflow

### Step 1 — Establish configuration
Determine: number of decks; influencer/audience cohort present; extra workspaces present; whether this deck was adapted from another. This selects which conditional sections of `references/qa-checklist.md` apply.

### Step 2 — Render the deck to images
QA is visual. Convert every PDF page to an image and inspect what actually rendered — overflow, clipping, axis scaling, logo colour and link styling are only visible in the render, never in the builder source.

```bash
pdftoppm -jpeg -r 130 <deck>.pdf <prefix>
```

### Step 3 — Classify every slide: data-driven vs hardcoded
If the builder source is available, scan it. A slide that reads its content from a data file adapts automatically (low risk). A slide with literal numbers/names/captions typed into the builder is the risk surface — every literal must be traced in Step 4. Hardcoded summary/headline slides are top priority.

### Step 4 — Run the checklist
Run the **core checklist** (always) plus every **conditional section** the configuration activates. Full itemised checklist in `references/qa-checklist.md`. The core checklist covers twelve defect families — C1–C11 and C13 below; a further family, C12, activates only on multi-market runs:

- **C1 Summary-vs-detail** — every headline/summary figure matches the detail slide that derives it.
- **C2 Data tracing** — every figure, count, name, title, ID traces to the source data for THIS deck.
- **C3 No foreign leftovers** — nothing inherited from a prior market/client/template.
- **C4 Chart integrity** — every data label matches the line/bar it sits on (a "Rising" label never on a falling line); axis maxima fit the data; legend matches series; and every chart is readable on its own — a reader can quantify each point because the axis is labelled or the points carry value labels. **A trend status word (SUSTAINED / SEASONAL / FALLING / RISING / EMERGING / SINGLE-SHOT / DECAYED) is a computed claim, not a caption** — when the chart shows per-point values, re-derive the status from those values against the trend rubric (SUSTAINED = mean ≥20% AND coefficient of variation <30%; FALLING = net decline ending at the minimum; SEASONAL = cyclic peaks/troughs / CV ≥30% with no monotonic trend) and confirm the printed label matches. A volatile series (deep troughs, CV well above 30%) labelled SUSTAINED is a defect even though its average is high. **And the SAME tension must carry the SAME status on every slide it appears** — the trend-chart slide, the movement-table slide and any divergence/narrative slide must agree; one tension shown SUSTAINED on one slide and SEASONAL/FALLING on another is a cross-slide contradiction. **A delta or "X → Y" arrow notation must show the series' actual start and end values.** If the second value is a mid-series peak rather than the endpoint, that is a misrepresentation — relabel it (e.g. "X → end · peak Y"). The arrow must never imply a flattering peak is where the series finished.
- **C5 References & links** — every required source URL is present AND actually clickable (a real hyperlink, not plain text); post/insight references resolve to the right resource; the audit-trail slide has every ID hyperlinked to its SOMIN record — including **product and proposition IDs**, not only workspaces/studies/stories (if the slide promises "every ID is a live link", every ID class on it must be linked, or the promise must be scoped to what is actually linked); the footer URL is a live link on every slide.
- **C6 Brand identity** — logo/wordmark rendered in the correct colours AND the correct spacing per the brand spec; palette correct; every recurring category (e.g. a whitespace verdict) uses ONE consistent colour and label everywhere it appears.
- **C7 Layout** — no text overflows or overlaps any element or the slide edge; no clipped headline; no empty filler slide; nothing collides with the reserved footer band (the footer text and page number strip at the slide bottom) — captions, footnotes, chart labels and the last card row must clear it.
- **C8 Data-object fidelity** — when the deck presents a platform object (SOMIN proposition, study, moment), it shows that object's REAL fields from the actual record, not invented content and not an arbitrary subset that drops the object's defining fields. A proposition in particular must appear with its actual **name (focus line) and insight tagline** — a card printing only "Proposition {id}" shows an ID reference, not the proposition, and fails.
- **C9 Tone** — professional MNC-marketing register; no buzzwords or hype filler; headlines and on-slide labels state the actual finding in plain words, not borrowed strategy-framework jargon ("where to play / how to play", "north star", "the X imperative").
- **C10 Claim integrity** — language never claims more than SOMIN measured. SOMIN detects concepts from CONTENT; it does not observe the audience. No slide may say "audience demand", "what [audience] wants/talks about", "demand-side" or similar. Content cohorts are "content made for [audience]"; whitespace is a content-supply gap. "Audience reacted" is allowed only when citing a views/engagement figure, as volume.
- **C11 Comparison-slide integrity** — any slide comparing entities side by side must make the compared dimension actually vary. A hero stat identical across every column (three "1 of 6" tiles), or columns mixing different metrics/units under one headline, is a defect. If a statistic is genuinely uniform, state it once as the finding — do not repeat N identical tiles.
- **C12 Cross-deck independence (multi-market runs only)** — in a multi-market engagement each market's deck must be derived from its own market's data. No two market decks may share pillar names, insight-story text, character names, product IDs or proposition text. Identical pillars or propositions across markets is a FAIL — it means the analysis was reused, not run per market. A theme may legitimately recur across markets, but only if each deck's pillars, stories, characters, product and propositions trace to that market's own SOMIN records; verify the IDs differ deck to deck.
- **C13 Deliverable completeness** — the deck contains every layer and every object its agreed scope requires. Two failure shapes: (1) **dropped objects** — the analysis generated 9 propositions, 3 insight chains, N moments, but the deck shows only a subset (e.g. 3 of 9 propositions, or a pillar with no chain). Every generated object appears. (2) **scope shortfall** — a deck presented as the full strategy deck is missing whole layers (trend section, content calendar, proposition plates) and runs far short of the ~32-slide blueprint. A reduced-scope deck is acceptable *only* when the configuration says reduced scope was explicitly agreed; a full-scope deck missing layers, or a reduced-scope deck presented as complete, is a FAIL. Check the deck's section coverage and object counts against the scope recorded in the configuration.

### Step 5 — Produce the verdict
Output **PASS** or **FAIL** with a defect list (`references/qa-report-format.md`). For each defect: slide, family, what is wrong, the correct value/spec, the fix.

### Step 6 — The rebuild loop (mandatory on any FAIL)
A FAIL is not a report the user acts on at their discretion — it triggers a fixed loop that QA owns and drives to completion:

1. **The deck is blocked from delivery.** Do not present, send, link, or describe a FAILed deck as finished. One unresolved defect blocks the whole deck.
2. **Fix at the source — never patch the output.** For every defect, change the **source data or the builder code**, not the rendered PPTX/PDF. Hand-editing the output file, or patching a single literal in place, is forbidden — it leaves the root cause live and the next rebuild reintroduces the defect. If a defect is a hardcoded literal, the fix is to make that value read from / be computed from data.
3. **Rebuild the whole deck** from the corrected source — re-run the builder end to end. Do not splice a corrected slide into the old file.
4. **Re-run the FULL checklist from the top** — every core family and every conditional section, not only the slides that failed. A fix routinely introduces a new defect elsewhere (a corrected stat with a now-stale caption; a widened axis that overflows its frame; a relinked URL that shifts layout). Partial re-QA misses these.
5. **Repeat 1–4 until the verdict is PASS.** There is no iteration cap and no "good enough" — the loop ends only on a clean PASS.

**Only a PASS makes a deck deliverable.** QA is a gate, not advice: every issue it finds sends the deck back through this loop. In a multi-deck run, each deck runs its own loop and must individually reach PASS before the set is delivered.

## What a defect looks like (one per family)

- **C1** Slide 2 shows 50%; the deck's data has no 50% theme — its largest is 55%. FAIL — stale hardcoded summary stat.
- **C2** Slide 3 says "21 studies"; the registry lists 17. FAIL — hardcoded count.
- **C3** Slide 4 names an ambassador/competitor/city from another market. FAIL — stale template text.
- **C4** Slide 9 line trends downward but is labelled "Rising". FAIL — label contradicts the data.
- **C4** A trend chart shows 79, 4, 36, 0, 69, 77% labelled SUSTAINED. Recomputed: mean 44% but coefficient of variation ≈75% — far above the 30% SUSTAINED ceiling. FAIL — the series is volatile/seasonal; SUSTAINED is wrong even though the average is high. Re-derive the label from the values.
- **C4** A tension is shown SUSTAINED on the trend-chart slide but FALLING on the movement-table slide and "swings seasonally" on the divergence slide. FAIL — the same tension must carry one status everywhere; reconcile all three to the value-derived status.
- **C4** A small-multiple panel of four line charts has no axis and no value labels — the reader sees four shapes but cannot read any level off them. FAIL — chart not readable on its own; add an axis or point labels.
- **C4** A trend table shows volume as "23 → 89" where 89 is a mid-year peak and the actual final value is 55. FAIL — the arrow implies an endpoint; show the true start→end and note the peak separately ("23 → 55 · peak 89").
- **C5** A slide cites a SOMIN insight but the URL is plain text, not a clickable link. FAIL — reference not clickable.
- **C5** The audit-trail slide promises "every claim traces to a SOMIN ID" but the workspace/study/story IDs are plain text, not hyperlinks. FAIL — the traceability slide must have every ID linked to its SOMIN record.
- **C5** The audit-trail slide links workspaces, studies and stories but the product and proposition IDs are plain text, while the caption still says "every ID below is a live link". FAIL — link every ID class, or scope the caption to what is actually linked.
- **C6** The "S O MIN" wordmark is rendered in one flat colour, or with the letters jammed tight. FAIL — wordmark must be "SO" teal + "MIN" dark/white as two tight tonal groups with a clear gap between them, per the brand spec.
- **C7** Slide 11 body text runs past the slide edge. FAIL — overflow.
- **C8** Propositions are listed by name only; the proposition object's own fields are dropped or replaced with invented copy. FAIL — show the real object fields.
- **C8** A proposition slide shows nine cards each reading only "Proposition 1201", "Proposition 1202"… FAIL — an ID is not the proposition; each card must show the real name (focus line) and insight tagline from the record.
- **C9** A slide leans on hype filler ("unleash next-level synergy"). FAIL — rewrite in plain professional register.
- **C9** A headline reads "Where to play, how to play — everywhere" — borrowed strategy-framework jargon that states no actual finding and could sit on any deck. FAIL — rewrite to the concrete point of the slide ("One strategic frame, used in all four markets").
- **C10** A slide says "what Foodies want" or "audience demand" for a metric derived from creator content. FAIL — SOMIN measured content, not the audience; reframe as "content made for Foodies".
- **C11** A four-market comparison slide shows "1 of 6" as the hero stat in three columns and "15" in the fourth. FAIL — the columns don't differ and mix two metrics; give each market a distinct hero number on the same metric, or state the uniform finding once.
- **C12** The UK, JP and US market decks each show the same three propositions, word-for-word. FAIL — propositions were copied across markets instead of generated per market from each market's own insight stories; each deck must carry its own product and proposition IDs.
- **C13** The analysis generated 9 propositions; the deck's proposition slide shows 3. FAIL — every generated proposition must appear (on dedicated plate slides); a 3-of-9 subset drops two-thirds of the work.
- **C13** A deck presented as the full SOMIN strategy deck has 14 slides, no trend section and no content calendar, and the configuration records no reduced-scope agreement. FAIL — build the missing layers to the ~32-slide blueprint, or have reduced scope explicitly agreed and recorded.

## Common failure modes (of QA itself)

- **QA'ing from the builder source instead of the rendered deck** — overflow, clipping, link styling and logo colour only show in the render.
- **Spot-checking instead of full coverage** — the defect hides on whichever slide was not checked. Every slide, every literal, every link, every chart.
- **Trusting a slide because it "looks reasonable"** — 50/2/45 looked reasonable on three decks. Reasonable is not correct; only tracing to source is.
- **Reading a trend status as a caption instead of recomputing it** — SUSTAINED / SEASONAL / FALLING are computed verdicts. If the chart shows the values, recompute (mean + coefficient of variation) and check against the rubric; a high-average but wildly swinging series is not SUSTAINED.
- **Checking that a URL is present but not that it is clickable** — a printed URL that is not a live hyperlink still fails C5.
- **Skipping the conditional sections** — a multi-market run with the multi-market section skipped is how decks inherit each other's content.
- **Treating QA as advisory** — a FAIL means rebuild-and-recheck, not "deliver with a note".

## Token discipline

- Render to images and inspect; do not paste builder source or full JSONs into context.
- The itemised checklist, report format and defect library live in `references/`; load them when running a pass.
- The verdict is small — the PASS/FAIL line plus the defect table is the deliverable.

## References

- `references/qa-checklist.md` — the full itemised checklist: eight-family core section + every conditional section.
- `references/qa-report-format.md` — the PASS/FAIL verdict and defect-table format.
- `references/failure-pattern-library.md` — catalogued real defects from past engagements, each with cause and how it is caught.


## Creative expressions check (only if the run included `creative-expressions`)

Apply these **only** when the scope passed to QA says expressions were generated:

- **Count matches scope.** The number of rendered expressions in the Creative-Library appendix equals what was agreed (All / Top N per pillar / specific total). A short appendix when "All" was chosen is a FAIL.
- **No stray placeholders.** In a final (non-partial) deck, no "Pending render" cards or blank cells remain. Every appendix cell shows a real render with its concept-key + subtype caption.
- **Grouped correctly.** One grid per (pillar × TOFU/MOFU/BOFU); each grid's pillar/persona header matches its concepts; no thumbnail or caption overflows the footer.
- **On-brand.** The appendix uses the client's real brand tokens (surface, ink, accent, fonts) — not the engine's neutral defaults.
- **Proposition visuals (only if "embed" was chosen).** Each embedded example sits on a proposition slide and matches that slide's insight/pillar. If "text-only" was chosen, there are **no** creative images anywhere in the proposition section.
- **Provenance honesty.** Any audit/method note describes the expressions accurately (SOMIN-generated, the count, and that the full set lives in the appendix).
