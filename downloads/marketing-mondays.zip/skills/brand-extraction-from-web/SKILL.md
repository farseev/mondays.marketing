---
name: brand-extraction-from-web
description: Extract a client's brand identity (color palette, typography hints, voice/taglines, real factual claims like phone/email/addresses, product/service offerings, and social handles) directly from their public website. Use whenever about to produce any branded artefact (deck, mockup, content brief, marketing collateral, landing page) for a client whose website you have access to AND whose brand specifics are not already in context. Trigger on cues like "build a deck for [client]", "design for [brand]", "their brand colours", "in [client]'s style", "I'm working on something for [client website]", or any request where the deliverable needs to look or sound like a specific real organisation. Always run this before guessing colors, palettes, fonts, taglines, or product details from training data — guesses go stale, screenshots and HTML do not. Returns a structured brand-voice JSON consumable by downstream skills (somin-brand-deck, somin-agency-deck if installed, content-brief-from-moment, frontend-design).
---

# Brand Extraction from Web

Turn a client URL into a structured brand JSON. Built to be called once per client at the start of an engagement and reused by every downstream skill that needs brand specifics.

## When to call

- Starting any deliverable for a client whose website is available
- The conversation references the client by name + a URL is mentioned or fetchable
- A downstream skill (deck-builder, content brief, mockup) needs colors/fonts/voice/taglines

**Don't call** if a `brand.json` is already present in context, OR if the deliverable is internal scratch work with no brand requirement.

## Workflow

1. **Confirm or solicit the URL.** If the conversation contains a client URL, use it. Otherwise ask once.
2. **Fetch the homepage screenshot** if available (user upload), OR fetch the homepage HTML via `web_fetch`. Screenshots give pixel-accurate colors; HTML gives voice/facts. Both is best.
3. **Run the palette extractor** on any screenshot:
   ```bash
   python scripts/extract_palette.py <screenshot.png> > palette.json
   ```
4. **Run the voice extractor** on the homepage and 1–3 key pages (about, products, contact):
   ```bash
   python scripts/extract_voice.py <homepage_url> [page2] [page3] > voice.json
   ```
5. **Assemble** the two into a single brand JSON:
   ```bash
   python scripts/assemble_brand_json.py palette.json voice.json > brand.json
   ```
6. **Validate** that every claim in `brand.json` traces to a source URL or screenshot. Strip anything inferred.

If no screenshot is available, attempt CSS-based color extraction (the voice extractor has a `--colors` flag for parsing inline styles and CSS variables). Note in the output that palette accuracy is "CSS-derived, not pixel-verified".

## Output schema

See `references/brand-schema.md` for the full schema with field-by-field descriptions and an annotated Example Academy example.

Short form:
```json
{
  "client_name": "...",
  "source_urls": [...],
  "palette": {"primary": "...", "secondary": "...", "neutral": "...", "...": "..."},
  "typography": {"display": "...", "body": "..."},
  "voice": {"taglines": [...], "mission": "...", "tone_words": [...]},
  "facts": {"phone": "...", "email": "...", "addresses": [...], "socials": {...}},
  "offerings": [{"name": "...", "description": "...", "url": "..."}],
  "extraction_metadata": {"date": "...", "confidence": "pixel|css|inferred"}
}
```

## What good output looks like

- Palette: 4–8 hex colors with role labels (primary, secondary, neutral, accent), each annotated with where it was sampled (logo / nav / CTA button / card bg)
- Voice: 1–3 verbatim taglines, the mission/about copy verbatim or paraphrased, tone words (3–7)
- Facts: only what's literally on the site — phone, email, addresses, real social handles, real URLs
- Offerings: list with real names and real URLs, NOT inferred categories

## Common failure modes

- **Guessing colors from training data instead of running the extractor.** Always run the script even if you "recognise" the brand.
- **Inferring missing fields.** Better to return `null` than fabricate a tagline.
- **Confusing CSS-named colors with brand colors.** Stock CSS frameworks (Bootstrap, Tailwind defaults) bleed into pages — the palette extractor distinguishes branded saturated colors from default greys.
- **Using only one page.** The homepage rarely contains the mission. Fetch about/contact/key product pages too.

## Token discipline

- The scripts run silently and write JSON. Do NOT cat the script source unless debugging.
- When passing `brand.json` to a downstream skill, pass the file path, not the contents inlined.
- The Example Academy example in references/ is the only worked example needed; don't paste it inline.
