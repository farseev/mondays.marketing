#!/usr/bin/env python3
"""
extract_voice.py — Extract taglines, mission, tone, facts, and offerings from website pages.

Usage:
  python extract_voice.py <homepage_url> [page2_url] [page3_url] ...

Approach:
- Fetch each URL (via requests; if not available, expects HTML content piped in)
- Parse with BeautifulSoup
- Identify: <h1>, <h2>, hero <p>, footer addresses/phone/email
- Detect taglines: h1/hero text under ~80 chars, often italic, often near logo
- Detect mission: first long paragraph (>200 chars) under any "about" heading
- Extract facts: regex for phone, email; addresses from <address> or footer
- Extract offerings: navigation/menu items + their target URLs
- Detect social handles: href patterns like instagram.com/X, facebook.com/X

Outputs structured JSON to stdout.
"""
import sys
import json
import re
import argparse
from urllib.parse import urlparse

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print('{"error": "requests + beautifulsoup4 required: pip install requests beautifulsoup4 --break-system-packages"}', file=sys.stderr)
    sys.exit(1)


PHONE_RE = re.compile(r"\+?\d[\d\s\-().]{7,}\d")
EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
SOCIAL_PATTERNS = {
    "instagram": re.compile(r"instagram\.com/([A-Za-z0-9_.]+)"),
    "facebook": re.compile(r"facebook\.com/([A-Za-z0-9_.]+)"),
    "youtube": re.compile(r"youtube\.com/(?:channel/|user/|@)?([A-Za-z0-9_\-]+)"),
    "tiktok": re.compile(r"tiktok\.com/@([A-Za-z0-9_.]+)"),
    "linkedin": re.compile(r"linkedin\.com/(?:company|in)/([A-Za-z0-9_\-]+)"),
    "twitter": re.compile(r"(?:twitter|x)\.com/([A-Za-z0-9_]+)"),
}


def fetch(url, timeout=15):
    headers = {"User-Agent": "Mozilla/5.0 (brand-extraction-bot)"}
    r = requests.get(url, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.text


def extract_one(url, html):
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    # Headlines and hero
    h1s = [h.get_text(strip=True) for h in soup.find_all("h1") if h.get_text(strip=True)]
    h2s = [h.get_text(strip=True) for h in soup.find_all("h2") if h.get_text(strip=True)]

    # Taglines: short distinctive lines from hero/header area
    candidates = h1s + h2s
    taglines = [t for t in candidates if 10 < len(t) < 100 and not t.lower().startswith(("home", "menu", "search"))]

    # Mission: longest paragraph under an "about"-like context
    text_blocks = []
    for p in soup.find_all(["p", "div"]):
        txt = p.get_text(strip=True)
        if 100 < len(txt) < 800:
            text_blocks.append(txt)
    text_blocks.sort(key=len, reverse=True)
    mission = text_blocks[0] if text_blocks else None

    # Facts
    full_text = soup.get_text(" ", strip=True)
    phones = list(dict.fromkeys(PHONE_RE.findall(full_text)))[:3]
    emails = list(dict.fromkeys(EMAIL_RE.findall(full_text)))[:3]

    addresses = []
    for addr in soup.find_all("address"):
        a = addr.get_text(" ", strip=True)
        if a:
            addresses.append(a)

    # Socials — scan all <a href>
    socials = {}
    for a in soup.find_all("a", href=True):
        href = a["href"]
        for platform, pat in SOCIAL_PATTERNS.items():
            m = pat.search(href)
            if m and platform not in socials:
                socials[platform] = m.group(1)

    # Offerings: navigation items
    offerings = []
    seen = set()
    for nav in soup.find_all(["nav", "ul"]):
        for a in nav.find_all("a", href=True):
            name = a.get_text(strip=True)
            href = a["href"]
            if not name or len(name) > 60 or len(name) < 2:
                continue
            if name.lower() in ("home", "menu", "search", "login", "sign in", "cart", "contact", "about", "shop"):
                continue
            if name in seen:
                continue
            seen.add(name)
            offerings.append({"name": name, "url": href})
    offerings = offerings[:20]

    return {
        "source_url": url,
        "h1": h1s[:5],
        "h2": h2s[:8],
        "taglines": taglines[:5],
        "mission_candidate": mission,
        "phones": phones,
        "emails": emails,
        "addresses": addresses,
        "socials": socials,
        "offerings": offerings,
    }


def main():
    p = argparse.ArgumentParser(description="Extract voice/facts from website pages")
    p.add_argument("urls", nargs="+", help="One or more URLs (homepage first)")
    p.add_argument("--from-file", help="Read HTML from file instead of fetching (for offline use)")
    args = p.parse_args()

    results = []
    for url in args.urls:
        try:
            if args.from_file:
                with open(args.from_file) as f:
                    html = f.read()
            else:
                html = fetch(url)
            results.append(extract_one(url, html))
        except Exception as e:
            results.append({"source_url": url, "error": str(e)})

    print(json.dumps({"pages": results}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
