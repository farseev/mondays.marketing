#!/usr/bin/env python3
"""
extract_palette.py — Sample brand-significant colors from a website screenshot.

Strategy:
1. Scan the full image, bin all pixels by 8-step quantisation.
2. Filter out:
   - Greyscale (max-min saturation < 30)
   - Near-white (>240 all channels) and near-black (<25 all channels) — they're surfaces, not brand
   - Skin tones in detected face regions (optional, off by default)
3. Cluster remaining saturated colors into top-N buckets.
4. For each bucket, classify role by hue+saturation+lightness:
   - High-saturation primary (logo, nav strip)
   - Mid-saturation secondary (accent, hover)
   - Pale tint (background panel) — same hue as a primary but lightened
   - Dark utility (button bg, charcoal)
5. Output JSON to stdout.

Usage:
  python extract_palette.py <screenshot.png> [--min-count 500] [--top-n 8]
"""
import sys
import json
import argparse
import collections
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print('{"error": "PIL/Pillow required: pip install pillow --break-system-packages"}', file=sys.stderr)
    sys.exit(1)


def rgb_to_hsl(r, g, b):
    r, g, b = r / 255.0, g / 255.0, b / 255.0
    mx, mn = max(r, g, b), min(r, g, b)
    l = (mx + mn) / 2.0
    if mx == mn:
        return 0, 0, l
    d = mx - mn
    s = d / (2.0 - mx - mn) if l > 0.5 else d / (mx + mn)
    if mx == r:
        h = ((g - b) / d + (6 if g < b else 0)) / 6
    elif mx == g:
        h = ((b - r) / d + 2) / 6
    else:
        h = ((r - g) / d + 4) / 6
    return h * 360, s, l


def color_role(r, g, b):
    """Classify a hex color into a role label."""
    h, s, l = rgb_to_hsl(r, g, b)
    if l < 0.25 and s < 0.3:
        return "dark_utility"
    if l > 0.8 and s > 0.1:
        return "pale_tint"
    if s > 0.6:
        return "primary"
    if s > 0.3:
        return "secondary"
    if l > 0.85:
        return "neutral_light"
    if l < 0.35:
        return "neutral_dark"
    return "accent"


def hex_str(rgb):
    return "#{:02X}{:02X}{:02X}".format(*rgb)


def cluster_distance(c1, c2):
    return abs(c1[0] - c2[0]) + abs(c1[1] - c2[1]) + abs(c1[2] - c2[2])


def merge_similar(buckets, threshold=40):
    """Merge color buckets that are visually similar."""
    merged = []
    for color, count in buckets:
        placed = False
        for i, (existing_color, existing_count) in enumerate(merged):
            if cluster_distance(color, existing_color) < threshold:
                # weighted average
                total = existing_count + count
                new_color = tuple(
                    (existing_color[k] * existing_count + color[k] * count) // total
                    for k in range(3)
                )
                merged[i] = (new_color, total)
                placed = True
                break
        if not placed:
            merged.append((color, count))
    return merged


def extract_palette(image_path, min_count=500, top_n=8, bin_step=8):
    im = Image.open(image_path).convert("RGB")
    # Downsample to reduce cost
    if im.width > 1500:
        ratio = 1500 / im.width
        im = im.resize((int(im.width * ratio), int(im.height * ratio)))

    counter = collections.Counter()
    for r, g, b in im.getdata():
        # Skip greyscale
        if max(r, g, b) - min(r, g, b) < 30:
            # Allow very dark and very light as separate buckets
            if r > 240 and g > 240 and b > 240:
                key = ("WHITE", 255, 255, 255)
            elif r < 25 and g < 25 and b < 25:
                key = ("BLACK", 0, 0, 0)
            else:
                continue
            counter[key[1:]] += 1
            continue
        rr = (r // bin_step) * bin_step
        gg = (g // bin_step) * bin_step
        bb = (b // bin_step) * bin_step
        counter[(rr, gg, bb)] += 1

    # Get top candidates
    candidates = [c for c in counter.most_common(80) if c[1] >= min_count]
    # Merge visually similar ones
    merged = merge_similar(candidates, threshold=32)
    merged.sort(key=lambda x: -x[1])
    merged = merged[:top_n]

    palette = []
    for (r, g, b), count in merged:
        role = color_role(r, g, b)
        palette.append({
            "hex": hex_str((r, g, b)),
            "rgb": [r, g, b],
            "role_guess": role,
            "pixel_count": count,
        })

    return {
        "source": str(Path(image_path).name),
        "image_size": list(im.size),
        "palette": palette,
    }


def main():
    p = argparse.ArgumentParser(description="Extract brand palette from screenshot")
    p.add_argument("image", help="Path to screenshot PNG/JPG")
    p.add_argument("--min-count", type=int, default=500)
    p.add_argument("--top-n", type=int, default=8)
    args = p.parse_args()
    result = extract_palette(args.image, args.min_count, args.top_n)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
