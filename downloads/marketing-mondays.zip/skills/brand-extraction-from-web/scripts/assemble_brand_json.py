#!/usr/bin/env python3
"""
assemble_brand_json.py — Merge palette.json + voice.json → brand.json.

Picks the best signal from each, de-dupes, and outputs the canonical brand schema.
Validates that nothing is invented; every field traces to a source.

Usage:
  python assemble_brand_json.py palette.json voice.json [--client-name "..."] > brand.json
"""
import sys
import json
import argparse
import datetime
from collections import Counter


def best_taglines(pages_data, limit=3):
    """Pick the most distinctive taglines across all pages."""
    seen = Counter()
    for page in pages_data.get("pages", []):
        for t in page.get("taglines", []):
            seen[t] += 1
    # Prefer ones that appear on multiple pages (true brand lines) then by length
    ranked = sorted(seen.items(), key=lambda x: (-x[1], -len(x[0])))
    return [t for t, _ in ranked[:limit]]


def best_mission(pages_data):
    candidates = []
    for page in pages_data.get("pages", []):
        m = page.get("mission_candidate")
        if m:
            candidates.append((len(m), m))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1]


def merge_facts(pages_data):
    phones, emails, addresses = [], [], []
    socials = {}
    for page in pages_data.get("pages", []):
        for p in page.get("phones", []):
            if p not in phones:
                phones.append(p)
        for e in page.get("emails", []):
            if e not in emails:
                emails.append(e)
        for a in page.get("addresses", []):
            if a not in addresses:
                addresses.append(a)
        for plat, handle in page.get("socials", {}).items():
            if plat not in socials:
                socials[plat] = handle
    return {
        "phones": phones[:3],
        "emails": emails[:3],
        "addresses": addresses[:5],
        "socials": socials,
    }


def merge_offerings(pages_data, limit=20):
    seen = {}
    for page in pages_data.get("pages", []):
        for o in page.get("offerings", []):
            name = o.get("name")
            if name and name not in seen:
                seen[name] = o
    return list(seen.values())[:limit]


def classify_palette(palette_data):
    """Re-assign role labels by inter-color analysis."""
    by_role = {
        "primary": None,
        "secondary": None,
        "accent": None,
        "pale_tint": None,
        "dark_utility": None,
        "neutral_light": None,
        "neutral_dark": None,
    }
    for c in palette_data.get("palette", []):
        role = c.get("role_guess", "accent")
        if by_role.get(role) is None:
            by_role[role] = c["hex"]
    # Flatten to clean output
    return {k: v for k, v in by_role.items() if v is not None}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("palette_json")
    p.add_argument("voice_json")
    p.add_argument("--client-name", default=None)
    args = p.parse_args()

    with open(args.palette_json) as f:
        palette_data = json.load(f)
    with open(args.voice_json) as f:
        voice_data = json.load(f)

    source_urls = [pg["source_url"] for pg in voice_data.get("pages", []) if "source_url" in pg]

    brand = {
        "client_name": args.client_name or "(set --client-name)",
        "source_urls": source_urls,
        "palette": classify_palette(palette_data),
        "palette_full": palette_data.get("palette", []),  # for downstream skills that want all colors
        "typography": {
            "display": "(not extracted — read CSS/screenshot manually)",
            "body": "(not extracted)",
        },
        "voice": {
            "taglines": best_taglines(voice_data),
            "mission": best_mission(voice_data),
            "tone_words": [],  # human-curated step
        },
        "facts": merge_facts(voice_data),
        "offerings": merge_offerings(voice_data),
        "extraction_metadata": {
            "date": datetime.date.today().isoformat(),
            "confidence": "pixel+html" if palette_data.get("palette") and voice_data.get("pages") else "partial",
            "tool": "brand-extraction-from-web v1",
        },
    }
    print(json.dumps(brand, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
