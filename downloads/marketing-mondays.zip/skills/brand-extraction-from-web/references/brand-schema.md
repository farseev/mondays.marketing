# brand.json — Output Schema

Read this when you need to understand or debug the brand JSON produced by `assemble_brand_json.py`. Downstream skills (somin-brand-deck, content-brief-from-moment, frontend-design) consume this exact shape.

## Top-level fields

| Field | Type | Source | Notes |
|---|---|---|---|
| `client_name` | string | --client-name flag | Human-readable. Defaults to placeholder if not set. |
| `source_urls` | string[] | voice extractor | Every URL the extraction touched. Required for audit. |
| `palette` | object | palette + classifier | 4–8 hex codes by role. See "Role labels" below. |
| `palette_full` | object[] | palette extractor | All sampled colors with pixel counts. Use only if downstream needs every shade. |
| `typography` | object | manual | `display` and `body` font names. Currently stub — fill manually or via CSS scrape. |
| `voice.taglines` | string[] | voice extractor | Up to 3 most-repeated short headlines across pages. |
| `voice.mission` | string | voice extractor | Longest paragraph candidate — verify before quoting. |
| `voice.tone_words` | string[] | manual curation | 3–7 adjectives. Fill by hand after reading mission. |
| `facts.phones` | string[] | regex extract | Verify these dial out before publishing CTAs. |
| `facts.emails` | string[] | regex extract | |
| `facts.addresses` | string[] | `<address>` tags | |
| `facts.socials` | object | href patterns | Keys: instagram, facebook, youtube, tiktok, linkedin, twitter |
| `offerings` | object[] | nav scrape | `{name, url}`. The real product/service list. |
| `extraction_metadata` | object | tooling | `date`, `confidence` (pixel+html / css-only / partial), `tool` version |

## Role labels for palette

The classifier assigns these roles by HSL analysis:

- `primary` — high saturation (>0.6), the brand-signature hex (logo letters, top nav)
- `secondary` — mid saturation (0.3–0.6), supporting accent
- `accent` — third saturated color, often used sparingly
- `pale_tint` — high lightness (>0.8) AND some saturation — card backgrounds derived from primary
- `dark_utility` — low lightness AND low saturation — button backgrounds, charcoal
- `neutral_light` — near-white surface
- `neutral_dark` — near-black surface

If two extracted colors fight for the same role, the one with higher pixel count wins. Inspect `palette_full` to override.

## Worked example — Example Arts Academy

Input: homepage screenshot + 3 URLs (homepage, why-us, loyalty).

Output:
```json
{
  "client_name": "Example Arts Academy",
  "source_urls": [
    "https://example-academy.com/",
    "https://example-academy.com/about/why-us/",
    "https://example-academy.com/about/loyalty/"
  ],
  "palette": {
    "primary": "#58C8F0",
    "secondary": "#A8C060",
    "pale_tint": "#C0E8F8",
    "dark_utility": "#504850",
    "neutral_light": "#F8F9FB",
    "neutral_dark": "#2D2A32"
  },
  "typography": {
    "display": "(serif — appears to be a humanist font)",
    "body": "(sans-serif)"
  },
  "voice": {
    "taglines": [
      "The Enchanting World of Music and Dance",
      "Where Talent Grows",
      "Rewarding dedication. Celebrating progress. Inspiring excellence."
    ],
    "mission": "...deliver the gift of classical music and ballet to students of all ages and challenge them to reach for the stars",
    "tone_words": ["heritage", "rigorous", "celebratory", "kiasu-friendly"]
  },
  "facts": {
    "phones": ["+65 0000 0000"],
    "emails": ["hello@example-academy.com"],
    "addresses": [
      "#04-17, 1 Example Road",
      "#03-03, 2 Sample Street"
    ],
    "socials": {
      "instagram": "exampleacademy",
      "facebook": "exampleacademy",
      "youtube": "UC0000000000example000000"
    }
  },
  "offerings": [
    {"name": "Classical Ballet (RAD UK + Vaganova)", "url": "/classes/dance-classes/classical-ballet"},
    {"name": "Modern Dance", "url": "/classes/dance-classes/modern"},
    {"name": "Hip-Hop", "url": "/classes/dance-classes/hip-hop"},
    {"name": "Piano", "url": "/classes/music-classes/piano-class"},
    {"name": "Violin", "url": "/classes/music-classes/violin-class"},
    {"name": "Conducting", "url": "/classes/music-classes/conducting"}
  ],
  "extraction_metadata": {
    "date": "2026-05-16",
    "confidence": "pixel+html",
    "tool": "brand-extraction-from-web v1"
  }
}
```

## Verification checklist before passing to downstream skills

- [ ] Every URL in `source_urls` returned 200
- [ ] `palette.primary` and `palette.secondary` both have hex values
- [ ] `voice.taglines` has at least 1 entry that is NOT a navigation label
- [ ] `facts.phones` either has a verified number or is empty (don't fabricate)
- [ ] `offerings` reflects real pages (each URL exists on the site)
- [ ] If any field is uncertain, set it to `null` rather than a guess
