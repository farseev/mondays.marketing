---
name: somin-brand-guideline
description: >-
  Apply the SOMIN 2026 visual identity (teal #2DBF9C primary, deep teal-black
  #16201F dark surface, white #FFFFFF page background, the "SOMIN" wordmark, a
  bold geometric sans-serif type system, and a small set of repeating layout
  patterns — section labels, numbered step cards, teal checkmark bullets, 3-up
  stat grids, pull quotes, and the SOMIN footer) to any document, deck,
  dashboard, web page, mockup, or marketing artefact branded as SOMIN. Use this
  skill whenever the user mentions SOMIN, somin.ai, builds anything for SOMIN,
  redesigns a SOMIN-branded artefact, or asks for a deck / page / asset "in
  SOMIN colours" or "in SOMIN style". Trigger even when the request only
  mentions a colour, a slide, a stat tile, or a logo placement — if SOMIN is
  named anywhere in the conversation, prefer this skill. Covers the wordmark,
  type system, palette (light + dark surfaces), and all repeating layout
  patterns from the 2026 SOMIN sales decks (Brands and Agency voices).
---

# SOMIN Brand Guideline

For producing SOMIN-branded artefacts consistent with the somin.ai website, product UI, and 2026 sales decks.

The brand has **four constants**:
1. Teal `#2DBF9C` as primary accent
2. Deep teal-black `#16201F` as primary dark surface
3. "SOMIN" wordmark — two tight tonal groups in one mark
4. Bold geometric sans-serif type family + repeating layout patterns

Get those right and almost any new artefact reads as SOMIN.

## Quick reference

```
COLOURS — PRIMARY
  Teal accent:           #2DBF9C
  Dark surface:          #16201F
  Page background:       #FFFFFF

SUPPORTING (light surface, teal-tinted greys)
  Body text:             #2A3635
  Secondary text:        #6B7A78
  Soft text / footer:    #9BA8A6
  Dividers / fills:      #C9D1D0
  Card background:       #F2FAF8

ACCENT COMPANION
  Darker teal:           #1F8A70
  Light teal wash:       #D5F2EA

DARK SURFACE TINTS
  Card fill:             #1F2A29
  Dark divider:          #2A3635
  Body on dark:          #FFFFFF / #C9D1D0

PROGRESSION ACCENT (3-step flows only)
  Lime step-3:           #9CD632

TYPE
  Family:        Montserrat (one bold geometric sans, all weights)
  Headlines:     ExtraBold/Black, sentence case (Brands) or UPPERCASE (Agency)
  Section labels: Regular ALL CAPS, letter-spaced 0.15–0.25em, teal
  Body:          Regular, line-height 1.5
  Stat numbers:  ExtraBold/Black, 3–5rem

WORDMARK — "SOMIN"
  "SO":        teal #2DBF9C
  "MIN":       #16201F on light / #FFFFFF on dark
  Construction: two tight tonal groups joined as ONE word "SOMIN"
  Spacing:     NO space between "SO" and "MIN" — they are joined; only the colour changes. All letters tight, NOT spaced out
  Placement:   top-left of every page
```

## Two editorial voices

| Voice | Headline case | Background default | Used for |
|---|---|---|---|
| **Brands voice** | Sentence case | White | Brand-team-facing decks, product website. Calmer, product-led. |
| **Agency voice** | UPPERCASE | Mixed — heavy use of `#16201F` dark hero slides | Agency-facing decks, BD materials. Sharper, declarative. |

Pick one voice per artefact and stay in it. Both share the same palette, wordmark, type family, and layout patterns — only headline case and dark/light mix differ.

## Detailed references

For palette and contrast rules (light surface + dark surface) → `references/palette.md`

For type system with CSS-ready specs → `references/typography.md`

For repeating layout patterns (section label, checkmark bullets, numbered step cards, 3-up stat grid, pull quote, footer chrome) → `references/layout-patterns.md`

For wordmark spec (the "SOMIN" two-tone construction) → `assets/wordmark-spec.md`

## 9-step application checklist

When applying SOMIN to an existing artefact:

1. Replace every accent colour with `#2DBF9C`
2. Replace dark surfaces / dark text with `#16201F`
3. Replace cream / off-white / beige backgrounds with `#FFFFFF`
4. Re-route warm or neutral greys to teal-tinted greys (`#2A3635`, `#6B7A78`, `#9BA8A6`)
5. Replace serif or italic headlines with bold geometric sans
6. Pick voice — Brands (sentence case) or Agency (UPPERCASE) — and stay in it
7. Add "SOMIN" wordmark top-left of every page (two tight tonal groups, "SO" teal + "MIN" dark/white)
8. Convert dot/dash bullets to teal-circle checkmarks
9. Convert key-stats callouts to 3-up stat grid (number / ALL CAPS teal label / descriptor)

Then verify contrast — body on white must be `#2A3635`, not `#9BA8A6`.

## When the artefact contains a client brand

When a SOMIN deck contains a mockup of, say, a client's Instagram post, that mockup uses the client's brand colours. The deck chrome AROUND the mockup is still SOMIN. The SOMIN system is the analytical surface; the client brand is what the audience sees.

## What NOT to do

- **Don't introduce red, orange, or yellow** — accent family is teal-only (plus optional lime for 3-step progressions)
- **Don't use neutral greys** — every grey in the palette is teal-tinted
- **Don't use Georgia, italic serif, or decorative typefaces** — 2026 system is single geometric sans-serif family
- **Don't space the wordmark letters out** — "SO" and "MIN" are joined with no space into one word "SOMIN"; the only break is the teal→dark colour change. Wide tracking is a defect
- **Don't invert the wordmark colours** — "S O" is always teal; only "MIN" swaps between dark and white
- **Don't apply this palette to client-branded mockups inside SOMIN decks** — client brand stays client brand; SOMIN is the chrome
- **Don't use the parallelogram in 2026 sales materials** — legacy mark for internal strategy decks only

## Common failure modes

- **Wordmark rendered in one flat colour** — "SOMIN" is ONE mark with an internal colour change: "SO" teal `#2DBF9C`, "MIN" `#16201F` on light / `#FFFFFF` on dark. A single-colour wordmark is wrong.
- **Wordmark spacing wrong** — the wordmark is "SO" + "MIN" joined into one word "SOMIN" with NO space between them; the only break is the internal teal→dark colour change. Letters set apart (any added gap, wide tracking, `0.25em` / `charSpacing` 2–3, or a literal space such as `"S O M I N"` or `"SO MIN"`) is the most common defect — it makes the mark look like loose letters or two words. Keep all letters tight; `charSpacing` = 0 in pptxgenjs. Render as two text runs (`"SO"` teal + `"MIN"` dark/white, no space) — see `assets/wordmark-spec.md` → "PPTX implementation".
- **Wordmark colours inverted** — "SO" is always teal; only "MIN" swaps dark/white with the surface. Never the reverse.
- **Category colour-coding drifting** — when a deck uses a fixed set of categories (whitespace verdicts, pillars, trend statuses), define the colour-to-category map ONCE and apply it identically on every slide. The same category must never change colour between slides; two categories must never share a colour. Inconsistent colour-coding is a brand defect, not just a data defect.
- **Off-spec accent colours** — accent family is teal-only (plus optional lime for 3-step progressions). Any red/orange/yellow/cool accent is off-brand.

After producing any SOMIN-branded deck, the `deck-qa` skill's C6 (brand identity) check verifies the wordmark colours, the wordmark spacing, and category colour-coding against this spec — on a light slide AND a dark slide.

## Token discipline

- The detailed palette tables and CSS specs live in references/ — load them when actually producing HTML/CSS
- The 9-step checklist above is the canonical migration workflow
