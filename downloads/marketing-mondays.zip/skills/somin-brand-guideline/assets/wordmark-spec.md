# SOMIN "SOMIN" Wordmark — Implementation Spec

## The wordmark

A single line of bold geometric sans-serif, set as **two tight tonal groups joined into one word**:

- **"SO"** in primary teal `#2DBF9C`
- **"MIN"** in primary dark `#16201F` on light surfaces, or `#FFFFFF` on dark surfaces
- **No space between "SO" and "MIN"** — they are joined into the single word "SOMIN"; the only break is the internal teal→dark colour change, not a gap
- Bold weight, all-caps, tight (normal-to-snug) letter spacing

The mark reads "SOMIN" as one solid word. There is no gap between the groups — the colour change alone signals where "SO" ends and "MIN" begins.

## Letter spacing — keep it tight

The wordmark is **one solid word in two colours**, not airy spaced-out letters.

1. **Within and across the groups** — "SOMIN" is set tight, like a single normal bold word. Do NOT apply wide tracking. Letters spaced far apart (the old `0.25em` / `charSpacing:3` treatment) is a **defect** — it makes the mark look like loose individual letters rather than a wordmark.
2. **No gap between the groups** — "SO" runs straight into "MIN" with no space character. Only the colour differs; there is no extra space, kern, or separator between the "O" and the "M".

So the full mark, left to right, is: `S` `O` `M` `I` `N` — joined, no gaps — "SO" teal, "MIN" dark/white, all letters tight.

## CSS implementation

```html
<span class="somin-mark">
  <span class="s-o">SO</span><span class="min">MIN</span>
</span>
```

```css
.somin-mark {
  font-family: 'Montserrat', system-ui, sans-serif;
  font-weight: 800;
  letter-spacing: normal;     /* tight — NOT 0.25em */
  font-size: 1.25rem;
}
.somin-mark .s-o  { color: #2DBF9C; }
.somin-mark .min  { color: #16201F; }   /* on light surfaces */
/* On dark surface, swap .min colour to #FFFFFF */
```

There is no space (and no `&nbsp;`) between "SO" and "MIN" — the two spans sit flush against each other so the word reads as one solid "SOMIN". Only the colour differs. No extra letter-spacing.

## PPTX implementation (pptxgenjs)

Render the wordmark as **two text runs** in one `addText` call so the two colours sit in one mark:

```js
s.addText([
  { text: "SO",  options: { color: "2DBF9C" } },
  { text: "MIN", options: { color: minColor } }   // minColor = 16201F light / FFFFFF dark
], { x:0.55, y:0.34, w:2.4, h:0.4, fontFace:"Montserrat", fontSize:16, bold:true,
     charSpacing:0, margin:0, valign:"middle" });
```

Key points:
- Run 1 is the literal string `"SO"` — **no space between S and O**.
- Run 2 is `"MIN"` — **no leading space**; "SO" and "MIN" are joined into one word. Only the colour differs.
- `charSpacing` = `0` (no added tracking). Do NOT set it to 2–3 — that produces the gappy, spaced-out letters that are off-brand.
- A wordmark that is one flat colour, OR has any added `charSpacing`, OR writes the letters with spaces between them (`"S O"` or `"SO MIN"`), is a defect.

## Variants

| Surface | "SO" colour | "MIN" colour |
|---|---|---|
| White / light surface | `#2DBF9C` teal | `#16201F` dark |
| Dark `#16201F` surface | `#2DBF9C` teal | `#FFFFFF` white |
| Teal `#2DBF9C` surface | `#FFFFFF` white | `#FFFFFF` white (both invert) |

## What NOT to do

- **Don't space the letters out** — "SO" and "MIN" are tight letter groups. Wide tracking is the most common defect and the one to watch for.
- **Don't write the letters with spaces** — it is `"SO"` + `"MIN"` joined, never `"S O M I N"`, `"S O"`, or `"SO MIN"`.
- **Don't separate "SO" from "MIN"** with a space, slash, dot, or line — the teal→dark colour change is the only break.
- **Don't invert the wordmark colours** — "SO" is always teal; only "MIN" swaps dark/white with the surface.
- **Don't put a teal "MIN" or a dark "SO"** — the two-tone construction is fixed.
- **Don't render it one flat colour** — the internal teal→dark colour change is mandatory.
- **Don't use a serif or lowercase** — geometric sans, all-caps, bold.

## The parallelogram mark (legacy / secondary)

A rhombus (equal-sided parallelogram, 45° interior angle) is a secondary mark, occasionally used as a corner accent on internal strategy decks. It does **NOT** appear in 2026 sales decks — use the wordmark by default.

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 41.42" preserveAspectRatio="xMidYMid meet">
  <polygon points="0,41.42 58.58,41.42 100,0 41.42,0" fill="#2DBF9C"/>
</svg>
```

Aspect ratio locked at **2.414 : 1**. Never stretch it. Stays teal on both light and dark surfaces.
