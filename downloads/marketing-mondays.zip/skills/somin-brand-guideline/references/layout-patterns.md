# SOMIN Layout Patterns

Patterns that appear on nearly every page of the 2026 SOMIN decks. Use these by default.

## Section label (eyebrow)

A small ALL CAPS line in teal sitting **above** the headline, separated by line break (not divider rule). When the label has two parts, join with middle dot `·`:

```
THE PLATFORM
Four products. One workflow, end-to-end.

CASE STUDY · CHALLENGE & APPROACH
From local guesswork to AI-powered hyper-localisation.

HOW IT WORKS · STEP 01
SEE WHAT YOUR COMPETITORS ARE ACTUALLY DOING.
```

CSS specs are in `typography.md`.

## Checkmark bullets

The default bullet on a SOMIN page is a **filled teal circle with a white checkmark** (✓), not a dot or a dash. Used for feature lists, "what you get", challenges, approach steps.

```html
<li>
  <span class="check" aria-hidden="true">✓</span>
  Multi-channel audit across paid and organic media
</li>
```

```css
.check {
  display: inline-flex; align-items: center; justify-content: center;
  width: 1.25em; height: 1.25em; border-radius: 50%;
  background: #2DBF9C; color: #FFFFFF;
  font-size: 0.75em; margin-right: 0.6em;
}
```

## Numbered step cards (horizontal flow)

Used for "platform" / "how it works" / "agentic pipeline" pages — horizontal row of 3–4 cards, each with number, icon, short label, one-line description, separated by right-arrows `→`.

Spec:
- Number: large (~2.5rem) in teal, top-left of card
- Icon: small teal glyph (magnifying-glass for Analyze, target for Strategy, lightbulb for Ideate, checkmark for Validate)
- Label: ALL CAPS bold, dark on light or white on dark
- Sub-label: small caps teal
- Body: 1–2 sentences in secondary text colour
- On dark surface: card fill `#1F2A29`, optional teal left-border on active card
- On light surface: no fill, just thin teal top rule above the icon

## Stat grid (3-up or 4-up)

The signature "proof" pattern. Horizontal row of 3 (or 4) stats. Each cell:

```
40+              3×               75%
HOURS            GRANULAR         COST-EFFICIENT
of manual        more refined     research and
research saved   audience         strategy costs
per campaign     segmentation     vs traditional
cycle
```

- Number: extra-bold sans, ~4rem, `#2DBF9C` on dark or `#16201F` on light
- Label below number: ALL CAPS teal, letter-spaced
- Descriptor: secondary text colour, 1–3 lines, regular weight

## Pull quote

For case-study callouts and testimonials:

- Large curly opening quote `"` in teal `#2DBF9C` at ~5rem, top-left of quote block
- Quote body in regular body sans (not italic by default), `#16201F` on light or `#FFFFFF` on dark, ~1.25rem
- Attribution below: name in bold, role in secondary text colour, optional small-caps teal eyebrow

```html
<blockquote class="pull">
  <span class="open-quote">"</span>
  <p class="body">SOMIN cut three days off our research cycle. Our planners got their time back.</p>
  <footer>
    <strong>Name Surname</strong> · Strategy Director, Agency X
  </footer>
</blockquote>
```

## Footer / page chrome

Every page carries the wordmark and a page number:

- **Left:** `SOMIN` wordmark, full colour on light, "MIN" inverted to white on dark
- **Centre** (Brands voice only): `somin.ai` in soft text `#9BA8A6`
- **Right:** page number — `NN` (Brands voice) or `NN / NN` (Agency voice), in soft text `#9BA8A6` Regular
- On title / hero slides, the wordmark may stay bottom-left but the page number can move top-right

## Cards on dark surfaces

When laying panels on `#16201F`:
- Card fill `#1F2A29`
- Teal left border `4px solid #2DBF9C` for emphasis (otherwise no border)
- Section label teal at top, then large headline in `#FFFFFF`, then body in `#C9D1D0`

```html
<div class="dark-card">
  <div class="eyebrow">BOTTLENECK 01</div>
  <h3 class="display">Research takes too long</h3>
  <p class="body">Strategy teams spend 3+ days assembling baseline audience intelligence per campaign.</p>
</div>
```

```css
.dark-card {
  background: #1F2A29;
  border-left: 4px solid #2DBF9C;
  padding: 32px;
  color: #FFFFFF;
}
.dark-card .body {
  color: #C9D1D0;
  margin-top: 16px;
}
```

## Dual-chart proportional comparison (for whitespace-analysis decks)

When comparing two cohorts of very different sample sizes, use **two separate charts side-by-side**, each scaled to its own cohort's range. Each chart gets a header label showing its `n =`. See whitespace-analysis skill's `references/sample-size-honesty.md` for the full rules.

## Imagery treatment

SOMIN decks generally avoid stock photography. Use:
- Data visualisations as the visual anchor
- Brand-coloured panel mockups (Instagram cards in client brand colours)
- Wordmark + ample white space on title / closing slides
- Documentary B/W only if photography is unavoidable
