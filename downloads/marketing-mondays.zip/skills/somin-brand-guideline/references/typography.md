# SOMIN Type System

SOMIN's 2026 type system is a **single bold geometric sans-serif family**, used at four sizes/weights for everything. No Georgia, no serif body, no italic by default.

## Type roles

| Role | Treatment |
|---|---|
| Display headline | ExtraBold/Black 700–900, sentence case (Brands) or UPPERCASE (Agency). Tight line-height ~1.05 |
| Section label | Regular/Medium 400–500, ALL CAPS, letter-spacing 0.15–0.25em, colour `#2DBF9C` |
| Body | Regular 400, line-height 1.5, colour `#2A3635` on light or `#FFFFFF` on dark |
| Stat number | ExtraBold/Black 800–900, very large (3–5rem), colour `#2DBF9C` on dark or `#16201F` on light |
| Stat label | Regular 400, ALL CAPS, letter-spacing 0.15em, colour `#2DBF9C` |

## Font-family stack

```css
font-family: 'Montserrat', system-ui, sans-serif;
```

Montserrat is the SOMIN typeface, used across everything in weights from Regular to Black. The bold, geometric character is what matters; fall back to a system geometric sans (`system-ui`) only if Montserrat is unavailable.

## Section label conventions

When the section label has two parts, join with a middle dot `·` (not em-dash, not pipe):

```
THE PLATFORM
Four products. One workflow, end-to-end.

CASE STUDY · CHALLENGE & APPROACH
From local guesswork to AI-powered hyper-localisation.

HOW IT WORKS · STEP 01
SEE WHAT YOUR COMPETITORS ARE ACTUALLY DOING.
```

The number anchors the section in the document's spine. Letter-spacing is wide enough that the label reads as a typographic device, not a phrase.

## Worked example (HTML/CSS)

```html
<div class="eyebrow">THE PLATFORM</div>
<h1 class="display">Four products. One workflow, end-to-end.</h1>
<p class="body">SOMIN gives strategy and creative teams an end-to-end pipeline — from audience discovery to campaign measurement.</p>
```

```css
.eyebrow {
  font-family: 'Montserrat', sans-serif;
  font-weight: 500;
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 0.2em;
  color: #2DBF9C;
  margin-bottom: 12px;
}
.display {
  font-family: 'Montserrat', sans-serif;
  font-weight: 800;
  font-size: 56px;
  line-height: 1.05;
  letter-spacing: -0.01em;
  color: #16201F;
}
.body {
  font-family: 'Montserrat', sans-serif;
  font-size: 16px;
  line-height: 1.5;
  color: #2A3635;
  max-width: 65ch;
}
```

## Stat number specs

The signature "stat tile":

```html
<div class="stat">
  <div class="number">40+</div>
  <div class="label">HOURS</div>
  <div class="desc">of manual research saved per campaign cycle</div>
</div>
```

```css
.stat .number {
  font-family: 'Montserrat', sans-serif;
  font-weight: 900;
  font-size: 4rem;
  line-height: 1;
  color: #2DBF9C;          /* on dark surface */
  /* color: #16201F;        on light surface */
}
.stat .label {
  font-family: 'Montserrat', sans-serif;
  font-weight: 400;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  color: #2DBF9C;
  margin-top: 12px;
  font-size: 13px;
}
.stat .desc {
  font-family: 'Montserrat', sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #6B7A78;          /* light surface secondary */
  /* color: #C9D1D0;        dark surface secondary */
  margin-top: 8px;
}
```

## Voice differences

Same fonts, different headline cases:

| Voice | Headline example |
|---|---|
| Brands voice | "Build the campaign around the opening." |
| Agency voice | "BUILD THE CAMPAIGN AROUND THE OPENING." |

The case is the voice. Don't mix sentence-case headlines with UPPERCASE headlines in the same deck.

## What's deprecated

The older internal SOMIN editorial decks used Georgia italic for "voice of the analyst" pull quotes. That is **deprecated** in the 2026 system. Pull quotes today use the same geometric sans family in Regular weight (or Bold for emphasis), with the large teal opening quote as the only display flourish.
