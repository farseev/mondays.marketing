# SOMIN Palette — Detailed Reference

## Primary

| Role | Hex | When to use |
|---|---|---|
| **Primary accent (teal)** | `#2DBF9C` | The "S O" in the wordmark, section labels, accent rules, chart series 1, checkmark fills, numbered step circles (default), CTA buttons, any element that signals SOMIN |
| **Primary dark (teal-black)** | `#16201F` | Dark slide backgrounds, the "MIN" in wordmark on light surfaces, body text on light, headlines on light. Replaces what a generic brand calls "charcoal" |
| **Primary light (white)** | `#FFFFFF` | Page backgrounds (default), text on dark surfaces, the "MIN" in wordmark on dark surfaces |

## Supporting greys (teal-tinted)

Every supporting grey is derived from primary teal so the whole palette reads as one family. **Never use neutral greys (`#808080`, etc.) on a SOMIN surface.**

| Role | Hex | When to use |
|---|---|---|
| Body text on light | `#2A3635` | Body copy on white. Slightly warmer than pure black |
| Secondary text | `#6B7A78` | Captions, subheadings, axis labels, descriptors under stat numbers |
| Soft text / inactive | `#9BA8A6` | Tertiary labels, page numbers, footer chrome on light, inactive step numbers |
| Dividers / fills | `#C9D1D0` | Table borders, faint dividers, low-importance fills, gridlines |
| Card background (light) | `#F2FAF8` | Faint teal mist for cards / call-outs on white pages — never use neutral off-whites |

## Accent companion

For moments when a second accent is needed (dual-series charts, "BLOCKED" vs "WHITESPACE" verdicts, second step in a progression):

| Role | Hex | When to use |
|---|---|---|
| Darker teal companion | `#1F8A70` | Second chart series, secondary panel borders, the "02" step circle. Never use red as the secondary accent — it breaks the family |
| Light teal wash | `#D5F2EA` | Highlight rows on tables (e.g., "peak week"), background tints, hover states |

## Progression accent (3-step flows only)

When laying out a numbered 3-step or 4-step progression, SOMIN decks occasionally use a brighter lime as the third step's circle to visually reinforce progression. **Only for that specific use; never as a general accent.**

| Role | Hex | When to use |
|---|---|---|
| Progression step 3 (lime) | `#9CD632` | Step-03 circle in a how-it-works flow on light. Pair with `#2DBF9C` (step 01) and `#1F8A70` (step 02). Do not use elsewhere |

If unsure, default the whole progression to `#2DBF9C` rather than introducing the lime.

## Dark surface tints

When building on the `#16201F` dark surface, you need slightly-lighter tints for cards and dividers. Sample these from primary dark, not from neutral greys:

| Role | Hex | When to use |
|---|---|---|
| Dark card fill | `#1F2A29` | Card / panel backgrounds on `#16201F` surface (e.g., 3 "bottleneck" cards on agency deck) |
| Dark divider | `#2A3635` | Horizontal rules and panel borders on dark surfaces |
| Body text on dark | `#FFFFFF` or `#C9D1D0` | White for primary body, `#C9D1D0` only for secondary captions. Never darker than `#C9D1D0` for body on dark — contrast fails |

## Contrast / accessibility

| Pairing | Min size for AA | Notes |
|---|---|---|
| `#2A3635` on `#FFFFFF` | any body size | Default body — safe |
| `#6B7A78` on `#FFFFFF` | 16px+ | Caption-safe |
| `#9BA8A6` on `#FFFFFF` | NEVER for body | Soft text only — footer chrome |
| `#FFFFFF` on `#16201F` | any | Default body on dark |
| `#C9D1D0` on `#16201F` | acceptable | Secondary captions on dark — don't go darker |
| `#2DBF9C` on `#FFFFFF` | display only | Large headlines, stat numbers, accent rules. Body teal must use `#1F8A70` instead |
| `#2DBF9C` on `#16201F` | passes for headlines | Use sparingly for body |
| `#9CD632` lime | display only | Verify contrast at the specific size before using as text |

## The "no red, no orange, no yellow" rule

SOMIN's accent family is teal + neutrals. Any legacy template that uses red, orange, or yellow gets replaced with `#2DBF9C` (or `#1F8A70` if a second teal is needed). The visual brand depends on staying in the teal family — introducing a warm accent fundamentally changes the brand read.

The exception: client brand colours inside a SOMIN-built mockup. If a deck contains a mockup of a client's Instagram post (say, a baby-care retailer in pink/lavender), that mockup keeps the client's pink/lavender. The SOMIN chrome around it stays teal.
