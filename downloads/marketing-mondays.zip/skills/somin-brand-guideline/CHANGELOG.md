# SOMIN brand-guideline skill — update log

## 2026-06-11 — Montserrat type + tightened wordmark

Two corrections from the brand owner, applied across the skill.

### 1. Typeface is Montserrat
The type family is now **Montserrat** (one bold geometric sans, all weights Regular→Black), replacing the previous "Inter / Manrope / Sora" stack. Fall back to a system geometric sans (`system-ui`) only if Montserrat is unavailable.

- `SKILL.md` — TYPE block family line.
- `references/typography.md` — font-family stack, the default-face prose, and every CSS `font-family` declaration (`.eyebrow`, `.display`, `.body`, `.stat .number/.label/.desc`).
- `assets/wordmark-spec.md` — CSS and PPTX `fontFace`.

### 2. Wordmark has no space — "SOMIN" is one joined word
The wordmark is now **"SOMIN" set as one solid word** in two colours ("SO" teal `#2DBF9C`, "MIN" `#16201F` on light / `#FFFFFF` on dark). There is **no space and no gap** between "SO" and "MIN" — the teal→dark colour change is the only break. All letters stay tight.

- Removed the "single space / single gap between the groups" model everywhere.
- PPTX: render as two runs `"SO"` + `"MIN"` (no leading space) with `charSpacing: 0` (was `0.4`).
- CSS: spans sit flush, no `&nbsp;`.
- "What NOT to do" now flags any added space (`"SO MIN"`, `"S O M I N"`) or any added `charSpacing` as a defect.
- Description text and footer references changed from `"S O MIN"` to `"SOMIN"`.

Unchanged: `references/palette.md` and the layout patterns themselves (only the footer wordmark string in `references/layout-patterns.md` was corrected).
