---
name: somin-keyword-explorer-widget
description: Render two related keyword/term datasets (e.g. hashtags vs caption keywords, or any other two-category term comparison across multiple brands/entities) as ONE combined interactive widget with three always-visible button rows — category, metric, and brand/entity — plus a hover popover linking to a real example record. Use whenever a skill or request needs an interactive word cloud, bar chart, or table that lets the user toggle between categories, metrics, and entities without new tool calls per click. This is a rendering component, not an analysis workflow — it assumes the caller already has the per-entity term data (term, volume, engagement/metric, avg metric, best-example record) and just needs it rendered. Used by competitor-audience-content-analysis for its Part A keyword explorer; reusable anywhere the same "two categories × three metrics × N entities, one widget" shape applies.
---

# SOMIN interactive keyword-explorer widget

A rendering component: one `visualize:show_widget` call that embeds two
related term datasets at once and exposes three always-visible button rows
so the user can explore every combination client-side, with zero
additional tool calls per click.

## When to use

- A calling skill has already assembled per-entity term data (e.g. per
  brand: hashtags and caption keywords, each with volume/engagement/avg
  metrics and a best-example post) and needs it rendered as one
  interactive widget rather than a static chart or markdown table.
- Any other "two categories × up to three metrics × N entities" shape —
  this pattern generalizes beyond hashtags/captions.

## When NOT to use

- The data is a single category with no metric-toggle need — a plain
  `chart_display_v0` call is simpler and correct.
- The comparison doesn't have a natural category split — don't force two
  categories where there's only one.

## The three-row contract

Regardless of format (word cloud / bar chart / table), the widget exposes
exactly **three button rows**, in this fixed order, all visible at once:

1. **Category row** — the two datasets (e.g. `Hashtags` / `Caption
   keywords`). Switches which dataset is currently shown.
2. **Metric row** — `Volume` / `Total engagement` / `Avg engagement per
   post` (or whatever the calling skill's three metrics are). Controls
   sizing/ranking/ordering.
3. **Entity row** — `All` / one button per entity in scope, in a fixed
   order (primary entity first). Filters which items are shown.

All three rows stay visible together at all times — never hide row 2 or
row 3 behind a row-1 selection. Every click re-renders client-side from
the dataset already embedded in the widget — no new tool call for any
button. A small live status line inside the widget states the current
category + metric + entity + scope (functional state indicator, not
narrative prose) so a single state is self-describing even out of context
(e.g. if the user screenshots it).

## Guarantee every entity a floor

A combined "top N overall" selection will silently starve out any entity
that posts/appears less repetitively than others, even when it has real,
distinctive terms — it doesn't disappear because it "has no terms," it
disappears because its terms individually rank below the cutoff next to
an entity that repeats the same term dozens of times. Before finalizing
any combined selection, reserve a floor of the top ~5 entity-exclusive
terms (by whichever metric is currently active) for every entity in
scope, then fill remaining slots with the global top-ranked terms.
**Re-apply this floor rule on every button click that changes category or
metric** — an entity's floor-5 by volume isn't the same five terms as its
floor-5 by avg engagement. If an entity still has zero exclusive terms
even after checking the full dataset, say that explicitly and show what
volume its own top term actually has — don't imply "no terms" when the
real situation is "terms exist but rank below others on this metric."

## Color coding

All visuals are color-coded by entity. Before building, check if a
brand-specific guideline skill applies (e.g. `somin-brand-guideline`, a
`<client>-brand-guideline` skill the user has installed, or any workspace-named
guideline skill) — if one exists and the caller wants brand-styled output,
pull its palette instead of the default assignment. Otherwise assign one
fixed hex per entity for the session (primary entity gets a distinct
accent color, e.g. coral `#D85A30`; others get blue `#378ADD`, amber
`#BA7517`, purple `#7F77DD`, teal `#1D9E75`, cycling if more than 5;
terms shared across 2+ entities render gray `#8A8A86`).

## Building the widget, per format

- **Word cloud** — the canonical reference implementation. Use
  `references/why-every-piece-is-fixed.md` for the rationale, then reuse
  `assets/word_cloud_widget.html` **verbatim**, substituting only `DATA`,
  `BRANDS`, and `BRAND_COLORS`. No alternative popover mechanism (native
  `title`, CSS `:hover` tooltips, a separate library), no alternative
  color mechanism (`c-{ramp}` classes, Tailwind-style utility classes,
  inline `class=` for entity color), and no omission of any piece (legend,
  per-item try/catch, hover-state flags, shared-term merge) is acceptable.
  Call `visualize:read_me({modules: ["chart", "interactive"]})` once
  before building.
- **Bar chart** and **Table** — see
  `references/bar-chart-and-table-variants.md` for the Chart.js and HTML
  table variants of the same three-row contract, plus export handling.

## Hover popovers

Every hoverable item (word, bar, table row, or card) must follow
`references/hover-popover-standards.md` — real clickable example links
with an honest "No link available" fallback, correct DOM nesting so
positioning resolves against the right containing block, explicit
hover-state flags instead of a single fragile timer, smart
above/below positioning, and per-item error isolation so one bad data
point can't silently kill every other item's hover binding.

## Titling

The design system forbids putting titles/prose inside the widget itself,
so a title line lives in the chat response immediately before the single
`visualize:show_widget` call — but because category, metric, and entity
are all live-toggleable inside one widget, the external title can't name
one specific combination. State instead: (1) what this combined explorer
covers, (2) the scope (e.g. literal time window), (3) a pointer to the
in-widget status line for the specific combination currently shown. E.g.
"**Keyword explorer — hashtags & caption keywords, all brands, 2026-06-04
to 2026-09-02** (use the buttons to switch category, metric, and brand)."

## Common failure modes

| Failure | Cause | Fix |
|---|---|---|
| Word cloud renders with no color coding, all words the same shade | Used `class="c-coral"` etc. on plain HTML `<span>` elements — those classes don't exist in this widget's scope | Use the canonical reference implementation verbatim: inline `style.color`/`style.background` from `BRAND_COLORS[entity]`, never a CSS class |
| Popover never appears on hover | Used the native `title` attribute (or CSS-only `:hover`) instead of a real positioned `<div>` popover | Use the canonical `showPopover`/`hidePopoverNow`/`scheduleHide` functions verbatim |
| Widget shows flat/uncolored text or missing button rows despite correct data | `widget_code` payload was HTML-entity-escaped (`&lt;div&gt;` instead of `<div>`) before the tool call | Pass raw literal angle brackets/ampersands; sanity-check the payload starts with a real `<` byte — see `references/why-every-piece-is-fixed.md` |
| A brand/entity appears to have "no terms" | A single global top-N ranking starved it out because it posts less repetitively | Reserve a per-entity floor of ~5 exclusive terms before filling remaining slots globally |
| Popover disappears too quickly or works in some rows but not others | Fragile single hide-timer race, and/or popover div is a sibling instead of a child of its positioned container | Nest popover inside its container; track `hoveringTrigger`/`hoveringTooltip` explicitly |
| Popover gets cut off or leaves a big empty gap under the last row | Fixed "always below" positioning | Measure popover height at hover time; flip above the trigger when it wouldn't fit below |
| Two runs with the same button state look interchangeable | No title separating widgets, or missing in-widget status line | Every widget call gets a title line before it; status line always states current category+metric+entity+scope |
