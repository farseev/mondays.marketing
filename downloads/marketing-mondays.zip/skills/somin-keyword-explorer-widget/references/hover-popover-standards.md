# Hover-popover standards — apply to every visualization, not just word clouds

Any visualization that lets the user hover to see an example post (word
clouds, bar charts, card grids) must follow the same rules below, because
they all hit the same bugs otherwise.

## 1. Real, clickable example-post links, never fabricated

Capture the single highest-engagement post behind whatever's being shown
(a keyword, a theme, a persona) — id, brand, date, `sourceType`, and
`rawData.code` if Instagram.

- For word-cloud keyword/hashtag "best" records, this data comes from the
  post-extraction pass that also captures engagement and salient terms —
  not a separate pull. A popover with no link is what happens when that
  extraction step is skipped or deferred (see the calling skill's
  extraction-fields requirement).
- For themes/personas, pull the representative post via
  `SOMIN:posts-search({clusterIds: [themeId], sortBy: "total_engagement",
  pageSize: 1})` (optionally with `profileIds` to get a specific brand's
  top post within that theme).
- Construct a permalink only when the platform supports it directly from
  data already in hand — Instagram: `https://www.instagram.com/p/{code}/`.
  If unconstructible (e.g. TikTok without a resolvable handle), show
  "No link available" — never invent a URL.

**Keep the popover condensed — 3 short lines, not a stacked report.** A
popover with two section headers ("AGGREGATE" / "EXAMPLE POST"), one stat
per line, and generous padding reads as oversized even though every
individual field is justified. Fit the same information into:

1. the word/theme name
2. one line combining volume/total/avg with abbreviated numbers
   (`short()`: 17231 → "17.2k") and short labels ("Vol"/"Tot"/"Avg"
   separated by `·`)
3. one line combining the example post's brand, short date (MM-DD),
   abbreviated engagement, and the link, again `·`-separated

Tighten padding to `8px 10px`, cap `max-width` around 210px, and don't add
a blank-line gap between the two stat lines — the distinction between
"aggregate" and "example" should be legible from context (the second line
starts with "Best:") without needing its own header row.

## 2. Avoid the hover-gap bug and the wrong-containing-block bug

Native tooltips (`title` attribute, Chart.js's built-in canvas tooltip)
can't hold a real `<a href>`, so any hoverable example-post link needs a
custom popover — an absolutely-positioned div for word clouds/cards, or a
Chart.js `external` tooltip callback for charts. Two things break this if
done carelessly:

- **The popover div must be a DOM child of the `position: relative`
  container it's positioned against**, never a sibling. `position:
  absolute` resolves against the nearest *positioned ancestor*, not
  against whatever element you computed coordinates relative to — if the
  popover is a sibling of the cloud/chart wrapper instead of nested inside
  it, coordinates computed via `getBoundingClientRect()` diffs against the
  wrapper get applied against the wrong containing block, silently
  misplacing the popover (most noticeable for triggers near the top of the
  widget, where the offset error is largest relative to the visible
  content).
- **Use explicit hover-state flags, not a single fragile show/hide
  timer.** Track `hoveringTrigger` and `hoveringTooltip` as separate
  booleans, set/cleared on each element's `mouseenter`/`mouseleave`; on any
  `mouseleave`, clear any pending hide and schedule a new one (~350ms)
  that only actually hides the popover if *neither* flag is still true at
  the time it fires. This is more robust than a single cancel/reschedule
  pair because it doesn't depend on the exact order `mouseenter`/
  `mouseleave` fire in during the handoff between trigger and popover.

## 3. Position smart, don't just reserve a big empty gap

A popover that only appears on hover isn't accounted for in the widget
host's initial content-height sizing, so a naive "always position below
the trigger" approach either gets clipped at the bottom or forces a large
empty reserved-space buffer that looks like a layout bug. Instead, decide
the position at hover time:

1. measure the popover's own height first (set its content and
   `visibility: hidden; display: block` briefly to read `offsetHeight`, or
   estimate from typical content)
2. check whether it fits below the trigger within the container's
   `clientHeight` — if yes, position below (`top = triggerBottom + gap`);
   if it would overflow, flip it to position **above** the trigger instead
   (`top = triggerTop - popoverHeight - gap`)

Bottom-row triggers will show their popover overlapping upward into
already-rendered content above them (fine — it's on top with a higher
z-index) rather than needing reserved space below. For Chart.js `external`
tooltips, apply the same flip logic using `tooltipModel.caretY` relative
to the chart's own height. Only keep a small buffer (~20-30px) as
insurance for edge cases, not a large fixed reserve.

## 4. The popover must never silently fail to appear at all

This is a different bug from rules 2–3 (a popover that shows but is
mispositioned) — this is a trigger that produces nothing on hover, which
is worse because it looks like the feature is broken rather than just
imperfect. Two root causes account for nearly all cases:

- **A build-time exception on one bad data point kills event binding for
  every other word/bar in the same widget.** If the popover-content
  builder throws (e.g. a post missing `rawData.code`, a null `metrics`
  field, an empty array treated as if it must be non-empty) while looping
  over all words/bars to attach hover handlers, and that loop isn't
  wrapped per-item, one malformed entry can abort the whole binding pass
  silently — words earlier in iteration order work and everything after
  the bad one has no listener at all, with no visible error to the user.
  Wrap the per-item popover-content construction in its own try/catch (or
  equivalent per-item guard) inside the binding loop, so one item's bad
  data degrades gracefully to a fallback ("No example post available")
  rather than breaking every sibling trigger.
- **Hover handlers conditionally skipped when data looks "incomplete"
  instead of always attached with a fallback.** Don't gate whether a
  hover listener gets attached at all on whether a full example-post
  record was successfully resolved — attach the listener unconditionally
  for every rendered word/bar, and let the popover's *content* (not its
  existence) reflect whatever data is actually available, down to "No
  example post available" per rule 1's honest-fallback standard. A
  conditional attach means the same word can have a popover in one view
  and silently have none in another, with no visible cause.

**Fastest diagnosis when this is reported:** check whether the missing
popovers cluster (all words for one brand, everything after a specific
word in DOM order, only in one category/metric view) — clustering points
to the try/catch-per-item fix above; scattered/random misses point to the
always-attach-with-fallback fix.

## Applying this across visualization types

- **Word clouds** — hover the word/chip.
- **Bar charts** — hover the bar via a Chart.js `external` tooltip.
- **Card grids** — expand the card's accordion; since accordions are
  already in normal document flow, rules 2–3 don't apply beyond keeping
  the tooltip itself well-behaved if one appears elsewhere in the card.
  Add the same condensed one-line "Best: brand · short-date ·
  abbreviated-engagement · link" inside the existing detail/accordion
  body, placed just above the `refs` footer.
