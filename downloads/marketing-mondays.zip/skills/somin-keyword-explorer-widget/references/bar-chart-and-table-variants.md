# Bar chart and table variants

The word cloud in `assets/word_cloud_widget.html` is the canonical format,
but the same three-button-row / one-embedded-dataset pattern applies to
bar-chart and table formats too. All three share: one `visualize:show_widget`
call, both keyword datasets (hashtags + caption keywords) embedded at once,
the same three always-visible button rows (category / metric / brand), and
the same hover-popover standard (see `hover-popover-standards.md`).

## Bar chart

Chart.js horizontal bar inside the same combined widget. On any of the
three button rows, **destroy and rebuild the Chart.js instance** (not a
data-only swap — a swap leaves stale scale/tooltip/legend state carrying
over between category or metric switches) using the embedded dataset for
the newly active category+metric+brand selection.

- One color per brand per the CDS chart guidance (`role="img"` +
  `aria-label`, custom HTML legend, no dual axes).
- Check the scale disparity between brands before picking a layout for the
  current view (same rule as whitespace-analysis's sample-size-honesty
  check): if the largest brand's top value is more than ~5x the smallest
  brand's, use **per-brand small multiples** (one mini horizontal-bar chart
  per brand, each with its own x-axis scale and a brand-name label above
  it) rather than one shared-axis chart that flattens smaller brands to
  invisible slivers. Only use a single shared-axis chart when the brands'
  scales are actually comparable for that view.
- Include the sample size in each bar's label (e.g. "Blueberry (n=2)")
  since top-average words are often driven by very few posts.
- Use a Chart.js `external` tooltip per `hover-popover-standards.md` rather
  than the default canvas tooltip — canvas-drawn tooltips can't hold a
  real `<a href>` link.

## Table

Also built as an HTML widget (not a plain markdown table — markdown can't
carry the three button rows or re-render on click). A `<table>` with
Brand / Word / Volume / Total engagement / Avg engagement per post
columns, so all three metrics are visible together regardless of which
metric button is "active" for sort order. The active metric button
controls sort order and highlights its own column, but doesn't hide the
other two — the table's whole purpose is letting the user compare all
three numbers for the same word without cross-referencing another widget.

- Row set re-filters on category and brand exactly like the other two
  formats.
- Each row is hoverable/tappable for the same condensed example-post
  popover as the other formats.
- Use a "Brand" column (not inline color) since table cells don't carry
  the brand color mapping as legibly as a dot or bar fill.

## Export

The combined widget doesn't have a built-in export button by default. If
the user wants a downloadable artifact:

- **HTML**: save the same data as a standalone HTML file via `create_file`
  to `/mnt/user-data/outputs/` and `present_files` — the exported HTML
  should keep all three button rows working, since it's the same
  embedded-dataset widget, just saved to disk.
- **PDF**: read `/mnt/skills/public/pdf/SKILL.md` first, then render one
  fixed category+metric+brand view as an image/table into a PDF via that
  skill (PDF can't carry the interactivity, so ask the user which single
  view to freeze, or freeze "All brands, Volume, Hashtags" as the default
  if they don't have a preference).

Ask which export type they want rather than assuming.
