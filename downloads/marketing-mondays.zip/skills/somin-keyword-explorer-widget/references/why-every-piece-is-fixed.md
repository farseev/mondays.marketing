# Why every piece of the reference widget is fixed, not a style choice

This is not negotiable per-run styling — it is the reproducibility contract
for this widget. A run that reimplements it from scratch, even with good
intentions, is the exact failure mode this reference exists to prevent.
Two prior runs shipped broken widgets before this became mandatory (see
below) — every future run reuses the structure in
`assets/word_cloud_widget.html` verbatim, substituting only `DATA`,
`BRANDS`, and `BRAND_COLORS`.

- **Brand color comes from `BRAND_COLORS[brand]` inline** (`style.color`,
  `style.background` via `color-mix`), **never a `class`.** The `c-{ramp}`
  SVG diagram color-ramp classes do not exist in this HTML widget's scope —
  applying them (e.g. `class="c-coral"` on a plain `<span>`) renders
  nothing. This was a confirmed shipped bug: nothing was color-coded
  because the classes silently did nothing outside the SVG diagram system.

- **The popover is a real `<div>` appended as a child of `#cloud`** — the
  `position: relative` container it's positioned against — never a
  sibling, and never the native `title` attribute. `title` cannot hold an
  `<a href>` link and is unreliable across platforms; a prior run used it
  and produced no visible tooltip on most platforms.

- **`hoveringTrigger`/`hoveringTooltip` plus the 350ms `scheduleHide`** are
  the fix for the hover-gap bug (see `hover-popover-standards.md`) — a
  single fragile show/hide timer breaks the handoff between trigger and
  popover depending on event-firing order.

- **The per-item `try/catch` inside the render loop** is the fix for one
  malformed term silently killing every subsequent word's event binding —
  without it, a build-time exception on one bad data point (e.g. a post
  missing `rawData.code`) aborts the whole binding pass, so words earlier
  in iteration order work and everything after has no listener at all,
  with no visible error.

- **The shared-term merge in `computeSelection`** (only when
  `state.brand==='All'`) is what turns a word used by 2+ brands into a
  single gray chip instead of two same-colored-as-nothing duplicates.

## Payload escaping — check this first if a widget renders flat

**Never HTML-escape the `widget_code` payload passed to
`visualize:show_widget`.** A confirmed failure mode: passing literal
`<`/`>`/`&` as `&lt;`/`&gt;`/`&amp;` entities anywhere in the string —
whether from copy-pasting through an intermediate escaping step, a
templating helper that HTML-encodes by default, or manually "playing it
safe" — makes tags and JS syntax render as inert text, or breaks JS
parsing (comparison operators like `<`/`>` inside `<script>` are
especially easy to mis-escape this way). Brand coloring, button rows, and
hover popovers can silently fail to apply even though the underlying
`DATA` is correct.

`widget_code` must contain raw literal angle brackets and ampersands
exactly as they appear in real HTML/JS — `<div>`, `<script>`, `a > b`,
`x && y` — never entity-encoded. Before calling the tool, sanity-check
that the payload starts with an actual `<` byte, not the four characters
`&lt;`.

If a rendered widget shows flat/uncolored text, missing button rows, or no
hover popovers where the `DATA`/logic is otherwise correct, treat "was the
code accidentally entity-escaped before this call" as the first thing to
check — before suspecting the data itself or re-deriving anything.
